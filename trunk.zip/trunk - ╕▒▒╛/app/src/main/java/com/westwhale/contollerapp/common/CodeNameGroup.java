package com.westwhale.contollerapp.common;

import java.util.List;

public class CodeNameGroup {
    public String mType;
    public String mTypeName;
    public List<CodeNameItem> mItemList;
}
