package com.westwhale.contollerapp.ui.main.adapter;

import android.view.View;

import com.chad.library.adapter.base.BaseMultiItemQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.chad.library.adapter.base.entity.AbstractExpandableItem;
import com.chad.library.adapter.base.entity.MultiItemEntity;
import com.westwhale.contollerapp.R;
import com.westwhale.api.protocolapi.bean.hostroom.Host;
import com.westwhale.api.protocolapi.bean.hostroom.Room;

import java.util.List;

public class SearchDevExpandItemAdapter extends BaseMultiItemQuickAdapter<MultiItemEntity, BaseViewHolder> {
    private final static int ITEM_TYPE_HOST = 0;
    private final static int ITEM_TYPE_ROOM = 1;
    private final static int ITEM_TYPE_DEFAULT = -1;

    private CallBack mCallBack;
//    private List<MultiItemEntity> mItemList = new ArrayList<>();

    public interface CallBack{
        void onHostItemClick(Host host);
        void onRoomItemClick(Room room);
        void onRoomStatClick(Room room);
    }

    public void setCallBack(CallBack callBack){
        mCallBack = callBack;
    }

    public void addHostItem(Host host){
        if (host != null){
            HostItem hostItem = new HostItem(host);
            if (host.rooms != null){
                for (int i=0; i < host.rooms.size(); i++){
                    hostItem.addSubItem(new RoomItem(host.rooms.get(i)));
                }
            }

            // 每次添加一项，都是追尾添加，所以添加项都为最后一项
            addData(hostItem);
            expand(mData.size()-1);
        }
    }

    public void updateHostItem(Host host){
        if (null == host){
            return;
        }
        int index = -1;
        for (int i=0; i < mData.size(); i++){
            MultiItemEntity item = mData.get(i);
            if (item.getItemType() == ITEM_TYPE_HOST){
                Host tempHost = ((HostItem)item).mHost;
                if ( (tempHost != null) && (tempHost.id.equals(host.id)) && (tempHost.deviceType.equals(host.deviceType)) ){
                    index = i;
                    break;
                }
            }
        }
        if (index != -1){
            notifyItemChanged(index);
        }
    }

    public void updateRoomItem(Room room){
        if (null == room){
            return;
        }
        int index = -1;
        for (int i=0; i < mData.size(); i++){
            MultiItemEntity item = mData.get(i);
            if (item.getItemType() == ITEM_TYPE_ROOM){
                Room tempRoom = ((RoomItem)item).mRoom;
                if ( (tempRoom != null) && (tempRoom.roomId.equals(room.roomId)) && (tempRoom.hostId.equals(room.hostId)) ){
                    index = i;
                    break;
                }
            }
        }
        if (index != -1){
            notifyItemChanged(index);
        }
    }

    public void removeALl(){
        if (mData != null) {
            mData.clear();
        }
        notifyDataSetChanged();
    }


    public SearchDevExpandItemAdapter(List<MultiItemEntity> list){
        super(list);

        addItemType(ITEM_TYPE_HOST,R.layout.item_search_host);
        addItemType(ITEM_TYPE_ROOM,R.layout.item_search_room);
    }


    @Override
    protected void convert(BaseViewHolder helper, MultiItemEntity item) {
        switch (helper.getItemViewType()) {
            case ITEM_TYPE_HOST:
                final HostItem hostItem = (HostItem) item;

                if (hostItem.mHost != null) {
                    helper.setText(R.id.item_search_host_name, hostItem.mHost.name);
                    helper.setText(R.id.item_search_host_type, hostItem.mHost.deviceType);
                }

                helper.itemView.findViewById(R.id.item_search_more_menu).setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (mCallBack != null){
                            mCallBack.onHostItemClick(hostItem.mHost);
                        }
                    }
                });

                helper.itemView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        // 若点击更多，则弹出更多框; 否则展开或收起
                        int pos = helper.getAdapterPosition();
                        if (hostItem.isExpanded()) {
                            collapse(pos);
                        } else {
                            expand(pos);
                        }
                    }
                });
                break;
            case ITEM_TYPE_ROOM:
                final RoomItem roomItem = (RoomItem) item;
                if (roomItem.mRoom != null){
                    int imageResourceId = R.drawable.btn_lock;
                    if ((Room.DevState.OPEN).equals(roomItem.mRoom.devStat)) {
                        imageResourceId = R.drawable.btn_unlock;
                    }

                    helper.setText(R.id.item_search_room_name,roomItem.mRoom.roomName);
                    helper.setImageResource(R.id.item_search_room_state,imageResourceId);

                    helper.itemView.findViewById(R.id.item_search_room_stat_layout).setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            if (mCallBack != null){
                                mCallBack.onRoomStatClick(roomItem.mRoom);
                            }
                        }
                    });

                    helper.itemView.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            if (mCallBack != null){
                                mCallBack.onRoomItemClick(roomItem.mRoom);
                            }
                        }
                    });

                }

                break;
        }
    }


    class RoomItem implements MultiItemEntity{
        private Room mRoom;
        RoomItem(Room room){
            mRoom = room;
        }

        @Override
        public int getItemType() {
            return ITEM_TYPE_ROOM;
        }
    }

    class HostItem extends AbstractExpandableItem<RoomItem> implements MultiItemEntity{
        private Host mHost;

        HostItem(Host host){
            mHost = host;
        }

        @Override
        public int getLevel() {
            return 0;
        }

        @Override
        public int getItemType() {
            return ITEM_TYPE_HOST;
        }
    }


}
