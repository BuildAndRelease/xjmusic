package com.westwhale.contollerapp.ui.localmusic.fragment;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.AppBarLayout;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.kingja.loadsir.callback.Callback;
import com.kingja.loadsir.callback.SuccessCallback;
import com.kingja.loadsir.core.LoadService;
import com.kingja.loadsir.core.LoadSir;
import com.scwang.smartrefresh.layout.api.RefreshLayout;
import com.scwang.smartrefresh.layout.listener.OnLoadMoreListener;
import com.scwang.smartrefresh.layout.listener.OnRefreshListener;
import com.westwhale.contollerapp.R;
import com.westwhale.contollerapp.application.WApp;
import com.westwhale.contollerapp.common.AppBarStateChangeListener;
import com.westwhale.contollerapp.dev.CmdActionLister;
import com.westwhale.contollerapp.dev.ICmdCallback;
import com.westwhale.contollerapp.dev.WRoom;
import com.westwhale.contollerapp.ui.main.MainRoomActivity;
import com.westwhale.contollerapp.ui.localmusic.adapter.LocalMediaListAdapter;
import com.westwhale.contollerapp.ui.localmusic.dialog.LocalMusicMoreDialog;
import com.westwhale.contollerapp.ui.base.fragment.BaseFragment;
import com.westwhale.contollerapp.ui.loadsircallback.EmptyCallback;
import com.westwhale.contollerapp.ui.loadsircallback.ErrorCallback;
import com.westwhale.contollerapp.ui.loadsircallback.LoadingCallback;
import com.westwhale.contollerapp.ui.loadsircallback.TimeoutCallback;
import com.westwhale.api.protocolapi.bean.LocalDirectory;
import com.westwhale.api.protocolapi.bean.media.LocalMusic;
import com.westwhale.api.protocolapi.net.Response;

/**
 * Description:
 * Author: chenyaoli
 * Date: 2018-11-16
 * History:
 */
public class LocalMusicFragment extends BaseFragment implements LocalMediaListAdapter.CallBack{
    private final static String TAG = LocalMusicFragment.class.getName();

    private ActionBar mActionBar;
    private Toolbar mToolBar;
    private ImageView mAlbumPicIv,mHeaderBgIv, mPlayIv, mAddFavoriteIv, mEditIv;
    private TextView mSubTittleTv, mTitleTv;
    private FrameLayout mLoadingFLayout;
    private RecyclerView mRecyclerView;
    private RefreshLayout mRefreshLayout;
    private AppBarLayout mAppBarLayout;
    protected LoadService mLoadService;

    private LocalMediaListAdapter mMediaListAdapter;

    private String mParentDirectoryName;
    private String mDirectoryName;
    private String mDirectoryMid;

    public void updateDirectoryInfo(String parentName,String directoryName,String directoryMid){
        mParentDirectoryName = parentName;
        mDirectoryName = directoryName;
        mDirectoryMid = directoryMid;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        // 先显示加载动画，针对布局做一些初始化
        return inflater.inflate(R.layout.frag_local_localmusic, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        initView(view);
        initListener();

        LoadSir loadSir = new LoadSir.Builder()
                .addCallback(new LoadingCallback())
                .addCallback(new TimeoutCallback())
                .addCallback(new ErrorCallback())
                .addCallback(new EmptyCallback())
                .setDefaultCallback(LoadingCallback.class)
                .build();

        mLoadingFLayout = view.findViewById(R.id.local_localmusic_musiclist_loadsir_layout);
//         创建mLoadService
        mLoadService = loadSir.register(mLoadingFLayout, new Callback.OnReloadListener() {
            @Override
            public void onReload(View v) {
                initData();
            }
        });

        initData();
    }

    @Override
    public void onResume() {
        super.onResume();
    }

    public void showLoadCallBack(Class<? extends Callback> callback){
        if (mLoadService != null){
            mLoadService.showCallback(callback);
            if (callback == SuccessCallback.class){
                if(mLoadingFLayout != null) {
                    mLoadingFLayout.setVisibility(View.INVISIBLE);
                }
                if (mRecyclerView != null){
                    mRecyclerView.setVisibility(View.VISIBLE);
                }

                if (mRefreshLayout != null){
                    mRefreshLayout.setEnableLoadMore(true);
                    mRefreshLayout.setEnableNestedScroll(true);
                }
            }else{
                if(mLoadingFLayout != null) {
                    mLoadingFLayout.setVisibility(View.VISIBLE);
                }
                if (mRecyclerView != null){
                    mRecyclerView.setVisibility(View.INVISIBLE);
                }

                if (mRefreshLayout != null){
                    mRefreshLayout.setEnableLoadMore(false);
                    mRefreshLayout.setEnableNestedScroll(false);
                }
            }
        }
    }

    private void initData() {
        mToolBar.setTitle(mParentDirectoryName);
        mTitleTv.setText(mDirectoryName);

        mBeginIndex = 0;
        mHasMoreData = true;

        if (mMediaListAdapter != null){
            mMediaListAdapter.clearDataList();
        }

        requestDataResource();
    }

    private void initView(View view) {
        mToolBar = view.findViewById(R.id.local_localmusic_toolbar);
        if (getActivity() != null) {
            ((AppCompatActivity) getActivity()).setSupportActionBar(mToolBar);
            mActionBar = ((AppCompatActivity) getActivity()).getSupportActionBar();
            if (mActionBar != null) {
                mActionBar.setDisplayHomeAsUpEnabled(true);
                mActionBar.setHomeAsUpIndicator(R.drawable.home_backup);
            }
        }

        mAlbumPicIv = view.findViewById(R.id.local_localmusic_header_pic);
        mAlbumPicIv.setImageResource(R.drawable.local_playlist_header_default);

        mHeaderBgIv = view.findViewById(R.id.local_localmusic_header_bg);
        mHeaderBgIv.setImageResource(R.drawable.local_playlist_header_mongo);

        mTitleTv = view.findViewById(R.id.local_localmusic_header_title);
        mSubTittleTv = view.findViewById(R.id.local_localmusic_header_subtitle);

        mPlayIv = view.findViewById(R.id.local_localmusic_header_play);
        mAddFavoriteIv = view.findViewById(R.id.local_localmusic_header_favorite);
        mAddFavoriteIv.setColorFilter(R.color.colorGrey);
        mEditIv = view.findViewById(R.id.local_localmusic_header_edit);
        mEditIv.setColorFilter(R.color.colorGrey);

        mLoadingFLayout = view.findViewById(R.id.local_localmusic_musiclist_loadsir_layout);

        mRecyclerView = view.findViewById(R.id.local_localmusic_musiclist_recyclerview);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(mContext);
        mRecyclerView.setLayoutManager(linearLayoutManager);
        mMediaListAdapter = new LocalMediaListAdapter(this);
        mRecyclerView.setAdapter(mMediaListAdapter);
        mRecyclerView.setHasFixedSize(true);
        mRecyclerView.addItemDecoration(new DividerItemDecoration(mContext, DividerItemDecoration.VERTICAL));

        mRefreshLayout = view.findViewById(R.id.local_localmusic_refreshlayout);
        mRefreshLayout.setEnableRefresh(false);
//        mRefreshLayout.setDisableContentWhenRefresh(true);
        mRefreshLayout.setEnableLoadMore(true);

        mAppBarLayout = view.findViewById(R.id.local_localmusic_app_bar);
    }

    private void initListener() {
        mToolBar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (getActivity() != null){
                    getActivity().onBackPressed();
                }
            }
        });

        mPlayIv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 播放当前列表
                LocalMusic musicItem = null;
                if ((mMediaListAdapter != null) && (mMediaListAdapter.getDataList() != null)){
                    for (int i=0; i < mMediaListAdapter.getDataList().size(); i++){
                        if (mMediaListAdapter.getDataList().get(i) instanceof LocalMusic){
                            musicItem = (LocalMusic)mMediaListAdapter.getDataList().get(i);
                            break;
                        }
                    }
                }
                if (musicItem != null){
                    WRoom room = WApp.Instance.getDevManager().getSelectedRoom();
                    if (room != null){
                        WRoom.cmdPlayMedia(musicItem,new CmdActionLister<Boolean>(LocalMusicFragment.this, new ICmdCallback<Boolean>() {
                            @Override
                            public void onSuccess(Boolean data) {

                            }

                            @Override
                            public void onFailed(int code, String msg) {
                                Toast.makeText(getContext(),"PlayLocalMusic获取失败:"+code,Toast.LENGTH_SHORT).show();
                            }
                        }));
                    }
                }else{
                    Toast.makeText(getContext(),"获取失败:无歌曲",Toast.LENGTH_SHORT).show();
                }
            }
        });

        mAddFavoriteIv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // TODO: 2018-12-15  弹出添加到收藏界面
            }
        });

        mEditIv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // TODO: 2018-12-15 多选编辑界面
            }
        });

        mRefreshLayout.setOnRefreshListener(new OnRefreshListener() {
            @Override
            public void onRefresh(@NonNull RefreshLayout refreshLayout) {
                initData();
            }
        });

        mRefreshLayout.setOnLoadMoreListener(new OnLoadMoreListener() {
            @Override
            public void onLoadMore(@NonNull RefreshLayout refreshLayout) {
                //  判断是否还有数据，从而判断是否还需要加载更多数据
                if( hasMoreData() ){
                    loadMoreData();
                }else {
                    mRefreshLayout.finishLoadMoreWithNoMoreData();
                }
            }
        });

        // 监听 AppBarLayout 的偏移状态，设置Toolbar的背景色
        mAppBarLayout .addOnOffsetChangedListener(new AppBarStateChangeListener() {
            @Override
            public void onStateChanged(AppBarLayout appBarLayout, State state) {
                if( state == State.EXPANDED ) {
                    //展开状态
                    mToolBar.setTitle(mParentDirectoryName);
                }else if(state == State.COLLAPSED){
                    //折叠状态
                    mToolBar.setTitle(mDirectoryName);
                }else {
                    //中间状态

                }
            }
        });
    }

    /*************************************    *****************************/
    @Override
    public void onDirectoryClick(LocalDirectory.Directory item) {
        LocalMusicFragment fragment = new LocalMusicFragment();
        String parentName = mDirectoryName;
        String directoryName = (item != null) ? item.directoryName : "未知";
        String directoryMid = (item != null) ? item.directoryMid : "未知";
        fragment.updateDirectoryInfo(parentName,directoryName,directoryMid);
        if (getActivity() instanceof MainRoomActivity) {
            ((MainRoomActivity) getActivity()).showFragment(fragment);
        }
    }

    @Override
    public void onDirecotryMoreClick(LocalDirectory.Directory item) {

    }


    @Override
    public void onSongItemClick(LocalMusic songItem) {
        if (songItem != null){
            WRoom room = WApp.Instance.getDevManager().getSelectedRoom();
            if (room != null){
                WRoom.cmdPlayMedia(songItem,new CmdActionLister<Boolean>(LocalMusicFragment.this, new ICmdCallback<Boolean>() {
                    @Override
                    public void onSuccess(Boolean data) {

                    }

                    @Override
                    public void onFailed(int code, String msg) {
                        Toast.makeText(getContext(),"PlayLocalMusic获取失败:"+code,Toast.LENGTH_SHORT).show();
                    }
                }));
            }
        }
    }

    @Override
    public void onSongItemMoreClick(LocalMusic songItem) {
        LocalMusicMoreDialog moreDialog = new LocalMusicMoreDialog();
        Bundle bundle = new Bundle();
        bundle.putString("music",songItem.toString());
        moreDialog.setArguments(bundle);
        moreDialog.show(getChildFragmentManager(),"LocalMusic_More");
    }






    private int mBeginIndex = 0;
    private int mNum = 50;
    private boolean mHasMoreData = true; // 记录是否还有更多数据

    private boolean hasMoreData() {
        return mHasMoreData;
    }

    private void loadMoreData() {
        requestDataResource();
    }

    private void updateDataList(LocalDirectory directory) {
        if (directory != null) {
            // 若无法获取到数据，则认为已经到底
            int mediaListsize = (directory.mediaList != null) ? directory.mediaList.size(): 0;
            int diretoryListsize = (directory.directoryList != null) ? directory.directoryList.size() : 0;

            // 若刚开始加载数据，则先清空数据
            if (mBeginIndex == 0){
                mMediaListAdapter.clearDataList();
            }

            mBeginIndex = mBeginIndex + mediaListsize + diretoryListsize;
            if ((mediaListsize == 0) && (diretoryListsize == 0)){
                mHasMoreData = false;
            }else{
                mMediaListAdapter.addToDataList(directory);
            }

            // 更新刷新等待状态
            mRefreshLayout.finishLoadMore();

            showLoadCallBack(SuccessCallback.class);
        }else{
            // 当获取数据失败时，则认为无数据了
            mHasMoreData = false;

            mRefreshLayout.finishLoadMore();
            showLoadCallBack(EmptyCallback.class);
        }
    }

    private void requestDataResource() {
        WRoom room = WApp.Instance.getDevManager().getSelectedRoom();
        if (room != null){
            String directoryMid = (mDirectoryMid != null) ? mDirectoryMid : "";
            int beginIndex = mBeginIndex;
            int num = mNum;
            boolean ignoreEmpty = false;
            WRoom.cmdGetLocalDirectory(directoryMid, beginIndex,num,ignoreEmpty, new CmdActionLister<Response<LocalDirectory>>(this, new ICmdCallback<Response<LocalDirectory>>() {
                @Override
                public void onSuccess(Response<LocalDirectory> data) {
                    updateDataList(data.bean);
                }

                @Override
                public void onFailed(int code, String msg) {
                    updateDataList(null);
                    Toast.makeText(getContext(),"GetLocalDirectory获取失败:"+code,Toast.LENGTH_SHORT).show();
                }
            }));
        }else{
            updateDataList(null);
        }
    }
}
