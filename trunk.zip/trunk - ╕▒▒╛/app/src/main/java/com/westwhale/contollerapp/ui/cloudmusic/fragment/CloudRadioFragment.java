package com.westwhale.contollerapp.ui.cloudmusic.fragment;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.Toast;

import com.kingja.loadsir.callback.Callback;
import com.kingja.loadsir.callback.SuccessCallback;
import com.westwhale.contollerapp.R;
import com.westwhale.contollerapp.ui.cloudmusic.adapter.CloudRadioAdapter;
import com.westwhale.contollerapp.ui.cloudmusic.adapter.CloudRadioNavAdapter;
import com.westwhale.contollerapp.application.WApp;
import com.westwhale.contollerapp.dev.CmdActionLister;
import com.westwhale.contollerapp.dev.ICmdCallback;
import com.westwhale.contollerapp.dev.WRoom;
import com.westwhale.contollerapp.ui.base.fragment.TitleBaseFragment;
import com.westwhale.contollerapp.ui.loadsircallback.EmptyCallback;
import com.westwhale.contollerapp.ui.loadsircallback.LoadingCallback;
import com.westwhale.api.protocolapi.bean.albumSet.CloudRadioSet;
import com.westwhale.api.protocolapi.bean.cloudmusic.CloudRadioGroup;

import java.util.ArrayList;
import java.util.List;

/**
 * Description:
 * Author: chenyaoli
 * Date: 2018-11-12
 * History:
 */
public class CloudRadioFragment extends TitleBaseFragment implements CloudRadioAdapter.CallBack, CloudRadioNavAdapter.CallBack{
    private static final String TAG = "CloudRadio";
    private FrameLayout mFrameLayout;
    private RecyclerView mDataRv;
    private RecyclerView mRadioNavRv;
    private Toolbar mToolBar;
    private CloudRadioAdapter mCloudRadioAdatper;
    private CloudRadioNavAdapter mCloudRadioNavAdapter;

    ArrayList<CloudRadioGroup> mRadioGroupList = new ArrayList<>();

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        // 先显示加载动画，针对布局做一些初始化
        return inflater.inflate(R.layout.frag_netmusic_radio,container,false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        mFrameLayout = view.findViewById(R.id.netmusic_radio_frame);

        // 创建mLoadService
        mLoadService = mLoadSir.register(mFrameLayout, new Callback.OnReloadListener() {
            @Override
            public void onReload(View v) {
                showLoadCallBack(LoadingCallback.class);

                initData();
            }
        });

        initView(view);

        initListener();

        initData();
    }

    @Override
    public void onResume() {
        super.onResume();
    }

    private void initView(View view) {
        mToolBar = view.findViewById(R.id.netmusic_radio_toolbar);
        configToolBar(mToolBar,getString(R.string.cloudmusic_radio_title));

        mDataRv = view.findViewById(R.id.netmusic_radio_center_recyclerview);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(mContext);
        mDataRv.setLayoutManager(linearLayoutManager);
        mCloudRadioAdatper = new CloudRadioAdapter(this);
        mDataRv.setAdapter(mCloudRadioAdatper);
        mDataRv.setHasFixedSize(true);
        // 设置下拉上拉无阴影效果
        mDataRv.setOverScrollMode(View.OVER_SCROLL_NEVER);

        mRadioNavRv = view.findViewById(R.id.netmusic_radio_left_recyclerView);
        LinearLayoutManager linearLayoutManager1 = new LinearLayoutManager(mContext);
        mRadioNavRv.setLayoutManager(linearLayoutManager1);
        mCloudRadioNavAdapter = new CloudRadioNavAdapter(this);
        mRadioNavRv.setAdapter(mCloudRadioNavAdapter);
        mRadioNavRv.setHasFixedSize(true);
        // 设置下拉上拉无阴影效果
        mRadioNavRv.setOverScrollMode(View.OVER_SCROLL_NEVER);
    }

    private void initListener() {
        mDataRv.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(@NonNull RecyclerView recyclerView, int newState) {
                super.onScrollStateChanged(recyclerView, newState);
            }

            @Override
            public void onScrolled(@NonNull RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);
                LinearLayoutManager linearLayoutManager = (LinearLayoutManager)recyclerView.getLayoutManager();
                if (linearLayoutManager != null){
                    int nowPos = linearLayoutManager.findFirstVisibleItemPosition();
                    int pos = linearLayoutManager.findFirstCompletelyVisibleItemPosition();
                    if (!recyclerView.canScrollVertically(1)){
                        nowPos = mCloudRadioAdatper.getItemCount()-1;
                    }
                    mCloudRadioNavAdapter.setCurrentPos(nowPos);
                }
            }
        });
    }

    private void initData() {
        // 获取数据时显示加载界面
        requestCloudResource();
    }

    public void updateDataList(List<CloudRadioGroup> list){
        if (list != null) {

            mCloudRadioAdatper.upateDataList(list);
            mCloudRadioAdatper.notifyDataSetChanged();

            mCloudRadioNavAdapter.upateDataList(list);
            mCloudRadioNavAdapter.setCurrentPos(0);
            mCloudRadioNavAdapter.notifyDataSetChanged();

            showLoadCallBack(SuccessCallback.class);
        }else {
            showLoadCallBack(EmptyCallback.class);
        }
    }

    @Override
    public void onRadioItemClick(CloudRadioSet radioItem) {
        // 点击某电台播放
        WRoom room = WApp.Instance.getDevManager().getSelectedRoom();
        if (room != null){
            WRoom.cmdPlayCloudRadio(radioItem.radioId,new CmdActionLister<Boolean>(CloudRadioFragment.this, new ICmdCallback<Boolean>() {
                @Override
                public void onSuccess(Boolean data) {

                }

                @Override
                public void onFailed(int code, String msg) {
                    Toast.makeText(getContext(), "播放电台失败...", Toast.LENGTH_SHORT).show();
                }
            }));
        }
    }

    @Override
    public void onRadioNavItemClick(int pos, CloudRadioGroup raidoGroupItem) {
        /* 采用 scrollToPositionWithOffset 可以保证 指定位置 置顶
           采用 scrollToPosition 只能保证 指定位置可见，就不再滚动，会出发 onScrolled 内部逻辑
         */
//        mDataRv.scrollToPosition(pos);
        LinearLayoutManager linearLayoutManager = (LinearLayoutManager)mDataRv.getLayoutManager();
        if (linearLayoutManager != null){
            linearLayoutManager.scrollToPositionWithOffset(pos, 0);
        }
    }


    public void requestCloudResource() {
        WRoom room = WApp.Instance.getDevManager().getSelectedRoom();
        if (room != null){
            WRoom.cmdGetRadio(new CmdActionLister<List<CloudRadioGroup>>(this, new ICmdCallback<List<CloudRadioGroup>>() {
                @Override
                public void onSuccess(List<CloudRadioGroup> data) {
                    updateDataList(data);
                }

                @Override
                public void onFailed(int code, String msg) {
                    updateDataList(null);
                    Toast.makeText(getContext(),"GetRadio获取失败:"+code,Toast.LENGTH_SHORT).show();
                }
            }));
        }else{
            updateDataList(null);
        }
    }
}
