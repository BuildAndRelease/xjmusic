package com.westwhale.contollerapp.ui.base.fragment;

import android.support.annotation.NonNull;

import com.westwhale.contollerapp.application.WApp;
import com.westwhale.contollerapp.dev.CmdActionLister;
import com.westwhale.contollerapp.dev.ICmdCallback;
import com.westwhale.contollerapp.dev.WRoom;
import com.westwhale.api.protocolapi.bean.media.Media;

public abstract  class PlayerBaseFragment extends BaseFragment {
    protected int mPlayTime = 0;
    protected int mDuration = 0;
    protected String mPlayStat;
    protected String mPlayMode;
    protected Media mMedia;
    protected String mRoomStat = ""; // 房间当前状态

    @Override
    public void onResume() {
        super.onResume();
    }

    @Override
    public void onPause() {
        super.onPause();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }

    public void setRoomStat(@NonNull String roomStat){
        // 该函数只在对象创建时调用
        mRoomStat = roomStat;
    }

    @NonNull
    public String getRoomStat(){
        return mRoomStat;
    }

    public abstract boolean isPlayerValid();

    @NonNull
    public abstract String getMediaSrc();

    public abstract void updateMediaInfo();
    public void updateMedia(Media media){
        if (isPlayerValid()) {
            mMedia = media;
            if (isVisible()) {
                updateMediaInfo();
            }
        }
    }

    public abstract void updateMediaDurationInfo();
    public void updatePlayingMediaDuration(int duration){
        if (isPlayerValid()) {
            mDuration = duration;
            if (isVisible()) {
                updateMediaDurationInfo();
            }
        }
    }

    public abstract void updatePlayStatInfo();
    public void updatePlayStat(String playStat){
        if (isPlayerValid()) {
            mPlayStat = playStat;
            if (isVisible()) {
                updatePlayStatInfo();
            }
        }
    }
    public void getPlayStat(){
        if (isPlayerValid()) {
            WRoom currentRoom = WApp.Instance.getDevManager().getSelectedRoom();
            if (currentRoom != null) {
                currentRoom.cmdGetPlayStat(new CmdActionLister<String>(PlayerBaseFragment.this, new ICmdCallback<String>() {
                    @Override
                    public void onSuccess(String data) {
                        updatePlayStat(data);
                    }

                    @Override
                    public void onFailed(int code, String msg) {
                        String stat = currentRoom.getPlayStat();
                        updatePlayStat(stat);
                    }
                }));
            }
        }
    }

    public abstract void updatePlayTimeInfo();
    public void updatePlayTime(int playtime){
        if (isPlayerValid()) {
            mPlayTime = playtime;
            if (isVisible()) {
                updatePlayTimeInfo();
            }
        }
    }
    public void getPlayTime(){
        if (isPlayerValid()) {
            WRoom currentRoom = WApp.Instance.getDevManager().getSelectedRoom();
            if (currentRoom != null) {
                currentRoom.cmdGetPlayTime(new CmdActionLister<Integer>(PlayerBaseFragment.this, new ICmdCallback<Integer>() {
                    @Override
                    public void onSuccess(Integer data) {
                        updatePlayTime(data);
                    }

                    @Override
                    public void onFailed(int code, String msg) {

                    }
                }));
            }
        }
    }

    public void setPlayTime(int playtime,CmdActionLister<Boolean> actionLister){
        if (isPlayerValid()) {
            WRoom currentRoom = WApp.Instance.getDevManager().getSelectedRoom();
            if (currentRoom != null) {
                currentRoom.cmdSetPlayTime(playtime, actionLister);
            }
        }
    }

    public abstract void updatePlayModeInfo();
    public void updatePlayMode(String playMode){
        if (isPlayerValid()) {
            mPlayMode = playMode;
            if (isVisible()) {
                updatePlayModeInfo();
            }
        }
    }
    public void setPlayMode(String playMode,CmdActionLister<Boolean> actionLister){
        if (isPlayerValid()) {
            WRoom currentRoom = WApp.Instance.getDevManager().getSelectedRoom();
            if (currentRoom != null) {
                currentRoom.cmdSetPlayMode(playMode, actionLister);
            }
        }
    }

    public void playNext(){
        if (isPlayerValid()) {
            WRoom currentRoom = WApp.Instance.getDevManager().getSelectedRoom();
            if (currentRoom != null) {
                currentRoom.cmdPlayNext();
            }
        }
    }

    public void playPre(){
        if (isPlayerValid()) {
            WRoom currentRoom = WApp.Instance.getDevManager().getSelectedRoom();
            if (currentRoom != null) {
                currentRoom.cmdPlayPrevious();
            }
        }
    }

    public void playPause(){
        if (isPlayerValid()) {
            WRoom currentRoom = WApp.Instance.getDevManager().getSelectedRoom();
            if (currentRoom != null) {
                currentRoom.cmdPlayPause();
            }
        }
    }

    public void playResume(){
        if (isPlayerValid()) {
            WRoom currentRoom = WApp.Instance.getDevManager().getSelectedRoom();
            if (currentRoom != null) {
                currentRoom.cmdPlayResume();
            }
        }
    }
}
