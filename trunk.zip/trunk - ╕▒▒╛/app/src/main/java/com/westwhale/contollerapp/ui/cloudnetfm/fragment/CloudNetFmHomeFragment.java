package com.westwhale.contollerapp.ui.cloudnetfm.fragment;

import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.kingja.loadsir.callback.Callback;
import com.kingja.loadsir.callback.SuccessCallback;
import com.kingja.loadsir.core.LoadService;
import com.kingja.loadsir.core.LoadSir;
import com.westwhale.contollerapp.R;
import com.westwhale.contollerapp.ui.base.fragment.LazyBaseFragment;
import com.westwhale.contollerapp.ui.cloudnetfm.adapter.CloudNetFmAdatper;
import com.westwhale.contollerapp.ui.cloudnetfm.adapter.CloudNetFmCategoryAdapter;
import com.westwhale.contollerapp.ui.main.MainRoomActivity;
import com.westwhale.contollerapp.application.WApp;
import com.westwhale.contollerapp.dev.CmdActionLister;
import com.westwhale.contollerapp.dev.ICmdCallback;
import com.westwhale.contollerapp.dev.WRoom;
import com.westwhale.contollerapp.ui.loadsircallback.EmptyCallback;
import com.westwhale.contollerapp.ui.loadsircallback.ErrorCallback;
import com.westwhale.contollerapp.ui.loadsircallback.LoadingCallback;
import com.westwhale.contollerapp.ui.loadsircallback.TimeoutCallback;
import com.westwhale.api.protocolapi.bean.cloudnetfm.Category;
import com.westwhale.api.protocolapi.bean.media.CloudNetFm;
import com.westwhale.api.protocolapi.bean.cloudnetfm.GetNetFmCategoryResult;
import com.westwhale.api.protocolapi.bean.cloudnetfm.Province;

import java.util.List;

/**
 * Description:
 * Author: chenyaoli
 * Date: 2019-04-06
 * History:
 */
public class CloudNetFmHomeFragment extends LazyBaseFragment implements CloudNetFmAdatper.CallBack, CloudNetFmCategoryAdapter.CallBack {
    private static final String TAG = CloudNetFmHomeFragment.class.getName();

    private ImageView mLocalIv, mNationIv, mProvinceIv, mNetworkIv;
    private TextView mSearchTv;
    private RelativeLayout mRankRv;
    private RecyclerView mRankDataRv,mCategoryDataRv;
    private CloudNetFmAdatper mItemAdapter;
    private CloudNetFmCategoryAdapter mCategoryAdapter;

    private LoadSir mLoadSir;
    private LoadService mRankLoadService;

    private List<Category> mCategoryList;
    private List<CloudNetFm> mCloudNetFmList;
    private List<Province> mProvinceList;
    private String mLocalCity = "";


    @Override
    public int getLayoutId() {
        return R.layout.frag_cloudnetfm_home;
    }

    @Override
    public void initView(View view) {
        try {
            // 界面的加载等待框架配置
            mLoadSir = new LoadSir.Builder()
                    .addCallback(new LoadingCallback())
                    .addCallback(new TimeoutCallback())
                    .addCallback(new ErrorCallback())
                    .addCallback(new EmptyCallback())
                    .setDefaultCallback(LoadingCallback.class)
                    .build();

            mSearchTv = view.findViewById(R.id.cloudnetfm_home_search);

            mLocalIv = view.findViewById(R.id.cloudnetfm_home_local);
            mNationIv = view.findViewById(R.id.cloudnetfm_home_nation);
            mProvinceIv = view.findViewById(R.id.cloudnetfm_home_province);
            mNetworkIv = view.findViewById(R.id.cloudnetfm_home_network);

            mCategoryDataRv = view.findViewById(R.id.cloudnetfm_home_category_recycleview);
            GridLayoutManager gridLayoutManager = new GridLayoutManager(mContext, 4);
            mCategoryDataRv.setLayoutManager(gridLayoutManager);
            mCategoryAdapter = new CloudNetFmCategoryAdapter(this);
            mCategoryDataRv.setAdapter(mCategoryAdapter);
            mCategoryDataRv.setHasFixedSize(true);


            mRankRv = view.findViewById(R.id.cloudnetfm_home_rank_layout);

            mRankDataRv = view.findViewById(R.id.cloudnetfm_home_recyclerview);
            LinearLayoutManager linearLayoutManager = new LinearLayoutManager(mContext);
            mRankDataRv.setLayoutManager(linearLayoutManager);
            mItemAdapter = new CloudNetFmAdatper(this);
            mRankDataRv.setAdapter(mItemAdapter);
            mRankDataRv.setHasFixedSize(true);

            mRankLoadService = mLoadSir.register(mRankDataRv, new Callback.OnReloadListener() {
                @Override
                public void onReload(View v) {
                    showLoadCallBack(mRankLoadService,LoadingCallback.class);
                    requestCloudResource();
                }
            });

        }catch (Exception e){
            e.printStackTrace();
        }
    }

    @Override
    public void initListener() {
        mSearchTv.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                // TODO: 跳转到搜索界面
            }
        });

        mLocalIv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 本地台
                CloudNetFmLocalAlbumFragment fragment = new CloudNetFmLocalAlbumFragment();
                if (getActivity() instanceof MainRoomActivity) {
                    ((MainRoomActivity) getActivity()).showFragment(fragment);
                }
            }
        });

        mNationIv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 国家台
                CloudNetFmNationAlbumFragment fragment = new CloudNetFmNationAlbumFragment();
                if (getActivity() instanceof MainRoomActivity) {
                    ((MainRoomActivity) getActivity()).showFragment(fragment);
                }
            }
        });

        mProvinceIv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 省市台
                CloudNetFmProvinceAlbumFragment fragment = new CloudNetFmProvinceAlbumFragment();
                fragment.updateProvinceList(mProvinceList);
                if (getActivity() instanceof MainRoomActivity) {
                    ((MainRoomActivity) getActivity()).showFragment(fragment);
                }
            }
        });

        mNetworkIv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 网络台
                CloudNetFmNetworkAlbumFragment fragment = new CloudNetFmNetworkAlbumFragment();
                if (getActivity() instanceof MainRoomActivity) {
                    ((MainRoomActivity) getActivity()).showFragment(fragment);
                }
            }
        });

        mRankRv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 排行榜
                CloudNetFmRankAlbumFragment fragment = new CloudNetFmRankAlbumFragment();
                if (getActivity() instanceof MainRoomActivity) {
                    ((MainRoomActivity) getActivity()).showFragment(fragment);
                }
            }
        });
    }

    @Override
    public void initData() {
        requestNetFmProvinceResource();

        requestNetFmCategoryResource();

        requestCloudResource();
    }

    @Override
    public void onLazyLoad() {
        initData();
    }

    @Override
    public void onRetryLoad() {
        super.onRetryLoad();
        if (mProvinceList == null){
            requestNetFmProvinceResource();
        }

        if (mCategoryList == null){
            requestNetFmCategoryResource();
        }

        if (mCloudNetFmList == null){
            requestCloudResource();
        }
    }


    @Override
    public void onItemClick(CloudNetFm item) {
        // 播放网络电台
        WRoom room = WApp.Instance.getDevManager().getSelectedRoom();
        if (room != null){
            WRoom.cmdPlayMedia(item,new CmdActionLister<Boolean>(this, new ICmdCallback<Boolean>() {
                @Override
                public void onSuccess(Boolean data) {
                }

                @Override
                public void onFailed(int code, String msg) {
                    Toast.makeText(getActivity(),"网络电台播放失败"+code,Toast.LENGTH_SHORT).show();
                }
            }));
        }
    }

    @Override
    public void onCategoryItemClick(Category item) {
        CloudNetFmCategoryAlbumFragment fragment = new CloudNetFmCategoryAlbumFragment();
        fragment.setCategory(item);
        if (getActivity() instanceof MainRoomActivity) {
            ((MainRoomActivity) getActivity()).showFragment(fragment);
        }
    }

    public void showLoadCallBack(LoadService loadService,Class<? extends Callback> callback){
        if (loadService != null){
            loadService.showCallback(callback);
        }
    }



    public void updateCategoryDataList(List<Category> list){
        if (list != null){
            mCategoryList = list;

            mCategoryAdapter.updateDataList(list);

            mCategoryAdapter.notifyDataSetChanged();
        }
    }

    public void updateDataList(List<CloudNetFm> list){
        if (list != null) {
            mCloudNetFmList = list;

            mItemAdapter.updateDataList(list);
            mItemAdapter.notifyDataSetChanged();

            showLoadCallBack(mRankLoadService,SuccessCallback.class);
        }else{
            showLoadCallBack(mRankLoadService,EmptyCallback.class);
        }
    }

    public void updateProvinceList(List<Province> list){
        mProvinceList = list;
    }

    public void updateLocalCity(String city){
        mLocalCity = city;
    }

    private void requestNetFmProvinceResource(){
        WRoom room = WApp.Instance.getDevManager().getSelectedRoom();
        if (room != null){
            WRoom.cmdGetNetFmProvinceCodeCategory( new CmdActionLister<List<Province>>(this, new ICmdCallback<List<Province>>() {
                @Override
                public void onSuccess(List<Province> data) {
                    updateProvinceList(data);
                }

                @Override
                public void onFailed(int code, String msg) {
                    updateProvinceList(null);
                    Toast.makeText(getContext(),"GetNetFmProvinceCodeCategory获取失败:"+code,Toast.LENGTH_SHORT).show();
                }
            }));
        }else{
            updateProvinceList(null);
        }
    }

    private void requestNetFmCategoryResource(){
        WRoom room = WApp.Instance.getDevManager().getSelectedRoom();
        if (room != null){
            WRoom.cmdGetNetFmCategory(new CmdActionLister<GetNetFmCategoryResult>(this, new ICmdCallback<GetNetFmCategoryResult>() {
                @Override
                public void onSuccess(GetNetFmCategoryResult data) {
                    updateLocalCity(data.location);

                    updateCategoryDataList(data.categories);
                }

                @Override
                public void onFailed(int code, String msg) {
                    updateCategoryDataList(null);
                    Toast.makeText(getContext(),"GetNetFmCategory获取失败:"+code,Toast.LENGTH_SHORT).show();
                }
            }));
        }else{
            updateCategoryDataList(null);
        }
    }


    private void requestCloudResource(){
        showLoadCallBack(mRankLoadService,LoadingCallback.class);
        WRoom room = WApp.Instance.getDevManager().getSelectedRoom();
        if (room != null){
            String pushType = "recommend";
            WRoom.cmdGetNetFmTopList(1,3, new CmdActionLister<List<CloudNetFm>>(this, new ICmdCallback<List<CloudNetFm>>() {
                @Override
                public void onSuccess(List<CloudNetFm> data) {
                    updateDataList(data);
                }

                @Override
                public void onFailed(int code, String msg) {
                    updateDataList(null);
                    Toast.makeText(getContext(),"GetNetFmTopList获取失败:"+code,Toast.LENGTH_SHORT).show();
                }
            }));
        }else{
            updateDataList(null);
        }
    }


}
