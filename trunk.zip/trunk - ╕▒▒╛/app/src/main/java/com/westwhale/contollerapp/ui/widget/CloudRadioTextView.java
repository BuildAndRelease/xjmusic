package com.westwhale.contollerapp.ui.widget;

import android.content.Context;
import android.graphics.Canvas;
import android.support.v7.widget.AppCompatTextView;
import android.util.AttributeSet;

/**
 * Description:
 * Author: chenyaoli
 * Date: 2018-12-08
 * History:
 */
public class CloudRadioTextView extends AppCompatTextView {
    private int mFirstIndexWidth;
    private int mSecondIndexWidth;
    private int mIndexHeight;

    public CloudRadioTextView(Context context) {
        super(context);
    }

    public CloudRadioTextView(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public CloudRadioTextView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        int height = getHeight();
        int width = getWidth();
        int paddingLeft = getPaddingLeft();
    }
}
