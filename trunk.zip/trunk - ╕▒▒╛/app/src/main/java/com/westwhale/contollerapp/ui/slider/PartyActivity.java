package com.westwhale.contollerapp.ui.slider;


import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.ImageView;

import com.blankj.utilcode.util.ToastUtils;
import com.scwang.smartrefresh.layout.api.RefreshLayout;
import com.scwang.smartrefresh.layout.listener.OnRefreshListener;
import com.westwhale.api.protocolapi.BaApi;
import com.westwhale.api.protocolapi.bean.hostroom.Room;
import com.westwhale.contollerapp.R;
import com.westwhale.contollerapp.application.WApp;
import com.westwhale.contollerapp.dev.CmdActionLister;
import com.westwhale.contollerapp.dev.ICmdCallback;
import com.westwhale.contollerapp.dev.WHost;
import com.westwhale.contollerapp.dev.WRoom;
import com.westwhale.contollerapp.ui.base.activity.BaseActivity;
import com.westwhale.contollerapp.ui.slider.adapter.PartyRoomAdapter;

import java.util.List;


public class PartyActivity extends BaseActivity implements PartyRoomAdapter.CallBack {
    public final static String TAG = PartyActivity.class.getName();

    private final String PARTY_STAT_OPEN = "open";
    private final String PARTY_STAT_CLOSE = "close";

    private Toolbar mToolbar;
    private ImageView mPartyStateIv;
    private RefreshLayout mRefreshLayout;
    private RecyclerView mDataRv;
    private PartyRoomAdapter mAdapter;

    private String mPartyStat = PARTY_STAT_CLOSE;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_slider_party);

        initView();
        initListener();

        initData();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    @Override
    public void onRoomStatClick(Room room) {
        // 房间的开关
        boolean isValid = false;
        String setDevStat = "";
        switch (room.devStat){
            case Room.DevState.OPEN:
                isValid = true;
                setDevStat = Room.DevState.CLOSE;
                break;
            case Room.DevState.CLOSE:
                isValid = true;
                setDevStat = Room.DevState.OPEN;
                break;
            default:
                break;
        }
        WRoom selectedRoom = WApp.Instance.getDevManager().getSelectedRoom();
        if (isValid && (selectedRoom != null)){
            // 开关不同的通道时，需注意roomId
            BaApi.getInstance().setRoomInfo(WApp.Instance.getDevManager().getHostById(room.hostId).ipAddress, room.roomId);
            WRoom.cmdSetDevStat(setDevStat,new CmdActionLister<Boolean>(PartyActivity.this, new ICmdCallback<Boolean>() {
                @Override
                public void onSuccess(Boolean data) {
                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            requestDataRoomList();
                        }
                    },200);

                }

                @Override
                public void onFailed(int code, String msg) {

                }
            }));

            // 操作完成后，需恢复roomId
            BaApi.getInstance().setRoomInfo(WApp.Instance.getDevManager().getHostById(selectedRoom.getHostId()).ipAddress, selectedRoom.getRoomId());
        }
    }

    private void initView() {
        mToolbar = findViewById(R.id.slider_party_toolbar);
        // 设置toolbar
        setSupportActionBar(mToolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        mPartyStateIv = findViewById(R.id.slider_party_state);

        mDataRv = findViewById(R.id.slider_party_recyclerview);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        mDataRv.setLayoutManager(linearLayoutManager);
        mAdapter = new PartyRoomAdapter();
        mAdapter.setCallBack(this);
        mDataRv.setAdapter(mAdapter);
        mDataRv.setHasFixedSize(true);
        mDataRv.addItemDecoration(new DividerItemDecoration(this, DividerItemDecoration.VERTICAL));

        mRefreshLayout = findViewById(R.id.slider_party_refresh);
        mRefreshLayout.setDisableContentWhenRefresh(true);
        mRefreshLayout.setEnableLoadMore(false);
    }

    private void initListener() {
        mToolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        mPartyStateIv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // party的开关
                WRoom room = WApp.Instance.getDevManager().getSelectedRoom();
                if (room != null){
                    String preSetPartyStat = PARTY_STAT_OPEN;
                    if (PARTY_STAT_OPEN.equals(mPartyStat)){
                        preSetPartyStat = PARTY_STAT_CLOSE;
                    }
                    String setStat = preSetPartyStat;
                    WRoom.cmdSetUniquePartyStat(room.getHostId(),preSetPartyStat,new CmdActionLister<Boolean>(PartyActivity.this, new ICmdCallback<Boolean>() {
                        @Override
                        public void onSuccess(Boolean data) {
                            updatePartyStat(setStat);

                            initData();
                        }

                        @Override
                        public void onFailed(int code, String msg) {
                            ToastUtils.showShort("设置party失败:"+code);
                        }
                    }));
                }
            }
        });

        mRefreshLayout.setOnRefreshListener(new OnRefreshListener() {
            @Override
            public void onRefresh(@NonNull RefreshLayout refreshLayout) {
                initData();
            }
        });

    }

    private void initData() {
        requestPartyStat();

        requestDataRoomList();
    }

    private void requestPartyStat(){
        WRoom room = WApp.Instance.getDevManager().getSelectedRoom();
        if (room != null){
            String preSetPartyStat = "";
            WRoom.cmdGetUniquePartyStat(new CmdActionLister<String>(PartyActivity.this, new ICmdCallback<String>() {
                @Override
                public void onSuccess(String data) {
                    updatePartyStat(data);
                }

                @Override
                public void onFailed(int code, String msg) {

                }
            }));
        }
    }

    private void requestDataRoomList() {
        // 获取房间列表信息
        WHost host = WApp.Instance.getDevManager().getSelectedHost();
        if ( (host != null) && (host.getHost() != null)){
            WHost.cmdGetHostRoomList(host.getHost().ipAddress, host.getHost().id,new CmdActionLister<List<Room>>(PartyActivity.this, new ICmdCallback<List<Room>>() {
                @Override
                public void onSuccess(List<Room> data) {
                    updateDataList(data);
                }

                @Override
                public void onFailed(int code, String msg) {
                    ToastUtils.showShort("GetHostRoomList 失败:%d",code);
                }
            }));
        }
    }

    private void updateDataList(List<Room> roomlist){
        if (mAdapter != null){
            mAdapter.clearAllData();

            mAdapter.updateList(roomlist);
            mAdapter.notifyDataSetChanged();
        }

        mRefreshLayout.finishRefresh();
    }

    private void updatePartyStat(String partyState){
        mPartyStat = partyState;
        int statPicResourceId = R.drawable.btn_lock;
        if ( PARTY_STAT_OPEN.equals(mPartyStat)){
            statPicResourceId = R.drawable.btn_unlock;
        }

        mPartyStateIv.setImageResource(statPicResourceId);
    }

}
