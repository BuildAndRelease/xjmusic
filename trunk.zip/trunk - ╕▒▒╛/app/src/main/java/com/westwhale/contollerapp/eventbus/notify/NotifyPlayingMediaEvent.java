package com.westwhale.contollerapp.eventbus.notify;

import com.westwhale.api.protocolapi.bean.media.Media;

public class NotifyPlayingMediaEvent {
    Media mMedia;
    public NotifyPlayingMediaEvent(Media media){
        mMedia = media;
    }
    public Media getPlayingMedia() {
        return mMedia;
    }
}
