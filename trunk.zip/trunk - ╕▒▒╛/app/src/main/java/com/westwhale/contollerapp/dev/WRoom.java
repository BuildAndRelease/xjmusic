package com.westwhale.contollerapp.dev;

import android.os.Handler;
import android.support.annotation.NonNull;
import android.util.Pair;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.blankj.utilcode.util.ThreadUtils;
import com.westwhale.api.protocolapi.bean.DelayClose;
import com.westwhale.api.protocolapi.bean.Talk;
import com.westwhale.api.protocolapi.bean.scene.RoomSceneAction;
import com.westwhale.api.protocolapi.bean.scene.Scene;
import com.westwhale.contollerapp.application.WApp;
import com.westwhale.contollerapp.dev.resourcecenter.CloudMusicResource;
import com.westwhale.contollerapp.dev.resourcecenter.CloudNetFmResource;
import com.westwhale.contollerapp.dev.resourcecenter.CloudStoryResource;
import com.westwhale.contollerapp.dev.resourcecenter.LocalMusicResource;
import com.westwhale.contollerapp.eventbus.notify.NotifyDevStatEvent;
import com.westwhale.contollerapp.eventbus.notify.NotifyMuteEvent;
import com.westwhale.contollerapp.dev.player.CloudMusicPlayer;
import com.westwhale.contollerapp.dev.player.CloudNetFmPlayer;
import com.westwhale.contollerapp.dev.player.CloudStoryPlayer;
import com.westwhale.contollerapp.dev.player.LocalMusicPlayer;
import com.westwhale.contollerapp.dev.player.WPlayer;
import com.westwhale.contollerapp.eventbus.notify.NotifyPlayingInfoEvent;
import com.westwhale.contollerapp.eventbus.notify.NotifyVolumeEvent;
import com.westwhale.api.protocolapi.BaProtocolBean;
import com.westwhale.api.protocolapi.BaApi;
import com.westwhale.api.protocolapi.CMD;
import com.westwhale.api.protocolapi.bean.media.CloudMusic;
import com.westwhale.api.protocolapi.bean.LocalDirectory;
import com.westwhale.api.protocolapi.bean.media.LocalMusic;
import com.westwhale.api.protocolapi.bean.media.Media;
import com.westwhale.api.protocolapi.bean.PlayList;
import com.westwhale.api.protocolapi.bean.Timer;
import com.westwhale.api.protocolapi.bean.albumSet.CloudAlbumSet;
import com.westwhale.api.protocolapi.bean.albumSet.CloudDissSet;
import com.westwhale.api.protocolapi.bean.albumSet.CloudSingerSet;
import com.westwhale.api.protocolapi.bean.albumSet.StoryTelling;
import com.westwhale.api.protocolapi.bean.cloudmusic.CloudMusicRecommed;
import com.westwhale.api.protocolapi.bean.cloudmusic.CloudRadioGroup;
import com.westwhale.api.protocolapi.bean.cloudmusic.DissCategoryGroup;
import com.westwhale.api.protocolapi.bean.cloudmusic.TopCate;
import com.westwhale.api.protocolapi.bean.media.CloudNetFm;
import com.westwhale.api.protocolapi.bean.cloudnetfm.GetNetFmCategoryResult;
import com.westwhale.api.protocolapi.bean.cloudnetfm.Province;
import com.westwhale.api.protocolapi.bean.download.DownloadItem;
import com.westwhale.api.protocolapi.bean.hostroom.PlayingInfo;
import com.westwhale.api.protocolapi.bean.hostroom.Room;
import com.westwhale.api.protocolapi.bean.hostroom.RoomStatInfo;
import com.westwhale.api.protocolapi.bean.telling.Anchor;
import com.westwhale.api.protocolapi.bean.telling.AnchorCategroy;
import com.westwhale.api.protocolapi.bean.telling.CatrgroyGroup;
import com.westwhale.api.protocolapi.bean.telling.RankItem;
import com.westwhale.api.protocolapi.bean.media.Section;
import com.westwhale.api.protocolapi.net.Response;

import org.greenrobot.eventbus.EventBus;

import java.util.List;

/**
 * 房间对应的实际设备的通道，主要包含了播放相关信息等
 */
public class WRoom {
    private static final String TAG = "WRoom";
    private String mRoomIp;  // 房间IP
    private Room mRoom;

    private String mHostId;  // 房间所属设备的设备ID
    private String mRoomId;  // 房间ID
    private String mRoomName; // 房间名称
    private String mDevStat; // 房间状态（开、关）
    private String mChannelStat; // 设备状态（inClosed,inNormal,inDlna,inAirplay,inBT）
    private WPlayer mPlayer;  // 当前房间的播放器
    public String mTalkId;
    public String mPartyId;
    public String mMuteStat;
    public String mPhoneMuteEnable;
    private int mVolume;


    private static Handler mHandler; // 消息回复处理

    public WRoom(@NonNull Room room,String ip) {
        mRoom = room;
        mHostId = room.hostId;
        mRoomId = room.roomId;
        mRoomName = room.roomName;
        mDevStat = room.devStat;
        mChannelStat = room.channelStat;

        mRoomIp = ip;

        mPlayer = null;
    }

    public String getHostId() {
        return mRoom.hostId;
    }
    public String getRoomId() {
        return mRoom.roomId;
    }




    public String getRoomName() {
        return mRoom.roomName;
    }
    public void updateRoomName(String name){
        mRoom.roomName = name;
        // 房间名称变更
//        EventBus.getDefault().post(new );
    }
    public void cmdSetDevInfo(String hostIp, String roomId,String name) {
        cmdSetDevInfo(hostIp,roomId,name, null);
    }
    public void cmdSetDevInfo(String hostIp, String roomId,String name, CmdActionLister<Boolean> actionLister) {
        ThreadUtils.getIoPool().execute(new Runnable() {
            @Override
            public void run() {
                Response<Boolean> response = null;
                try {
                    response = BaApi.getInstance().setDevInfo(hostIp,roomId,name);
                } catch (Exception e) {
                    e.printStackTrace();
                }finally {
                    postCmdResponse(response,actionLister);
                }
            }
        });
    }

    public static  void cmdSetAudioSource(String audioSource, String id) {
        cmdSetAudioSource(audioSource,id, null);
    }
    public static  void cmdSetAudioSource(String audioSource, String id, CmdActionLister<Boolean> actionLister) {
        ThreadUtils.getIoPool().execute(new Runnable() {
            @Override
            public void run() {
                Response<Boolean> response = null;
                try {
                    response = BaApi.getInstance().setAudioSource(audioSource,id);
                } catch (Exception e) {
                    e.printStackTrace();
                }finally {
                    postCmdResponse(response,actionLister);
                }
            }
        });
    }

    public void cmdSwitchToAux1(CmdActionLister<Boolean> actionLister) {
        ThreadUtils.getIoPool().execute(new Runnable() {
            @Override
            public void run() {
                Response<Boolean> response = null;
                try {
                    response = BaApi.getInstance().switchToAux1();
                } catch (Exception e) {
                    e.printStackTrace();
                }finally {
                    postCmdResponse(response,actionLister);
                }
            }
        });
    }

    public void cmdSwitchToAux2(CmdActionLister<Boolean> actionLister) {
        ThreadUtils.getIoPool().execute(new Runnable() {
            @Override
            public void run() {
                Response<Boolean> response = null;
                try {
                    response = BaApi.getInstance().switchToAux2();
                } catch (Exception e) {
                    e.printStackTrace();
                }finally {
                    postCmdResponse(response,actionLister);
                }
            }
        });
    }

    public static void cmdSetUniquePartyStat(String hostId, String partyStat,CmdActionLister<Boolean> actionLister) {
        ThreadUtils.getIoPool().execute(new Runnable() {
            @Override
            public void run() {
                Response<Boolean> response = null;
                try {
                    response = BaApi.getInstance().setUniquePartyStat(hostId,partyStat);
                } catch (Exception e) {
                    e.printStackTrace();
                }finally {
                    postCmdResponse(response,actionLister);
                }
            }
        });
    }

    public static void cmdGetUniquePartyStat(CmdActionLister<String> actionLister) {
        ThreadUtils.getIoPool().execute(new Runnable() {
            @Override
            public void run() {
                Response<String> response = null;
                try {
                    response = BaApi.getInstance().getUniquePartyStat();
                } catch (Exception e) {
                    e.printStackTrace();
                }finally {
                    postCmdResponse(response,actionLister);
                }
            }
        });
    }

    public static void cmdGetTalkList(CmdActionLister<List<Talk>> actionLister) {
        ThreadUtils.getIoPool().execute(new Runnable() {
            @Override
            public void run() {
                Response<List<Talk>> response = null;
                try {
                    response = BaApi.getInstance().getTalkList();
                } catch (Exception e) {
                    e.printStackTrace();
                }finally {
                    postCmdResponse(response,actionLister);
                }
            }
        });
    }

    public static void cmdAddTalk(String talkName, List<String> talkRoom,CmdActionLister<Boolean> actionLister) {
        ThreadUtils.getIoPool().execute(new Runnable() {
            @Override
            public void run() {
                Response<Boolean> response = null;
                try {
                    response = BaApi.getInstance().addTalk(talkName,talkRoom);
                } catch (Exception e) {
                    e.printStackTrace();
                }finally {
                    postCmdResponse(response,actionLister);
                }
            }
        });
    }

    public static void cmdDelTalk(int talkId,CmdActionLister<Boolean> actionLister) {
        ThreadUtils.getIoPool().execute(new Runnable() {
            @Override
            public void run() {
                Response<Boolean> response = null;
                try {
                    response = BaApi.getInstance().delTalk(talkId);
                } catch (Exception e) {
                    e.printStackTrace();
                }finally {
                    postCmdResponse(response,actionLister);
                }
            }
        });
    }

    public static void cmdGetTalkRoomList(int talkId,CmdActionLister<List<Room>> actionLister) {
        ThreadUtils.getIoPool().execute(new Runnable() {
            @Override
            public void run() {
                Response<List<Room>> response = null;
                try {
                    response = BaApi.getInstance().getTalkRoomList(talkId);
                } catch (Exception e) {
                    e.printStackTrace();
                }finally {
                    postCmdResponse(response,actionLister);
                }
            }
        });
    }

    public static void cmdGetTalkStat(int talkId,CmdActionLister<Talk> actionLister) {
        ThreadUtils.getIoPool().execute(new Runnable() {
            @Override
            public void run() {
                Response<Talk> response = null;
                try {
                    response = BaApi.getInstance().getTalkStat(talkId);
                } catch (Exception e) {
                    e.printStackTrace();
                }finally {
                    postCmdResponse(response,actionLister);
                }
            }
        });
    }

    public static void cmdSetTalkStat(int talkId, String talkStat,CmdActionLister<Talk> actionLister) {
        ThreadUtils.getIoPool().execute(new Runnable() {
            @Override
            public void run() {
                Response<Talk> response = null;
                try {
                    response = BaApi.getInstance().setTalkStat(talkId,talkStat);
                } catch (Exception e) {
                    e.printStackTrace();
                }finally {
                    postCmdResponse(response,actionLister);
                }
            }
        });
    }



    public void cmdGetRoomStatInfo() {
        cmdGetRoomStatInfo(null);
    }
    public void cmdGetRoomStatInfo(CmdActionLister<RoomStatInfo> actionLister){
        ThreadUtils.getIoPool().execute(new Runnable() {
            @Override
            public void run() {
                Response<RoomStatInfo> res = null;
                try {
                    res = BaApi.getInstance().getRoomStatInfo();
                    if (res.resultCode == 0){
                        RoomStatInfo roomStatInfo = BaApi.getInstance().getRoomStatInfo().bean;
                        if (roomStatInfo != null) {
                            updateDevState(roomStatInfo.devStat);

                            updateRoomState(roomStatInfo.roomStat);
                            udpatePlayingMedia(roomStatInfo.media);
                            updatePartyId(roomStatInfo.partyId);
                            updateTalkId(roomStatInfo.talkId);

                            updateMuteStat(roomStatInfo.muteStat);
                            updatePhoneMuteStat(roomStatInfo.phoneMuteEnable);

                            updatePlayMode(roomStatInfo.playMode);
                            updatePlayTime(roomStatInfo.playTime);

                            updateVolume(roomStatInfo.volume);

                            updatePlayStat(roomStatInfo.playStat);
                        }
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                } finally {
                    postCmdResponse(res,actionLister);
                }
            }
        });
    }

    synchronized private void updatePlayingInfo(PlayingInfo playingInfo) {
        if (playingInfo.isAvailble()) {
            updateRoomState(playingInfo.roomState);

            updatePartyId(playingInfo.partyId);
            updateTalkId(playingInfo.talkId);

            switch (playingInfo.roomState) {
                case Room.ChannelState.INCLOSED:
                    break;
                case Room.ChannelState.INPARTY:

                    udpatePlayingMedia(playingInfo.media);
                    break;
                case Room.ChannelState.INNORMAL:
                    udpatePlayingMedia(playingInfo.media);
                    break;
                case Room.ChannelState.INAIRPLAY:
                    break;
                case Room.ChannelState.INDLNA:
                    break;
                case Room.ChannelState.INTALK:
                    break;
                default:
                    break;
            }

            EventBus.getDefault().post(new  NotifyPlayingInfoEvent(playingInfo));
        }
    }


    synchronized public void updatePhoneMuteStat(String phoneMuteEnable) {
        mPhoneMuteEnable = phoneMuteEnable;
        //TODO: 通知
    }

    synchronized public void updateMuteStat(String muteStat) {
        mMuteStat = muteStat;
        // 静音状态 通知
        EventBus.getDefault().post(new NotifyMuteEvent(muteStat));
    }
    public String getMuteStat(){
        return mMuteStat;
    }
    public void cmdGetMuteStat(CmdActionLister<String> actionLister){
        ThreadUtils.getIoPool().execute(new Runnable() {
            @Override
            public void run() {
                Response<String> response = null;
                try {
                    response = BaApi.getInstance().getMute();
                } catch (Exception e) {
                    e.printStackTrace();
                }finally {
                    postCmdResponse(response,actionLister);
                }
            }
        });
    }
    public static void cmdSetMuteStat(String mutestat){
        cmdSetMuteStat(mutestat,null);
    }
    public static void cmdSetMuteStat(String mutestat,CmdActionLister<Boolean> actionLister){
        ThreadUtils.getIoPool().execute(new Runnable() {
            @Override
            public void run() {
                Response<Boolean> response = null;
                try {
                    response = BaApi.getInstance().setMute(mutestat);
                } catch (Exception e) {
                    e.printStackTrace();
                }finally {
                    postCmdResponse(response,actionLister);
                }
            }
        });
    }



    synchronized private void updateDevState(String devStat) {
        mRoom.devStat = devStat;
        // 开关状态 通知
        EventBus.getDefault().post(new NotifyDevStatEvent(mRoom.devStat));
    }
    public String getDevStat(){
        return mRoom.devStat;
    }
    public static  void cmdGetDevStat(CmdActionLister<String> actionLister){
        ThreadUtils.getIoPool().execute(new Runnable() {
            @Override
            public void run() {
                Response<String> response = null;
                try {
                    response = BaApi.getInstance().getDevStat();
                } catch (Exception e) {
                    e.printStackTrace();
                }finally {
                    postCmdResponse(response,actionLister);
                }
            }
        });
    }
    public static  void cmdSetDevStat(String devstat){
        cmdSetDevStat(devstat);
    }
    public static  void cmdSetDevStat(String devstat,CmdActionLister<Boolean> actionLister){
        ThreadUtils.getIoPool().execute(new Runnable() {
            @Override
            public void run() {
                Response<Boolean> response = null;
                try {
                    response = BaApi.getInstance().setDevStat(devstat);
                } catch (Exception e) {
                    e.printStackTrace();
                }finally {
                    postCmdResponse(response,actionLister);
                }
            }
        });
    }


    synchronized private void updateTalkId(String talkId) {
        mTalkId = talkId;
    }

    synchronized private void updatePartyId(String partyId) {
        mPartyId = partyId;
    }

    synchronized private void updateRoomState(String roomState) {
        mChannelStat = roomState;
    }
    public String getChannelStat(){
        return mChannelStat;
    }


    // 获取历史播放列表
    public void cmdGetHistoryPlayList(String mediaSrc, int pageNum, int pageSize,CmdActionLister<List<Media>> actionLister) {
        ThreadUtils.getIoPool().execute(new Runnable() {
            @Override
            public void run() {
                Response<List<Media>> response = null;
                try {
                    response = BaApi.getInstance().getHistoryPlayList(mediaSrc,pageNum,pageSize);
                } catch (Exception e) {
                    e.printStackTrace();
                }finally {
                    postCmdResponse(response,actionLister);
                }
            }
        });
    }

    // 获取定时器列表
    public void cmdGetTimerList(CmdActionLister<List<Timer>> actionLister) {
        ThreadUtils.getIoPool().execute(new Runnable() {
            @Override
            public void run() {
                Response<List<Timer>> response = null;
                try {
                    response = BaApi.getInstance().getTimerList();
                } catch (Exception e) {
                    e.printStackTrace();
                }finally {
                    postCmdResponse(response,actionLister);
                }
            }
        });
    }

    //添加定时器
    public void cmdAddTimer(Timer timer,CmdActionLister<Boolean> actionLister) {
        ThreadUtils.getIoPool().execute(new Runnable() {
            @Override
            public void run() {
                Response<Boolean> response = null;
                try {
                    response = BaApi.getInstance().addTimer(timer);
                } catch (Exception e) {
                    e.printStackTrace();
                }finally {
                    postCmdResponse(response,actionLister);
                }
            }
        });
    }

    //删除定时器
    public void cmdDelTimer(int timerId,CmdActionLister<Boolean> actionLister) {
        ThreadUtils.getIoPool().execute(new Runnable() {
            @Override
            public void run() {
                Response<Boolean> response = null;
                try {
                    response = BaApi.getInstance().delTimer(timerId);
                } catch (Exception e) {
                    e.printStackTrace();
                }finally {
                    postCmdResponse(response,actionLister);
                }
            }
        });
    }

    //修改定时器
    public void cmdModifyTimer(Timer timer,CmdActionLister<Boolean> actionLister) {
        ThreadUtils.getIoPool().execute(new Runnable() {
            @Override
            public void run() {
                Response<Boolean> response = null;
                try {
                    response = BaApi.getInstance().modifyTimer(timer);
                } catch (Exception e) {
                    e.printStackTrace();
                }finally {
                    postCmdResponse(response,actionLister);
                }
            }
        });
    }


    // 获取我的收藏歌单列表
    public void cmdGetFavoritePlayList(CmdActionLister<List<PlayList>> actionLister) {
        ThreadUtils.getIoPool().execute(new Runnable() {
            @Override
            public void run() {
                Response<List<PlayList>> response = null;
                try {
                    response = BaApi.getInstance().getFavoritePlayList();
                } catch (Exception e) {
                    e.printStackTrace();
                }finally {
                    postCmdResponse(response,actionLister);
                }
            }
        });
    }

    // 新建我的收藏歌单
    public void cmdAddFavoritePlayList(String playListName,CmdActionLister<PlayList> actionLister) {
        ThreadUtils.getIoPool().execute(new Runnable() {
            @Override
            public void run() {
                Response<PlayList> response = null;
                try {
                    response = BaApi.getInstance().addFavoritePlayList(playListName);
                } catch (Exception e) {
                    e.printStackTrace();
                }finally {
                    postCmdResponse(response,actionLister);
                }
            }
        });
    }

    // 删除我的收藏歌单
    public void cmdDelFavoritePlayList(int playListId,CmdActionLister<Boolean> actionLister) {
        ThreadUtils.getIoPool().execute(new Runnable() {
            @Override
            public void run() {
                Response<Boolean> response = null;
                try {
                    response = BaApi.getInstance().delFavoritePlayList(playListId);
                } catch (Exception e) {
                    e.printStackTrace();
                }finally {
                    postCmdResponse(response,actionLister);
                }
            }
        });
    }

    // 修改我的收藏歌单名
    public void cmdRenameFavoritePlayList(int playListId, String playListName,CmdActionLister<Boolean> actionLister) {
        ThreadUtils.getIoPool().execute(new Runnable() {
            @Override
            public void run() {
                Response<Boolean> response = null;
                try {
                    response = BaApi.getInstance().renameFavoritePlayList(playListId,playListName);
                } catch (Exception e) {
                    e.printStackTrace();
                }finally {
                    postCmdResponse(response,actionLister);
                }
            }
        });
    }

    // 将歌曲收藏到指定的我的收藏歌单
    public void cmdAddFavoriteMedia(int playListId, String mediaSrc, List<? extends Media> mediaList,CmdActionLister<Boolean> actionLister) {
        ThreadUtils.getIoPool().execute(new Runnable() {
            @Override
            public void run() {
                Response<Boolean> response = null;
                try {
                    response = BaApi.getInstance().addFavoriteMedia(playListId,mediaSrc,mediaList);
                } catch (Exception e) {
                    e.printStackTrace();
                }finally {
                    postCmdResponse(response,actionLister);
                }
            }
        });
    }

    // 将歌曲从指定的收藏歌单中取消收藏
    public void cmdDelFavoriteMedia(int playListId, String mediaSrc, List<Media> mediaList,CmdActionLister<Boolean> actionLister) {
        ThreadUtils.getIoPool().execute(new Runnable() {
            @Override
            public void run() {
                Response<Boolean> response = null;
                try {
                    response = BaApi.getInstance().delFavoriteMedia(playListId,mediaSrc,mediaList);
                } catch (Exception e) {
                    e.printStackTrace();
                }finally {
                    postCmdResponse(response,actionLister);
                }
            }
        });
    }

    // 获取指定的收藏歌单的歌曲列表
    public void cmdGetFavoriteMedia(int playListId,String mediaSrc,int beginIndex,int num,CmdActionLister<List<Media>> actionLister) {
        ThreadUtils.getIoPool().execute(new Runnable() {
            @Override
            public void run() {
                Response<List<Media>> response = null;
                try {
                    response = BaApi.getInstance().getFavoriteMedia(playListId,mediaSrc,beginIndex,num);
                } catch (Exception e) {
                    e.printStackTrace();
                }finally {
                    postCmdResponse(response,actionLister);
                }
            }
        });
    }

    // 判断歌曲是否已收藏
    public void cmdContainFavoriteMedia(int playListId, String mediaSrc, Media media,CmdActionLister<Boolean> actionLister) {
        ThreadUtils.getIoPool().execute(new Runnable() {
            @Override
            public void run() {
                Response<Boolean> response = null;
                try {
                    response = BaApi.getInstance().containFavoriteMedia(playListId,mediaSrc,media);
                } catch (Exception e) {
                    e.printStackTrace();
                }finally {
                    postCmdResponse(response,actionLister);
                }
            }
        });
    }

    // 播放我的收藏歌曲
    public void cmdPlayFavoriteMedia(int playListId, String mediaSrc, Media media,CmdActionLister<Boolean> actionLister) {
        ThreadUtils.getIoPool().execute(new Runnable() {
            @Override
            public void run() {
                Response<Boolean> response = null;
                try {
                    response = BaApi.getInstance().playFavoriteMedia(playListId,mediaSrc,media);
                } catch (Exception e) {
                    e.printStackTrace();
                }finally {
                    postCmdResponse(response,actionLister);
                }
            }
        });
    }

    /************************************  下载相关  *********************************/
    // 云资源下载
    public void cmdDownloadMusicList(String downloadPath, List<? extends Media> mediaList,CmdActionLister<Boolean> actionLister) {
        ThreadUtils.getIoPool().execute(new Runnable() {
            @Override
            public void run() {
                Response<Boolean> response = null;
                try {
                    response = BaApi.getInstance().downloadMusicList(downloadPath,mediaList);
                } catch (Exception e) {
                    e.printStackTrace();
                }finally {
                    postCmdResponse(response,actionLister);
                }
            }
        });
    }

    // 添加资源下载路径
    public void cmdAddDownloadPath(List<String> downloadPathList,CmdActionLister<Boolean> actionLister) {
        ThreadUtils.getIoPool().execute(new Runnable() {
            @Override
            public void run() {
                Response<Boolean> response = null;
                try {
                    response = BaApi.getInstance().addDownloadPath(downloadPathList);
                } catch (Exception e) {
                    e.printStackTrace();
                }finally {
                    postCmdResponse(response,actionLister);
                }
            }
        });
    }

    // 获取资源下载下载路径
    public void cmdGetDownloadPathList(CmdActionLister<Pair<String, List<String>>> actionLister) {
        ThreadUtils.getIoPool().execute(new Runnable() {
            @Override
            public void run() {
                Response<Pair<String, List<String>>> response = null;
                try {
                    response = BaApi.getInstance().getDownloadPathList();
                } catch (Exception e) {
                    e.printStackTrace();
                }finally {
                    postCmdResponse(response,actionLister);
                }
            }
        });
    }

    // 删除资源下载路径
    public void cmdDelDownloadPath(List<String> downloadPathList,CmdActionLister<Boolean> actionLister) {
        ThreadUtils.getIoPool().execute(new Runnable() {
            @Override
            public void run() {
                Response<Boolean> response = null;
                try {
                    response = BaApi.getInstance().delDownloadPath(downloadPathList);
                } catch (Exception e) {
                    e.printStackTrace();
                }finally {
                    postCmdResponse(response,actionLister);
                }
            }
        });
    }

    // 设置默认下载
    public void cmdSetDefaultDownloadPath(String defaultPath,CmdActionLister<Boolean> actionLister) {
        ThreadUtils.getIoPool().execute(new Runnable() {
            @Override
            public void run() {
                Response<Boolean> response = null;
                try {
                    response = BaApi.getInstance().setDefaultDownloadPath(defaultPath);
                } catch (Exception e) {
                    e.printStackTrace();
                }finally {
                    postCmdResponse(response,actionLister);
                }
            }
        });
    }

    // 获取已下载的列表
    public void cmdGetDownloadedMusicList(String mediaSrc,CmdActionLister<List<DownloadItem<CloudMusic>>> actionLister) {
        ThreadUtils.getIoPool().execute(new Runnable() {
            @Override
            public void run() {
                Response<List<DownloadItem<CloudMusic>>> response = null;
                try {
                    response = BaApi.getInstance().getDownloadedMusicList(mediaSrc);
                } catch (Exception e) {
                    e.printStackTrace();
                }finally {
                    postCmdResponse(response,actionLister);
                }
            }
        });
    }

    // 获取正在下载中的列表
    public void cmdGetDownloadingMusicList(String mediaSrc,CmdActionLister<List<DownloadItem<CloudMusic>>> actionLister) {
        ThreadUtils.getIoPool().execute(new Runnable() {
            @Override
            public void run() {
                Response<List<DownloadItem<CloudMusic>>> response = null;
                try {
                    response = BaApi.getInstance().getDownloadingMusicList(mediaSrc);
                } catch (Exception e) {
                    e.printStackTrace();
                }finally {
                    postCmdResponse(response,actionLister);
                }
            }
        });
    }

    // 操作下载列表
    public void cmdOperatorDownload(int cmd,List<DownloadItem<CloudMusic>> list,CmdActionLister<Boolean> actionLister) {
        ThreadUtils.getIoPool().execute(new Runnable() {
            @Override
            public void run() {
                Response<Boolean> response = null;
                try {
                    response = BaApi.getInstance().operatorDownload(cmd, list);
                } catch (Exception e) {
                    e.printStackTrace();
                }finally {
                    postCmdResponse(response,actionLister);
                }
            }
        });
    }

    public static void cmdGetSceneList(CmdActionLister<List<Scene>> actionLister) {
        ThreadUtils.getIoPool().execute(new Runnable() {
            @Override
            public void run() {
                Response<List<Scene>> response = null;
                try {
                    response = BaApi.getInstance().getSceneList();
                } catch (Exception e) {
                    e.printStackTrace();
                }finally {
                    postCmdResponse(response,actionLister);
                }
            }
        });
    }

    public static void cmdAddScene(String sceneName,CmdActionLister<Scene> actionLister) {
        ThreadUtils.getIoPool().execute(new Runnable() {
            @Override
            public void run() {
                Response<Scene> response = null;
                try {
                    response = BaApi.getInstance().addScene(sceneName);
                } catch (Exception e) {
                    e.printStackTrace();
                }finally {
                    postCmdResponse(response,actionLister);
                }
            }
        });
    }

    public static void cmdAddSceneWithAction(String sceneName, List<RoomSceneAction> actionList,CmdActionLister<Boolean> actionLister) {
        ThreadUtils.getIoPool().execute(new Runnable() {
            @Override
            public void run() {
                Response<Boolean> response = null;
                try {
                    response = BaApi.getInstance().addSceneWithAction(sceneName,actionList);
                } catch (Exception e) {
                    e.printStackTrace();
                }finally {
                    postCmdResponse(response,actionLister);
                }
            }
        });
    }

    public static void cmdDelScene(int sceneId,CmdActionLister<Boolean> actionLister) {
        ThreadUtils.getIoPool().execute(new Runnable() {
            @Override
            public void run() {
                Response<Boolean> response = null;
                try {
                    response = BaApi.getInstance().delScene(sceneId);
                } catch (Exception e) {
                    e.printStackTrace();
                }finally {
                    postCmdResponse(response,actionLister);
                }
            }
        });
    }

    public static void cmdRenameScene(int sceneId,String sceneName,CmdActionLister<Boolean> actionLister) {
        ThreadUtils.getIoPool().execute(new Runnable() {
            @Override
            public void run() {
                Response<Boolean> response = null;
                try {
                    response = BaApi.getInstance().renameScene(sceneId,sceneName);
                } catch (Exception e) {
                    e.printStackTrace();
                }finally {
                    postCmdResponse(response,actionLister);
                }
            }
        });
    }

    public static void cmdExecuteScene(int sceneId,CmdActionLister<Boolean> actionLister) {
        ThreadUtils.getIoPool().execute(new Runnable() {
            @Override
            public void run() {
                Response<Boolean> response = null;
                try {
                    response = BaApi.getInstance().executeScene(sceneId);
                } catch (Exception e) {
                    e.printStackTrace();
                }finally {
                    postCmdResponse(response,actionLister);
                }
            }
        });
    }

    public static void cmdSetActionListToScene(int sceneId, List<RoomSceneAction> actionList, CmdActionLister<Boolean> actionLister) {
        ThreadUtils.getIoPool().execute(new Runnable() {
            @Override
            public void run() {
                Response<Boolean> response = null;
                try {
                    response = BaApi.getInstance().setActionListToScene(sceneId,actionList);
                } catch (Exception e) {
                    e.printStackTrace();
                }finally {
                    postCmdResponse(response,actionLister);
                }
            }
        });
    }

    public static void cmdGetSceneActionList(int sceneId, CmdActionLister<Scene> actionLister) {
        ThreadUtils.getIoPool().execute(new Runnable() {
            @Override
            public void run() {
                Response<Scene> response = null;
                try {
                    response = BaApi.getInstance().getSceneActionList(sceneId);
                } catch (Exception e) {
                    e.printStackTrace();
                }finally {
                    postCmdResponse(response,actionLister);
                }
            }
        });
    }

    public static void cmdGetDelayCloseTimer( CmdActionLister<DelayClose> actionLister) {
        ThreadUtils.getIoPool().execute(new Runnable() {
            @Override
            public void run() {
                Response<DelayClose> response = null;
                try {
                    response = BaApi.getInstance().getDelayCloseTimer();
                } catch (Exception e) {
                    e.printStackTrace();
                }finally {
                    postCmdResponse(response,actionLister);
                }
            }
        });
    }

    public static void cmdModifyDelayCloseTimer(String timerEnable, int delayCloseAfterTimes, CmdActionLister<Boolean> actionLister) {
        ThreadUtils.getIoPool().execute(new Runnable() {
            @Override
            public void run() {
                Response<Boolean> response = null;
                try {
                    response = BaApi.getInstance().modifyDelayCloseTimer(timerEnable,delayCloseAfterTimes);
                } catch (Exception e) {
                    e.printStackTrace();
                }finally {
                    postCmdResponse(response,actionLister);
                }
            }
        });
    }

    public static void cmdCloseClockPlay(int timerId, CmdActionLister<Boolean> actionLister) {
        ThreadUtils.getIoPool().execute(new Runnable() {
            @Override
            public void run() {
                Response<Boolean> response = null;
                try {
                    response = BaApi.getInstance().closeClockPlay(timerId);
                } catch (Exception e) {
                    e.printStackTrace();
                }finally {
                    postCmdResponse(response,actionLister);
                }
            }
        });
    }


    /********************************************** 资源相关(本地音乐)  *****************************************/

    public static void cmdGetLocalDirectory(String directoryMid, int beginIndex, int num, boolean ignoreEmpty,CmdActionLister<Response<LocalDirectory>> actionLister) {
        LocalMusicResource.cmdGetLocalDirectory(directoryMid,beginIndex,num,ignoreEmpty,actionLister);
    }

    public static void cmdSearchLocalMusic(String keywords, int beginIndex, int num,CmdActionLister<List<Media>> actionLister) {
        LocalMusicResource.cmdSearchLocalMusic(keywords,beginIndex,num,actionLister);
    }
    /********************************************** 资源相关(本地音乐)  *****************************************/

    /********************************************** 资源相关(云音乐)  *****************************************/

    public static void cmdGetAlbum(int time, int area, int type, int index, int sort, int perpage, int pageNo,CmdActionLister<List<CloudAlbumSet>> actionLister) {
        CloudMusicResource.cmdGetAlbum(time,area,type,index,sort,perpage,pageNo,actionLister);
    }

    public static void cmdGetDiss(String categoryId, int sort, int from, int to,CmdActionLister<List<CloudDissSet>> actionLister) {
        CloudMusicResource.cmdGetDiss(categoryId,sort,from,to,actionLister);
    }

    public static void cmdGetDissCategory(CmdActionLister<List<DissCategoryGroup>> actionLister) {
        CloudMusicResource.cmdGetDissCategory(actionLister);
    }

    public static void cmdGetRadio(CmdActionLister<List<CloudRadioGroup>> actionLister) {
        CloudMusicResource.cmdGetRadio(actionLister);
    }

    public static void cmdGetTopList(CmdActionLister<List<TopCate>> actionLister) {
        CloudMusicResource.cmdGetTopList(actionLister);
    }

    public static void cmdGetSingerss(String category, String index, int pageNo,CmdActionLister<List<CloudSingerSet>> actionLister) {
        CloudMusicResource.cmdGetSingerss(category,index,pageNo, actionLister);
    }

    public static void cmdGetRecommend(CmdActionLister<CloudMusicRecommed> actionLister) {
        CloudMusicResource.cmdGetRecommend(actionLister);
    }


    public static void cmdGetAlbumSong(String albumMid,CmdActionLister<List<CloudMusic>> actionLister) {
        CloudMusicResource.cmdGetAlbumSong(albumMid,actionLister);
    }

    public static void cmdGetDissSong(String dissId,CmdActionLister<List<CloudMusic>> actionLister) {
        CloudMusicResource.cmdGetDissSong(dissId,actionLister);
    }

    public static void cmdGetNewSong(String area,CmdActionLister<List<CloudMusic>> actionLister) {
        CloudMusicResource.cmdGetNewSong(area,actionLister);
    }

    public static void cmdGetSingerSong(String singerMid, String order, int begin, int size,CmdActionLister<List<CloudMusic>> actionLister) {
        CloudMusicResource.cmdGetSingerSong(singerMid,order,begin,size,actionLister);
    }

    public static void cmdGetTopListSong(String topListId, String topListDate,CmdActionLister<List<CloudMusic>> actionLister) {
        CloudMusicResource.cmdGetTopListSong(topListId,topListDate,actionLister);
    }

    public static void cmdSearchSong(String searchText, int pageNo,CmdActionLister<List<CloudMusic>> actionLister) {
        CloudMusicResource.cmdSearchSong(searchText,pageNo,actionLister);
    }

    public static void cmdGetSongLyric(String mid,CmdActionLister<String> actionLister) {
        CloudMusicResource.cmdGetSongLyric(mid,actionLister);
    }

    /********************************************** 资源相关(云音乐) end *****************************************/


    /********************************************** 资源相关(语言节目)  *****************************************/
    public static void cmdGetStorytellingPush(String pushType,int perpage,int pagenum, CmdActionLister<List<StoryTelling>> actionLister){
        CloudStoryResource.cmdGetStorytellingPush(pushType,perpage,pagenum,actionLister);
    }

    public static void cmdGetStorytellingCategory(CmdActionLister<List<CatrgroyGroup>> actionLister){
        CloudStoryResource.cmdGetStorytellingCategory(actionLister);
    }

    public static void cmdGetStorytelling(String categoryId,int perpage,int pagenum, CmdActionLister<List<StoryTelling>> actionLister){
        CloudStoryResource.cmdGetStorytelling(categoryId,perpage,pagenum,actionLister);
    }

    public static void cmdGetStorytellingPlaylist(int mediaId, int perpage, int pagenum, CmdActionLister<List<Section>> actionLister){
        CloudStoryResource.cmdGetStorytellingPlaylist(mediaId,perpage,pagenum,actionLister);
    }

    public static void cmdGetStoryTellingRankingList(CmdActionLister<List<RankItem>> actionLister){
        CloudStoryResource.cmdGetStoryTellingRankingList(actionLister);
    }

    public static void cmdGetStoryTellingRankingListAlbum(int rankingListId,int perpage,int pagenum, CmdActionLister<List<StoryTelling>> actionLister){
        CloudStoryResource.cmdGetStoryTellingRankingListAlbum(rankingListId,perpage,pagenum,actionLister);
    }


    public static void cmdGetStoryTellingAnchorCategory(CmdActionLister<List<AnchorCategroy>> actionLister){
        CloudStoryResource.cmdGetStoryTellingAnchorCategory(actionLister);
    }

    public static void cmdGetStoryTellingAnchor(int categoryId, int pageSize, int pageNum, CmdActionLister<List<Anchor>> actionLister){
        CloudStoryResource.cmdGetStoryTellingAnchor(categoryId,pageSize,pageNum,actionLister);
    }

    public static void cmdGetStoryTellingAnchorByNormal(String categoryName, String recommendType, int pageSize, int pageNum,CmdActionLister<List<Anchor>> actionLister){
        CloudStoryResource.cmdGetStoryTellingAnchorByNormal(categoryName,recommendType,pageSize,pageNum,actionLister);
    }


    public static void cmdGetStoryTellingAnchorAlbum(int anchorId,int perpage,int pagenum, CmdActionLister<List<StoryTelling>> actionLister){
        CloudStoryResource.cmdGetStoryTellingAnchorAlbum(anchorId,perpage,pagenum,actionLister);
    }

    public static void cmdSearchStorytelling(String searchText, int perpage, int pagenum, CmdActionLister<List<StoryTelling>> actionLister){
        CloudStoryResource.cmdSearchStorytelling(searchText,perpage,pagenum,actionLister);
    }

    /********************************************** 资源相关(语言节目) end *****************************************/

    /********************************************** 资源相关(网络电台)  *****************************************/
    // 获取所有电台总目录ID,本地台，热门台
    public static void cmdGetNetFmCategory(CmdActionLister<GetNetFmCategoryResult> actionLister){
        CloudNetFmResource.cmdGetNetFmCategory(actionLister);
    }

    // 获取电台总目下子电台分类
    public static void cmdGetNetFmByCategory(int categoryId, int pageNum, int pageSize,CmdActionLister<List<CloudNetFm>> actionLister){
        CloudNetFmResource.cmdGetNetFmByCategory(categoryId,pageNum,pageSize,actionLister);
    }

    // 排行榜
    public static void cmdGetNetFmTopList(int pageNum, int pageSize,CmdActionLister<List<CloudNetFm>> actionLister){
        CloudNetFmResource.cmdGetNetFmTopList(pageNum,pageSize,actionLister);
    }

    // 国家台
    public static void cmdGetNetFmNational(int pageNum, int pageSize,CmdActionLister<List<CloudNetFm>> actionLister){
        CloudNetFmResource.cmdGetNetFmNational(pageNum,pageSize,actionLister);
    }

    // 网络台
    public static void cmdGetNetFmNetwork(int pageNum, int pageSize,CmdActionLister<List<CloudNetFm>> actionLister){
        CloudNetFmResource.cmdGetNetFmNetwork(pageNum,pageSize,actionLister);
    }

    // 所有省市列表
    public static void cmdGetNetFmProvinceCodeCategory(CmdActionLister<List<Province>> actionLister){
        CloudNetFmResource.cmdGetNetFmProvinceCodeCategory(actionLister);
    }

    // 省市台
    public static void cmdGetNetFmByCode(int provinceCode, int pageNum, int pageSize,CmdActionLister<List<CloudNetFm>> actionLister){
        CloudNetFmResource.cmdGetNetFmByCode(provinceCode,pageNum,pageSize,actionLister);
    }

    /********************************************** 资源相关网络电台 end  *****************************************/







    /********************************************** 播放器相关  *****************************************/
//    public WPlayer getPlayer() {
//        return mPlayer;
//    }

    synchronized public <T extends Media> void udpatePlayingMedia(T media) {
        if ( (null == media) || (null == media.mediaSrc) ) {
            return;
        }

        if ((null == mPlayer) || (mPlayer.getPlayingMedia() == null) || !media.mediaSrc.equals(mPlayer.getPlayingMedia().mediaSrc)) {
            switch (media.mediaSrc) {
                case Media.LOCAL_MUSIC:
                    mPlayer = new LocalMusicPlayer();
                    break;
                case Media.CLOUD_MUSIC:
                    mPlayer = new CloudMusicPlayer();
                    break;
                case Media.CLOUD_STORY_TELLING:
                    mPlayer = new CloudStoryPlayer();
                    break;
                case Media.CLOUD_NETFM:
                    mPlayer = new CloudNetFmPlayer();
                    break;
                case Media.LOCAL_AUX:
                    mPlayer = new CloudNetFmPlayer();
                    break;
                default:
                    mPlayer = null;
                    break;
            }
        }

        if (mChannelStat.equals(Room.ChannelState.INPARTY) || mChannelStat.equals(Room.ChannelState.INNORMAL)) {
            if (mPlayer != null) {
                mPlayer.updatePlayingMedia(media);
            }
        }
    }
    public Media getPlayingMedia(){
        return (mPlayer != null) ? mPlayer.getPlayingMedia() : null ;
    }

    private void updateVolume(int volume) {
        mVolume = volume;
        // 音量值 变更 广播
        EventBus.getDefault().post(new NotifyVolumeEvent(mVolume));
//        if (mPlayer != null) {
//            mPlayer.updateVolume(volume);
//        }
    }
    public int getVolume(){
        return mVolume;
//        return (mPlayer != null) ? mPlayer.getVolume() : 0 ;
    }
    public void cmdGetVolume() {
        cmdGetVolume(null);
    }
    public void cmdGetVolume(CmdActionLister<Integer> actionLister) {
        ThreadUtils.getIoPool().execute(new Runnable() {
            @Override
            public void run() {
                Response<Integer> res = null;
                try {
                    res = BaApi.getInstance().getVolume();
                } catch (Exception e) {
                    e.printStackTrace();
                } finally {
                    postCmdResponse(res, actionLister);
                }
            }
        });
//        if (mPlayer != null){
//            mPlayer.cmdGetVolume(actionLister);
//        }else{
//            postCmdResponse(null,actionLister);
//        }
    }
    public void cmdSetVolume(int volume){
        cmdSetVolume(volume,null);
    }
    public void cmdSetVolume(int volume,CmdActionLister<Boolean> actionLister){
        ThreadUtils.getIoPool().execute(new Runnable() {
            @Override
            public void run() {
                Response<Boolean> res = null;
                try {
                    res = BaApi.getInstance().setVolum(String.valueOf(volume));
                } catch (Exception e) {
                    e.printStackTrace();
                } finally {
                    postCmdResponse(res, actionLister);
                }
            }
        });

//        if (mPlayer != null){
//            mPlayer.cmdSetVolume(volume,actionLister);
//        }else{
//            postCmdResponse(null,actionLister);
//        }
    }

    private void updatePlayTime(int playTime) {
        if (mPlayer != null) {
            mPlayer.updatePlayTime(playTime);
        }
    }
    public int getPlayTime(){
        return (mPlayer != null) ? mPlayer.getPlayTime() : 0 ;
    }
    public void cmdGetPlayTime(){
        cmdGetPlayTime(null);
    }
    public void cmdGetPlayTime(CmdActionLister<Integer> actionLister) {
        if (mPlayer != null) {
            mPlayer.cmdGetPlayTime(actionLister);
        }else{
            postCmdResponse(null,actionLister);
        }
    }
    public void cmdSetPlayTime(int playtime){
        cmdSetPlayTime(playtime,null);
    }
    public void cmdSetPlayTime(int playtime,CmdActionLister<Boolean> actionLister) {
        if (mPlayer != null) {
            mPlayer.cmdSetPlayTime(playtime,actionLister);
        }else{
            postCmdResponse(null,actionLister);
        }
    }

    private void updatePlayStat(String playStat) {
        if (mPlayer != null) {
            mPlayer.updatePlayStat(playStat);
        }
    }
    public String getPlayStat(){
        return (mPlayer != null) ? mPlayer.getPlayStat() : null ;
    }
    public void cmdGetPlayStat(){
        cmdGetPlayStat(null);
    }
    public void cmdGetPlayStat(CmdActionLister<String> actionLister) {
        if (mPlayer != null) {
            mPlayer.cmdGetPlayStat(actionLister);
        } else {
            postCmdResponse(null, actionLister);
        }
    }

    private void updateMediaDuration(int duration) {
        if (mPlayer != null) {
            mPlayer.updateDuration(duration);
        }
    }
    public int getMediaDuration(){
        return (mPlayer != null) ? mPlayer.getDuration() : 0;
    }


    private void updatePlayMode(String playMode) {
        if (mPlayer != null) {
            mPlayer.updatePlayMode(playMode);
        }
    }
    public String getPlayMode(){
        return (mPlayer != null) ? mPlayer.getPlayMode() : null ;
    }
    public void cmdGetPlayMode(){
        cmdGetPlayStat(null);
    }
    public void cmdGetPlayMode(CmdActionLister<String> actionLister) {
        if (mPlayer != null) {
            mPlayer.cmdGetPlayMode(actionLister);
        } else {
            postCmdResponse(null, actionLister);
        }
    }
    public void cmdSetPlayMode(String playmode){
        cmdSetPlayMode(playmode,null);
    }
    public void cmdSetPlayMode(String playmode,CmdActionLister<Boolean> actionLister) {
        if (mPlayer != null) {
            mPlayer.cmdSetPlayMode(playmode,actionLister);
        } else {
            postCmdResponse(null, actionLister);
        }
    }

    public void cmdPlayNext() {
        cmdPlayNext(null);
    }
    public void cmdPlayNext(CmdActionLister<Boolean> actionLister){
        if (mPlayer != null) {
            mPlayer.cmdPlayNext(actionLister);
        }else{
            postCmdResponse(null,actionLister);
        }
    }

    public void cmdPlayPrevious() {
        cmdPlayPrevious(null);
    }
    public void cmdPlayPrevious(CmdActionLister<Boolean> actionLister){
        if (mPlayer != null) {
            mPlayer.cmdPlayPrev(actionLister);
        }else{
            postCmdResponse(null,actionLister);
        }
    }

    public void cmdPlayPause() {
        cmdPlayPause(null);
    }
    public void cmdPlayPause(CmdActionLister<Boolean> actionLister){
        if (mPlayer != null) {
            mPlayer.cmdPlayPause(actionLister);
        }else{
            postCmdResponse(null,actionLister);
        }
    }

    public void cmdPlayResume() {
        cmdPlayResume(null);
    }
    public void cmdPlayResume(CmdActionLister<Boolean> actionLister){
        if (mPlayer != null) {
            mPlayer.cmdPlayResume(actionLister);
        }else{
            postCmdResponse(null,actionLister);
        }
    }

    public static void cmdGetCurrentPlayList(int pageNum, int pageSize,CmdActionLister<Response<List<Media>>> actionLister){
        ThreadUtils.getIoPool().execute(new Runnable() {
            @Override
            public void run() {
                Response<List<Media>> res = null;
                try {
                    res = BaApi.getInstance().getCurrentPlayList(pageNum,pageSize);
                } catch (Exception e) {
                    e.printStackTrace();
                } finally {
                    postCmdResponseAll(res, actionLister);
                }
            }
        });
    }

    public static void cmdPlayCurrentPlayList(Media media,CmdActionLister<Boolean> actionLister){
        ThreadUtils.getIoPool().execute(new Runnable() {
            @Override
            public void run() {
                Response<Boolean> res = null;
                try {
                    res = BaApi.getInstance().playCurrentPlayList(media);
                } catch (Exception e) {
                    e.printStackTrace();
                } finally {
                    postCmdResponse(res, actionLister);
                }
            }
        });
    }

    public static void cmdAddToCloudMusicList(List<CloudMusic> mediaList,CmdActionLister<Boolean> actionLister){
        ThreadUtils.getIoPool().execute(new Runnable() {
            @Override
            public void run() {
                Response<Boolean> res = null;
                try {
                    res = BaApi.getInstance().addToCloudMusicList(mediaList);
                } catch (Exception e) {
                    e.printStackTrace();
                } finally {
                    postCmdResponse(res, actionLister);
                }
            }
        });
    }

    // 从当前播放列表中删除媒体(单个操作)
    public static void cmdDelMediaFromPlayMediaList(Media media,CmdActionLister<Boolean> actionLister){
        ThreadUtils.getIoPool().execute(new Runnable() {
            @Override
            public void run() {
                Response<Boolean> res = null;
                try {
                    res = BaApi.getInstance().delMediaFromPlayMediaList(media);
                } catch (Exception e) {
                    e.printStackTrace();
                } finally {
                    postCmdResponse(res, actionLister);
                }
            }
        });
    }

    // 从当前播放列表中删除媒体(批量操作)
    public static void cmdDelMediaListFromPlayMediaList(List<Media> mediaList,CmdActionLister<Boolean> actionLister){
        ThreadUtils.getIoPool().execute(new Runnable() {
            @Override
            public void run() {
                Response<Boolean> res = null;
                try {
                    res = BaApi.getInstance().delMediaListFromPlayMediaList(mediaList);
                } catch (Exception e) {
                    e.printStackTrace();
                } finally {
                    postCmdResponse(res, actionLister);
                }
            }
        });
    }

    public static void cmdClearPlayMediaList(CmdActionLister<Boolean> actionLister){
        ThreadUtils.getIoPool().execute(new Runnable() {
            @Override
            public void run() {
                Response<Boolean> res = null;
                try {
                    res = BaApi.getInstance().clearPlayMediaList();
                } catch (Exception e) {
                    e.printStackTrace();
                } finally {
                    postCmdResponse(res, actionLister);
                }
            }
        });
    }


//    public <T extends Media> void cmdPlayMedia(T media){
//        cmdPlayMedia(media,null);
//    }
//    public <T extends Media> void cmdPlayMedia(T media,CmdActionLister<Boolean> actionLister){
//        if (mPlayer != null) {
//            mPlayer.cmdPlayMedia(media,actionLister);
//        }else{
//            postCmdResponse(null,actionLister);
//        }
//    }

//    public <T extends Media> void cmdPlayMediaList(T media, List<T> mediaList){
//        cmdPlayMediaList(media,mediaList,null);
//    }
//    public <T extends Media> void cmdPlayMediaList(T media, List<T> mediaList,CmdActionLister<Boolean> actionLister){
//        if (mPlayer != null) {
//            mPlayer.cmdPlayMediaList(media,mediaList,actionLister);
//        }else{
//            postCmdResponse(null,actionLister);
//        }
//    }
//
//
//    public void cmdPlayCloudRadio(String radioId) {
//        cmdPlayCloudRadio(radioId, null);
//    }
//
//    public void cmdPlayCloudRadio(String radioId, CmdActionLister<Boolean> actionLister) {
//        if (mPlayer != null) {
//            mPlayer.cmdPlayCloudRadio(radioId,actionLister);
//        }else{
//            postCmdResponse(null,actionLister);
//        }
//    }

    public static <T extends Media> void cmdPlayMedia(T media){
        cmdPlayMedia(media,null);
    }
    public static <T extends Media> void cmdPlayMedia(T media,CmdActionLister<Boolean> actionLister){
        if (media instanceof CloudMusic){
            // 播放指定媒体
            ThreadUtils.getIoPool().execute(new Runnable() {
                @Override
                public void run() {
                    Response<Boolean> res = null;
                    try {
                        res = BaApi.getInstance().playCloudMusic((CloudMusic) media);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }finally {
                        postCmdResponse(res,actionLister);
                    }
                }
            });
        }else if (media instanceof LocalMusic){
            // 播放指定媒体
            ThreadUtils.getIoPool().execute(new Runnable() {
                @Override
                public void run() {
                    Response<Boolean> res = null;
                    try {
                        res = BaApi.getInstance().playLocalMusic((LocalMusic)media);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }finally {
                        postCmdResponse(res,actionLister);
                    }
                }
            });
        }else if (media instanceof Section){
            // 播放指定媒体
            ThreadUtils.getIoPool().execute(new Runnable() {
                @Override
                public void run() {
                    Response<Boolean> res = null;
                    try {
                        res = BaApi.getInstance().playCloudStory((Section)media);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }finally {
                        postCmdResponse(res,actionLister);
                    }
                }
            });
        }else if (media instanceof CloudNetFm){
            // 播放指定媒体
            ThreadUtils.getIoPool().execute(new Runnable() {
                @Override
                public void run() {
                    Response<Boolean> res = null;
                    try {
                        res = BaApi.getInstance().playCloudNetFm((CloudNetFm) media);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }finally {
                        postCmdResponse(res,actionLister);
                    }
                }
            });
        }else{
            postCmdResponse(null,actionLister);
        }
    }

    public static void cmdPlayCloudMusicList(CloudMusic media, List<CloudMusic> mediaList){
        cmdPlayCloudMusicList(media,mediaList,null);
    }
    public static void cmdPlayCloudMusicList(CloudMusic media, List<CloudMusic> mediaList,CmdActionLister<Boolean> actionLister){
        // 播放指定媒体
        ThreadUtils.getIoPool().execute(new Runnable() {
            @Override
            public void run() {
                Response<Boolean> res = null;
                try {
                    res = BaApi.getInstance().playCloudMusicList(media,mediaList);
                } catch (Exception e) {
                    e.printStackTrace();
                }finally {
                    postCmdResponse(res,actionLister);
                }
            }
        });
    }


    public static void cmdPlayCloudRadio(String radioId) {
        cmdPlayCloudRadio(radioId, null);
    }

    public static void cmdPlayCloudRadio(String radioId, CmdActionLister<Boolean> actionLister) {
        // 播放指定媒体
        ThreadUtils.getIoPool().execute(new Runnable() {
            @Override
            public void run() {
                Response<Boolean> res = null;
                try {
                    res = BaApi.getInstance().playCloudRadio(radioId);
                } catch (Exception e) {
                    e.printStackTrace();
                }finally {
                    postCmdResponse(res,actionLister);
                }
            }
        });
    }

    /********************************************** 播放器相关  end *****************************************/


    //在泛型类中声明了一个泛型方法，使用泛型E，这种泛型E可以为任意类型。可以类型与T相同，也可以不同。
    //由于泛型方法在声明的时候会声明泛型<E>，因此即使在泛型类中并未声明泛型，编译器也能够正确识别泛型方法中识别的泛型。
    private static <E> void postCmdResponse(Response<E> result, CmdActionLister<E> actionLister) {
        if (null == mHandler) {
            mHandler = new Handler(WApp.Instance.getMainLooper());
        }

        mHandler.post(new Runnable() {
            @Override
            public void run() {
                if (!ThreadUtils.isMainThread() || (null == actionLister)) {
                    return;
                }

                String msg = "";
                E data = null;
                int resultCode = -1;
                if (result != null) {
                    resultCode = result.resultCode;
                    if (0 == resultCode) {
                        data = result.bean;
                    }
                }

                actionLister.callback(resultCode, data, msg);
            }
        });
    }

    private static <E> void postCmdResponseAll(Response<E> result, CmdActionLister<Response<E>> actionLister) {
        if (null == mHandler) {
            mHandler = new Handler(WApp.Instance.getMainLooper());
        }

        mHandler.post(new Runnable() {
            @Override
            public void run() {
                if (!ThreadUtils.isMainThread() || (null == actionLister)) {
                    return;
                }

                String msg = "";
                Response<E> data = null;
                int resultCode = -1;
                if (result != null) {
                    resultCode = result.resultCode;
                    if (0 == resultCode) {
                        data = result;
                    }
                }

                actionLister.callback(resultCode, data, msg);
            }
        });
    }

    // 处理广播通知
    public void parseNotifyInfo(@NonNull BaProtocolBean head) {
        String argStr = head.arg;
        try {
            JSONObject argJson = JSON.parseObject(argStr);
            switch (head.cmd) {
                case CMD.NOTIFY_DEV_STAT: {
                    String devstat = argJson.getString("devStat");
                    updateDevState(devstat);
                    break;
                }
                case CMD.NOTIFY_PLAYING_INFO: {
                    PlayingInfo playingInfo = new PlayingInfo(argStr);
                    updatePlayingInfo(playingInfo);

                    break;
                }
                case CMD.NOTIFY_PLAYING_MEDIA_DURATION: {
                    int duration = argJson.getInteger("duration");
                    if (mChannelStat.equals(Room.ChannelState.INNORMAL) || mChannelStat.equals(Room.ChannelState.INPARTY)) {
                        updateMediaDuration(duration);
                    }
                    break;
                }
                case CMD.NOTIFY_PLAY_STAT: {
                    String playStat = argJson.getString("playStat");
                    if (mChannelStat.equals(Room.ChannelState.INNORMAL) || mChannelStat.equals(Room.ChannelState.INPARTY)) {
                        updatePlayStat(playStat);
                    }
                    break;
                }
                case CMD.NOTIFY_PLAY_MODE: {
                    String playMode = argJson.getString("playMode");
                    if (mChannelStat.equals(Room.ChannelState.INNORMAL) || mChannelStat.equals(Room.ChannelState.INPARTY)) {
                        updatePlayMode(playMode);
                    }
                    break;
                }
                case CMD.NOTIFY_PLAY_TIME: {
                    int playTime = argJson.getInteger("playTime");
                    if (mChannelStat.equals(Room.ChannelState.INNORMAL) || mChannelStat.equals(Room.ChannelState.INPARTY)) {
                        updatePlayTime(playTime);
                    }
                    break;
                }
                case CMD.NOTIFY_VOLUME: {
                    int volume = argJson.getInteger("volume");
                    updateVolume(volume);
                    break;
                }
                default:
                    break;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


}
