package com.westwhale.contollerapp.ui.scene.bean;


import android.support.annotation.StringRes;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;

public class CmdSetAudioSource extends CmdActionBase {
    public final static String AUDIO_SOURCE_CLOUDMUSIC = "cloudMusic";
    public final static String AUDIO_SOURCE_CLOUDSTORYTELLING = "storyTelling";
    public final static String AUDIO_SOURCE_LOCALMUSIC = "localMusic";
    public final static String AUDIO_SOURCE_CLOUDNETFM = "cloudNetFm";
    public final static String AUDIO_SOURCE_AUX1 = "aux1";
    public final static String AUDIO_SOURCE_AUX2 = "aux2";

    private String mAudioSource = AUDIO_SOURCE_CLOUDMUSIC;
    private int mSourceId = -1;

    public CmdSetAudioSource() {
        mType = CMD_TYPE_SETAUDIOSOURCE;
        mCmdName = getCmdName();
    }

    @Override
    public String toJsonString() {
        JSONObject argObject = new JSONObject();
        argObject.put("audioSource",mAudioSource);
        argObject.put("id",mSourceId);

        JSONObject jsonObject = new JSONObject();
        jsonObject.put("cmd",mCmdName);
        jsonObject.put("arg",argObject);

        return jsonObject.toJSONString();
    }

    @Override
    public String getActionValue() {
        String value = "";
        switch(mAudioSource){
            case AUDIO_SOURCE_CLOUDMUSIC:
                value = "切换到 云音乐";
                break;
            case AUDIO_SOURCE_CLOUDSTORYTELLING:
                value = "切换到 语言节目";
                break;
            case AUDIO_SOURCE_LOCALMUSIC:
                value = "切换到 本地音乐";
                break;
            case AUDIO_SOURCE_CLOUDNETFM:
                value = "切换到 网络电台";
                break;
            case AUDIO_SOURCE_AUX1:
                value = "切换到 AUX1";
                break;
            case AUDIO_SOURCE_AUX2:
                value = "切换到 AUX2";
                break;
            default:
                break;
        }
        return value;
    }

    @Override
    public void parseArgs() {
        if ((mCmdArgs == null) || (mCmdArgs.isEmpty())){
            return;
        }

        try {
            mAudioSource = JSON.parseObject(mCmdArgs).getString("audioSource");
            mSourceId = JSON.parseObject(mCmdArgs).getIntValue("id");
        }catch (Exception e){
            mAudioSource = "";
            mSourceId = -1;
        }
    }

    public void setAudioSource(String source){
        mAudioSource = source;
    }
}
