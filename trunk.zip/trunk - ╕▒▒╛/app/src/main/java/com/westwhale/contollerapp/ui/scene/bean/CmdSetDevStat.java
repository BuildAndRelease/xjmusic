package com.westwhale.contollerapp.ui.scene.bean;


import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;

public class CmdSetDevStat extends CmdActionBase {
    public final static String DEV_STAT_OPEN = "open";
    public final static String DEV_STAT_CLOSE = "close";

    private String mDevStat = DEV_STAT_CLOSE;

    public CmdSetDevStat() {
        mType = CMD_TYPE_SETDEVSTAT;
        mCmdName = getCmdName();
    }

    @Override
    public String toJsonString() {
        JSONObject argObject = new JSONObject();
        argObject.put("devStat",mDevStat);

        JSONObject jsonObject = new JSONObject();
        jsonObject.put("cmd",mCmdName);
        jsonObject.put("arg",argObject);

        return jsonObject.toJSONString();
    }

    @Override
    public String getActionValue() {
        String value = "关机";
        if (DEV_STAT_OPEN.equals(mDevStat)){
            value = "开机";
        }
        return value;
    }

    @Override
    public void parseArgs() {
        if ((mCmdArgs == null) || (mCmdArgs.isEmpty())){
            return;
        }

        try {
            mDevStat = JSON.parseObject(mCmdArgs).getString("devStat");
        }catch (Exception e){
            mDevStat = "";
        }
    }

    public void setDevStat(String stat){
        mDevStat = stat;
    }

    public String getDevStat(){
        return mDevStat;
    }
}
