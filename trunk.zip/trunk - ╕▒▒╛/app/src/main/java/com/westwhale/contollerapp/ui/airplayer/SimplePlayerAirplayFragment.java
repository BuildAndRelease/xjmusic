package com.westwhale.contollerapp.ui.airplayer;

import android.animation.ObjectAnimator;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.GestureDetector;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.LinearInterpolator;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.github.lzyzsd.circleprogress.DonutProgress;
import com.westwhale.contollerapp.R;
import com.westwhale.contollerapp.ui.base.fragment.PlayerBaseFragment;
import com.westwhale.contollerapp.ui.main.dialog.VolumeDialog;
import com.westwhale.api.protocolapi.bean.media.Media;
import com.westwhale.api.protocolapi.bean.hostroom.Room;

public class SimplePlayerAirplayFragment extends PlayerBaseFragment implements View.OnTouchListener, GestureDetector.OnGestureListener {
    private final static String TAG = "AirplayerSimple";

    private ImageView mMediaIv,mMediaListIv,mVolumeIv;
    private TextView mTitleTv,mSubTitleTv;
    private DonutProgress mSimplePlayProgress;
    private FrameLayout mPlayerButtonLayout;
    private LinearLayout mTitleLayout;

    protected ObjectAnimator mCircleAnimator;    //图片旋转动画

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        // 先显示加载动画，针对布局做一些初始化
        View view = inflater.inflate(R.layout.frag_airplay_player_simple,container,false);

        initView(view);

        initListener();

        updateMediaInfo();
        updatePlayStatInfo();

        return view;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
    }

    @Override
    public void onPause() {
        super.onPause();

        pauseCircleAnimator();
    }

    @Override
    public void onResume() {
        super.onResume();

        resumeCircleAnimator();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();

        if (mCircleAnimator != null) {
            mCircleAnimator.cancel();
        }
    }

    private void initView(View view) {
        if (null == view){
            return;
        }

        mMediaIv = view.findViewById(R.id.simple_player_img);
        mVolumeIv = view.findViewById(R.id.simple_player_volume);
        mTitleTv = view.findViewById(R.id.simple_player_title);

        initCireAnimator(mMediaIv);
    }

    private void initListener() {
        mMediaIv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // TODO: 2019/2/21 点击进入详细播放界面
            }
        });


        mVolumeIv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 弹出音量调节框
                VolumeDialog volumeDialog = new VolumeDialog();
                volumeDialog.show(getChildFragmentManager(),"Volume Dialog");
            }
        });

    }

    @Override
    public boolean isPlayerValid() {
        if ((Room.ChannelState.INAIRPLAY).equals(mRoomStat)){
            return true;
        }

        return false;
    }

    @NonNull
    @Override
    public String getMediaSrc() {
        return "";
    }


    @Override
    public void updateMedia(Media media) {

    }

    @Override
    public void updateMediaInfo(){
        // 设置主标题和副标题
        String title = "Airplay";
        String subTitle = "";
        mTitleTv.setText(title);

        // 设置图片
        mMediaIv.setImageResource(R.drawable.simple_player_default);
    }

    @Override
    public void updatePlayingMediaDuration(int duration) {

    }

    @Override
    public void updateMediaDurationInfo() {

    }

    @Override
    public void updatePlayTime(int playtime) {

    }

    @Override
    public void updatePlayTimeInfo() {

    }

    @Override
    public void updatePlayMode(String playMode) {

    }

    @Override
    public void updatePlayModeInfo() {
    }


    @Override
    public void updatePlayStat(String playStat) {

    }

    @Override
    public void updatePlayStatInfo() {
        // 更新播放状态
    }


    /******************************** 图片转动 ***********************************/
    private void initCireAnimator(@NonNull View view) {
        mCircleAnimator = ObjectAnimator.ofFloat(view, "rotation", 0.0f, 360.0f);
        mCircleAnimator.setDuration(20*1000);
        mCircleAnimator.setInterpolator(new LinearInterpolator());
        mCircleAnimator.setRepeatCount(-1);
        mCircleAnimator.setRepeatMode(ObjectAnimator.RESTART);
    }

    private void resumeCircleAnimator() {
        if (mCircleAnimator != null){
            if (mCircleAnimator.isStarted()){
                mCircleAnimator.resume();
            }else{
                mCircleAnimator.start();
            }
        }
    }

    private void pauseCircleAnimator() {
        if (mCircleAnimator != null){
            mCircleAnimator.pause();
        }
    }

    /******************************** 手势 ***********************************/
    private static final int FLING_MIN_DISTANCE = 80;// 移动最小距离
    private static final int FLING_MIN_VELOCITY = 200;// 移动最大速度
    //构建手势探测器
    GestureDetector mGesture = new GestureDetector(this);
    @Override
    public boolean onDown(MotionEvent e) {
        // 默认为false，最好设置为true，触发 performClick
        return true;
    }

    @Override
    public void onShowPress(MotionEvent e) {

    }

    @Override
    public boolean onSingleTapUp(MotionEvent e) {
        return false;
    }

    @Override
    public boolean onScroll(MotionEvent e1, MotionEvent e2, float distanceX, float distanceY) {
        return false;
    }

    @Override
    public void onLongPress(MotionEvent e) {

    }

    @Override
    public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX, float velocityY) {
        // e1：第1个ACTION_DOWN MotionEvent
        // e2：最后一个ACTION_MOVE MotionEvent
        // velocityX：X轴上的移动速度（像素/秒）
        // velocityY：Y轴上的移动速度（像素/秒）
        if (e2.getX() -e1.getX() >FLING_MIN_DISTANCE) {
            // 向右手势

        } else if (e1.getX() -e2.getX() > FLING_MIN_DISTANCE){
            // 向左手势

        }

        return false;
    }

    @Override
    public boolean onTouch(View v, MotionEvent event) {
        return mGesture.onTouchEvent(event);
    }
}
