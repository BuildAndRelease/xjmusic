package com.westwhale.contollerapp.ui.download.fragment;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.AppBarLayout;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;

import com.blankj.utilcode.util.ToastUtils;
import com.kingja.loadsir.callback.Callback;
import com.kingja.loadsir.callback.SuccessCallback;
import com.kingja.loadsir.core.LoadService;
import com.kingja.loadsir.core.LoadSir;
import com.scwang.smartrefresh.layout.api.RefreshLayout;
import com.scwang.smartrefresh.layout.listener.OnLoadMoreListener;
import com.scwang.smartrefresh.layout.listener.OnRefreshListener;
import com.westwhale.contollerapp.R;
import com.westwhale.contollerapp.application.WApp;
import com.westwhale.contollerapp.common.AppBarStateChangeListener;
import com.westwhale.contollerapp.dev.CmdActionLister;
import com.westwhale.contollerapp.dev.ICmdCallback;
import com.westwhale.contollerapp.dev.WRoom;
import com.westwhale.contollerapp.ui.base.fragment.BaseFragment;
import com.westwhale.contollerapp.ui.download.activity.DownloadedMultiActivity;
import com.westwhale.contollerapp.ui.download.adapter.DownloadedListAdapter;
import com.westwhale.contollerapp.ui.download.dialog.DownloadedItemMoreDialog;
import com.westwhale.contollerapp.ui.loadsircallback.EmptyCallback;
import com.westwhale.contollerapp.ui.loadsircallback.ErrorCallback;
import com.westwhale.contollerapp.ui.loadsircallback.LoadingCallback;
import com.westwhale.contollerapp.ui.loadsircallback.TimeoutCallback;
import com.westwhale.contollerapp.ui.main.MainRoomActivity;
import com.westwhale.api.protocolapi.bean.media.CloudMusic;
import com.westwhale.api.protocolapi.bean.media.Media;
import com.westwhale.api.protocolapi.bean.download.DownloadItem;

import java.util.ArrayList;
import java.util.List;

public class DownloadedListFragment extends BaseFragment implements DownloadedListAdapter.CallBack {

    private final static String TAG = DownloadedListFragment.class.getName();

    public static final int REQUEST_CODE_DETELE = 1;
    public static final int ACTIVITY_RESULT_CODE_DETELE = 1;

    private ActionBar mActionBar;
    private Toolbar mToolBar;
    private ImageView mHeaderTitleIv,mHeaderBgIv, mPlayIv, mDownloadingIv, mAddFavoriteIv, mEditIv;
    private TextView mSubtitleTv, mTitleTv;
    private FrameLayout mLoadingFLayout;
    private RecyclerView mRecyclerView;
    private RefreshLayout mRefreshLayout;
    private AppBarLayout mAppBarLayout;
    protected LoadService mLoadService;

    private DownloadedListAdapter mListAdapter;

    private String mFragmentTitle;
    private String mTitle;
    private String mSubtitle;


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        // 先显示加载动画，针对布局做一些初始化
        return inflater.inflate(R.layout.frag_download_downloaded, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        initView(view);
        initListener();

        initData();
    }

    @Override
    public void onDownloadedItemClick(List<DownloadItem<CloudMusic>> itemList, DownloadItem<CloudMusic> item) {
        // 播放下载歌曲
        CloudMusic media = (item == null) ? null : item.media;
        List<CloudMusic> mediaList = new ArrayList<>();
        if ((itemList != null) && (itemList.size() > 0)){
            for (int i=0; i < itemList.size(); i++){
                DownloadItem<CloudMusic> tempItem = itemList.get(i);
                if ((tempItem != null) && (tempItem.media != null)){
                    mediaList.add(tempItem.media);
                }
            }
        }
        if (mediaList.size() > 0){
            WRoom room = WApp.Instance.getDevManager().getSelectedRoom();
            if (room != null){
                WRoom.cmdPlayCloudMusicList(media,mediaList,new CmdActionLister<>(DownloadedListFragment.this, new ICmdCallback<Boolean>() {
                    @Override
                    public void onSuccess(Boolean data) {

                    }

                    @Override
                    public void onFailed(int code, String msg) {
                        ToastUtils.showShort("播放歌曲失败 %d...",code);
                    }
                }));
            }
        }else{
            ToastUtils.showShort("列表为空");
        }
    }

    @Override
    public void onDownloadedItemMoreClick(DownloadItem<CloudMusic> item) {
        // 弹出更多选项框
        DownloadedItemMoreDialog moreDialog = new DownloadedItemMoreDialog();
        moreDialog.setDataItem(item);
        moreDialog.setTargetFragment(DownloadedListFragment.this,REQUEST_CODE_DETELE);
        if (getFragmentManager() != null) {
            moreDialog.show(getFragmentManager(), DownloadedItemMoreDialog.TAG);
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_CODE_DETELE){
            if ((resultCode == Activity.RESULT_OK) || (resultCode == ACTIVITY_RESULT_CODE_DETELE)){
                // 若删除成功，则重新获取数据
                requestDataResource();
            }
        }
    }

    private void initView(View view) {
        mToolBar = view.findViewById(R.id.download_downloaded_toolbar);
        if (getActivity() != null) {
            ((AppCompatActivity) getActivity()).setSupportActionBar(mToolBar);
            mActionBar = ((AppCompatActivity) getActivity()).getSupportActionBar();
            if (mActionBar != null) {
                mActionBar.setDisplayHomeAsUpEnabled(true);
                mActionBar.setHomeAsUpIndicator(R.drawable.home_backup);
            }
        }

        mHeaderTitleIv = view.findViewById(R.id.download_downloaded_header_pic);
        mHeaderTitleIv.setImageResource(R.drawable.local_playlist_header_default);

        mHeaderBgIv = view.findViewById(R.id.download_downloaded_header_bg);
        mHeaderBgIv.setImageResource(R.drawable.local_playlist_header_mongo);

        mTitleTv = view.findViewById(R.id.download_downloaded_header_title);
        mSubtitleTv = view.findViewById(R.id.download_downloaded_header_subtitle);

        mPlayIv = view.findViewById(R.id.download_downloaded_header_play);
        mDownloadingIv = view.findViewById(R.id.download_downloaded_header_downloading);
        mAddFavoriteIv = view.findViewById(R.id.download_downloaded_header_favorite);
        mEditIv = view.findViewById(R.id.download_downloaded_header_edit);

        mLoadingFLayout = view.findViewById(R.id.download_downloaded_loadsir_layout);

        mRecyclerView = view.findViewById(R.id.download_downloaded_recyclerview);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(mContext);
        mRecyclerView.setLayoutManager(linearLayoutManager);
        mListAdapter = new DownloadedListAdapter(this);
        mRecyclerView.setAdapter(mListAdapter);
        mRecyclerView.setHasFixedSize(true);
        mRecyclerView.addItemDecoration(new DividerItemDecoration(mContext, DividerItemDecoration.VERTICAL));

        mRefreshLayout = view.findViewById(R.id.download_downloaded_refreshlayout);
        mRefreshLayout.setEnableRefresh(false);
//        mRefreshLayout.setDisableContentWhenRefresh(true);
        mRefreshLayout.setEnableLoadMore(true);

        mAppBarLayout = view.findViewById(R.id.download_downloaded_app_bar);


        LoadSir loadSir = new LoadSir.Builder()
                .addCallback(new LoadingCallback())
                .addCallback(new TimeoutCallback())
                .addCallback(new ErrorCallback())
                .addCallback(new EmptyCallback())
                .setDefaultCallback(LoadingCallback.class)
                .build();

//         创建mLoadService
        mLoadService = loadSir.register(mLoadingFLayout, new Callback.OnReloadListener() {
            @Override
            public void onReload(View v) {
                initData();
            }
        });
    }

    private void initListener() {
        mToolBar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (getActivity() != null){
                    getActivity().onBackPressed();
                }
            }
        });

        mPlayIv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 播放下载歌曲
                CloudMusic item = null;
                List<CloudMusic> itemList = new ArrayList<>();
                if (mListAdapter != null){
                    List<DownloadItem<CloudMusic>> dataList = mListAdapter.getDataList();
                    if ((dataList != null) && (dataList.size() > 0)){
                        for (int i=0; i < dataList.size(); i++){
                            DownloadItem<CloudMusic> tempItem = dataList.get(i);
                            if ((tempItem != null) && (tempItem.media != null)){
                                itemList.add(tempItem.media);
                            }
                        }
                    }
                }
                if (itemList.size() > 0){
                    item = itemList.get(0);
                    WRoom room = WApp.Instance.getDevManager().getSelectedRoom();
                    if (room != null){
                        WRoom.cmdPlayCloudMusicList(item,itemList,new CmdActionLister<>(DownloadedListFragment.this, new ICmdCallback<Boolean>() {
                            @Override
                            public void onSuccess(Boolean data) {

                            }

                            @Override
                            public void onFailed(int code, String msg) {
                                ToastUtils.showShort("播放歌曲失败 %d...",code);
                            }
                        }));
                    }
                }else{
                    ToastUtils.showShort("列表为空");
                }
            }
        });

        mDownloadingIv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 正在下载中 界面
                DownloadingListFragment fragment = new DownloadingListFragment();
                if (getActivity() instanceof MainRoomActivity){
                    ((MainRoomActivity) getActivity()).showFragment(fragment);
                }
            }
        });

        mAddFavoriteIv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // TODO: 2018-12-15  弹出添加到收藏界面
            }
        });

        mEditIv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 多选编辑界面
                if (mListAdapter != null) {
                    DownloadedMultiActivity.setDataList(mListAdapter.getDataList());
                    startActivityForResult(new Intent(getContext(), DownloadedMultiActivity.class), REQUEST_CODE_DETELE);
                }
            }
        });

        mRefreshLayout.setOnRefreshListener(new OnRefreshListener() {
            @Override
            public void onRefresh(@NonNull RefreshLayout refreshLayout) {
                initData();
            }
        });

        mRefreshLayout.setOnLoadMoreListener(new OnLoadMoreListener() {
            @Override
            public void onLoadMore(@NonNull RefreshLayout refreshLayout) {
                //  判断是否还有数据，从而判断是否还需要加载更多数据
                if( hasMoreData() ){
                    loadMoreData();
                }else {
                    mRefreshLayout.finishLoadMoreWithNoMoreData();
                }
            }
        });

        // 监听 AppBarLayout 的偏移状态，设置Toolbar的背景色
        mAppBarLayout .addOnOffsetChangedListener(new AppBarStateChangeListener() {
            @Override
            public void onStateChanged(AppBarLayout appBarLayout, State state) {
                if( state == State.EXPANDED ) {
                    //展开状态
                    mToolBar.setTitle(mFragmentTitle);
                }else if(state == State.COLLAPSED){
                    //折叠状态
                    mToolBar.setTitle(mTitle);
                }else {
                    //中间状态

                }
            }
        });
    }

    private void initData() {
        mFragmentTitle = "云音乐-下载";
        mTitle = "已下载";
        mSubtitle = "";

        mToolBar.setTitle(mFragmentTitle);
        mTitleTv.setText(mTitle);
        mSubtitleTv.setText(mSubtitle);

        mHasMoreData = false;

        if (mListAdapter != null){
            mListAdapter.clearDataList();
        }

        requestDataResource();
    }

    public void showLoadCallBack(Class<? extends Callback> callback){
        if (mLoadService != null){
            mLoadService.showCallback(callback);
            if (callback == SuccessCallback.class){
                if(mLoadingFLayout != null) {
                    mLoadingFLayout.setVisibility(View.INVISIBLE);
                }
                if (mRecyclerView != null){
                    mRecyclerView.setVisibility(View.VISIBLE);
                }

                if (mRefreshLayout != null){
                    mRefreshLayout.setEnableLoadMore(true);
                    mRefreshLayout.setEnableNestedScroll(true);
                }
            }else{
                if(mLoadingFLayout != null) {
                    mLoadingFLayout.setVisibility(View.VISIBLE);
                }
                if (mRecyclerView != null){
                    mRecyclerView.setVisibility(View.INVISIBLE);
                }

                if (mRefreshLayout != null){
                    mRefreshLayout.setEnableLoadMore(false);
                    mRefreshLayout.setEnableNestedScroll(false);
                }
            }
        }
    }


    private boolean mHasMoreData = false; // 记录是否还有更多数据

    private boolean hasMoreData() {
        return mHasMoreData;
    }

    private void loadMoreData() {
        requestDataResource();
    }

    private void updateDataList(List<DownloadItem<CloudMusic>> list) {
        if (list != null) {
            // 若刚开始加载数据，则先清空数据
            mListAdapter.setDataList(list);
            mListAdapter.notifyDataSetChanged();

            // 更新刷新等待状态
            mRefreshLayout.finishLoadMore();

            showLoadCallBack(SuccessCallback.class);
        }else{
            // 当获取数据失败时，则认为无数据了
            mHasMoreData = false;

            mRefreshLayout.finishLoadMore();
            showLoadCallBack(EmptyCallback.class);
        }
    }

    private void requestDataResource() {
        WRoom room = WApp.Instance.getDevManager().getSelectedRoom();
        if (room != null){
            String mediaSrc = Media.CLOUD_MUSIC;
            room.cmdGetDownloadedMusicList(mediaSrc,new CmdActionLister<List<DownloadItem<CloudMusic>>>(this, new ICmdCallback<List<DownloadItem<CloudMusic>>>() {
                @Override
                public void onSuccess(List<DownloadItem<CloudMusic>> data) {
                    updateDataList(data);
                }

                @Override
                public void onFailed(int code, String msg) {
                    updateDataList(null);
                    ToastUtils.showShort("GetFavoriteMedia Failed %d...,",code);
                }
            }));
        }else{
            updateDataList(null);
        }
    }


}
