package com.westwhale.contollerapp.dev;

import android.support.annotation.NonNull;


import com.westwhale.contollerapp.ui.base.activity.BaseActivity;
import com.westwhale.contollerapp.ui.base.dialog.AttachDialogFragment;
import com.westwhale.contollerapp.ui.base.fragment.BaseFragment;

public class CmdActionLister<T> implements BaseFragment.IDestroyListener,
        BaseActivity.IDestroyListener,
        AttachDialogFragment.IDestroyListener {

    private ICmdCallback<T> mCmdCallback;
    private Object mLifecycleObject;

    // 需注意： 在 cmdCallback 接口中，若使用了context中的UI变量，则需要在此处把 context 传入
    public CmdActionLister(@NonNull BaseFragment context, ICmdCallback<T> cmdCallback){
        context.registerDestroyedListener(this);
        mLifecycleObject = context;
        mCmdCallback = cmdCallback;
    }

    public CmdActionLister(@NonNull BaseActivity context, ICmdCallback<T> cmdCallback){
        context.registerDestroyedListener(this);
        mLifecycleObject = context;
        mCmdCallback = cmdCallback;
    }

    public CmdActionLister(@NonNull AttachDialogFragment context, ICmdCallback<T> cmdCallback){
        context.registerDestroyedListener(this);
        mLifecycleObject = context;
        mCmdCallback = cmdCallback;
    }

    public void callback(int resultCode,T data, String msg){
        // 若对象不存在，则需要把接口置为null
        if (mLifecycleObject instanceof BaseActivity){
            ((BaseActivity)mLifecycleObject).unRegisterDestroyedListener(this);
        }else  if (mLifecycleObject instanceof BaseFragment){
            ((BaseFragment)mLifecycleObject).unRegisterDestroyedListener(this);
        }else  if (mLifecycleObject instanceof AttachDialogFragment){
            ((AttachDialogFragment)mLifecycleObject).unRegisterDestroyedListener(this);
        }

        if (mCmdCallback == null){
            return;
        }

        if (resultCode == 0){
            mCmdCallback.onSuccess(data);
        }else{
            mCmdCallback.onFailed(resultCode,msg);
        }
    }

    @Override
    public void onFragmentPrepareDestroy() {
        mCmdCallback = null;
        mLifecycleObject = null;
    }

    @Override
    public void onActivityPrepareDestroy() {
        mCmdCallback = null;
        mLifecycleObject = null;
    }

    @Override
    public void onDialogPrepareDestroy() {
        mCmdCallback = null;
        mLifecycleObject = null;
    }
}
