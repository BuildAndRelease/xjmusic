package com.westwhale.contollerapp.ui.favorite.songsheet.adapter;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.util.SparseBooleanArray;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.TextView;

import com.westwhale.contollerapp.R;
import com.westwhale.api.protocolapi.bean.PlayList;

import java.util.ArrayList;
import java.util.List;

/**
 * Description:
 * Author: chenyaoli
 * Date: 2018-12-12
 * History:
 */
public class FavoriteMediaManagerMultiAdapter extends RecyclerView.Adapter {
    public int TYPE_ITEM = 0;

    private List<PlayList> mItemList;
    private SparseBooleanArray mSelectedPositions = new SparseBooleanArray();
    private CallBack mCallBack;

    public interface CallBack{
        void onItemClick(PlayList item, boolean selected);

        void onCheckedNumChanged(int selectednum);
    }

    public List<PlayList> getSelectedList(){
        List<PlayList> itemlist = new ArrayList<>();
        for (int i=0; i < mSelectedPositions.size(); i++){
            int index = mSelectedPositions.keyAt(i);
            if ((index > -1) && (mItemList != null) && (index < mItemList.size())){
                itemlist.add(mItemList.get(index));
            }
        }

        return itemlist;
    }

    public int getSelectedNum(){
        return mSelectedPositions.size();
    }

    public void selectAllItem(){
        if (mItemList != null){
            for (int i=0; i < mItemList.size(); i++){
                mSelectedPositions.put(i, true);
            }

            notifyDataSetChanged();

            if (mCallBack != null){
                mCallBack.onCheckedNumChanged(mSelectedPositions.size());
            }
        }
    }

    public void cancelAllItem(){
        mSelectedPositions.clear();
        notifyDataSetChanged();

        if (mCallBack != null){
            mCallBack.onCheckedNumChanged(mSelectedPositions.size());
        }
    }

    public void setDataList(List<PlayList> itemList){
        if (mItemList != null){
            mItemList.clear();
            notifyDataSetChanged();
        }
        this.mItemList = itemList;
    }

    private boolean isItemChecked(int position) {
        return mSelectedPositions.get(position);
    }

    public FavoriteMediaManagerMultiAdapter(CallBack callBack){
        this.mItemList = null;
        this.mCallBack = callBack;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_favorite_media_manager_multi, viewGroup, false);
        return new ItemHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder viewHolder, int i) {
        ItemHolder itemHolder = (ItemHolder)viewHolder;
        PlayList item = mItemList.get(i);
        boolean checkStat = isItemChecked(i);
        itemHolder.mCheckBox.setChecked(checkStat);
        if (item != null){
            itemHolder.mNameTv.setText(item.playListName);
        }

        itemHolder.mCheckBox.setClickable(false);
        itemHolder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if ((item ==null) || item.playListId == 0){
                    return;
                }
                boolean checkStat = isItemChecked(i);
                boolean newStat = !checkStat;
                if (newStat) {
                    mSelectedPositions.put(i, newStat);
                }else{
                    mSelectedPositions.delete(i);
                }

                if (mCallBack != null){
                    mCallBack.onCheckedNumChanged(mSelectedPositions.size());
                }

                notifyItemChanged(i);

                mCallBack.onItemClick(item,newStat);
            }
        });
    }

    @Override
    public int getItemViewType(int position) {
        return TYPE_ITEM;
    }

    @Override
    public int getItemCount() {
        return (null == mItemList) ? 0 : mItemList.size();
    }

    /**************************************   ItemHolder *******************************************/
    public class ItemHolder extends RecyclerView.ViewHolder{
        CheckBox mCheckBox;
        TextView mNameTv;
        public ItemHolder(@NonNull View itemView) {
            super(itemView);
            mCheckBox = itemView.findViewById(R.id.item_favorite_media_manager_checkbox);
            mNameTv = itemView.findViewById(R.id.item_favorite_media_manager_name);
        }
    }
}
