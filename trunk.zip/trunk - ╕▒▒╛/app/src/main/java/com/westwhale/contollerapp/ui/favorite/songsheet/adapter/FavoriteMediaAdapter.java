package com.westwhale.contollerapp.ui.favorite.songsheet.adapter;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.westwhale.contollerapp.R;
import com.westwhale.api.protocolapi.bean.media.CloudMusic;
import com.westwhale.api.protocolapi.bean.media.LocalMusic;
import com.westwhale.api.protocolapi.bean.media.Media;

import java.util.ArrayList;
import java.util.List;

public class FavoriteMediaAdapter extends RecyclerView.Adapter {
    private List<Media> mItemList;
    private CallBack mCallBack;

    public interface CallBack{
        void onMediaItemClick(List<Media> itemList, Media mediaItem);

        void onMediaItemMoreClick(Media mediaItem);
    }

    public void setDataList(List<Media> itemList){
        if (mItemList != null){
            mItemList.clear();
            notifyDataSetChanged();
        }
        mItemList = itemList;
    }

    public List<Media> getDataList(){
        return mItemList;
    }

    public void updateDataList(List<Media> itemList){
        if (mItemList != null){
            mItemList.clear();
            notifyDataSetChanged();
        }
        this.mItemList = itemList;
    }

    public void clearDataList(){
        if (mItemList != null){
            this.mItemList.clear();
        }
        notifyDataSetChanged();
    }

    public void addToDataList(List<Media> itemList){
        if (mItemList == null){
            mItemList = new ArrayList<>();
            notifyDataSetChanged();
        }
        mItemList.addAll(itemList);
    }

    public FavoriteMediaAdapter(CallBack callBack){
        this.mItemList = null;
        this.mCallBack = callBack;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        // 默认返回 HOST 类型的 viewHolder
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_favorite_media_media, viewGroup, false);
        return new ItemHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder viewHolder, int i) {
        Media item = mItemList.get(i);
        ItemHolder itemHolder = (ItemHolder)viewHolder;
        itemHolder.mItemNoTv.setText(String.valueOf(i+1));
        String title = "";
        String subtitle = "";
        switch(item.mediaSrc){
            case Media.CLOUD_MUSIC:
                title = ((CloudMusic)item).songName;
                subtitle = ((CloudMusic)item).getSingersName();
                break;
            case Media.LOCAL_MUSIC:
                title = ((LocalMusic)item).songName;
                subtitle = item.mediaSrc;
                break;
            default:
                subtitle = item.mediaSrc;
                break;
        }
        itemHolder.mTitleTv.setText(title);
        itemHolder.mSubTitleTv.setText(subtitle);

        viewHolder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mCallBack.onMediaItemClick(mItemList,item);
            }
        });

        ((ItemHolder)viewHolder).mItemMoreIv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mCallBack.onMediaItemMoreClick(item);
            }
        });
    }

    @Override
    public int getItemCount() {
        return (mItemList != null) ? mItemList.size() : 0;
    }

    private class ItemHolder extends RecyclerView.ViewHolder{
        ImageView mItemMoreIv;
        TextView mItemNoTv, mTitleTv, mSubTitleTv;
        public ItemHolder(@NonNull View itemView) {
            super(itemView);
            mItemMoreIv = itemView.findViewById(R.id.favorite_media_media_item_more);
            mItemNoTv = itemView.findViewById(R.id.favorite_media_media_item_no);
            mTitleTv = itemView.findViewById(R.id.favorite_media_media_item_title);
            mSubTitleTv = itemView.findViewById(R.id.favorite_media_media_item_subtitle);
        }
    }
}
