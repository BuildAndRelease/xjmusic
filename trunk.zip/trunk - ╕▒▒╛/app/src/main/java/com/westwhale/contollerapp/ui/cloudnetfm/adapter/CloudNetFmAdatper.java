package com.westwhale.contollerapp.ui.cloudnetfm.adapter;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.util.Base64;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.load.resource.bitmap.RoundedCorners;
import com.bumptech.glide.request.RequestOptions;
import com.westwhale.contollerapp.R;
import com.westwhale.api.protocolapi.bean.media.CloudNetFm;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

/**
 * Description:
 * Author: chenyaoli
 * Date: 2018-12-06
 * History:
 */
public class CloudNetFmAdatper extends RecyclerView.Adapter{

    private List<CloudNetFm> mItemList;
    private CallBack mCallBack;

    public CloudNetFmAdatper(CallBack callBack){
        this.mCallBack = callBack;
    }

    public interface CallBack{
        void onItemClick(CloudNetFm item);
    }

    public void updateDataList(List<CloudNetFm> dataList){
        mItemList = dataList;
    }

    public void clearDataList(){
        if (mItemList != null){
            this.mItemList.clear();
        }
        notifyDataSetChanged();
    }

    public void addToDataList(List<CloudNetFm> itemList){
        if (mItemList == null){
            mItemList = new ArrayList<>();
        }
        mItemList.addAll(itemList);
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_cloudnetfm_item, viewGroup, false);
        return new CloudNetFmItemHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder viewHolder, int i) {
        final CloudNetFm item = mItemList.get(i);
        CloudNetFmItemHolder itemHolder = (CloudNetFmItemHolder)viewHolder;

        String text = (i+1) + "";
        itemHolder.mNumTv.setText(text);

        itemHolder.mTitleTv.setText(item.name);

        text = "正在直播:" + item.programName;
        itemHolder.mSecondItemTv.setText(text);

        text = "";
        DecimalFormat df = new DecimalFormat("#.0");
        if (item.playCount > 10000*10000){
            float count = item.playCount / 100000000.0f;
            text = df.format(count) + "亿人";
        }else if (item.playCount > 10000){
            float count = item.playCount / 10000.0f;
            text = df.format(count) + "万人";
        }else{
            text = item.playCount + "人";
        }

        itemHolder.mThirdItemTv.setText(text);



        // 首先 base64 解码
        String pic = (item.picUrl != null) ? item.picUrl : "";
        String url = pic;
        try{
            if (!pic.startsWith("http://")){
                url = new String(Base64.decode(pic.getBytes(), Base64.DEFAULT));
            }
        }catch (Exception e){
            url = "";
            e.printStackTrace();
        }
        //设置图片圆角角度
        RoundedCorners roundedCorners= new RoundedCorners(6);
        //通过RequestOptions扩展功能,override:采样率,因为ImageView就这么大,可以压缩图片,降低内存消耗
        RequestOptions mRequestOptions = RequestOptions.bitmapTransform(roundedCorners).diskCacheStrategy(DiskCacheStrategy.NONE) //不做磁盘缓存
                .placeholder(R.drawable.cloud_album_default)  //未加载图片之前显示的图片
                .error(R.drawable.cloud_album_default)     //错误时显示的图片
                .override(350, 350);
//                      .skipMemoryCache(true);//不做内存缓存
        Glide.with(itemHolder.itemView)
                .load(url)
                .apply(mRequestOptions)
                .into(itemHolder.mItemPicIv);

        viewHolder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mCallBack.onItemClick(item);
            }
        });
    }

    @Override
    public int getItemCount() {
        return (mItemList == null) ? 0 : mItemList.size();
    }


    private class CloudNetFmItemHolder extends RecyclerView.ViewHolder{
        ImageView mItemPicIv;
        TextView mNumTv, mTitleTv,mSecondItemTv,mThirdItemTv;
        public CloudNetFmItemHolder(@NonNull View itemView) {
            super(itemView);
            mNumTv = itemView.findViewById(R.id.item_netfm_no);
            mItemPicIv = itemView.findViewById(R.id.item_netfm_pic);
            mTitleTv = itemView.findViewById(R.id.item_netfm_title);
            mSecondItemTv = itemView.findViewById(R.id.item_netfm_two);
            mThirdItemTv = itemView.findViewById(R.id.item_netfm_three);
        }
    }
}