package com.westwhale.contollerapp.eventbus;


import com.westwhale.api.protocolapi.bean.hostroom.Host;

/**
 * Description:
 * Author: chenyaoli
 * Date: 2018-12-24
 * History:
 */
public class CheckAppUpdateEvent {
    private boolean mNeedUpdate;
    public CheckAppUpdateEvent(boolean needupdate){
        mNeedUpdate = needupdate;
    }

    public boolean getAppUpdateStat() {
        return mNeedUpdate;
    }
}
