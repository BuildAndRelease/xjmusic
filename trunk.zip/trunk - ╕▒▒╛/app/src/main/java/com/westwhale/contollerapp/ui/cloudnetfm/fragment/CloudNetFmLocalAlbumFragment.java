package com.westwhale.contollerapp.ui.cloudnetfm.fragment;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.View;
import android.widget.Toast;

import com.alibaba.fastjson.JSONReader;
import com.kingja.loadsir.callback.SuccessCallback;
import com.lzy.okgo.OkGo;
import com.lzy.okgo.callback.AbsCallback;
import com.lzy.okgo.model.Response;
import com.westwhale.contollerapp.application.WApp;
import com.westwhale.contollerapp.common.LocationResponse;
import com.westwhale.contollerapp.dev.CmdActionLister;
import com.westwhale.contollerapp.dev.ICmdCallback;
import com.westwhale.contollerapp.dev.WRoom;
import com.westwhale.contollerapp.ui.loadsircallback.EmptyCallback;
import com.westwhale.api.protocolapi.bean.media.CloudNetFm;

import java.util.List;

import okhttp3.ResponseBody;

public class CloudNetFmLocalAlbumFragment extends CloudNetFmBaseFragment {
    private int mCurPageNo = 1; //记录当前的页面数, 云音乐歌手获取时必须从第一页开始
    private int mPageSize = 50;
    private boolean mHasMoreData = true; // 记录是否还有更多数据

    private LocationResponse mLocation = null;

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        //初始化 toolbar
        configToolBar(mToolBar,"本地台");

        mCategoryLayout.setVisibility(View.GONE);

    }

    @Override
    protected void initData() {
        mCurPageNo = 1;
        mHasMoreData = true;

        // 每次先清空原有数据
        if (mAdapter != null){
            mAdapter.clearDataList();
        }

        if (mLocation != null){
            requestCloudResource();
        }else{
            // 获取本地省份的code
            requestLocalProvince();
        }
    }

    @Override
    protected boolean hasMoreData() {
        return mHasMoreData;
    }

    @Override
    protected void loadMoreData() {
        mCurPageNo++;
        requestCloudResource();
    }

    @Override
    protected void updateDataList(List<CloudNetFm> list) {
        if (list != null) {
            // 若无法获取到数据，则认为已经到底
            int size = list.size();

            if (mCurPageNo == 0) {
                mAdapter.clearDataList();
            }

            if (size != 0){
                int startIndex = mAdapter.getItemCount();
                mAdapter.addToDataList(list);
                mAdapter.notifyItemRangeInserted(startIndex,size);
            }else{
                mHasMoreData = false;
            }

            // 更新刷新等待状态
            mRefreshLayout.finishRefresh();
            mRefreshLayout.finishLoadMore();

            showLoadCallBack(SuccessCallback.class);
        }else{
            // 当获取数据失败时，则认为无数据了
            mHasMoreData = false;

            // 更新刷新等待状态
            mRefreshLayout.finishRefresh();
            mRefreshLayout.finishLoadMore();

            showLoadCallBack(EmptyCallback.class);
        }
    }

    @Override
    protected void requestCloudResource() {
        WRoom room = WApp.Instance.getDevManager().getSelectedRoom();
        if (room != null){
            String provinceCodeStr = ((mLocation != null) && (mLocation.data != null)) ? mLocation.data.adcode : "";
            int provinceCode =  -1;
            try {
                provinceCode = Integer.parseInt(provinceCodeStr);
            }catch (Exception e){
                e.printStackTrace();
            }
            room.cmdGetNetFmByCode(provinceCode,mCurPageNo,mPageSize, new CmdActionLister<List<CloudNetFm>>(this, new ICmdCallback<List<CloudNetFm>>() {
                @Override
                public void onSuccess(List<CloudNetFm> data) {
                    updateDataList(data);
                }

                @Override
                public void onFailed(int code, String msg) {
                    updateDataList(null);
                    Toast.makeText(getContext(),"GetNetFmByCode获取失败:"+code,Toast.LENGTH_SHORT).show();
                }
            }));
        }else{
            updateDataList(null);
        }
    }

    private void requestLocalProvince(){
        //"http://cloud.touchus.com/ossapi/audiotml/getAreaByIp.json"
        String url = "http://cloud.touchus.com/ossapi/audiotml/getAreaByIp.json";

        OkGo.<LocationResponse>get(url).execute(new AbsCallback<LocationResponse>() {
            @Override
            public void onSuccess(Response<LocationResponse> response) {
                // UI线程
                LocationResponse result = response.body();
                if ((result != null) && result.success && result.data != null){
                    mLocation = result;

                    requestCloudResource();
                }else{
                    showLoadCallBack(EmptyCallback.class);
                }
            }

            @Override
            public LocationResponse convertResponse(okhttp3.Response response) throws Throwable {
                // 子线程
                LocationResponse resultJson = null;

                ResponseBody body = response.body();
                if (body != null){
                    JSONReader jsonReader = new JSONReader(body.charStream());
                    resultJson = jsonReader.readObject(LocationResponse.class);
                }

                return resultJson;
            }

            @Override
            public void onError(Response<LocationResponse> response) {
                // UI线程
                super.onError(response);

                showLoadCallBack(EmptyCallback.class);
            }
        });
    }
}
