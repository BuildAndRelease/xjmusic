package com.westwhale.contollerapp.ui.cloudstory.fragment;

import android.os.Bundle;
import android.util.Base64;
import android.widget.Toast;

import com.kingja.loadsir.callback.SuccessCallback;
import com.westwhale.contollerapp.application.WApp;
import com.westwhale.contollerapp.dev.CmdActionLister;
import com.westwhale.contollerapp.dev.ICmdCallback;
import com.westwhale.contollerapp.dev.WRoom;
import com.westwhale.contollerapp.ui.loadsircallback.EmptyCallback;
import com.westwhale.contollerapp.ui.loadsircallback.LoadingCallback;
import com.westwhale.api.protocolapi.bean.albumSet.StoryTelling;
import com.westwhale.api.protocolapi.bean.media.Section;

import java.util.List;

public class CloudStoryMediaListAlbumFragment extends CloudStoryMediaListBaseFragment {

    private int mCurPageNo = 1;
    private int mPageSize = 100;
    private boolean mHasMoreData = true; // 记录是否还有更多数据

    private StoryTelling mStoryTellingSet;

    public void updateStoryTellingSet(StoryTelling storyTellingItem){
        mStoryTellingSet = storyTellingItem;
    }

    @Override
    public void initData() {
        showLoadCallBack(LoadingCallback.class);

        updateHeaderInfo();

        // 每次先清空原有数据
        mCurPageNo = 1;
        mHasMoreData = true;
        if (mMediaAdapter != null){
            mMediaAdapter.clearDataList();
        }

        requestCloudResource();
    }

    @Override
    public boolean hasMoreData() {
        return mHasMoreData;
    }

    @Override
    public void loadMoreData() {
        mCurPageNo++;
        requestCloudResource();
    }

    @Override
    public void requestCloudResource() {
        WRoom room = WApp.Instance.getDevManager().getSelectedRoom();
        if (room != null){
            int mediaId = (mStoryTellingSet != null) ? mStoryTellingSet.id : 0;
            WRoom.cmdGetStorytellingPlaylist(mediaId,mPageSize, mCurPageNo, new CmdActionLister<List<Section>>(this, new ICmdCallback<List<Section>>() {
                @Override
                public void onSuccess(List<Section> data) {
                    updateDataList(data);
                }

                @Override
                public void onFailed(int code, String msg) {
                    updateDataList(null);
                    Toast.makeText(getContext(),"GetStorytellingPlaylist获取失败:"+code,Toast.LENGTH_SHORT).show();
                }
            }));
        }else{
            updateDataList(null);
        }
    }

    @Override
    public void updateDataList(List<Section> list){
        if (list != null){
            // 若无法获取到数据，则认为已经到底
            int size = list.size();

            if (mCurPageNo == 1) {
                mMediaAdapter.clearDataList();
            }

            if (size != 0){
                int startIndex = mMediaAdapter.getItemCount();
                mMediaAdapter.addToDataList(list);
                mMediaAdapter.notifyItemRangeInserted(startIndex,size);
            }else{
                mHasMoreData = false;
            }

            // 更新刷新等待状态
            mRefreshLayout.finishRefresh();
            mRefreshLayout.finishLoadMore();

            showLoadCallBack(SuccessCallback.class);
        }else{
            mHasMoreData = false;

            // 更新刷新等待状态
            mRefreshLayout.finishRefresh();
            mRefreshLayout.finishLoadMore();

            showLoadCallBack(EmptyCallback.class);
        }
    }

    private void updateHeaderInfo(){
        String toolbarTitle = "";
        if (getArguments() != null){
            Bundle bundle = getArguments();
            toolbarTitle = bundle.getString("toolbarTitle");
        }

        String title = (mStoryTellingSet != null) ? mStoryTellingSet.mediaName : "";
        String subTitle = (mStoryTellingSet != null) ? mStoryTellingSet.description : "";
        String picUrl = "";
        if (mStoryTellingSet != null){
            picUrl = (mStoryTellingSet.getPic() != null) ? mStoryTellingSet.getPic() : "";
            if (!picUrl.startsWith("http://")){
                try {
                    picUrl = new String(Base64.decode(picUrl, Base64.DEFAULT));
                }catch (Exception e){
                    picUrl = "";
                }
            }
        }

        updateHeader(toolbarTitle,title,subTitle,picUrl);
    }
}
