package com.westwhale.contollerapp.ui.widget.dialog;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.DialogFragment;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.TextView;

import com.westwhale.contollerapp.R;
import com.westwhale.contollerapp.ui.base.dialog.AttachDialogFragment;
import com.westwhale.contollerapp.ui.timer.activity.TimerAddEditActivity;
import com.westwhale.contollerapp.ui.widget.interfs.DialogResultListener;


public class TextEditDialog extends AttachDialogFragment {
    public static final String TAG = TextEditDialog.class.getName();

    public static final String DIALOG_TITLE = "title";
    public static final String TEXT_NAME = "name";
    public static final String TEXT_VALUE = "value";
    public static final String TEXT_HINT = "hint";

    private EditText mNameEv;
    private TextView mTitleTv, mCancelTv,mOKTv;

    private DialogResultListener<String> mResultListener;

    public void setOnDialogResultListener(DialogResultListener<String> listener){
        mResultListener = listener;
    }

    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);
        if (!isVisibleToUser){
            hideSoftInputFromWindow();
        }
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // 背景色，动画效果，通过主题设置
        setStyle(DialogFragment.STYLE_NORMAL, R.style.CommonDialogStyle);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        //布局
        View view = inflater.inflate(R.layout.dialogfrag_textedit, container);

        initView(view);
        initListener();

        return view;
    }

    @Override
    public void onStart() {
        super.onStart();

        //设置fragment高度 、宽度
        double heightPercent = 0.5;
        double widthPercent = 0.85;
        int dialogHeight = (int) (mContext.getResources().getDisplayMetrics().heightPixels * heightPercent);
        int dialogWidth = (int) (mContext.getResources().getDisplayMetrics().widthPixels * widthPercent);
        Window window = getDialog().getWindow();
        if (window != null) {
            WindowManager.LayoutParams params = window.getAttributes();
            params.gravity = Gravity.CENTER;
            params.width = dialogWidth;
//            params.height = dialogHeight;
            params.height = ViewGroup.LayoutParams.WRAP_CONTENT;
            window.setAttributes(params);
        }
        getDialog().setCanceledOnTouchOutside(true);

        initData();
    }

    private void initView(View view) {

        mTitleTv = view.findViewById(R.id.dialog_textedit_title);
        mNameEv = view.findViewById(R.id.dialog_textedit_edit);
        mCancelTv = view.findViewById(R.id.dialog_textedit_cancel);
        mOKTv = view.findViewById(R.id.dialog_textedit_ok);
    }

    private void initListener() {
        mCancelTv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dismiss();
            }
        });

        mOKTv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 把选中的结果传递出去
                String name = mNameEv.getText().toString();
                if (name.isEmpty()){
                    return;
                }

                if (mResultListener != null){
                    mResultListener.onResultListener(name);
                }

                dismiss();
            }
        });
    }

    private void initData() {
        String title = "";
        String nameText = "";
        String valueText = "";
        String hintText = "";
        Bundle bundle = getArguments();
        if (getArguments() != null){
            title = bundle.getString(DIALOG_TITLE,"");
            nameText = bundle.getString(TEXT_NAME,"");
            valueText = bundle.getString(TEXT_VALUE,"");
            hintText = bundle.getString(TEXT_HINT,"");
        }

        mTitleTv.setText(title);
        mNameEv.setHint(hintText);

        mNameEv.setText(valueText);
        mNameEv.setSelection(valueText.length());
    }

    private void hideSoftInputFromWindow(){
        // 隐藏虚拟键盘
        if (getActivity() != null){
            InputMethodManager imm = (InputMethodManager)getActivity().getSystemService(Context.INPUT_METHOD_SERVICE);
            if (imm != null) {
                imm.hideSoftInputFromWindow(mNameEv.getWindowToken(), 0);
            }
        }
    }

}
