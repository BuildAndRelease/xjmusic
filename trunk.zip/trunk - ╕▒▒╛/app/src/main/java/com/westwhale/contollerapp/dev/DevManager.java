package com.westwhale.contollerapp.dev;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.util.Pair;

import com.blankj.utilcode.util.LogUtils;
import com.blankj.utilcode.util.NetworkUtils;
import com.westwhale.api.protocolapi.BaApi;
import com.westwhale.api.protocolapi.BaProtocolBean;
import com.westwhale.api.protocolapi.CMD;
import com.westwhale.api.protocolapi.bean.hostroom.Host;
import com.westwhale.api.protocolapi.bean.hostroom.Room;
import com.westwhale.api.protocolapi.net.SocketService;
import com.westwhale.api.protocolapi.util.BaUtil;
import com.westwhale.api.protocolapi.util.Consumer;
import com.westwhale.api.protocolapi.util.SLog;
import com.westwhale.contollerapp.eventbus.SearchHostEvent;
import com.westwhale.contollerapp.eventbus.notify.NotifyDevStatJsonEvent;

import org.greenrobot.eventbus.EventBus;
import org.json.JSONObject;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class DevManager {

    private HashMap<String, Host> mHostMap = new HashMap<>();  // 搜索到的主机列表
    private WHost mSelectedHost; // 当前选中房间所属主机
    private WRoom mSelectedWRoom;  // 当前选中房间

    private String mDeviceUUID;  // API中所需的设备ID
    private Context mContext;   // 建议配置 application

    public DevManager(@NonNull Context context,@NonNull String appSendUuid){
        mContext = context;
        mDeviceUUID = appSendUuid;

        initWestWhaleSdk();
    }


    private void initWestWhaleSdk(){

        // 配置ID
        BaApi.getInstance().initSendId(mDeviceUUID);

        // 启动SOCKET 服务
        mContext.startService(new Intent(mContext, SocketService.class));

        SocketService.configureDebugMode(true);
        // 定义一个 SocketService UDP广播 回调函数
        SocketService.setConsumer(new Consumer<Pair<String, String>>() {
            @Override
            public void accept(Pair<String, String> object) {
                String info = object.first;
                String ip = object.second;
                if ((null == ip) || (null == info)){
                    return;
                }

                String selfIp = NetworkUtils.getIPAddress(true);
                if (ip.equals(selfIp)){
                    return;
                }
                handleApiCallback(ip,info,true);
            }
        });
    }



    // UDP 广播信息的回调函数
    private void handleApiCallback(String ip, String jsonInfo,boolean fromUdp){
        try {
            BaProtocolBean head = new BaProtocolBean(jsonInfo);
            if ((CMD.SEARCH_HOST).equals(head.cmd) && ((API_DEFINE.CMD_DIRECTION_RESPONE).equals(head.direction))){
                Host host = Host.parse(head.arg, ip);
                EventBus.getDefault().post(new SearchHostEvent(host));
            }else{
                // 若未选择房间，则需要监听房间的开关状态广播，并把开关状态与正常的开关状态区分开来
                // 若不是搜索主机的广播，则只接收本机IP的消息，忽略其它主机的广播信息
                Host host = (mSelectedHost != null) ? mSelectedHost.getHost() : null;
                if (host == null){
                    if ((CMD.NOTIFY_DEV_STAT).equals(head.cmd)){
                        EventBus.getDefault().post(new NotifyDevStatJsonEvent(head));
                    }
                }else{
                    // 广播机制，若有TCP长连接，则使用长连接，若没有，则使用UDP
                    boolean recvDataFlag = false;
                    if (MachineType.hasFunc_TcpBroadcast(host.deviceType)){
                        if (!fromUdp){
                            recvDataFlag = true;
                        }
                    }else{
                        recvDataFlag = true;
                    }
                    if (recvDataFlag) {
                        if (ip.equals(host.ipAddress)) {
                            if (checkNeedAccptNotify(head.sendId)) {
                                mSelectedWRoom.parseNotifyInfo(head);
                            }
                        }
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private boolean checkNeedAccptNotify(String sendId){
        boolean isAccept = false;

        // 只接受当前主机和当前房间的广播
        if ((mSelectedHost != null) && (mSelectedHost.getHost().id.equals(sendId))){
            isAccept = true;
        }else if ((mSelectedWRoom != null) && (mSelectedWRoom.getRoomId().equals(sendId))){
            isAccept = true;
        }

        return isAccept;
    }

    public HashMap<String, Host> getHostMap() {
        return mHostMap;
    }

    public Host insertHostMap(String hostId, Host host){
        return mHostMap.put(hostId,host);
    }

    public Host getHostById(String hostId){
        return mHostMap.get(hostId);
    }

    public Room getRoomById(String roomId){
        Room room = null;

        for (Host host : mHostMap.values()){
            if ((host != null) && (host.rooms != null)){
                List<Room> roomList = host.rooms;
                for (Room tempRoom : roomList){
                    if (tempRoom.roomId.equals(roomId)){
                        room = tempRoom;
                        break;
                    }
                }
                if (room != null){
                    break;
                }
            }
        }

        return room;
    }
    public Room getRoomById(String hostId, String roomId){
        Room room = null;
        if (mHostMap.containsKey(hostId)){
            Host host = mHostMap.get(hostId);
            if ((host != null) && (host.rooms != null)){
                List<Room> roomList = host.rooms;
                for (Room tempRoom : roomList){
                    if (tempRoom.roomId.equals(roomId)){
                        room = tempRoom;
                        break;
                    }
                }
            }
        }

        return room;
    }


    public void setCurrentRoom(String hostId, String roomId) {
        Host host = getHostById(hostId);
        Room room = getRoomById(hostId,roomId);
        if ((host != null) && (room != null)){
            mSelectedHost =  new WHost(host);

            mSelectedWRoom = new WRoom(room,host.ipAddress);

            // 选择某房间后，配置房间的基本信息
            BaApi.getInstance().setRoomInfo(mSelectedHost.getHost().ipAddress,roomId);

            if (MachineType.hasFunc_TcpBroadcast(mSelectedHost.getHost().deviceType)) {
                SocketService.startBroadcastTcpListener(mSelectedHost.getHost().ipAddress, mSelectedHost.getHost().id, new Consumer<Pair<String, String>>() {
                    @Override
                    public void accept(Pair<String, String> stringStringPair) {
                        String info = stringStringPair.first;
                        String ip = stringStringPair.second;
                        if ((null == ip) || (null == info)) {
                            return;
                        }
                        handleApiCallback(ip, info, false);
                    }
                });
            }
        }
    }

    public WRoom getSelectedRoom(){
        return mSelectedWRoom;
    }

    public WHost getSelectedHost(){
        return mSelectedHost;
    }

    public void resetHostAndRoom() {
        mHostMap.clear();

        mSelectedHost = null;
        mSelectedWRoom = null;
    }

}
