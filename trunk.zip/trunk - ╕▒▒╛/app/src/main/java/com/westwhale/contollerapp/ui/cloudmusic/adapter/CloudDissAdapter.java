package com.westwhale.contollerapp.ui.cloudmusic.adapter;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.util.Base64;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.load.resource.bitmap.CenterCrop;
import com.bumptech.glide.request.RequestOptions;
import com.westwhale.contollerapp.R;
import com.westwhale.api.protocolapi.bean.albumSet.CloudDissSet;

import java.util.ArrayList;
import java.util.List;

public class CloudDissAdapter extends RecyclerView.Adapter {
    public int TYPE_ITEM = 0;

    private List<CloudDissSet> mItemList;
    private CallBack mCallBack;

    public interface CallBack{
        void onDissItemClick(CloudDissSet dissItem);
    }

    public void updateDataList(List<CloudDissSet> itemList){
        this.mItemList = itemList;
    }

    public void clearDataList(){
        if (mItemList != null){
            this.mItemList.clear();
        }
        notifyDataSetChanged();
    }

    public void addToDataList(List<CloudDissSet> itemList){
        if (mItemList == null){
            mItemList = new ArrayList<>();
        }
        mItemList.addAll(itemList);
    }

    public CloudDissAdapter(CallBack callBack){
        this.mItemList = null;
        this.mCallBack = callBack;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        // 默认返回 HOST 类型的 viewHolder
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_netmusic_diss, viewGroup, false);
        return new CloudDissItemHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder viewHolder, int i) {
        if (viewHolder instanceof CloudDissItemHolder){
            final CloudDissSet item = mItemList.get(i);
            CloudDissItemHolder itemHolder = (CloudDissItemHolder)viewHolder;
            itemHolder.mTitleTv.setText(item.dissName);
            itemHolder.mSubTitleTv.setText(item.createrName);

            // 首先 base64 解码
            String pic = (item.getPic() != null) ? item.getPic() : "";
            String url = new String(Base64.decode(pic.getBytes(), Base64.DEFAULT));
            //通过RequestOptions扩展功能,override:采样率,因为ImageView就这么大,可以压缩图片,降低内存消耗
            RequestOptions mRequestOptions = RequestOptions.bitmapTransform(new CenterCrop()).diskCacheStrategy(DiskCacheStrategy.NONE) //不做磁盘缓存
                    .placeholder(R.drawable.cloud_diss_default)  //未加载图片之前显示的图片
                    .error(R.drawable.cloud_diss_default);     //错误时显示的图片
//                      .skipMemoryCache(true);//不做内存缓存
            Glide.with(itemHolder.itemView)
                    .load(url)
                    .apply(mRequestOptions)
                    .into(itemHolder.mPicIv);

            itemHolder.mPicIv.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    mCallBack.onDissItemClick(item);
                }
            });
        }
    }

    @Override
    public int getItemCount() {
        return (null == mItemList) ? 0 : mItemList.size();
    }

    @Override
    public int getItemViewType(int position) {
        return TYPE_ITEM;
    }

    private class CloudDissItemHolder extends RecyclerView.ViewHolder{
        ImageView mPicIv;
        TextView mTitleTv, mSubTitleTv;
        CloudDissItemHolder(@NonNull View itemView) {
            super(itemView);
            mPicIv = itemView.findViewById(R.id.netmusic_diss_item_pic);
            mTitleTv = itemView.findViewById(R.id.netmusic_diss_item_title);
            mSubTitleTv = itemView.findViewById(R.id.netmusic_diss_item_subtitle);
        }
    }

}
