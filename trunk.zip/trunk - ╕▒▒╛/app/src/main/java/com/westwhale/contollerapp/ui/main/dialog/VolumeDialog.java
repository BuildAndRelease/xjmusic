package com.westwhale.contollerapp.ui.main.dialog;

import android.annotation.SuppressLint;
import android.app.ActionBar;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.DialogFragment;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import com.blankj.utilcode.util.LogUtils;
import com.westwhale.contollerapp.R;
import com.westwhale.contollerapp.application.WApp;
import com.westwhale.contollerapp.dev.API_DEFINE;
import com.westwhale.contollerapp.dev.CmdActionLister;
import com.westwhale.contollerapp.dev.ICmdCallback;
import com.westwhale.contollerapp.dev.WRoom;
import com.westwhale.contollerapp.eventbus.notify.NotifyMuteEvent;
import com.westwhale.contollerapp.eventbus.notify.NotifyVolumeEvent;
import com.westwhale.contollerapp.ui.base.dialog.AttachDialogFragment;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

/**
 * Description:
 * Author: chenyaoli
 * Date: 2019-04-06
 * History:
 */
public class VolumeDialog extends AttachDialogFragment implements View.OnTouchListener {

    private ImageView mVolumeMuteIv;
    private TextView mVolumeValueTv;
    private SeekBar mSeekbar;

    private String mMuteStat;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // 背景色，动画效果，通过主题设置
        setStyle(DialogFragment.STYLE_NORMAL, R.style.NoAnimateDialogStyle);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        //布局
        View view = inflater.inflate(R.layout.dialogfrag_volume, container);

        initView(view);
        initListener();

        initData();

        return view;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();

        // eventbus 取消注册
        EventBus.getDefault().unregister(this);
    }


    @Override
    public void onStart() {
        super.onStart();

        //设置fragment高度 、宽度
        double widthPercent = 0.9;
        int dialogWidth = (int) (mContext.getResources().getDisplayMetrics().widthPixels * widthPercent);
        Window window = getDialog().getWindow();
        WindowManager.LayoutParams params = window.getAttributes();
        params.gravity = Gravity.CENTER;
        params.width = dialogWidth;
        params.height = ActionBar.LayoutParams.WRAP_CONTENT;
        params.dimAmount = 0.1f;  //外背景透明度
        window.setAttributes(params);
        getDialog().setCanceledOnTouchOutside(true);

        //重新获取一次音量，用于更新数据
        WRoom room = WApp.Instance.getDevManager().getSelectedRoom();
        if (room != null){
            room.cmdGetVolume(new CmdActionLister<Integer>(this, new ICmdCallback<Integer>() {
                @Override
                public void onSuccess(Integer data) {
                    updateVolume(data);
                }

                @Override
                public void onFailed(int code, String msg) {

                }
            }));

            room.cmdGetMuteStat(new CmdActionLister<String>(this, new ICmdCallback<String>() {
                @Override
                public void onSuccess(String data) {
                    updateMuteStat(data);
                }

                @Override
                public void onFailed(int code, String msg) {

                }
            }));
        }

        startClickListener();
    }

    private void initView(View view) {
        if (null == view){
            return;
        }

        mVolumeMuteIv = view.findViewById(R.id.dialog_volume_mute);
        mVolumeValueTv = view.findViewById(R.id.dialog_volume_value);
        mSeekbar = view.findViewById(R.id.dialog_volume_seekbar);

        mSeekbar.setMax(31);
    }

    @SuppressLint("ClickableViewAccessibility")
    private void initListener() {
        mVolumeMuteIv.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if (event.getAction() == MotionEvent.ACTION_DOWN){
                    stopClickListener();
                }else if (event.getAction() == MotionEvent.ACTION_UP){
                    startClickListener();
                }
                return false;
            }
        });
        mVolumeMuteIv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 点击静音
                String newStat = API_DEFINE.CMD_MUTESTAT_MUTE;
                if ((API_DEFINE.CMD_MUTESTAT_MUTE).equals(mMuteStat)){
                    newStat = API_DEFINE.CMD_MUTESTAT_NORMAL;
                }
                WRoom room = WApp.Instance.getDevManager().getSelectedRoom();
                if (room != null){
                    room.cmdSetMuteStat(newStat,new CmdActionLister<Boolean>(VolumeDialog.this, new ICmdCallback<Boolean>() {
                        @Override
                        public void onSuccess(Boolean data) {

                        }

                        @Override
                        public void onFailed(int code, String msg) {
                            Toast.makeText(getActivity(),"SetMuteStat失败:"+code,Toast.LENGTH_SHORT).show();
                        }
                    }));
                }
                updateMuteStat(newStat);
            }
        });

        mSeekbar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (seekBar != null && fromUser){
                    int volume = progress;
                    WRoom room = WApp.Instance.getDevManager().getSelectedRoom();
                    if (room != null){
                        room.cmdSetVolume(volume,new CmdActionLister<Boolean>(VolumeDialog.this, new ICmdCallback<Boolean>() {
                            @Override
                            public void onSuccess(Boolean data) {

                            }

                            @Override
                            public void onFailed(int code, String msg) {
                                Toast.makeText(getActivity(),"SetVolume失败:"+code,Toast.LENGTH_SHORT).show();
                            }
                        }));
                    }
                    updateVolume(volume);
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                stopClickListener();
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                startClickListener();
                if (seekBar != null){
                    int volume = seekBar.getProgress();
                    WRoom room = WApp.Instance.getDevManager().getSelectedRoom();
                    if (room != null){
                        room.cmdSetVolume(volume,new CmdActionLister<Boolean>(VolumeDialog.this, new ICmdCallback<Boolean>() {
                            @Override
                            public void onSuccess(Boolean data) {

                            }

                            @Override
                            public void onFailed(int code, String msg) {
                                Toast.makeText(getActivity(),"SetVolume失败:"+code,Toast.LENGTH_SHORT).show();
                            }
                        }));
                    }
                    updateVolume(volume);
                }
            }
        });
    }

    private void initData() {
        // eventbus 注册
        EventBus.getDefault().register(this);

        WRoom room = WApp.Instance.getDevManager().getSelectedRoom();
        if (room != null){
            int volume = room.getVolume();
            String muteStat = room.getMuteStat();

            updateVolume(volume);
            updateMuteStat(muteStat);
        }
    }

    private void updateVolume(int volume){
        if (!isAdded()){
            return;
        }

        mVolumeValueTv.setText(String.valueOf(volume));
        mSeekbar.setProgress(volume);
    }

    private void updateMuteStat(String mutestat){
        // 避免多次重复快速点击时，[Fragment VolumeDialog{36999101} not attached to a context.]
        if (!isAdded()){
            return;
        }
        mMuteStat = mutestat;
        if ((API_DEFINE.CMD_MUTESTAT_MUTE).equals(mutestat)){
            mVolumeMuteIv.setImageDrawable(getResources().getDrawable(R.drawable.volume_mute));
        }else{
            mVolumeMuteIv.setImageDrawable(getResources().getDrawable(R.drawable.volume_normal));
        }
    }

    @Subscribe()
    public void onNotifyMuteEvent(NotifyMuteEvent event){
        if (isVisible()){
            updateMuteStat(event.getMuteStat());
        }
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onNotifyVolumeEvent(NotifyVolumeEvent event){
        if (isVisible()){
            // 暂时屏蔽音量的广播，避免在快速频繁调节音量时，滑动条滑块自动闪烁变更位置的BUG，chenyaoli，2019.10.17
//            updateVolume(event.getVolume());
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    @Override
    public boolean onTouch(View v, MotionEvent event) {
        return false;
    }

    private Handler handler = new Handler(Looper.getMainLooper());
    private void startClickListener(){
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                dismiss();
            }
        },5*1000);
    }

    private void stopClickListener(){
        handler.removeCallbacksAndMessages(null);
    }
}
