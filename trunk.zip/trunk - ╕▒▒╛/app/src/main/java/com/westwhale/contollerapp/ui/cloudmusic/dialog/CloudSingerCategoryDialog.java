package com.westwhale.contollerapp.ui.cloudmusic.dialog;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.DialogFragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.TextView;

import com.westwhale.contollerapp.R;
import com.westwhale.contollerapp.ui.cloudmusic.adapter.CloudSingerCategoryAdapter;
import com.westwhale.contollerapp.common.CodeNameGroup;
import com.westwhale.contollerapp.common.CodeNameItem;
import com.westwhale.contollerapp.ui.base.dialog.AttachDialogFragment;
import com.westwhale.contollerapp.ui.cloudmusic.fragment.CloudAlbumFragment;
import com.westwhale.contollerapp.ui.cloudmusic.fragment.CloudSingerFragment;

import java.util.ArrayList;
import java.util.List;

/**
 * Description:
 * Author: chenyaoli
 * Date: 2018-12-01
 * History:
 */
public class CloudSingerCategoryDialog extends AttachDialogFragment implements CloudSingerCategoryAdapter.CallBack {
    private TextView mTitleTv,mEnterTv;
    private RecyclerView mSingerRv;
    private CloudSingerCategoryAdapter mSingerCategoryAdapter;

    private List<CodeNameGroup> mCategoryGroupList;

    private CodeNameItem mAreaItem;
    private CodeNameItem mIndexItem;

    public void setCategoryGroupList(List<CodeNameGroup> groupList) {
        mCategoryGroupList = groupList;
    }

    public void setSelectItems(CodeNameItem areaItem,CodeNameItem indexItem){
        // 必须从列表中找到指定项，因为后续所有的Item都是直接传递. 而传入的参数可能不是直接来自 mCategoryGroupList
        CodeNameItem optItem = null;
        if (mCategoryGroupList != null) {
            for (int i = 0; i < mCategoryGroupList.size(); i++) {
                CodeNameGroup CodeNameGroup = mCategoryGroupList.get(i);
                if (CodeNameGroup != null){
                    switch (CodeNameGroup.mType) {
                        case CloudAlbumFragment.TYPE_AREA:
                            optItem = areaItem;
                            break;
                        case CloudAlbumFragment.TYPE_INDEX:
                            optItem = indexItem;
                            break;
                        default:
                            break;
                    }

                    if (CodeNameGroup.mItemList != null){
                        for (int j=0; j < CodeNameGroup.mItemList.size(); j++){
                            CodeNameItem item = CodeNameGroup.mItemList.get(j);
                            if ((item != null) && item.equals(optItem)){
                                switch (CodeNameGroup.mType) {
                                    case CloudAlbumFragment.TYPE_AREA:
                                        mAreaItem = item;
                                        break;
                                    case CloudAlbumFragment.TYPE_INDEX:
                                        mIndexItem = item;
                                        break;
                                    default:
                                        break;
                                }

                                break;
                            }
                        }
                    } // end if (CodeNameGroup.mItemList != null)
                }
            } // end for (int i = 0; i < mCategoryGroupList.size(); i++)
        }
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // 背景色，动画效果，通过主题设置
        setStyle(DialogFragment.STYLE_NORMAL,R.style.CommonDialogStyle);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        //布局
        View view = inflater.inflate(R.layout.dialogfrag_singer_category, container);

        initView(view);
        initListener();

        return view;
    }

    @Override
    public void onStart() {
        super.onStart();

        //设置fragment高度 、宽度
        double heightPercent = 0.7;
        double widthPercent = 0.9;
        int dialogHeight = (int) (mContext.getResources().getDisplayMetrics().heightPixels * heightPercent);
        int dialogWidth = (int) (mContext.getResources().getDisplayMetrics().widthPixels * widthPercent);
        Window window = getDialog().getWindow();
        WindowManager.LayoutParams params = window.getAttributes();
        params.gravity = Gravity.CENTER;
        params.width = dialogWidth;
        params.height = dialogHeight;
        window.setAttributes(params);
        getDialog().setCanceledOnTouchOutside(true);

        initData();

    }

    private void initView(View view) {
        String title = getString(R.string.cloudmusic_dialog_singercategory);
        mTitleTv = view.findViewById(R.id.dialogfrag_singer_title);
        mTitleTv.setText(title);

        mEnterTv = view.findViewById(R.id.dialogfrag_singer_enter);

        mSingerRv = view.findViewById(R.id.dialogfrag_singer_recyclerview);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(mContext);
        mSingerRv.setLayoutManager(linearLayoutManager);
        mSingerCategoryAdapter = new CloudSingerCategoryAdapter(this);
        mSingerRv.setAdapter(mSingerCategoryAdapter);
        mSingerRv.setHasFixedSize(true);
        // 设置下拉上拉无阴影效果
        mSingerRv.setOverScrollMode(View.OVER_SCROLL_NEVER);
    }

    private void initListener() {
        mEnterTv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 把选中的结果传递出去
                if ( getTargetFragment() == null) {
                    return ;
                }
                Intent intent = new Intent();
                intent.putExtra(CloudSingerFragment.SINGER_TYPE_AREA,mAreaItem);
                intent.putExtra(CloudSingerFragment.SINGER_TYPE_INDEX,mIndexItem);
                //获得目标Fragment,并将数据通过onActivityResult放入到intent中进行传值
                getTargetFragment().onActivityResult(CloudAlbumFragment.REQUEST_CODDE, Activity.RESULT_OK, intent);


                dismiss();
            }
        });
    }

    private void initData() {
        ArrayList<CodeNameGroup> itemList = new ArrayList<>(mCategoryGroupList);
        if (mSingerCategoryAdapter != null) {
            mSingerCategoryAdapter.updateDataList(itemList);
            mSingerCategoryAdapter.setSelectItems(mAreaItem,mIndexItem);
            mSingerCategoryAdapter.notifyDataSetChanged();
        }
    }

    @Override
    public void onCategoryItemClick(CodeNameItem item) {
        // 点击某一项后
        if (item != null) {
            switch (item.mType) {
                case CloudAlbumFragment.TYPE_AREA:
                    mAreaItem = item;
                    break;
                case CloudAlbumFragment.TYPE_INDEX:
                    mIndexItem = item;
                    break;
                default:
                    break;
            }
        }
    }

}
