package com.westwhale.contollerapp.ui.timer;

import java.util.Dictionary;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;

public class TimerDefine {

    public static final String TIMER_INTENT_ARG_KEY_TIMER = "timer";
    public static final String TIMER_INTENT_ARG_KEY_REPEAT_CIRCLEDAY = "circleday";
    public static final String TIMER_INTENT_ARG_KEY_REPEAT_SPECIALDATE = "specialDate";
    public static final String TIMER_INTENT_ARG_KEY_MEDIA = "media";

    public static final String TIMER_FUNC_OPEN = "open";
    public static final String TIMER_FUNC_CLOSE = "close";
    public static final String TIMER_FUNC_CLOCKPLAY = "clockPlay";
    public static final String TIMER_FUNC_ALARM = "alarm";

    public static final String TIMER_FUNC_OPEN_NAME = "开机";
    public static final String TIMER_FUNC_CLOSE_NAME = "关机";
    public static final String TIMER_FUNC_CLOCKPLAY_NAME = "闹钟";
    public static final String TIMER_FUNC_ALARM_NAME = "闹钟";

    public static final String TIMER_ENABLE_ENABLE = "enable";
    public static final String TIMER_ENABLE_DISABLE = "disable";

    public static final String TIMER_REPEAT_NOREPEAT_NAME = "不重复";
    public static final String TIMER_REPEAT_EVERYDAY_NAME = "每天";
    public static final String TIMER_REPEAT_1_5_NAME = "周一至周五";
    public static final String TIMER_REPEAT_MONDAY = "周一";
    public static final String TIMER_REPEAT_TUESDAY = "周二";
    public static final String TIMER_REPEAT_WEDNESDAY = "周三";
    public static final String TIMER_REPEAT_THURSDAY = "周四";
    public static final String TIMER_REPEAT_FRIDAY = "周五";
    public static final String TIMER_REPEAT_SATURDAY = "周六";
    public static final String TIMER_REPEAT_SUNDAY = "周日";

    public static final int TIMER_REPEAT_NOREPEAT = 0;
    public static final int TIMER_REPEAT_EVERYDAY = 127;
    public static final int TIMER_REPEAT_1_5 = 31;


    public static String getTimerFuncName(String func){
        String name = "";
        switch (func){
            case TIMER_FUNC_OPEN:
                name = TIMER_FUNC_OPEN_NAME;
                break;
            case TIMER_FUNC_CLOSE:
                name = TIMER_FUNC_CLOSE_NAME;
                break;
            case TIMER_FUNC_CLOCKPLAY:
                name = TIMER_FUNC_CLOCKPLAY_NAME;
                break;
            case TIMER_FUNC_ALARM:
                name = TIMER_FUNC_ALARM_NAME;
                break;
            default:
                break;
        }

        return name;
    }

    public static String getTimerRepeat(int circleday){
        return getTimerRepeat(circleday,null);
    }

    public static String getTimerRepeat(int circleday,String date){
        String repeatStr = "";
        if ((date==null) || date.isEmpty()){
            if (TIMER_REPEAT_NOREPEAT == circleday){
                repeatStr = TIMER_REPEAT_NOREPEAT_NAME;
            }else if (TIMER_REPEAT_EVERYDAY == circleday){
                repeatStr = TIMER_REPEAT_EVERYDAY_NAME;
            }else if (TIMER_REPEAT_1_5 == circleday){
                repeatStr = TIMER_REPEAT_1_5_NAME;
            }else{
                repeatStr = "";
                StringBuilder builder = new StringBuilder();
                builder.append("");
                if ((circleday & 0x01) == 1){
                    if (!builder.toString().isEmpty()){
                        builder.append("、");
                    }
                    builder.append("一");
                }

                if (((circleday>>1) & 0x01) == 1){
                    if (!builder.toString().isEmpty()){
                        builder.append("、");
                    }
                    builder.append("二");
                }

                if (((circleday>>2) & 0x01) == 1){
                    if (!builder.toString().isEmpty()){
                        builder.append("、");
                    }
                    builder.append("三");
                }

                if (((circleday>>3) & 0x01) == 1){
                    if (!builder.toString().isEmpty()){
                        builder.append("、");
                    }
                    builder.append("四");
                }

                if (((circleday>>4) & 0x01) == 1){
                    if (!builder.toString().isEmpty()){
                        builder.append("、");
                    }
                    builder.append("五");
                }

                if (((circleday>>5) & 0x01) == 1){
                    if (!builder.toString().isEmpty()){
                        builder.append("、");
                    }
                    builder.append("六");
                }

                if (((circleday>>6) & 0x01) == 1){
                    if (!builder.toString().isEmpty()){
                        builder.append("、");
                    }
                    builder.append("七");
                }

                repeatStr = "周" + builder.toString();
//                repeatStr = repeatStr + (((circleday & 0x01) == 1) ?  "一、" : "");
//                repeatStr = repeatStr + ((((circleday>>1) & 0x01) == 1) ?  "二、" : "");
//                repeatStr = repeatStr + ((((circleday>>2) & 0x01) == 1) ?  "三、" : "");
//                repeatStr = repeatStr + ((((circleday>>3) & 0x01) == 1) ?  "四、" : "");
//                repeatStr = repeatStr + ((((circleday>>4) & 0x01) == 1) ?  "五、" : "");
//                repeatStr = repeatStr + ((((circleday>>5) & 0x01) == 1) ?  "六、" : "");
//                repeatStr = repeatStr + ((((circleday>>6) & 0x01) == 1) ?  "七、" : "");

            }
        }else{
            repeatStr = date;
        }

        return repeatStr;
    }

    public static boolean getTimerEnable(String enableStr){
        return (TIMER_ENABLE_ENABLE).equals(enableStr);
    }


    public static boolean checkActionName(String actionName){
        boolean isValid = false;
        switch (actionName){
            case TIMER_FUNC_OPEN:
            case TIMER_FUNC_CLOSE:
            case TIMER_FUNC_CLOCKPLAY:
            case TIMER_FUNC_ALARM:
                isValid = true;
                break;
            default:
                break;
        }

        return isValid;
    }

    private static Map<String,String> mFunctionMap;
    public static Map<String,String> getFunctionMap(){
        if (mFunctionMap == null){
            mFunctionMap = new HashMap<>();
            mFunctionMap.put(TIMER_FUNC_OPEN,TIMER_FUNC_OPEN_NAME);
            mFunctionMap.put(TIMER_FUNC_CLOSE,TIMER_FUNC_CLOSE_NAME);
            mFunctionMap.put(TIMER_FUNC_CLOCKPLAY,TIMER_FUNC_CLOCKPLAY_NAME);
            mFunctionMap.put(TIMER_FUNC_ALARM,TIMER_FUNC_ALARM_NAME);
        }

        return mFunctionMap;
    }

}
