package com.westwhale.contollerapp.dev.player;

import android.os.Handler;
import android.util.Log;

import com.blankj.utilcode.util.ThreadUtils;
import com.westwhale.contollerapp.dev.CmdActionLister;
import com.westwhale.contollerapp.application.WApp;
import com.westwhale.contollerapp.eventbus.notify.NotifyPlayModeEvent;
import com.westwhale.contollerapp.eventbus.notify.NotifyPlayStateEvent;
import com.westwhale.contollerapp.eventbus.notify.NotifyPlayTimeEvent;
import com.westwhale.contollerapp.eventbus.notify.NotifyPlayingMediaDuration;
import com.westwhale.contollerapp.eventbus.notify.NotifyVolumeEvent;
import com.westwhale.api.protocolapi.BaApi;
import com.westwhale.api.protocolapi.bean.media.Media;
import com.westwhale.api.protocolapi.net.Response;

import org.greenrobot.eventbus.EventBus;

/*************************************************
 *    该类必须在主线程中创建，因为采用接口实现方式
 *
 *     getXXX 函数： 对外获取接口
 *     setXXX 函数： 设置对应项，会发送TCP指令
 *     updateXXX函数： 更新对应项，会发送Eventbus事件
 *
 *
 *
 ************************************************/
public abstract class WPlayer<T extends Media> {
//    “pause”“resume”“next”“prev”
    protected final String CMD_ARG_PLAY_NEXT = "next";
    protected final String CMD_ARG_PLAY_PREV = "prev";
    protected final String CMD_ARG_PLAY_PAUSE = "pause";
    protected final String CMD_ARG_PLAY_RESUME = "resume";

    protected int mPlayTime; // 当前播放时长
    protected int mDuration; // 媒体总时长
    protected String mPlayMode;  // 当前播放模式
    protected String mPlayStat;  // 当前播放状态
    protected int mVolume = 0; // 当前音量
    protected T mPlayingMedia; // 当前播放媒体

    private Handler mHandler; // 消息处理，用于当某个cmd执行完成后，在主线程中调用接口回调

    synchronized public void updatePlayingMedia(T media) {
        Log.e("WPlayer","------************--MediaInfo:"+media.toString());
        mPlayingMedia = media;
    }

    public T getPlayingMedia() {
        return mPlayingMedia;
    }

    public void cmdPlayNext() {
        cmdPlayNext(null);
    }

    public void cmdPlayNext(CmdActionLister<Boolean> actionLister) {
        // 下一首
        onPlayCmd(CMD_ARG_PLAY_NEXT, actionLister);
    }

    public void cmdPlayPrev() {
        cmdPlayPrev(null);
    }

    public void cmdPlayPrev(CmdActionLister<Boolean> actionLister) {
        // 上一首
        onPlayCmd(CMD_ARG_PLAY_PREV, actionLister);
    }

    public void cmdPlayPause() {
        cmdPlayPause(null);
    }

    public void cmdPlayPause(CmdActionLister<Boolean> actionLister) {
        // 暂停
        onPlayCmd(CMD_ARG_PLAY_PAUSE, actionLister);
    }

    public void cmdPlayResume() {
        cmdPlayResume(null);
    }

    public void cmdPlayResume(CmdActionLister<Boolean> actionLister) {
        // 恢复播放
        onPlayCmd(CMD_ARG_PLAY_RESUME, actionLister);
    }

    private void onPlayCmd(String cmd, CmdActionLister<Boolean> actionLister) {
        ThreadUtils.getIoPool().execute(new Runnable() {
            @Override
            public void run() {
                Response<Boolean> res = null;
                try {
                    res = BaApi.getInstance().playOperation(cmd);
                } catch (Exception e) {
                    e.printStackTrace();
                } finally {
                    postCmdResponse(res, actionLister);
                }
            }
        });
    }

    synchronized public void updateVolume(int volume) {
        mVolume = volume;
        // 音量值 变更 广播
        EventBus.getDefault().post(new NotifyVolumeEvent(mVolume));
    }

    public int getVolume() {
        return mVolume;
    }

    public void cmdGetVolume() {
        cmdGetVolume(null);
    }

    public void cmdGetVolume(CmdActionLister<Integer> actionLister) {
        ThreadUtils.getIoPool().execute(new Runnable() {
            @Override
            public void run() {
                Response<Integer> res = null;
                try {
                    res = BaApi.getInstance().getVolume();
                } catch (Exception e) {
                    e.printStackTrace();
                } finally {
                    postCmdResponse(res, actionLister);
                }
            }
        });
    }

    public void cmdSetVolume(int volume) {
        cmdSetVolume(volume, null);
    }

    public void cmdSetVolume(int volume, CmdActionLister<Boolean> actionLister) {
        ThreadUtils.getIoPool().execute(new Runnable() {
            @Override
            public void run() {
                Response<Boolean> res = null;
                try {
                    res = BaApi.getInstance().setVolum(String.valueOf(volume));
                } catch (Exception e) {
                    e.printStackTrace();
                } finally {
                    postCmdResponse(res, actionLister);
                }
            }
        });
    }

    synchronized public void updatePlayTime(int playtime) {
        mPlayTime = playtime;
        // 播放时长值 变更 广播
        EventBus.getDefault().post(new NotifyPlayTimeEvent(mPlayTime));
    }

    public int getPlayTime() {
        return mPlayTime;
    }

    public void cmdGetPlayTime() {
        cmdGetPlayTime(null);
    }

    public void cmdGetPlayTime(CmdActionLister<Integer> actionLister) {
        ThreadUtils.getIoPool().execute(new Runnable() {
            @Override
            public void run() {
                Response<Integer> response = new Response<>();
                try {
                    response = BaApi.getInstance().getPlayTime();
                } catch (Exception e) {
                    e.printStackTrace();
                } finally {
                    postCmdResponse(response, actionLister);
                }
            }
        });
    }

    public void cmdSetPlayTime(int playtime) {
        cmdSetPlayTime(playtime, null);
    }

    public void cmdSetPlayTime(int playtime, CmdActionLister<Boolean> actionLister) {
        ThreadUtils.getIoPool().execute(new Runnable() {
            @Override
            public void run() {
                Response<Boolean> res = null;
                try {
                    res = BaApi.getInstance().setPlayTime(playtime);
                } catch (Exception e) {
                    e.printStackTrace();
                } finally {
                    postCmdResponse(res, actionLister);
                }
            }
        });
    }


    public int getDuration() {
        return mDuration;
    }

    synchronized public void updateDuration(int duration) {
        mDuration = duration;
        // 时长 广播
        EventBus.getDefault().post(new NotifyPlayingMediaDuration(mDuration));
    }

    synchronized public void updatePlayMode(String playMode) {
        mPlayMode = playMode;
        // 播放时长值 变更 广播
        EventBus.getDefault().post(new NotifyPlayModeEvent(mPlayMode));
    }

    public String getPlayMode() {
        return mPlayMode;
    }

    public void cmdSetPlayMode(String playmode) {
        cmdSetPlayMode(playmode, null);
    }

    public void cmdSetPlayMode(String playmode, CmdActionLister<Boolean> actionLister) {
        ThreadUtils.getIoPool().execute(new Runnable() {
            @Override
            public void run() {
                Response<Boolean> res = null;
                try {
                    res = BaApi.getInstance().setPlayMode(playmode);
                } catch (Exception e) {
                    e.printStackTrace();
                } finally {
                    postCmdResponse(res, actionLister);
                }
            }
        });
    }

    public void cmdGetPlayMode() {
        cmdGetPlayMode(null);
    }

    public void cmdGetPlayMode(CmdActionLister<String> actionLister) {
        ThreadUtils.getIoPool().execute(new Runnable() {
            @Override
            public void run() {
                Response<String> res = null;
                try {
                    res = BaApi.getInstance().getPlayMode();
                } catch (Exception e) {
                    e.printStackTrace();
                } finally {
                    postCmdResponse(res, actionLister);
                }
            }
        });
    }

    synchronized public void updatePlayStat(String playStat) {
        mPlayStat = playStat;
        // 播放状态 变更 广播
        EventBus.getDefault().post(new NotifyPlayStateEvent(mPlayStat));
    }

    public String getPlayStat() {
        return mPlayStat;
    }

    public void cmdGetPlayStat() {
        cmdGetPlayStat(null);
    }

    public void cmdGetPlayStat(CmdActionLister<String> actionLister) {
        ThreadUtils.getIoPool().execute(new Runnable() {
            @Override
            public void run() {
                Response<String> res = null;
                try {
                    res = BaApi.getInstance().getPlayStat();
                } catch (Exception e) {
                    e.printStackTrace();
                } finally {
                    postCmdResponse(res, actionLister);
                }
            }
        });
    }

    //在泛型类中声明了一个泛型方法，使用泛型E，这种泛型E可以为任意类型。可以类型与T相同，也可以不同。
    //由于泛型方法在声明的时候会声明泛型<E>，因此即使在泛型类中并未声明泛型，编译器也能够正确识别泛型方法中识别的泛型。
    protected <E> void postCmdResponse(Response<E> result, CmdActionLister<E> actionLister) {
        if (null == mHandler) {
            mHandler = new Handler(WApp.Instance.getMainLooper());
        }

        mHandler.post(new Runnable() {
            @Override
            public void run() {
                if (!ThreadUtils.isMainThread() || (null == actionLister)) {
                    return;
                }

                String msg = "";
                E data = null;
                int resultCode = -1;
                if (result != null) {
                    resultCode = result.resultCode;
                    if (0 == resultCode) {
                        data = result.bean;
                    }
                }

                actionLister.callback(resultCode, data, msg);
            }
        });
    }

    private <E> void postCmdResponseAll(Response<E> result, CmdActionLister<Response<E>> actionLister) {
        if (null == mHandler) {
            mHandler = new Handler(WApp.Instance.getMainLooper());
        }

        mHandler.post(new Runnable() {
            @Override
            public void run() {
                if (!ThreadUtils.isMainThread() || (null == actionLister)) {
                    return;
                }

                String msg = "";
                Response<E> data = null;
                int resultCode = -1;
                if (result != null) {
                    resultCode = result.resultCode;
                    // 针对云音乐的某些resultCode 为-2的特殊情况
                    if ((0 == resultCode) || (-2 == resultCode)) {
                        resultCode = 0;
                        data = result;
                    }
                }

                actionLister.callback(resultCode, data, msg);
            }
        });
    }
}
