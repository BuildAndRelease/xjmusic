package com.westwhale.contollerapp.ui.cloudmusic.adapter;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.util.SparseBooleanArray;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.TextView;

import com.westwhale.contollerapp.R;
import com.westwhale.api.protocolapi.bean.media.CloudMusic;

import java.util.ArrayList;
import java.util.List;

/**
 * Description:
 * Author: chenyaoli
 * Date: 2018-12-12
 * History:
 */
public class CloudMultiAdapter extends RecyclerView.Adapter<CloudMultiAdapter.ItemHolder> {
    public int TYPE_ITEM = 0;

    private List<CloudMusic> mItemList;
    private SparseBooleanArray mSelectedPositions = new SparseBooleanArray();
    private CallBack mCallBack;

    public interface CallBack{
        void onMusicItemClick(CloudMusic musicItem,boolean selected);

        void onCheckedNumChanged(int selectednum);
    }

    public List<CloudMusic> getSelectedList(){
        List<CloudMusic> musicList = new ArrayList<>();
        for (int i=0; i < mSelectedPositions.size(); i++){
            int index = mSelectedPositions.keyAt(i);
            if ((index > -1) && (mItemList != null) && (index < mItemList.size())){
                musicList.add(mItemList.get(index));
            }
        }

        return musicList;
    }

    public int getSelectedNum(){
        return mSelectedPositions.size();
    }

    public void selectAllItem(){
        if (mItemList != null){
            for (int i=0; i < mItemList.size(); i++){
                mSelectedPositions.put(i,true);
            }

            notifyDataSetChanged();

            if (mCallBack != null){
                mCallBack.onCheckedNumChanged(mSelectedPositions.size());
            }
        }
    }

    public void cancelAllItem(){
        mSelectedPositions.clear();
        notifyDataSetChanged();

        if (mCallBack != null){
            mCallBack.onCheckedNumChanged(mSelectedPositions.size());
        }
    }

    public void upateDataList(List<CloudMusic> itemList){
        if (mItemList != null){
            mItemList.clear();
            notifyDataSetChanged();
        }
        this.mItemList = itemList;
    }

    private boolean isItemChecked(int position) {
        return mSelectedPositions.get(position);
    }

    public CloudMultiAdapter(CallBack callBack){
        this.mItemList = null;
        this.mCallBack = callBack;
    }

    @NonNull
    @Override
    public ItemHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_netmusic_select, viewGroup, false);
        return new ItemHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ItemHolder itemHolder, int i) {
        CloudMusic cloudMusic = mItemList.get(i);
        boolean checkStat = isItemChecked(i);
        itemHolder.mCheckBox.setChecked(checkStat);
        itemHolder.mTitleTv.setText(cloudMusic.songName);
        itemHolder.mSubTitleTv.setText(cloudMusic.getSingersName());

        int colorResourceId = R.color.colorText;
        boolean canPlay = true;
        if (cloudMusic.canPlay == 1) {
            colorResourceId = R.color.colorGrey;
            canPlay = false;
        }
        int color = itemHolder.itemView.getResources().getColor(colorResourceId);
        itemHolder.mTitleTv.setTextColor(color);
        itemHolder.mSubTitleTv.setTextColor(color);

        itemHolder.mCheckBox.setClickable(false);
        itemHolder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                boolean checkStat = isItemChecked(i);
                boolean newStat = !checkStat;
                if (newStat) {
                    mSelectedPositions.put(i, newStat);
                }else{
                    mSelectedPositions.delete(i);
                }

                notifyItemChanged(i);
                if (mCallBack != null){
                    mCallBack.onCheckedNumChanged(mSelectedPositions.size());
                    mCallBack.onMusicItemClick(cloudMusic,newStat);
                }
            }
        });
    }

    @Override
    public int getItemViewType(int position) {
        return TYPE_ITEM;
    }

    @Override
    public int getItemCount() {
        return (null == mItemList) ? 0 : mItemList.size();
    }

    /**************************************   ItemHolder *******************************************/
    public class ItemHolder extends RecyclerView.ViewHolder{
        CheckBox mCheckBox;
        TextView mTitleTv, mSubTitleTv;
        public ItemHolder(@NonNull View itemView) {
            super(itemView);
            mCheckBox = itemView.findViewById(R.id.item_cloud_mutli_checkbox);
            mTitleTv = itemView.findViewById(R.id.item_cloud_mutli_title);
            mSubTitleTv = itemView.findViewById(R.id.item_cloud_mutli_subtitle);
        }
    }
}
