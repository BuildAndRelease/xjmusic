package com.westwhale.contollerapp.ui.cloudstory.fragment;

import android.animation.ObjectAnimator;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.util.Base64;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.LinearInterpolator;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.request.RequestOptions;
import com.westwhale.contollerapp.R;
import com.westwhale.contollerapp.application.WApp;
import com.westwhale.contollerapp.dev.API_DEFINE;
import com.westwhale.contollerapp.dev.MachineType;
import com.westwhale.contollerapp.dev.WHost;
import com.westwhale.contollerapp.ui.cloudstory.dialog.CloudStoryPlayListDialog;
import com.westwhale.contollerapp.ui.main.dialog.VolumeDialog;
import com.westwhale.contollerapp.ui.base.fragment.PlayerBaseFragment;
import com.westwhale.api.protocolapi.bean.media.Media;
import com.westwhale.api.protocolapi.bean.hostroom.Room;
import com.westwhale.api.protocolapi.bean.media.Section;
import com.westwhale.contollerapp.ui.scene.dialog.SceneExecuteDialog;
import com.westwhale.contollerapp.ui.timer.dialog.DelayTimerDialog;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

import jp.wasabeef.glide.transformations.BlurTransformation;

public class PlayerStoryFragment extends PlayerBaseFragment {
    private final static String TAG = "CloudMusicPlayer";

    private ImageView mBackgroudIv,mBackgroudMongoIv,mPlayPicIv,mBackforwardIv;
    private ImageView mPlayPrevIv,mPlayNextIv,mPlayStatIv,mPlaylistIv;
    private ImageView mVolumeIv,mAddFavoriteIv,mDownloadIv,mSceneIv,mRoomTimerIv;

    private TextView mTitleTv,mSubTitleTv, mPlayTimeTv,mDurationTv;
    private SeekBar mSeekbar;

    private ObjectAnimator mProgressAnimator;   //进度条旋转动画
    private ObjectAnimator mCircleAnimator;    //图片旋转动画


    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        // 先显示加载动画，针对布局做一些初始化
        View view = inflater.inflate(R.layout.frag_cloudstory_player,container,false);

        initView(view);

        initListener();

        updateMediaInfo();
        updatePlayStatInfo();

        return view;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
    }

    @Override
    public void onPause() {
        super.onPause();
    }

    @Override
    public void onResume() {
        super.onResume();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();

        if (mProgressAnimator != null) {
            mProgressAnimator.cancel();
        }
        if (mCircleAnimator != null) {
            mCircleAnimator.cancel();
        }
    }

    private void initView(View view) {
        if (null == view) {
            return;
        }

        mBackforwardIv = view.findViewById(R.id.player_back);
        mBackgroudIv = view.findViewById(R.id.player_bg);
        mBackgroudMongoIv = view.findViewById(R.id.player_bg_mongo);
        mPlayPicIv = view.findViewById(R.id.player_media_pic);

        mPlayPrevIv = view.findViewById(R.id.player_pre);
        mPlayStatIv = view.findViewById(R.id.player_play);
        mPlayNextIv = view.findViewById(R.id.playing_next);
        mPlaylistIv = view.findViewById(R.id.playing_playlist);

        mVolumeIv = view.findViewById(R.id.player_volume);
        mAddFavoriteIv = view.findViewById(R.id.player_add);
        mAddFavoriteIv.setColorFilter(R.color.colorGrey);
        mDownloadIv = view.findViewById(R.id.player_down);
        mDownloadIv.setColorFilter(R.color.colorGrey);
        mSceneIv = view.findViewById(R.id.player_scene);
//        mSceneIv.setColorFilter(R.color.colorGrey);
        mRoomTimerIv = view.findViewById(R.id.player_timer);
//        mRoomTimerIv.setColorFilter(R.color.colorGrey);

        mTitleTv = view.findViewById(R.id.player_title);
        mSubTitleTv = view.findViewById(R.id.player_center_title);

        mPlayTimeTv = view.findViewById(R.id.player_playtime);
        mDurationTv = view.findViewById(R.id.player_duration);

        mSeekbar = view.findViewById(R.id.player_seekbar);

        initCireAnimator(mPlayPicIv);
    }

    private void initListener() {

        mBackforwardIv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 返回按钮
                if (getActivity() != null){
                    getActivity().onBackPressed();
                }
            }
        });

        mPlayPrevIv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 上一首
                playPre();
            }
        });

        mPlayStatIv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 点击播放/暂停，需设置播放按钮（因为Frame的可触控面积大于播放按钮）
                if ((API_DEFINE.CMD_PLAYSTAT_PLAY).equals(mPlayStat)){
                    playPause();
                    updatePlayStat(API_DEFINE.CMD_PLAYSTAT_PAUSE);
                }else{
                    playResume();
                    updatePlayStat(API_DEFINE.CMD_PLAYSTAT_PLAY);
                }
            }
        });

        mPlayNextIv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 下一首
                playNext();
            }
        });

        mPlaylistIv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 弹出播放列表
                CloudStoryPlayListDialog dialog = new CloudStoryPlayListDialog();
                dialog.show(getFragmentManager(),"Playlist Dialog");
            }
        });

        mVolumeIv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 音量
                VolumeDialog volumeDialog = new VolumeDialog();
                volumeDialog.show(getFragmentManager(),"Volume Dialog");
            }
        });
        
        mAddFavoriteIv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // TODO: 2019/4/3 收藏 
            }
        });
        
        mDownloadIv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // TODO: 2019/4/3 下载 
            }
        });
        
        mSceneIv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 场景
                boolean hasFunc_Scene = false;
                WHost host = WApp.Instance.getDevManager().getSelectedHost();
                if (host != null) {
                    hasFunc_Scene = MachineType.hasFunc_Scene(host.getHost().deviceType);
                }
                if (hasFunc_Scene) {
                    SceneExecuteDialog dialog = new SceneExecuteDialog();
                    dialog.show(getChildFragmentManager(), SceneExecuteDialog.TAG);
                }
            }
        });
        
        mRoomTimerIv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 定时器
                DelayTimerDialog dialog = new DelayTimerDialog();
                dialog.show(getChildFragmentManager(),DelayTimerDialog.TAG);
            }
        });

        mSeekbar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (seekBar != null){
                    long millisecond = progress * 1000;

                    SimpleDateFormat timeFormat = new SimpleDateFormat("mm:ss", Locale.CHINA);
                    if (progress >= 60*60){
                        timeFormat =  new SimpleDateFormat("hh:mm:ss", Locale.CHINA);
                    }
                    timeFormat.setTimeZone(TimeZone.getTimeZone("GMT+00:00"));
                    // time为转换格式后的字符串
                    String timeStr = timeFormat.format(new Date(millisecond));

                    mPlayTimeTv.setText(String.valueOf(timeStr));
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                if (seekBar != null){
                    int playtime = seekBar.getProgress();
                    setPlayTime(playtime,null);
                    updatePlayTime(playtime);
                }
            }
        });
    }

    @Override
    public boolean isPlayerValid() {
        if ((Room.ChannelState.INNORMAL).equals(mRoomStat) || (Room.ChannelState.INPARTY).equals(mRoomStat) ){
            return true;
        }

        return false;
    }

    @NonNull
    @Override
    public String getMediaSrc() {
        return Media.CLOUD_STORY_TELLING;
    }

    @Override
    public void updateMediaInfo(){
        if (mMedia instanceof Section) {
            Section media = (Section)mMedia;
            // 设置主标题和副标题
            String songName = (media.sectionName==null) ? "未知" : media.sectionName;
            String subtitle =  "语言节目" ;

            mTitleTv.setText(songName);

            mSubTitleTv.setText(subtitle);

            // 设置图片,首先 base64 解码
            String pic = (media.pic != null) ? media.pic : "";
            String url = pic;
            try {
                if (!pic.startsWith("http:")) {
                    url = new String(Base64.decode(pic.getBytes(), Base64.DEFAULT));
                }
            }catch (Exception e){
                url = "";
                e.printStackTrace();
            }
            RequestOptions requestOptions = RequestOptions.circleCropTransform().diskCacheStrategy(DiskCacheStrategy.NONE) //不做磁盘缓存
                    .placeholder(R.drawable.simple_player_default)  //未加载图片之前显示的图片
                    .error(R.drawable.simple_player_default);       //错误时显示的图片
//                      .skipMemoryCache(true);//不做内存缓存
            // 在Fragment未 attach Activity时，会抛出activity null 异常
            Glide.with(this)
                    .load(url)
                    .apply(requestOptions)
                    .into(mPlayPicIv);


            RequestOptions blurRequestOptions = RequestOptions.bitmapTransform(new BlurTransformation( 22, 3)).diskCacheStrategy(DiskCacheStrategy.NONE) //不做磁盘缓存
                    .override(600, 600);
            Glide.with(mContext)
                    .load(url)
                    .apply(blurRequestOptions)
                    .into(mBackgroudIv);

            // 更新总时长
            mPlayTime = 0;
            mDuration = 0;
            try{
                int duration = media.duration;
                this.updatePlayingMediaDuration(duration);
            }catch (Exception e){
                e.printStackTrace();
            }
        }
    }

    @Override
    public void updateMediaDurationInfo() {
        // 更新总时长时，重新获取当前播放时间
        if (mDuration > 0) {
            getPlayTime();
        }
    }

    @Override
    public void updatePlayStatInfo() {
        // 更新播放状态
        if ((API_DEFINE.CMD_PLAYSTAT_PLAY).equals(mPlayStat)){
            mPlayStatIv.setImageDrawable(getResources().getDrawable(R.drawable.player_pause));

            resumeCircleAnimator();

            resumeProgressAnimator();
        }else {
            mPlayStatIv.setImageDrawable(getResources().getDrawable(R.drawable.player_play));

            pauseCircleAnimator();

            pauseProgressAnimator();
        }
    }

    @Override
    public void updatePlayTimeInfo() {
        updateProgress();
    }

    @Override
    public void updatePlayMode(String playMode) {

    }

    @Override
    public void updatePlayModeInfo() {

    }



    public void updateProgress(){
        // 500秒
        long millisecond = mPlayTime * 1000;
        SimpleDateFormat timeFormat = new SimpleDateFormat("mm:ss", Locale.CHINA);
        if (mPlayTime >= 60*60){
            timeFormat =  new SimpleDateFormat("hh:mm:ss", Locale.CHINA);
        }
        timeFormat.setTimeZone(TimeZone.getTimeZone("GMT+00:00"));
        // time为转换格式后的字符串
        String timeStr = timeFormat.format(new Date(millisecond));
        mPlayTimeTv.setText(String.valueOf(timeStr));


        SimpleDateFormat dateFormat = new SimpleDateFormat("mm:ss", Locale.CHINA);
        if (mDuration >= 60*60){
            dateFormat =  new SimpleDateFormat("hh:mm:ss", Locale.CHINA);
        }
        dateFormat.setTimeZone(TimeZone.getTimeZone("GMT+00:00"));
        millisecond = mDuration * 1000;
        String durationStr = dateFormat.format(new Date(millisecond));
        mDurationTv.setText(String.valueOf(durationStr));

        initProgressAnimator(mPlayTime,mDuration);

        if ((API_DEFINE.CMD_PLAYSTAT_PLAY).equals(mPlayStat)) {
            resumeProgressAnimator();
        }

    }

    /******************************** 进度条转动 ***********************************/
    private void initProgressAnimator(int beginTime, int duration) {
        if (mProgressAnimator != null){
            mProgressAnimator.removeAllListeners();
            mProgressAnimator.cancel();
            mProgressAnimator = null;
        }
        if ((duration <= 0) || (beginTime > duration)){
            return;
        }

        mSeekbar.setMax(duration);
        mProgressAnimator = ObjectAnimator.ofInt(mSeekbar, "progress", beginTime,duration);
        mProgressAnimator.setInterpolator(new LinearInterpolator());
        mProgressAnimator.setRepeatCount(0);
        mProgressAnimator.setDuration((duration - beginTime)*1000);
    }


    private void resumeProgressAnimator() {
        if (mProgressAnimator != null){
            if (mProgressAnimator.isStarted()){
                mProgressAnimator.resume();
            }else{
                mProgressAnimator.start();
            }
        }
    }

    private void pauseProgressAnimator() {
        if (mProgressAnimator != null){
            mProgressAnimator.pause();
        }
    }


    /******************************** 图片转动 ***********************************/
    private void initCireAnimator(@NonNull View view) {
        mCircleAnimator = ObjectAnimator.ofFloat(view, "rotation", 0.0f, 360.0f);
        mCircleAnimator.setDuration(30*1000);
        mCircleAnimator.setInterpolator(new LinearInterpolator());
        mCircleAnimator.setRepeatCount(-1);
        mCircleAnimator.setRepeatMode(ObjectAnimator.RESTART);
    }

    private void resumeCircleAnimator() {
        if (mCircleAnimator != null){
            if (mCircleAnimator.isStarted()){
                mCircleAnimator.resume();
            }else{
                mCircleAnimator.start();
            }
        }
    }

    private void pauseCircleAnimator() {
        if (mCircleAnimator != null){
            mCircleAnimator.pause();
        }
    }


}
