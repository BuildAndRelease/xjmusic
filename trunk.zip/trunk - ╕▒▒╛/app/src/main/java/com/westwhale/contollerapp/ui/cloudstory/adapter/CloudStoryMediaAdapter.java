package com.westwhale.contollerapp.ui.cloudstory.adapter;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.westwhale.contollerapp.R;
import com.westwhale.api.protocolapi.bean.media.Section;

import java.util.ArrayList;
import java.util.List;

/**
 * Description:
 * Author: chenyaoli
 * Date: 2018-11-17
 * History:
 */
public class CloudStoryMediaAdapter extends RecyclerView.Adapter {

    private List<Section> mItemList;
    private CallBack mCallBack;

    public interface CallBack {
        void onMediaItemClick(Section item);
    }

    public void updateDataList(List<Section> itemList){
        this.mItemList = itemList;
    }

    public void clearDataList(){
        if (mItemList != null){
            this.mItemList.clear();
        }
        notifyDataSetChanged();
    }

    public void addToDataList(List<Section> itemList){
        if (mItemList == null){
            mItemList = new ArrayList<>();
            notifyDataSetChanged();
        }
        mItemList.addAll(itemList);
    }

    public CloudStoryMediaAdapter(CallBack callBack) {
        this.mItemList = null;
        this.mCallBack = callBack;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_cloudstory_item, viewGroup, false);
        return new StoryMediaItemHolder(view);

    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder viewHolder, int i) {
        // 在此处，处理默认类型的 viewHolder
        Section item = mItemList.get(i);
        StoryMediaItemHolder itemHolder = (StoryMediaItemHolder) viewHolder;


        itemHolder.mItemNo.setText(String.valueOf(i+1));
        itemHolder.mTitleTv.setText(item.sectionName);
        String subtitle = item.anchorName;
        itemHolder.mSubtitle.setText(subtitle);

        viewHolder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mCallBack.onMediaItemClick(item);
            }
        });

    }

    @Override
    public int getItemCount() {
        return (mItemList == null) ? 0 : mItemList.size();
    }


    private class StoryMediaItemHolder extends RecyclerView.ViewHolder {
        TextView mItemNo, mTitleTv, mSubtitle;

        StoryMediaItemHolder(@NonNull View itemView) {
            super(itemView);
            mItemNo = itemView.findViewById(R.id.item_story_item_no);
            mTitleTv = itemView.findViewById(R.id.item_story_item_name);
            mSubtitle = itemView.findViewById(R.id.item_story_item_artist);
        }
    }
}
