package com.westwhale.contollerapp.ui.cloudmusic.adapter;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.westwhale.contollerapp.R;
import com.westwhale.api.protocolapi.bean.media.CloudMusic;

import java.util.ArrayList;
import java.util.List;

public class CloudSongAdapter extends RecyclerView.Adapter {
    private List<CloudMusic> mItemList;
    private CallBack mCallBack;
    private int mMaxSize;  // 通过限制最大数，从而限制视图的可见个数

    public interface CallBack{
        void onSongItemClick(List<CloudMusic> itemList, CloudMusic songItem);

        void onSongItemMoreClick(CloudMusic songItem);
    }

    public List<CloudMusic> getDataList(){
        return mItemList;
    }

    public void updateDataList(List<CloudMusic> itemList){
        if (mItemList != null){
            mItemList.clear();
            notifyDataSetChanged();
        }
        this.mItemList = itemList;
    }

    public void clearDataList(){
        if (mItemList != null){
            this.mItemList.clear();
        }
        notifyDataSetChanged();
    }

    public void addToDataList(List<CloudMusic> itemList){
        if (mItemList == null){
            mItemList = new ArrayList<>();
            notifyDataSetChanged();
        }
        mItemList.addAll(itemList);
    }

    public CloudSongAdapter(CallBack callBack){
        this.mItemList = null;
        this.mMaxSize = 0;
        this.mCallBack = callBack;
    }

    public CloudSongAdapter(int maxSize,CallBack callBack){
        this.mItemList = null;
        this.mMaxSize = maxSize;
        this.mCallBack = callBack;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        // 默认返回 HOST 类型的 viewHolder
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_netmusic_song, viewGroup, false);
        return new CloudSongItemHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder viewHolder, int i) {
        if (viewHolder instanceof CloudSongItemHolder){
            CloudMusic item = mItemList.get(i);
            CloudSongItemHolder itemHolder = (CloudSongItemHolder)viewHolder;
            itemHolder.mSongNoTv.setText(String.valueOf(i+1));
            itemHolder.mSongNameTv.setText(item.songName);
            itemHolder.mSongSingerTv.setText(item.getSingersName());

            int colorResourceId = R.color.colorText;
            boolean canPlay = true;
            if (item.canPlay == 1) {
                colorResourceId = R.color.colorGrey;
                canPlay = false;
            }
            int color = itemHolder.itemView.getResources().getColor(colorResourceId);
            itemHolder.mSongNoTv.setTextColor(color);
            itemHolder.mSongNameTv.setTextColor(color);
            itemHolder.mSongSingerTv.setTextColor(color);

            viewHolder.itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    mCallBack.onSongItemClick(mItemList,item);
                }
            });

            ((CloudSongItemHolder) viewHolder).mItemMoreIv.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    mCallBack.onSongItemMoreClick(item);
                }
            });
        }
    }

    @Override
    public int getItemCount() {
        if (null == mItemList){
            return 0;
        }

        // 通过判断允许的最大个数，来限制视图大小
        if ((mMaxSize > 0) && (mItemList.size() > mMaxSize)){
            return mMaxSize;
        }else{
            return mItemList.size();
        }
    }

    private class CloudSongItemHolder extends RecyclerView.ViewHolder{
        ImageView mItemMoreIv;
        TextView mSongNoTv, mSongNameTv, mSongSingerTv;
        public CloudSongItemHolder(@NonNull View itemView) {
            super(itemView);
            mItemMoreIv = itemView.findViewById(R.id.netmusic_song_item_more);
            mSongNoTv = itemView.findViewById(R.id.netmusic_song_item_no);
            mSongNameTv = itemView.findViewById(R.id.netmusic_song_item_name);
            mSongSingerTv = itemView.findViewById(R.id.netmusic_song_item_artist);
        }
    }
}
