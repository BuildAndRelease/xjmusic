package com.westwhale.contollerapp.ui.loadsircallback;


import android.content.Context;
import android.view.View;

import com.kingja.loadsir.callback.Callback;
import com.westwhale.contollerapp.R;


public class SimplePlayerPlaceholderCallback extends Callback {
    @Override
    protected int onCreateView() {
        return R.layout.frag_load_simpleplayer_placeholder;
    }

    @Override
    protected boolean onReloadEvent(Context context, View view) {
        return true;
    }
}
