package com.westwhale.contollerapp.ui.cloudstory.fragment;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;


import com.kingja.loadsir.callback.Callback;
import com.kingja.loadsir.callback.SuccessCallback;
import com.scwang.smartrefresh.layout.api.RefreshLayout;
import com.scwang.smartrefresh.layout.listener.OnLoadMoreListener;
import com.scwang.smartrefresh.layout.listener.OnRefreshListener;
import com.westwhale.contollerapp.R;
import com.westwhale.contollerapp.ui.main.MainRoomActivity;
import com.westwhale.contollerapp.ui.cloudstory.adapter.StoryCategoryAdapter;
import com.westwhale.contollerapp.application.WApp;
import com.westwhale.contollerapp.dev.CmdActionLister;
import com.westwhale.contollerapp.dev.ICmdCallback;
import com.westwhale.contollerapp.dev.WRoom;
import com.westwhale.contollerapp.ui.base.fragment.TitleBaseFragment;
import com.westwhale.contollerapp.ui.loadsircallback.EmptyCallback;
import com.westwhale.contollerapp.ui.loadsircallback.LoadingCallback;
import com.westwhale.api.protocolapi.bean.telling.CatrgroyGroup;

import java.util.List;


/**
 * Description:
 * Author: chenyaoli
 * Date: 2019-04-06
 * History:
 */
public class CloudStoryCategoryFragment extends TitleBaseFragment implements StoryCategoryAdapter.CallBack {
    private static final String TAG = "StoryCategory";

    private Toolbar mToolBar;
    private RefreshLayout mRefreshLayout;
    private RecyclerView mDataRv;

    private StoryCategoryAdapter mAdapter;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        // 先显示加载动画，针对布局做一些初始化
        return inflater.inflate(R.layout.frag_cloudstory_category,container,false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        RecyclerView recyclerView = view.findViewById(R.id.cloudstory_category_recylerview);

        // 创建mLoadService
        mLoadService = mLoadSir.register(recyclerView, new Callback.OnReloadListener() {
            @Override
            public void onReload(View v) {
                showLoadCallBack(LoadingCallback.class);
                initData();
            }
        });

        initView(view);

        initListener();

        initData();
    }

    @Override
    public void onResume() {
        super.onResume();
    }

    @Override
    public void onCategoryItemClick(CatrgroyGroup item) {
        // TODO: 2019-04-06 点击进入语言节目 专辑界面
        CloudStoryCategoryAlbumFragment fragment = new CloudStoryCategoryAlbumFragment();
        fragment.updateCategoryGroup(item);
        ((MainRoomActivity)getActivity()).showFragment(fragment);
    }

    private void initView(@NonNull View view) {
        mToolBar = view.findViewById(R.id.cloudstory_category_toolbar);
        configToolBar(mToolBar,"分类");

        mDataRv = view.findViewById(R.id.cloudstory_category_recylerview);
        GridLayoutManager gridLayoutManager = new GridLayoutManager(mContext, 3);
        mDataRv.setLayoutManager(gridLayoutManager);
        mAdapter = new StoryCategoryAdapter(this);
        mDataRv.setAdapter(mAdapter);
        mDataRv.setHasFixedSize(true);

        mRefreshLayout = view.findViewById(R.id.cloudstory_category_refresh);
        mRefreshLayout.setDisableContentWhenRefresh(true);
        mRefreshLayout.setEnableLoadMore(false);
    }

    private void initListener() {
        mRefreshLayout.setOnRefreshListener(new OnRefreshListener() {
            @Override
            public void onRefresh(@NonNull RefreshLayout refreshLayout) {
                initData();
            }
        });

        mRefreshLayout.setOnLoadMoreListener(new OnLoadMoreListener() {
            @Override
            public void onLoadMore(@NonNull RefreshLayout refreshLayout) {
                mRefreshLayout.finishLoadMoreWithNoMoreData();
            }
        });
    }

    private void initData() {
        requestCloudStoryCategory();
    }

    private void updateCategory(List<CatrgroyGroup> list){
        // 刷新列表
        if (list != null){
            Log.e(TAG,"----------- updateCategory ---111---");
            mAdapter.updateDataList(list);
            mAdapter.notifyDataSetChanged();

            Log.e(TAG,"----------- updateCategory ---222---" + mAdapter.getItemCount());
            // 更新刷新等待状态
            mRefreshLayout.finishRefresh();

            showLoadCallBack(SuccessCallback.class);
        }else{
            showLoadCallBack(EmptyCallback.class);
        }
    }

    private void requestCloudStoryCategory(){
        Log.e(TAG,"----------- requestCloudStoryCategory ------");
        WRoom room = WApp.Instance.getDevManager().getSelectedRoom();
        if (room != null){
            room.cmdGetStorytellingCategory(new CmdActionLister<List<CatrgroyGroup>>(this, new ICmdCallback<List<CatrgroyGroup>>() {
                @Override
                public void onSuccess(List<CatrgroyGroup> data) {
                    Log.e(TAG,"-----------onSuccess------" + data.size());
                    updateCategory(data);
                }

                @Override
                public void onFailed(int code, String msg) {
                    Log.e(TAG,"-----------------"+code+msg);
                    updateCategory(null);
                    Toast.makeText(getContext(),"获取失败:"+code,Toast.LENGTH_SHORT).show();
                }
            }));
        }else{
            updateCategory(null);
        }
    }


}
