package com.westwhale.contollerapp.dev;

import com.blankj.utilcode.util.LogUtils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 所有关于机型的功能区分判断，在此类中做区分
 *
 */
public class MachineType {
    private static final String MACHINE_TYPE_STR_P6 = "BAP6";
    private static final String MACHINE_TYPE_STR_A76 = "BaServer";
    private static final int MACHINE_TYPE_P6 = 0;

    private static final String MACHINE_TYPE_STR_S5 = "S5";
    private static final int MACHINE_TYPE_S5 = 1;

    private static final String MACHINE_TYPE_STR_M0 = "M0";
    private static final int MACHINE_TYPE_M0 = 2;

    private static final int FUNC_PARTY = 0;
    private static final int FUNC_TALK = 1;
    private static final int FUNC_SCENE = 2;
    private static final int FUNC_DOWNLOAD = 3;


    private static final int FUNC_HOST_RESTART = 50;

    private static final int FUNC_TCP_BROADCAST = 100;

    private static final int MEDIA_SRC_AUX1 = 200;
    private static final int MEDIA_SRC_AUX2 = 201;


    private static ArrayList<Integer> mP6FuncList = new ArrayList<Integer>(){
        {
            add(FUNC_PARTY);
            add(FUNC_TALK);
//            add(FUNC_SCENE);

            add(FUNC_TCP_BROADCAST);
            add(FUNC_HOST_RESTART);

            add(MEDIA_SRC_AUX1);
            add(MEDIA_SRC_AUX2);
        }
    };

    private static ArrayList<Integer> mS5FuncList = new ArrayList<Integer>(){
        {
            add(FUNC_PARTY);
            add(FUNC_TALK);

            add(FUNC_DOWNLOAD);
            add(FUNC_SCENE);

            add(FUNC_TCP_BROADCAST);

            add(MEDIA_SRC_AUX1);
        }
    };

    private static ArrayList<Integer> mM0FuncList = new ArrayList<Integer>(){
        {
            add(FUNC_PARTY);
            add(FUNC_TALK);

            add(FUNC_DOWNLOAD);
            add(FUNC_SCENE);

            add(FUNC_TCP_BROADCAST);

            add(MEDIA_SRC_AUX1);
            add(MEDIA_SRC_AUX2);
        }
    };

    private static boolean checkTypeFunc(String type,int func){
        boolean contains = false;
        switch (type){
            case MACHINE_TYPE_STR_P6:
            case MACHINE_TYPE_STR_A76:
                contains = mP6FuncList.contains(func);
                break;
            case MACHINE_TYPE_STR_S5:
                contains = mS5FuncList.contains(func);
                break;
            case MACHINE_TYPE_STR_M0:
                contains = mM0FuncList.contains(func);
                break;
            default:
                contains = false;
                break;
        }

        return contains;
    }




    public static boolean hasFunc_Party(String type) {
        return checkTypeFunc(type,FUNC_PARTY);
    }

    public static boolean hasFunc_Talk(String type) {
        return checkTypeFunc(type,FUNC_TALK);
    }

    public static boolean hasFunc_Scene(String type) {
        return checkTypeFunc(type,FUNC_SCENE);
    }

    public static boolean hasFunc_Download(String type) {
        return checkTypeFunc(type,FUNC_DOWNLOAD);
    }



    public static boolean hasFunc_HostRestart(String type) {
        return checkTypeFunc(type,FUNC_HOST_RESTART);
    }

    public static boolean hasFunc_TcpBroadcast(String type) {
        return checkTypeFunc(type,FUNC_TCP_BROADCAST);
    }

    public static boolean containMediaSrcAux1(String type){
        return checkTypeFunc(type,MEDIA_SRC_AUX1);
    }

    public static boolean containMediaSrcAux2(String type){
        return checkTypeFunc(type,MEDIA_SRC_AUX2);
    }
}
