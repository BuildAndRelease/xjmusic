package com.westwhale.contollerapp.ui.slider;


import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.blankj.utilcode.util.NetworkUtils;
import com.blankj.utilcode.util.ToastUtils;
import com.westwhale.contollerapp.R;
import com.westwhale.contollerapp.application.WApp;
import com.westwhale.contollerapp.dev.CmdActionLister;
import com.westwhale.contollerapp.dev.ICmdCallback;
import com.westwhale.contollerapp.dev.WHost;
import com.westwhale.contollerapp.ui.base.activity.BaseActivity;
import com.westwhale.api.protocolapi.bean.ServerIpInfo;

/**
 * Description:
 * Author: chenyaoli
 * Date: 2018-12-20
 * History
 */
public class IpConfigActivity extends BaseActivity {
    private Toolbar mToolbar;
    private ImageView mAutoSetIp;
    private TextView mManualIpSaveTv;
    private EditText mPhoneIpEdit, mDevIpEdit, mDevGetwayEdit, mDevNetmaskEdit, mDevDns1Edit, mDevDns2Edit;

    private boolean mAutoSetIpFlag = false;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_slider_ipconfig);

        initView();
        initListener();

        initData();
    }

    @Override
    protected void onPause() {
        super.onPause();

        hideSoftInput();
    }

    private void hideSoftInput(){
        InputMethodManager imm = (InputMethodManager)this.getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm != null) {
            imm.hideSoftInputFromWindow(mDevIpEdit.getWindowToken(), 0);
        }
    }

    private void initView() {
        mToolbar = findViewById(R.id.ipconfig_toolbar);
        // 设置toolbar
        setSupportActionBar(mToolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        mPhoneIpEdit = findViewById(R.id.ipconfig_localip_edit);
        mAutoSetIp = findViewById(R.id.ipconfig_manual_image);

        mDevIpEdit = findViewById(R.id.ipconfig_device_ip_edit);
        mDevGetwayEdit = findViewById(R.id.ipconfig_device_gateway_edit);
        mDevNetmaskEdit = findViewById(R.id.ipconfig_device_netmask_edit);
        mDevDns1Edit = findViewById(R.id.ipconfig_device_dns1_edit);
        mDevDns2Edit = findViewById(R.id.ipconfig_device_dns2_edit);

        mManualIpSaveTv = findViewById(R.id.ipconfig_manual_save);
    }

    private void initListener() {
        mToolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        mAutoSetIp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                updateAutoIpStat(!mAutoSetIpFlag);

                // 只有为自动获取IP时，才调用
                if (mAutoSetIpFlag){
                    configDevIp();
                }
            }
        });


        mManualIpSaveTv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 只有为手动配置IP时，才调用
                if (!mAutoSetIpFlag) {
                    configDevIp();
                }

                hideSoftInput();
            }
        });
    }

    private void configDevIp() {
        String devIp = "";
        String devGatway = "";
        String devNetMask = "";
        String devDns1 = "";
        String devDns2 = "";
        if (!mAutoSetIpFlag){
            // 首先IP检测，然后再发送
            devIp = mDevIpEdit.getText().toString();
            devGatway = mDevGetwayEdit.getText().toString();
            devNetMask = mDevNetmaskEdit.getText().toString();
            devDns1 = mDevDns1Edit.getText().toString();
            devDns2 = mDevDns2Edit.getText().toString();
        }

        ServerIpInfo serverIpInfo = new ServerIpInfo();
        serverIpInfo.autoSetIp = mAutoSetIpFlag ? 0 : 1;
        serverIpInfo.address = devIp;
        serverIpInfo.gateway = devGatway;
        serverIpInfo.netmask = devNetMask;
        serverIpInfo.dns1 = devDns1;
        serverIpInfo.dns2 = devDns2;

        WHost host = WApp.Instance.getDevManager().getSelectedHost();
        if (host != null){
            host.cmdSetServerIpInfo(serverIpInfo,new CmdActionLister<Boolean>(IpConfigActivity.this, new ICmdCallback<Boolean>() {
                @Override
                public void onSuccess(Boolean data) {

                }

                @Override
                public void onFailed(int code, String msg) {
                    ToastUtils.showShort("Ip Config failed...%d",code);
                }
            }));
        }
    }

    private void initData() {
        // 手机IP
        String selfIp = NetworkUtils.getIPAddress(true);

        mPhoneIpEdit.setText(selfIp);

        requestData();
    }

    private void updateAutoIpStat(boolean autostat){
        mAutoSetIpFlag = autostat;
        if (mAutoSetIpFlag) {
            mAutoSetIp.setImageResource(R.drawable.btn_lock);

            mDevIpEdit.setCursorVisible(false);
            mDevIpEdit.setFocusable(false);
            mDevIpEdit.setFocusableInTouchMode(false);
            mDevGetwayEdit.setCursorVisible(false);
            mDevGetwayEdit.setFocusable(false);
            mDevGetwayEdit.setFocusableInTouchMode(false);
            mDevNetmaskEdit.setCursorVisible(false);
            mDevNetmaskEdit.setFocusable(false);
            mDevNetmaskEdit.setFocusableInTouchMode(false);
            mDevDns1Edit.setCursorVisible(false);
            mDevDns1Edit.setFocusable(false);
            mDevDns1Edit.setFocusableInTouchMode(false);
            mDevDns2Edit.setCursorVisible(false);
            mDevDns2Edit.setFocusable(false);
            mDevDns2Edit.setFocusableInTouchMode(false);

            mManualIpSaveTv.setVisibility(View.GONE);

        } else {
            mAutoSetIp.setImageResource(R.drawable.btn_unlock);

            mDevIpEdit.setCursorVisible(true);
            mDevIpEdit.setFocusable(true);
            mDevIpEdit.setFocusableInTouchMode(true);
            mDevGetwayEdit.setCursorVisible(true);
            mDevGetwayEdit.setFocusable(true);
            mDevGetwayEdit.setFocusableInTouchMode(true);
            mDevNetmaskEdit.setCursorVisible(true);
            mDevNetmaskEdit.setFocusable(true);
            mDevNetmaskEdit.setFocusableInTouchMode(true);
            mDevDns1Edit.setCursorVisible(true);
            mDevDns1Edit.setFocusable(true);
            mDevDns1Edit.setFocusableInTouchMode(true);
            mDevDns2Edit.setCursorVisible(true);
            mDevDns2Edit.setFocusable(true);
            mDevDns2Edit.setFocusableInTouchMode(true);

            mManualIpSaveTv.setVisibility(View.VISIBLE);
        }
    }

    private void updateIpInfo(ServerIpInfo serverIpInfo){
        if (serverIpInfo != null){
            boolean autostat = (0 == serverIpInfo.autoSetIp);
            updateAutoIpStat(autostat);

            mDevIpEdit.setText(serverIpInfo.address);
            mDevGetwayEdit.setText(serverIpInfo.gateway);
            mDevNetmaskEdit.setText(serverIpInfo.netmask);
            mDevDns1Edit.setText(serverIpInfo.dns1);
            mDevDns2Edit.setText(serverIpInfo.dns2);
        }
    }

    private void requestData(){
        WHost host = WApp.Instance.getDevManager().getSelectedHost();
        if (host != null){
            host.cmdGetServerIpInfo(new CmdActionLister<ServerIpInfo>(IpConfigActivity.this, new ICmdCallback<ServerIpInfo>() {
                @Override
                public void onSuccess(ServerIpInfo data) {
                    updateIpInfo(data);
                }

                @Override
                public void onFailed(int code, String msg) {
                    updateIpInfo(null);
                    ToastUtils.showShort("GetServerIpInfo failed...%d",code);
                }
            }));
        }
    }
}
