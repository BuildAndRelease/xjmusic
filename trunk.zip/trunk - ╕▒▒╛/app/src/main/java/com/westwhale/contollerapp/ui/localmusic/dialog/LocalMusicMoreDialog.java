package com.westwhale.contollerapp.ui.localmusic.dialog;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.DialogFragment;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.TextView;

import com.alibaba.fastjson.JSON;
import com.westwhale.contollerapp.R;
import com.westwhale.contollerapp.common.ImageTextItem;
import com.westwhale.contollerapp.ui.localmusic.adapter.LocalMoreInfoAdapter;
import com.westwhale.contollerapp.ui.base.dialog.AttachDialogFragment;
import com.westwhale.contollerapp.ui.favorite.songsheet.dialog.FavoriteAddMediaDialog;
import com.westwhale.api.protocolapi.bean.media.LocalMusic;

import java.util.ArrayList;

/**
 * Description:
 * Author: chenyaoli
 * Date: 2018-11-23
 * History:
 */
public class LocalMusicMoreDialog extends AttachDialogFragment implements LocalMoreInfoAdapter.CallBack {
    public String TAG = "LocalMusic_More";
    private TextView mTitleTv;
    private RecyclerView mItemRv;
    private LocalMoreInfoAdapter mMoreInfoAdapter;
    private ArrayList<ImageTextItem> mItemList = new ArrayList<>();
    private LocalMusic mLocalMusic;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // 背景色，动画效果，通过主题设置
        setStyle(DialogFragment.STYLE_NORMAL,R.style.CommonDialogStyle);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        //布局
        View view = inflater.inflate(R.layout.frag_info_more, container);

        initView(view);
        initListener();

        return view;
    }

    @Override
    public void onStart() {
        super.onStart();

        //设置fragment高度 、宽度
        double heightPercent = 0.4;
        int dialogHeight = (int) (mContext.getResources().getDisplayMetrics().heightPixels * heightPercent);
        Window window = getDialog().getWindow();
        WindowManager.LayoutParams params = window.getAttributes();
        params.gravity = Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL;
        params.width = WindowManager.LayoutParams.MATCH_PARENT;
        params.height = dialogHeight; // 底部弹出的DialogFragment的高度，如果是MATCH_PARENT则铺满整个窗口
        window.setAttributes(params);
        getDialog().setCanceledOnTouchOutside(true);

        initData();
    }

    private void initView(View view) {
        String musicInfo = this.getArguments().getString("music");
        if (musicInfo != null) {
            mLocalMusic = JSON.parseObject(musicInfo, LocalMusic.class);
        }
        String title = "歌曲: ";
        if (mLocalMusic != null){
            title += mLocalMusic.songName;
        }
        mTitleTv = view.findViewById(R.id.info_more_title);
        mTitleTv.setText(title);

        mItemRv = view.findViewById(R.id.info_more_recylerview);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(mContext);
        mItemRv.setLayoutManager(linearLayoutManager);
        mMoreInfoAdapter = new LocalMoreInfoAdapter();
        mMoreInfoAdapter.setCallBack(this);
        mItemRv.setAdapter(mMoreInfoAdapter);
        mItemRv.setHasFixedSize(true);
        mItemRv.addItemDecoration(new DividerItemDecoration(getContext(), DividerItemDecoration.VERTICAL));
        // 设置下拉上拉无阴影效果
        mItemRv.setOverScrollMode(View.OVER_SCROLL_NEVER);

        mItemList.clear();
        this.setMusicInfo();

        mMoreInfoAdapter.updateList(mItemList);
    }

    //设置音乐overflow条目
    private void setMusicInfo() {
        //设置mlistInfo，listview要显示的内容
        setInfo("下一首播放", R.drawable.local_next);
        setInfo("收藏到歌单", R.drawable.local_more_add);
        setInfo("删除", R.drawable.local_more_delete);
    }

    //为info设置数据，并放入mlistInfo
    private void setInfo(String title, int id) {
        ImageTextItem information = new ImageTextItem();
        information.setTitle(title);
        information.setImageRes(id);
        mItemList.add(information); //将新的info对象加入到信息列表中
    }

    private void initListener() {
    }

    private void initData() {
    }

    @Override
    public void onMoreInfoItemClick(View view, String data) {
        switch (Integer.parseInt(data)) {
            case 0:
                // TODO: 2018-11-29 下一首播放 
                dismiss();
                break;
            case 1:
                // TODO: 2018-11-29 收藏到歌单
                if (mLocalMusic != null){
                    FavoriteAddMediaDialog favoriteDialog = new FavoriteAddMediaDialog();
                    Bundle bundle = new Bundle();
                    bundle.putString("music", mLocalMusic.toString());
                    favoriteDialog.setArguments(bundle);
                    favoriteDialog.show(getFragmentManager(),"Favorite_Diag");
                }

                dismiss();
                break;
            case 2:
                // TODO: 2018-11-29 删除
                dismiss();
                break;

            default:
                dismiss();
                break;
        }
    }
}
