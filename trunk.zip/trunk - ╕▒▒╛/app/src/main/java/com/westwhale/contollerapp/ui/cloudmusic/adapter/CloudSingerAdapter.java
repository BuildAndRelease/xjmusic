package com.westwhale.contollerapp.ui.cloudmusic.adapter;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.util.Base64;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.request.RequestOptions;
import com.westwhale.contollerapp.R;
import com.westwhale.api.protocolapi.bean.albumSet.CloudSingerSet;

import java.util.ArrayList;
import java.util.List;

public class CloudSingerAdapter extends RecyclerView.Adapter {
    private List<CloudSingerSet> mItemList;
    private CallBack mCallBack;

    public interface CallBack{
        void onSingerItemClick(CloudSingerSet singerItem);
    }

    public void clearDataList(){
        if (mItemList != null){
            this.mItemList.clear();
        }
        notifyDataSetChanged();
    }

    public void addToDataList(List<CloudSingerSet> itemList){
        if (mItemList == null){
            mItemList = new ArrayList<>();
        }
        mItemList.addAll(itemList);
    }

    public void upateDataList(List<CloudSingerSet> itemList){
        this.mItemList = itemList;
    }

    public CloudSingerAdapter(CallBack callBack){
        this.mItemList = null;
        this.mCallBack = callBack;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        // 默认返回 HOST 类型的 viewHolder
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_netmusic_singer, viewGroup, false);
        return new CloudSingerItemHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder viewHolder, int i) {
        if (viewHolder instanceof CloudSingerItemHolder){
            final CloudSingerSet singer = mItemList.get(i);
            CloudSingerItemHolder itemHolder = (CloudSingerItemHolder)viewHolder;
            itemHolder.mSingerNameTv.setText(singer.Fsinger_name);

            // 首先 base64 解码
            String pic = (singer.getPic() != null) ? singer.getPic() : "";
            String url = new String(Base64.decode(pic.getBytes(), Base64.DEFAULT));
            RequestOptions mRequestOptions = RequestOptions.circleCropTransform().diskCacheStrategy(DiskCacheStrategy.NONE) //不做磁盘缓存
                    .placeholder(R.drawable.cloud_radio_default)  //未加载图片之前显示的图片
                    .error(R.drawable.cloud_radio_default);       //错误时显示的图片
//                      .skipMemoryCache(true);//不做内存缓存

            Glide.with(viewHolder.itemView)
                    .load(url)
                    .apply(mRequestOptions)
                    .into(itemHolder.mPicIv);

            itemHolder.itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    mCallBack.onSingerItemClick(singer);
                }
            });
        }
    }

    @Override
    public int getItemCount() {
        return (mItemList == null) ? 0 : mItemList.size();
    }

    private class CloudSingerItemHolder extends RecyclerView.ViewHolder{
        ImageView mPicIv;
        TextView mSingerNameTv;
        public CloudSingerItemHolder(@NonNull View itemView) {
            super(itemView);
            mPicIv = itemView.findViewById(R.id.item_netmusic_singer_pic);
            mSingerNameTv = itemView.findViewById(R.id.item_netmusic_singer_name);
        }
    }
}
