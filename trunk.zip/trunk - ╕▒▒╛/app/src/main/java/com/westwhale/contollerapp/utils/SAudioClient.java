package com.westwhale.contollerapp.utils;

import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.MediaRecorder;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.util.LinkedList;

public class SAudioClient {
    protected AudioRecord m_in_rec ;
    protected int         m_in_buf_size ;
    protected byte []     m_in_bytes ;
    protected boolean     m_keep_running ;
    protected DatagramSocket s;
    protected LinkedList<byte[]> m_in_q ;
    protected String ipAddress;
    protected int port;

    public SAudioClient(String ipAddress, int port) {
        try {
            this.ipAddress = ipAddress;
            this.port = port;
            m_in_buf_size =  AudioRecord.getMinBufferSize(44100,  AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT);
            m_in_rec = new AudioRecord(MediaRecorder.AudioSource.DEFAULT, 44100,  AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, m_in_buf_size);
            m_in_bytes = new byte [m_in_buf_size];
            m_keep_running = true;
            m_in_q=new LinkedList<>();
            s=new DatagramSocket();
        } catch (Exception e) {
            m_keep_running = false;
            e.printStackTrace();
        }
    }

    public void start() {
        try {
            m_in_rec.startRecording();
            InetAddress address = InetAddress.getByName(ipAddress);
            while(m_keep_running) {
                if(m_in_q.size() >= 2) {
                    byte[] talk_data = m_in_q.removeFirst();
                    int msg_length = talk_data.length;
                    DatagramPacket p = new DatagramPacket(talk_data, msg_length, address, port);
                    s.send(p);
                }
                m_in_rec.read(m_in_bytes, 0, m_in_bytes.length);
                m_in_q.add(m_in_bytes.clone());
            }
            m_in_rec.release();
            m_in_rec = null;
            m_in_bytes = null;
            s.close();
        } catch(Exception e) {
            e.printStackTrace();
        }
    }

    public void free() {
        m_keep_running = false;
    }
}
