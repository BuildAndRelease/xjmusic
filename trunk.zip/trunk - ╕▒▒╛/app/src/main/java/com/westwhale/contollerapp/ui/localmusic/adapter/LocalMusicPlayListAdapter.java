package com.westwhale.contollerapp.ui.localmusic.adapter;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.westwhale.contollerapp.R;
import com.westwhale.api.protocolapi.bean.media.LocalMusic;

import java.util.ArrayList;
import java.util.List;

/**
 * Description:
 * Author: chenyaoli
 * Date: 2018-11-17
 * History:
 */
public class LocalMusicPlayListAdapter extends RecyclerView.Adapter {

    private List<LocalMusic> mItemList;
    private CallBack mCallBack;
    private int mSelectedIndex;
    private LocalMusic mSelectedItem;

    public interface CallBack {
        void onSongItemClick(LocalMusic songItem);
    }

    public void updateSelectedItem(LocalMusic item){
        if ((null == item) || (mItemList == null)){
            return;
        }
        int oldIndex = -1;
        if (mSelectedItem != null){
            oldIndex = mItemList.indexOf(mSelectedItem);
        }

        int newIndex = -1;
        for (int i=0; i < mItemList.size(); i++){
            LocalMusic localMusic = mItemList.get(i);
            if (localMusic != null){
                if (localMusic.songMid.equals(item.songMid)){
                    newIndex = i;
                    mSelectedItem = localMusic;
                    break;
                }
            }
        }

        if ((newIndex != -1) && (newIndex != oldIndex)){
            if (oldIndex != -1){
                notifyItemChanged(oldIndex);
            }

            notifyItemChanged(newIndex);
        }
    }

    public void updateDataList(List<LocalMusic> itemList){
        this.mItemList = itemList;
    }

    public void clearDataList(){
        if (mItemList != null){
            this.mItemList.clear();
        }
        notifyDataSetChanged();
    }

    public void addToDataList(List<LocalMusic> itemList){
        if (mItemList == null){
            mItemList = new ArrayList<>();
            notifyDataSetChanged();
        }
        mItemList.addAll(itemList);
    }

    public LocalMusicPlayListAdapter(CallBack callBack) {
        this.mItemList = null;
        this.mCallBack = callBack;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_localmusic_song_1, viewGroup, false);
        return new MusicListItemHolder(view);

    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder viewHolder, int i) {
        // 在此处，处理默认类型的 viewHolder
        LocalMusic item = mItemList.get(i);
        MusicListItemHolder itemHolder = (MusicListItemHolder) viewHolder;

        if (item == mSelectedItem){
            //设置选中颜色
            int selectColor = itemHolder.itemView.getResources().getColor(R.color.colorAccent);
            itemHolder.mSongNoTv.setTextColor(selectColor);
            itemHolder.mTitleTv.setTextColor(selectColor);
//            itemHolder.mSubtitle.setTextColor(selectColor);
        }else{
            //设置未选中颜色
            int selectColor = itemHolder.itemView.getResources().getColor(R.color.searchdev_text);
            itemHolder.mSongNoTv.setTextColor(selectColor);
            itemHolder.mTitleTv.setTextColor(selectColor);
//            itemHolder.mSubtitle.setTextColor(selectColor);
        }

        itemHolder.mSongNoTv.setText(String.valueOf(i+1));
        itemHolder.mTitleTv.setText(item.songName);
//        String subtitle = item.getSingersName() + "-" + item.albumName + "";
//        itemHolder.mSubtitle.setText(subtitle);

        viewHolder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mCallBack.onSongItemClick(item);
            }
        });

    }

    @Override
    public int getItemCount() {
        return (mItemList == null) ? 0 : mItemList.size();
    }


    private class MusicListItemHolder extends RecyclerView.ViewHolder {
        TextView mSongNoTv, mTitleTv, mSubtitle;

        MusicListItemHolder(@NonNull View itemView) {
            super(itemView);
            mSongNoTv = itemView.findViewById(R.id.localmusic_song_item_no);
            mTitleTv = itemView.findViewById(R.id.localmusic_song_item_name);
            mSubtitle = itemView.findViewById(R.id.localmusic_song_item_artist);
        }
    }
}
