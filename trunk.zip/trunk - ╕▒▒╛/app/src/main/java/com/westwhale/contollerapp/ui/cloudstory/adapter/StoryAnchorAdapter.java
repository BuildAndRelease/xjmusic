package com.westwhale.contollerapp.ui.cloudstory.adapter;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.util.Base64;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.request.RequestOptions;
import com.westwhale.contollerapp.R;
import com.westwhale.api.protocolapi.bean.telling.Anchor;

import java.util.ArrayList;
import java.util.List;

public class StoryAnchorAdapter extends RecyclerView.Adapter {
    private List<Anchor> mItemList;
    private CallBack mCallBack;

    public interface CallBack{
        void onAnchorItemClick(Anchor singerItem);
    }

    public void clearDataList(){
        if (mItemList != null){
            this.mItemList.clear();
        }
        notifyDataSetChanged();
    }

    public void addToDataList(List<Anchor> itemList){
        if (mItemList == null){
            mItemList = new ArrayList<>();
        }
        mItemList.addAll(itemList);
    }

    public void upateDataList(ArrayList<Anchor> itemList){
        this.mItemList = itemList;
    }

    public StoryAnchorAdapter(CallBack callBack){
        this.mItemList = null;
        this.mCallBack = callBack;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        // 默认返回 HOST 类型的 viewHolder
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_story_anchor, viewGroup, false);
        return new StoryAnchorItemHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder viewHolder, int i) {
        final Anchor item = mItemList.get(i);
        StoryAnchorItemHolder itemHolder = (StoryAnchorItemHolder)viewHolder;
        itemHolder.mNameTv.setText(item.nickname);

        // 首先 base64 解码

        String pic = (item.pic != null) ? item.pic : "";
        String url = pic;
        try {
            if (!pic.startsWith("http:")) {
                url = new String(Base64.decode(pic.getBytes(), Base64.DEFAULT));
            }
        }catch (Exception e){
            url = "";
            e.printStackTrace();
        }
        RequestOptions mRequestOptions = RequestOptions.circleCropTransform().diskCacheStrategy(DiskCacheStrategy.NONE) //不做磁盘缓存
                .placeholder(R.drawable.cloud_radio_default)  //未加载图片之前显示的图片
                .error(R.drawable.cloud_radio_default);       //错误时显示的图片
//                      .skipMemoryCache(true);//不做内存缓存

        Glide.with(viewHolder.itemView)
                .load(url)
                .apply(mRequestOptions)
                .into(itemHolder.mPicIv);

        itemHolder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mCallBack.onAnchorItemClick(item);
            }
        });
    }

    @Override
    public int getItemCount() {
        return (mItemList == null) ? 0 : mItemList.size();
    }

    private class StoryAnchorItemHolder extends RecyclerView.ViewHolder{
        ImageView mPicIv;
        TextView mNameTv;
        public StoryAnchorItemHolder(@NonNull View itemView) {
            super(itemView);
            mPicIv = itemView.findViewById(R.id.item_story_anchor_pic);
            mNameTv = itemView.findViewById(R.id.item_story_anchor_name);
        }
    }
}
