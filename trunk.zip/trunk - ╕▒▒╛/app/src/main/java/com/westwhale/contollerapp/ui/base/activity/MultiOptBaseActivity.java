package com.westwhale.contollerapp.ui.base.activity;

import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;

import com.westwhale.contollerapp.ui.base.adapter.MultiOptBaseAdapter;

public class MultiOptBaseActivity<T> extends BaseActivity implements MultiOptBaseAdapter.CallBack<T> {
    private Toolbar mToolbar;
    private RecyclerView mDataRecyclerView;

    @Override
    public void onMultiItemClick(T item, boolean selected) {

    }

    @Override
    public void onCheckedNumChanged(int selectednum) {

    }
}
