package com.westwhale.contollerapp.ui.timer.activity;


import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.CheckBox;
import android.widget.LinearLayout;

import com.westwhale.contollerapp.R;
import com.westwhale.contollerapp.ui.base.activity.BaseActivity;
import com.westwhale.contollerapp.ui.localmusic.activity.SelectLocalMusicActivity;
import com.westwhale.contollerapp.ui.timer.TimerDefine;
import com.westwhale.api.protocolapi.bean.media.LocalMusic;

/**
 * Description:
 * Author: chenyaoli
 * Date: 2018-12-20
 * History
 */
public class TimerOpenMediaActivity extends BaseActivity {
    private final String TAG = TimerOpenMediaActivity.class.getName();

    private final int REQUEST_CODE_OPENMEDIA_LOCALMUSIC = 1;
    private final int OPENMEDIA_MODE_DEFAULT = 1;
    private final int OPENMEDIA_MODE_LOCALMUSIC = 2;

    private Toolbar mToolbar;
    private LinearLayout mDefaultLayout, mLocalMusicLayout;
    private CheckBox mDefaultChx, mLocalMusicChx;

    private CheckBox mCurrentSelectedChx;

    private LocalMusic mMedia;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_timer_openmedia);

        initView();
        initListener();

        initData();
    }

    @Override
    protected void onPause() {
        super.onPause();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if ((requestCode == REQUEST_CODE_OPENMEDIA_LOCALMUSIC) && (resultCode == Activity.RESULT_OK)){

            setResult(Activity.RESULT_OK,data);

            finish();
        }
    }

    private void initView() {
        mToolbar = findViewById(R.id.timer_openmedia_toolbar);
        // 设置toolbar
        setSupportActionBar(mToolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        mDefaultLayout = findViewById(R.id.timer_openmedia_default_layout);
        mDefaultChx = findViewById(R.id.timer_openmedia_default_checkbox);

        mLocalMusicLayout = findViewById(R.id.timer_openmedia_localmusic_layout);
        mLocalMusicChx = findViewById(R.id.timer_openmedia_localmusic_checkbox);
    }

    private void initListener() {
        mToolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        mDefaultLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                switchToMediaMode(OPENMEDIA_MODE_DEFAULT);
                Intent intent = new Intent();
                intent.putExtra(TimerDefine.TIMER_INTENT_ARG_KEY_MEDIA,"");
                setResult(Activity.RESULT_OK,new Intent());

                finish();
            }
        });

        mLocalMusicLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                switchToMediaMode(OPENMEDIA_MODE_LOCALMUSIC);
                startActivityForResult(new Intent(TimerOpenMediaActivity.this, SelectLocalMusicActivity.class),REQUEST_CODE_OPENMEDIA_LOCALMUSIC);
            }
        });

    }

    private void switchToMediaMode(int i) {
        if (mCurrentSelectedChx != null){
            mCurrentSelectedChx.setChecked(false);
        }


        switch (i){
            case OPENMEDIA_MODE_DEFAULT:{
                mCurrentSelectedChx = mDefaultChx;

                break;
            }
            case OPENMEDIA_MODE_LOCALMUSIC:{
                mCurrentSelectedChx = mLocalMusicChx;
                break;
            }
            default:
                break;
        }

        if (mCurrentSelectedChx != null) {
            mCurrentSelectedChx.setChecked(true);
        }
    }


    private void initData() {
        //初始化
        Intent intent = getIntent();
        if (intent != null){

            LocalMusic media = intent.getParcelableExtra("media");

            int repeatMode = OPENMEDIA_MODE_DEFAULT;
            if (media != null){
                repeatMode = OPENMEDIA_MODE_LOCALMUSIC;
            }

            switchToMediaMode(repeatMode);
        }
    }

}
