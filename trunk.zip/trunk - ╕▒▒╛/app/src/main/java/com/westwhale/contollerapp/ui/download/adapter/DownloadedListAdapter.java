package com.westwhale.contollerapp.ui.download.adapter;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.westwhale.contollerapp.R;
import com.westwhale.api.protocolapi.bean.media.CloudMusic;
import com.westwhale.api.protocolapi.bean.media.Media;
import com.westwhale.api.protocolapi.bean.download.DownloadItem;

import java.util.ArrayList;
import java.util.List;

public class DownloadedListAdapter extends RecyclerView.Adapter {
    private List<DownloadItem<CloudMusic>> mItemList;
    private CallBack mCallBack;

    public interface CallBack{
        void onDownloadedItemClick(List<DownloadItem<CloudMusic>> itemList, DownloadItem<CloudMusic> item);

        void onDownloadedItemMoreClick(DownloadItem<CloudMusic> item);
    }

    public void setDataList(List<DownloadItem<CloudMusic>> itemList){
        if (mItemList != null){
            mItemList.clear();
            notifyDataSetChanged();
        }
        mItemList = itemList;
    }

    public List<DownloadItem<CloudMusic>> getDataList(){
        return mItemList;
    }

    public void clearDataList(){
        if (mItemList != null){
            this.mItemList.clear();
        }
        notifyDataSetChanged();
    }

    public void addToDataList(List<DownloadItem<CloudMusic>> itemList){
        if (mItemList == null){
            mItemList = new ArrayList<>();
            notifyDataSetChanged();
        }
        mItemList.addAll(itemList);
    }

    public DownloadedListAdapter(CallBack callBack){
        this.mItemList = null;
        this.mCallBack = callBack;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        // 默认返回 HOST 类型的 viewHolder
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_download_downloaded_media, viewGroup, false);
        return new ItemHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder viewHolder, int i) {
        DownloadItem<CloudMusic> item = mItemList.get(i);
        ItemHolder itemHolder = (ItemHolder)viewHolder;

        String text = "";
        int colorResourceId = R.color.colorText;
        boolean canPlay = true;
        if (item.media.canPlay == 1) {
            text = "无版权";
            colorResourceId = R.color.colorGrey;
            canPlay = false;
        }
        String title = "";
        String subtitle = "";
        switch(item.mediaSrc){
            case Media.CLOUD_MUSIC:
                title = item.media.songName;
                subtitle = item.media.getSingersName();
                break;
            case Media.LOCAL_MUSIC:
                title = item.media.songName;
                subtitle = item.mediaSrc;
                break;
            default:
                subtitle = item.mediaSrc;
                break;
        }

        itemHolder.mItemNoTv.setText(String.valueOf(i+1));
        itemHolder.mTitleTv.setText(title);
        itemHolder.mSubTitleTv.setText(subtitle);
        itemHolder.mCopyrightTv.setText(text);

        int color = itemHolder.itemView.getResources().getColor(colorResourceId);
        itemHolder.mItemNoTv.setTextColor(color);
        itemHolder.mTitleTv.setTextColor(color);
        itemHolder.mSubTitleTv.setTextColor(color);
        itemHolder.mCopyrightTv.setTextColor(color);

        viewHolder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mCallBack.onDownloadedItemClick(mItemList, item);
            }
        });

        ((ItemHolder) viewHolder).mItemMoreIv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mCallBack.onDownloadedItemMoreClick(item);
            }
        });
    }

    @Override
    public int getItemCount() {
        return (mItemList != null) ? mItemList.size() : 0;
    }

    private class ItemHolder extends RecyclerView.ViewHolder{
        ImageView mItemMoreIv;
        TextView mItemNoTv, mTitleTv, mSubTitleTv,mCopyrightTv;
        public ItemHolder(@NonNull View itemView) {
            super(itemView);
            mItemNoTv = itemView.findViewById(R.id.download_downloaded_media_item_no);
            mTitleTv = itemView.findViewById(R.id.download_downloaded_media_item_title);
            mSubTitleTv = itemView.findViewById(R.id.download_downloaded_media_item_subtitle);
            mCopyrightTv = itemView.findViewById(R.id.download_downloaded_media_copyright);

            mItemMoreIv = itemView.findViewById(R.id.download_downloaded_media_item_more);
        }
    }
}
