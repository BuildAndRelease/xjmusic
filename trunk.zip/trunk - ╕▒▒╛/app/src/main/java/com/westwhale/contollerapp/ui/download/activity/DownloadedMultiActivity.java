package com.westwhale.contollerapp.ui.download.activity;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.blankj.utilcode.util.ToastUtils;
import com.westwhale.api.protocolapi.BAKey;
import com.westwhale.contollerapp.R;
import com.westwhale.contollerapp.application.WApp;
import com.westwhale.contollerapp.dev.CmdActionLister;
import com.westwhale.contollerapp.dev.ICmdCallback;
import com.westwhale.contollerapp.dev.WRoom;
import com.westwhale.contollerapp.ui.base.activity.BaseActivity;
import com.westwhale.contollerapp.ui.download.adapter.DownloadedItemMultiAdapter;
import com.westwhale.contollerapp.ui.download.fragment.DownloadedListFragment;
import com.westwhale.contollerapp.ui.favorite.songsheet.dialog.FavoriteAddMediaDialog;
import com.westwhale.api.protocolapi.CMD;
import com.westwhale.api.protocolapi.bean.media.CloudMusic;
import com.westwhale.api.protocolapi.bean.media.Media;
import com.westwhale.api.protocolapi.bean.download.DownloadItem;

import java.util.ArrayList;
import java.util.List;

/**
 * Description:
 * Author: chenyaoli
 * Date: 2018-12-12
 * History:
 */
public class DownloadedMultiActivity extends BaseActivity implements DownloadedItemMultiAdapter.CallBack {
    private Toolbar mToolbar;
    private RecyclerView mDataRecyclerView;
    private LinearLayout mPlayLayout,mPlaylistAddLayout, mFavoriteAddLayout, mDeleteLayout;
    private DownloadedItemMultiAdapter mMultiAdapter;
    private Menu mMenu;

    private static List<DownloadItem<CloudMusic>> mItemList;

    public static void setDataList(List<DownloadItem<CloudMusic>> list){
        mItemList = list;
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_downloaded_select);

        initView();
        initListener();
        initData();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        mItemList = null;
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        super.onCreateOptionsMenu(menu);

        getMenuInflater() .inflate(R.menu.menu_batch, menu);

        mMenu = menu;
        return true;
    }

    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {
        MenuItem item = menu.findItem(R.id.menu_select_all);

        return super.onPrepareOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.menu_select_all){
            if (mMultiAdapter.getSelectedNum() == mMultiAdapter.getItemCount()){
                // 全不选
                mMultiAdapter.cancelAllItem();
            }else{
                // 全选
                mMultiAdapter.selectAllItem();
            }
        }
        return super.onOptionsItemSelected(item);
    }

    private void initView() {
        mToolbar = findViewById(R.id.item_mutli_toolbar);
        // 设置toolbar
        setSupportActionBar(mToolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setHomeAsUpIndicator(R.drawable.cloud_mutli_backup);
        }

        mPlayLayout = findViewById(R.id.item_mutli_play);
        mPlaylistAddLayout = findViewById(R.id.item_mutli_playlist_add);
        mFavoriteAddLayout = findViewById(R.id.item_mutli_favorite_add);
        mDeleteLayout = findViewById(R.id.item_mutli_delete);

        mDataRecyclerView = findViewById(R.id.item_mutli_recyclerview);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        mDataRecyclerView.setLayoutManager(linearLayoutManager);
        mMultiAdapter = new DownloadedItemMultiAdapter(this);
        mDataRecyclerView.setAdapter(mMultiAdapter);
        mDataRecyclerView.setHasFixedSize(true);
        mDataRecyclerView.addItemDecoration(new DividerItemDecoration(this, DividerItemDecoration.VERTICAL));
    }

    private void initListener() {
        mToolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        mPlayLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 开始播放已选择的歌曲
                CloudMusic item = null;
                List<CloudMusic> itemList = new ArrayList<>();
                if (mMultiAdapter != null){
                    List<DownloadItem<CloudMusic>> selectedList = mMultiAdapter.getSelectedList();
                    if ((selectedList != null) && (selectedList.size() > 0)){
                        for (int i=0; i < selectedList.size(); i++){
                            DownloadItem<CloudMusic> tempItem = selectedList.get(i);
                            if ((tempItem != null) && (tempItem.media != null)){
                                itemList.add(tempItem.media);
                            }
                        }
                    }
                }
                if (itemList.size() > 0){
                    item = itemList.get(0);
                    WRoom room = WApp.Instance.getDevManager().getSelectedRoom();
                    if (room != null){
                        WRoom.cmdPlayCloudMusicList(item,itemList,new CmdActionLister<>(DownloadedMultiActivity.this, new ICmdCallback<Boolean>() {
                            @Override
                            public void onSuccess(Boolean data) {

                            }

                            @Override
                            public void onFailed(int code, String msg) {
                                Toast.makeText(DownloadedMultiActivity.this, "播放歌曲失败...", Toast.LENGTH_SHORT).show();
                            }
                        }));
                    }
                }else{
                    Toast.makeText(DownloadedMultiActivity.this, "列表为空", Toast.LENGTH_SHORT).show();
                }

            }
        });

        mPlaylistAddLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 添加到播放列表
                List<CloudMusic> itemList = new ArrayList<>();
                if (mMultiAdapter != null){
                    List<DownloadItem<CloudMusic>> selectedList = mMultiAdapter.getSelectedList();
                    if ((selectedList != null) && (selectedList.size() > 0)){
                        for (int i=0; i < selectedList.size(); i++){
                            DownloadItem<CloudMusic> tempItem = selectedList.get(i);
                            if ((tempItem != null) && (tempItem.media != null)){
                                itemList.add(tempItem.media);
                            }
                        }
                    }
                }
                if (itemList.size() > 0){
                    WRoom room = WApp.Instance.getDevManager().getSelectedRoom();
                    if (room != null){
                        WRoom.cmdAddToCloudMusicList(itemList,new CmdActionLister<>(DownloadedMultiActivity.this, new ICmdCallback<Boolean>() {
                            @Override
                            public void onSuccess(Boolean data) {
                                Toast.makeText(DownloadedMultiActivity.this, "添加到播放列表成功", Toast.LENGTH_SHORT).show();
                            }

                            @Override
                            public void onFailed(int code, String msg) {
                                Toast.makeText(DownloadedMultiActivity.this, "添加失败...", Toast.LENGTH_SHORT).show();
                            }
                        }));
                    }
                }else{
                    Toast.makeText(DownloadedMultiActivity.this, "列表为空", Toast.LENGTH_SHORT).show();
                }

            }
        });

        mFavoriteAddLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 将已选择的歌曲添加到云音乐播放列表
                List<CloudMusic> itemList = new ArrayList<>();
                if (mMultiAdapter != null){
                    List<DownloadItem<CloudMusic>> selectedList = mMultiAdapter.getSelectedList();
                    if ((selectedList != null) && (selectedList.size() > 0)){
                        for (int i=0; i < selectedList.size(); i++){
                            DownloadItem<CloudMusic> tempItem = selectedList.get(i);
                            if ((tempItem != null) && (tempItem.media != null)){
                                itemList.add(tempItem.media);
                            }
                        }
                    }
                }
                if (itemList.size() > 0){
                    FavoriteAddMediaDialog favoriteDialog = new FavoriteAddMediaDialog();
                    favoriteDialog.updateMediaList(Media.CLOUD_MUSIC,itemList);
                    favoriteDialog.show(getSupportFragmentManager(),FavoriteAddMediaDialog.TAG);
                }else{
                    Toast.makeText(DownloadedMultiActivity.this, "列表为空", Toast.LENGTH_SHORT).show();
                }
            }
        });

        mDeleteLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 删除已下载的歌曲
                List<DownloadItem<CloudMusic>> selectedList = null;
                if (mMultiAdapter != null) {
                    selectedList = mMultiAdapter.getSelectedList();
                }
                if ((selectedList != null) && (selectedList.size() > 0)){
                    WRoom room = WApp.Instance.getDevManager().getSelectedRoom();
                    if (room != null){
                        room.cmdOperatorDownload(BAKey.ARG_DEL_DOWNLOADED,selectedList,new CmdActionLister<Boolean>(DownloadedMultiActivity.this, new ICmdCallback<Boolean>() {
                            @Override
                            public void onSuccess(Boolean data) {
                                if (data) {
                                    ToastUtils.showShort("删除成功");

                                    mItemList.removeAll(mMultiAdapter.getSelectedList());
                                    mMultiAdapter.cancelAllItem();

                                    setResult(DownloadedListFragment.ACTIVITY_RESULT_CODE_DETELE, new Intent());
                                }
                            }

                            @Override
                            public void onFailed(int code, String msg) {
                                ToastUtils.showShort("删除失败 %d",code);
                            }
                        }));
                    }
                }else{
                    Toast.makeText(DownloadedMultiActivity.this, "列表为空", Toast.LENGTH_SHORT).show();
                }

            }
        });
    }

    private void initData() {
        if (mItemList != null) {
            mMultiAdapter.setDataList(mItemList);
            mMultiAdapter.notifyDataSetChanged();
        }
    }

    @Override
    public void onMultiItemClick(DownloadItem<CloudMusic> item, boolean selected) {

    }

    @Override
    public void onCheckedNumChanged(int selectednum) {
        String title = getString(R.string.toolbar_menu_all_select);
        if ((selectednum == mMultiAdapter.getItemCount()) && (selectednum != 0)){
            title = getString(R.string.toolbar_menu_all_un_select);
        }
        updateMenuTitle(title);

        String toolbarTitle = getString(R.string.downloaded_multi_title);
        if (selectednum > 0){
            toolbarTitle = toolbarTitle + "(" + selectednum +")";
        }
        mToolbar.setTitle(toolbarTitle);
    }

    private void updateMenuTitle(String title){

        if (mMenu != null) {
            MenuItem menuItem = mMenu.findItem(R.id.menu_select_all);
            if (menuItem != null) {
                menuItem.setTitle(title);
            }
        }
    }
}
