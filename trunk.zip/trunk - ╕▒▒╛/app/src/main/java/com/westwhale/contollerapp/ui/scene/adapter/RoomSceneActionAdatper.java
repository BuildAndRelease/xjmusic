package com.westwhale.contollerapp.ui.scene.adapter;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.util.Base64;
import android.util.SparseBooleanArray;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.load.resource.bitmap.RoundedCorners;
import com.bumptech.glide.request.RequestOptions;
import com.westwhale.api.protocolapi.bean.cloudmusic.TopCate;
import com.westwhale.api.protocolapi.bean.hostroom.Room;
import com.westwhale.contollerapp.R;
import com.westwhale.contollerapp.ui.scene.bean.CmdActionBase;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Description:
 * Author: chenyaoli
 * Date: 2018-12-06
 * History:
 */
public class RoomSceneActionAdatper extends RecyclerView.Adapter{

    private List<CmdActionBase> mItemList;
    private CallBack mCallBack;

    private SparseBooleanArray mCheckStatList = new SparseBooleanArray();

    public RoomSceneActionAdatper(){
        mItemList = null;
        mCallBack = null;
    }

    public interface CallBack{
        void onItemClick(CmdActionBase item,int pos);
    }

    public void setCallBack(CallBack callBack){
        mCallBack = callBack;
    }

    public void setDataList(List<CmdActionBase> dataList){
        mCheckStatList.clear();
        if (mItemList != null){
            mItemList.clear();
            mItemList = null;
            notifyDataSetChanged();
        }
        mItemList = dataList;
    }

    public void setDataList(List<CmdActionBase> cmdDataList, Map<CmdActionBase, Boolean> dataMap) {
        mCheckStatList.clear();
        if (mItemList != null){
            mItemList.clear();
            mItemList = null;
            notifyDataSetChanged();
        }

        mItemList =cmdDataList;
        if ((mItemList != null)) {
            for (int i = 0; i < mItemList.size(); i++){
                boolean contain = false;
                try {
                    contain = ((dataMap != null) && dataMap.get(mItemList.get(i)));
                }catch (Exception e){
                    e.printStackTrace();
                }

                mCheckStatList.put(i,contain);
            }
        }
    }

    public void clearAllData(){
        mCheckStatList.clear();
        if (mItemList != null){
            mItemList.clear();
            mItemList = null;
            notifyDataSetChanged();
        }
    }

    public List<CmdActionBase> getSelectedList(){
        List<CmdActionBase> dataList = new ArrayList<>();
        for (int i=0; i < mCheckStatList.size(); i++){
            boolean isChecked = mCheckStatList.valueAt(i);
            if (isChecked){
                dataList.add(mItemList.get(i));
            }
        }

        return dataList;
    }

    public void updateItem(CmdActionBase action,boolean checkStat){
        if (mItemList != null){
            int index = mItemList.indexOf(action);
            if (index > -1){
                mCheckStatList.put(index,checkStat);
                notifyItemChanged(index);
            }
        }
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_scene_roomsceneaction, viewGroup, false);
        return new ItemHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder viewHolder, int i) {
        if ( viewHolder instanceof ItemHolder){
            int pos = viewHolder.getAdapterPosition();
            ItemHolder itemHolder = (ItemHolder)viewHolder;
            CmdActionBase cmdaction = mItemList.get(pos);

            itemHolder.mCheckBox.setChecked(mCheckStatList.get(pos));
            itemHolder.mNameTv.setText(cmdaction.getActionName());
            itemHolder.mValueTv.setText(cmdaction.getActionValue());

            itemHolder.mHeadLayout.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    boolean newCheckStat = !itemHolder.mCheckBox.isChecked();
                    mCheckStatList.put(pos,newCheckStat);
                    itemHolder.mCheckBox.setChecked(newCheckStat);
                }
            });

            itemHolder.itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (mCallBack != null){
                        mCallBack.onItemClick(cmdaction,pos);
                    }
                }
            });
        }
    }

    @Override
    public int getItemCount() {
        return mItemList.size();
    }



    private class ItemHolder extends RecyclerView.ViewHolder{
        LinearLayout mHeadLayout;
        CheckBox mCheckBox;
        TextView mNameTv,mValueTv;
        public ItemHolder(@NonNull View itemView) {
            super(itemView);
            mHeadLayout = itemView.findViewById(R.id.item_scene_roomsceneaction_headlayout);
            mCheckBox = itemView.findViewById(R.id.item_scene_roomsceneaction_checkbox);
            mNameTv = itemView.findViewById(R.id.item_scene_roomsceneaction_name);
            mValueTv = itemView.findViewById(R.id.item_scene_roomsceneaction_value);
        }
    }
}