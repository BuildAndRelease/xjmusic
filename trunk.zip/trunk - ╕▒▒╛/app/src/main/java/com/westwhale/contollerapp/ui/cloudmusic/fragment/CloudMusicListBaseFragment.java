package com.westwhale.contollerapp.ui.cloudmusic.fragment;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.load.resource.bitmap.CenterCrop;
import com.bumptech.glide.request.RequestOptions;
import com.kingja.loadsir.callback.Callback;
import com.kingja.loadsir.callback.SuccessCallback;
import com.kingja.loadsir.core.LoadService;
import com.kingja.loadsir.core.LoadSir;
import com.scwang.smartrefresh.layout.api.RefreshLayout;
import com.scwang.smartrefresh.layout.listener.OnLoadMoreListener;
import com.scwang.smartrefresh.layout.listener.OnRefreshListener;
import com.westwhale.contollerapp.R;
import com.westwhale.contollerapp.ui.cloudmusic.activity.CloudMusicMultiActivity;
import com.westwhale.contollerapp.ui.cloudmusic.adapter.CloudSongAdapter;
import com.westwhale.contollerapp.application.WApp;
import com.westwhale.contollerapp.dev.CmdActionLister;
import com.westwhale.contollerapp.dev.ICmdCallback;
import com.westwhale.contollerapp.dev.WRoom;
import com.westwhale.contollerapp.ui.cloudmusic.dialog.CloudMusicMoreDialog;
import com.westwhale.contollerapp.ui.base.fragment.BaseFragment;
import com.westwhale.contollerapp.ui.loadsircallback.EmptyCallback;
import com.westwhale.contollerapp.ui.loadsircallback.ErrorCallback;
import com.westwhale.contollerapp.ui.loadsircallback.LoadingCallback;
import com.westwhale.contollerapp.ui.loadsircallback.TimeoutCallback;
import com.westwhale.api.protocolapi.bean.media.CloudMusic;

import java.util.List;

import jp.wasabeef.glide.transformations.BlurTransformation;

/**
 * Description:
 * Author: chenyaoli
 * Date: 2018-11-16
 * History:
 */
public abstract class CloudMusicListBaseFragment extends BaseFragment implements CloudSongAdapter.CallBack {
    private final static String TAG = "CloudMusicListBase";

    protected Toolbar mToolBar;
    protected ImageView mHeaderBlurPicIv,mHeaderPicIv,mPlayIv,mAddFavoriteIv,mEditIv;
    protected TextView mTitleTv, mSubTitleTv;
    protected FrameLayout mLoadingFLayout;
    protected RecyclerView mRecyclerView;
    protected RefreshLayout mRefreshLayout;

    protected CloudSongAdapter mMusicAdapter;
    protected LoadService mLoadService;

    public abstract void initData();
    public abstract boolean hasMoreData();
    public abstract void loadMoreData();
    public abstract void updateDataList(List<CloudMusic> list);
    public abstract void requestCloudResource();

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        // 先显示加载动画，针对布局做一些初始化
        return inflater.inflate(R.layout.frag_netmusic_musiclist,container,false);

    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        initView(view);
        initListener();

        LoadSir loadSir = new LoadSir.Builder()
                .addCallback(new LoadingCallback())
                .addCallback(new TimeoutCallback())
                .addCallback(new ErrorCallback())
                .addCallback(new EmptyCallback())
                .setDefaultCallback(LoadingCallback.class)
                .build();

//        RecyclerView dataRecycleView = view.findViewById(R.id.netmusic_musiclist_recyclerview);
        mLoadingFLayout = view.findViewById(R.id.netmusic_musiclist_loadsir_layout);
//         创建mLoadService
        mLoadService = loadSir.register(mLoadingFLayout, new Callback.OnReloadListener() {
            @Override
            public void onReload(View v) {
                initData();
            }
        });

        initData();
    }

    @Override
    public void onResume() {
        super.onResume();
    }

    @Override
    public void onSongItemClick(List<CloudMusic> itemList, CloudMusic songItem) {
        // 点击推荐歌曲的某歌曲，开始播放
        WRoom room = WApp.Instance.getDevManager().getSelectedRoom();
        if (room != null){
            WRoom.cmdPlayCloudMusicList(songItem,itemList,new CmdActionLister<>(CloudMusicListBaseFragment.this, new ICmdCallback<Boolean>() {
                @Override
                public void onSuccess(Boolean data) {

                }

                @Override
                public void onFailed(int code, String msg) {
                    Toast.makeText(getContext(), "播放歌曲失败...", Toast.LENGTH_SHORT).show();
                }
            }));
        }
    }

    @Override
    public void onSongItemMoreClick(CloudMusic songItem) {
        // 点击推荐歌曲的某Item项的更多按钮时，弹出更多选项框
        CloudMusicMoreDialog moreDialog = new CloudMusicMoreDialog();
        Bundle bundle = new Bundle();
        bundle.putString(CloudMusicMoreDialog.MUSIC_ITEM,songItem.toString());
        moreDialog.setArguments(bundle);
        moreDialog.show(getChildFragmentManager(),CloudMusicMoreDialog.TAG);
    }

    public void showLoadCallBack(Class<? extends Callback> callback){
        if (mLoadService != null){
            mLoadService.showCallback(callback);
            if (callback == SuccessCallback.class){
                if(mLoadingFLayout != null) {
                    mLoadingFLayout.setVisibility(View.INVISIBLE);
                }
                if (mRecyclerView != null){
                    mRecyclerView.setVisibility(View.VISIBLE);
                }

                if (mRefreshLayout != null){
                    mRefreshLayout.setEnableLoadMore(true);
                    mRefreshLayout.setEnableNestedScroll(true);
                }
            }else{
                if(mLoadingFLayout != null) {
                    mLoadingFLayout.setVisibility(View.VISIBLE);
                }
                if (mRecyclerView != null){
                    mRecyclerView.setVisibility(View.INVISIBLE);
                }

                if (mRefreshLayout != null){
                    mRefreshLayout.setEnableLoadMore(false);
                    mRefreshLayout.setEnableNestedScroll(false);
                }
            }
        }
    }

    private void initView(View view){
        mToolBar = view.findViewById(R.id.netmusic_musiclist_toolbar);
        mToolBar.setNavigationIcon(R.drawable.home_backup);

        mHeaderBlurPicIv = view.findViewById(R.id.netmusic_musiclist_header_albumpic);
        mHeaderPicIv = view.findViewById(R.id.netmusic_musiclist_header_pic);

        mTitleTv = view.findViewById(R.id.netmusic_musiclist_header_title);
        mSubTitleTv = view.findViewById(R.id.netmusic_musiclist_header_subtitle);

        mPlayIv = view.findViewById(R.id.netmusic_musiclist_header_play);
        mAddFavoriteIv = view.findViewById(R.id.netmusic_musiclist_header_favorite);
        mAddFavoriteIv.setColorFilter(R.color.colorGrey);
        mEditIv = view.findViewById(R.id.netmusic_musiclist_header_edit);

        mRecyclerView = view.findViewById(R.id.netmusic_musiclist_recyclerview);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(mContext);
        mRecyclerView.setLayoutManager(linearLayoutManager);
        mMusicAdapter = new CloudSongAdapter(this);
        mRecyclerView.setAdapter(mMusicAdapter);
        mRecyclerView.setHasFixedSize(true);
        mRecyclerView.addItemDecoration(new DividerItemDecoration(mContext, DividerItemDecoration.VERTICAL));
        // 设置下拉上拉无阴影效果
        mRecyclerView.setOverScrollMode(View.OVER_SCROLL_NEVER);
//        mRecyclerView.setNestedScrollingEnabled(false);

        mRefreshLayout = view.findViewById(R.id.netmusic_musiclist_refreshlayout);
        mRefreshLayout.setEnableRefresh(false);
//        mRefreshLayout.setDisableContentWhenRefresh(true);
        mRefreshLayout.setEnableLoadMore(true);

    }

    private void initListener(){
        mToolBar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (getActivity() != null){
                    getActivity().onBackPressed();
                }
            }
        });

        mPlayIv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 点击推荐歌曲的某歌曲，开始播放
                CloudMusic item = null;
                List<CloudMusic> itemList = null;
                if (mMusicAdapter != null){
                    itemList = mMusicAdapter.getDataList();
                    if ((itemList != null) && (itemList.size() > 0)){
                        item = itemList.get(0);
                    }
                }
                WRoom room = WApp.Instance.getDevManager().getSelectedRoom();
                if (room != null){
                    WRoom.cmdPlayCloudMusicList(item,itemList,new CmdActionLister<>(CloudMusicListBaseFragment.this, new ICmdCallback<Boolean>() {
                        @Override
                        public void onSuccess(Boolean data) {

                        }

                        @Override
                        public void onFailed(int code, String msg) {
                            Toast.makeText(getContext(), "播放歌曲失败...", Toast.LENGTH_SHORT).show();
                        }
                    }));
                }
            }
        });

        mAddFavoriteIv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // TODO: 2018-11-16 弹出添加到收藏界面
            }
        });

        mEditIv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 跳转到歌曲编辑界面
                Intent intent = new Intent(getContext(), CloudMusicMultiActivity.class);
                String data = "";
                try {
                    JSONArray array= JSONArray.parseArray(JSON.toJSONString(mMusicAdapter.getDataList()));
                    data = array.toJSONString();
                }catch (Exception e){
                    e.printStackTrace();
                }
                intent.putExtra(CloudMusicMultiActivity.DATA_MUSIC_LIST,data);
                startActivity(intent);
            }
        });

        mRefreshLayout.setOnRefreshListener(new OnRefreshListener() {
            @Override
            public void onRefresh(@NonNull RefreshLayout refreshLayout) {
                initData();
            }
        });

        mRefreshLayout.setOnLoadMoreListener(new OnLoadMoreListener() {
            @Override
            public void onLoadMore(@NonNull RefreshLayout refreshLayout) {
                //  判断是否还有数据，从而判断是否还需要加载更多数据
                if( hasMoreData() ){
                    loadMoreData();
                }else {
                    mRefreshLayout.finishLoadMoreWithNoMoreData();
                }
            }
        });
    }


    protected void updateHeader(String toolbartitle,String title,String subtitle,String picurl){
        mToolBar.setTitle(toolbartitle);
        mTitleTv.setText(title);
        mSubTitleTv.setText(subtitle);

        RequestOptions mRequestOptions = RequestOptions.bitmapTransform(new BlurTransformation( 14, 3)).diskCacheStrategy(DiskCacheStrategy.NONE) //不做磁盘缓存
                .placeholder(R.drawable.cloud_album_default)  //未加载图片之前显示的图片
                .error(R.drawable.cloud_album_default)     //错误时显示的图片
                .override(350, 350);
        Glide.with(mContext)
                .load(picurl)
                .apply(mRequestOptions)
                .into(mHeaderBlurPicIv);


        mRequestOptions = RequestOptions.bitmapTransform(new CenterCrop()).diskCacheStrategy(DiskCacheStrategy.NONE) //不做磁盘缓存
                .placeholder(R.drawable.cloud_album_default)  //未加载图片之前显示的图片
                .error(R.drawable.cloud_album_default)     //错误时显示的图片
                .override(350, 350);
        Glide.with(mContext).asDrawable()
                .load(picurl)
                .apply(mRequestOptions)
                .into(mHeaderPicIv);
    }
}
