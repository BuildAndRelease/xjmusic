package com.westwhale.contollerapp.ui.scene.bean;


import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.westwhale.api.protocolapi.bean.media.LocalMusic;

public class CmdPlayLocalMusic extends CmdActionBase {

    private LocalMusic mMedia = null;

    public CmdPlayLocalMusic() {
        mType = CMD_TYPE_PLAYMEDIA;
        mCmdName = getCmdName();
    }

    @Override
    public String toJsonString() {
        JSONObject argObject = new JSONObject();
        argObject.put("media",mMedia);

        JSONObject jsonObject = new JSONObject();
        jsonObject.put("cmd",mCmdName);
        jsonObject.put("arg",argObject);
        return jsonObject.toJSONString();
    }

    @Override
    public String getActionValue() {
        String value = "无";
        if (mMedia != null){
            value = mMedia.songName;
        }
        return value;
    }

    @Override
    public void parseArgs() {
        if ((mCmdArgs == null) || (mCmdArgs.isEmpty())){
            return;
        }

        try {
            mMedia = JSON.parseObject(mCmdArgs,LocalMusic.class);
        }catch (Exception e){
            mMedia = null;
        }
    }

    public void setMedia(LocalMusic localMusic){
        mMedia = localMusic;
    }
}
