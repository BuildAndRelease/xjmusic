package com.westwhale.contollerapp.ui.cloudmusic.adapter;

import android.support.annotation.NonNull;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.westwhale.contollerapp.R;
import com.westwhale.contollerapp.common.CodeNameGroup;
import com.westwhale.contollerapp.common.CodeNameItem;
import com.westwhale.contollerapp.ui.cloudmusic.fragment.CloudAlbumFragment;

import java.util.ArrayList;
import java.util.List;

/**
 * Description:
 * Author: chenyaoli
 * Date: 2018-12-01
 * History:
 */
public class CloudAlbumCategoryAdapter extends RecyclerView.Adapter {
    private ArrayList<CodeNameGroup> mItemList;
    private CodeNameItem mAreaSelectItem;
    private CodeNameItem mTypeSelectItem;
    private CodeNameItem mTimeSelectItem;
    private CodeNameItem mIndexSelectItem;

    private CallBack mCallback;

    public interface CallBack{
        void onCategoryItemClick(CodeNameItem item);
    }

    public void updateDataList(ArrayList<CodeNameGroup> itemList){
        this.mItemList = itemList;
    }

    public void setSelectItems(CodeNameItem timeItem,CodeNameItem areaItem,CodeNameItem typeItem,CodeNameItem indexItem){
        mTimeSelectItem = timeItem;
        mAreaSelectItem = areaItem;
        mTypeSelectItem = typeItem;
        mIndexSelectItem = indexItem;
    }

    public CloudAlbumCategoryAdapter(CallBack callBack){
        this.mItemList = null;
        this.mCallback = callBack;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_netmusic_album_category, viewGroup, false);
        return new CategoryItemHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder viewHolder, int i) {
        if (viewHolder instanceof CategoryItemHolder) {
            final CodeNameGroup CodeNameGroup = mItemList.get(i);
            CategoryItemHolder itemHolder = (CategoryItemHolder) viewHolder;

            itemHolder.mTitleTv.setText(CodeNameGroup.mTypeName);

            // 配置内部的Recyclerview
            RecyclerView recyclerView = itemHolder.mRecyclerView;
            GridLayoutManager gridLayoutManager = new GridLayoutManager(viewHolder.itemView.getContext(),4);
            recyclerView.setLayoutManager(gridLayoutManager);
            GridRecyclerAdapter gridRecyclerAdapter = new GridRecyclerAdapter();
            gridRecyclerAdapter.setCallBack(mCallback);
            recyclerView.setAdapter(gridRecyclerAdapter);
            recyclerView.setHasFixedSize(true);
            recyclerView.setNestedScrollingEnabled(false);

            CodeNameItem selectItem = null;
            switch (CodeNameGroup.mType) {
                case CloudAlbumFragment.TYPE_AREA:
                    selectItem = mAreaSelectItem;
                    break;
                case CloudAlbumFragment.TYPE_TIME:
                    selectItem = mTimeSelectItem;
                    break;
                case CloudAlbumFragment.TYPE_INDEX:
                    selectItem = mIndexSelectItem;
                    break;
                case CloudAlbumFragment.TYPE_TYPE:
                    selectItem = mTypeSelectItem;
                    break;
                default:
                    break;
            }
            gridRecyclerAdapter.setSelectItem(selectItem);
            gridRecyclerAdapter.updateDataList(CodeNameGroup.mItemList);
            gridRecyclerAdapter.notifyDataSetChanged();
        }
    }

    @Override
    public int getItemCount() {
        return (mItemList == null) ? 0 : mItemList.size();
    }

    private class CategoryItemHolder extends RecyclerView.ViewHolder{
        RecyclerView mRecyclerView;
        TextView mTitleTv;
        CategoryItemHolder(@NonNull View itemView) {
            super(itemView);
            mRecyclerView = itemView.findViewById(R.id.netmusic_album_category_recyclerview);
            mTitleTv = itemView.findViewById(R.id.netmusic_album_category_item_title);
        }
    }



    /**************************************   inner adapter *******************************************/
    private class GridRecyclerAdapter extends RecyclerView.Adapter {
        private List<CodeNameItem> mItemList;
        private CodeNameItem mSelectedItem;
        private CallBack mCallback;

        public void setCallBack(CallBack callBack){
            mCallback = callBack;
        }

        public void updateDataList(List<CodeNameItem> itemList){
            if (mItemList != null){
                mItemList.clear();
                notifyDataSetChanged();
            }
            this.mItemList = itemList;
        }

        public void setSelectItem(CodeNameItem selectItem){
            mSelectedItem = selectItem;
        }

        @NonNull
        @Override
        public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
            // 默认返回 HOST 类型的 viewHolder
            View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_netmusic_category_item, viewGroup, false);
            return new GridItemHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull RecyclerView.ViewHolder viewHolder, int i) {
            if (viewHolder instanceof GridItemHolder){
                final CodeNameItem item = mItemList.get(i);
                GridItemHolder itemHolder = (GridItemHolder)viewHolder;

                if (item.equals(mSelectedItem)){
                    itemHolder.mContentTv.setBackgroundColor(itemHolder.itemView.getResources().getColor(R.color.cloud_singer_category_select));
                }else{
                    itemHolder.mContentTv.setBackgroundColor(itemHolder.itemView.getResources().getColor(R.color.cloud_singer_category));
                }

                itemHolder.mContentTv.setText(item.mName);

                itemHolder.mContentTv.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        // 先把已经变色的更改颜色，然后再设置当前选项的颜色
                        if ( (mSelectedItem != null) && !mSelectedItem.equals(item) ){
                            if (mItemList.contains(mSelectedItem)){
                                int pos = mItemList.indexOf(mSelectedItem);
                                notifyItemChanged(pos);
                            }
                        }
                        mSelectedItem = item;
                        itemHolder.mContentTv.setBackgroundColor(itemHolder.itemView.getResources().getColor(R.color.cloud_singer_category_select));

                        if (mCallback != null){

                            mCallback.onCategoryItemClick(item);
                        }
                    }
                });
            }
        }

        @Override
        public int getItemCount() {
            return (null == mItemList) ? 0 : mItemList.size();
        }


        // ItemHolder
        private class GridItemHolder extends RecyclerView.ViewHolder{
            TextView mContentTv;
            GridItemHolder(@NonNull View itemView) {
                super(itemView);
                mContentTv = itemView.findViewById(R.id.item_cloud_category_text);
            }
        }

    }
}
