package com.westwhale.contollerapp.ui.timer.adapter;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.westwhale.contollerapp.R;
import com.westwhale.contollerapp.ui.timer.TimerDefine;
import com.westwhale.api.protocolapi.bean.Timer;

import java.util.List;

/**
 * Description:
 * Author: chenyaoli
 * Date: 2018-12-12
 * History:
 */
public class TimerInfoAdapter extends RecyclerView.Adapter {

    public static final int TIMER_TYPE_INFO = 0;
    public static final int TIMER_TYPE_DELETE = 1;

    private int mTimerType = TIMER_TYPE_INFO;
    private List<Timer> mItemList;
    private CallBack mCallBack;

    public interface CallBack{
        void onItemClick(Timer timer);

        void onItemEnableClick(Timer timer,boolean enable);

        void onItemDeleteClick(Timer timer);
    }

    public void setDataList(List<Timer> itemList){
        this.mItemList = itemList;
    }

    public void setTimerType(int type){
        if ((type == TIMER_TYPE_INFO) || (type == TIMER_TYPE_DELETE)){
            mTimerType = type;
        }
    }

    public TimerInfoAdapter(CallBack callBack){
        this.mItemList = null;
        this.mCallBack = callBack;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_timer_info, viewGroup, false);
        return new ItemHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder viewHolder, int i) {

        if (viewHolder instanceof ItemHolder){
            ItemHolder itemHolder = (ItemHolder)viewHolder;

            int pos = itemHolder.getAdapterPosition();
            Timer item = mItemList.get(pos);

            itemHolder.mTimeTv.setText(item.preSetTime);
            itemHolder.mNameTv.setText(item.timerName);

            String function = TimerDefine.getTimerFuncName(item.actionName);
            itemHolder.mFunctionTv.setText(function);

            String repeatStr = TimerDefine.getTimerRepeat(item.circleDay,item.specialDate);
            itemHolder.mRepeatTv.setText(repeatStr);

            boolean enable = TimerDefine.getTimerEnable(item.timerEnable);
            int resourceId = enable ? R.drawable.btn_unlock : R.drawable.btn_lock;
            itemHolder.mEnableIv.setImageResource(resourceId);

            if (mTimerType == TIMER_TYPE_INFO){
                itemHolder.mEnableIv.setVisibility(View.VISIBLE);
                itemHolder.mDeleteIv.setVisibility(View.INVISIBLE);
                itemHolder.mDeleteIv.setClickable(false);

                itemHolder.mEnableIv.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (mCallBack != null){
                            boolean enable = !TimerDefine.getTimerEnable(item.timerEnable);
                            int resourceId = enable ? R.drawable.btn_unlock : R.drawable.btn_lock;
                            itemHolder.mEnableIv.setImageResource(resourceId);

                            mCallBack.onItemEnableClick(item,enable);
                        }
                    }
                });

                itemHolder.itemView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (mCallBack != null){
                            mCallBack.onItemClick(item);
                        }
                    }
                });
            }else if (mTimerType == TIMER_TYPE_DELETE){
                itemHolder.mEnableIv.setVisibility(View.INVISIBLE);
                itemHolder.mDeleteIv.setVisibility(View.VISIBLE);

                itemHolder.mEnableIv.setClickable(false);
                itemHolder.itemView.setClickable(false);

                itemHolder.mDeleteIv.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (mCallBack != null){
                            mCallBack.onItemDeleteClick(item);
                        }
                    }
                });
            }
        }

    }

    @Override
    public int getItemCount() {
        return (null == mItemList) ? 0 : mItemList.size();
    }

    /**************************************   ItemHolder *******************************************/
    public class ItemHolder extends RecyclerView.ViewHolder{
        ImageView mEnableIv,mDeleteIv;
        TextView mTimeTv, mFunctionTv,mNameTv,mRepeatTv;
        public ItemHolder(@NonNull View itemView) {
            super(itemView);
            mEnableIv = itemView.findViewById(R.id.item_timer_opt_enable);
            mDeleteIv = itemView.findViewById(R.id.item_timer_opt_delete);

            mTimeTv = itemView.findViewById(R.id.item_timer_info_time);
            mFunctionTv = itemView.findViewById(R.id.item_timer_info_function);
            mNameTv = itemView.findViewById(R.id.item_timer_info_name);
            mRepeatTv = itemView.findViewById(R.id.item_timer_info_repeat);
        }
    }
}
