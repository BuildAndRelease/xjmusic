package com.westwhale.contollerapp.ui.cloudmusic.dialog;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.DialogFragment;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.alibaba.fastjson.JSONObject;
import com.blankj.utilcode.util.ToastUtils;
import com.scwang.smartrefresh.layout.api.RefreshLayout;
import com.scwang.smartrefresh.layout.listener.OnLoadMoreListener;
import com.westwhale.contollerapp.R;
import com.westwhale.contollerapp.eventbus.notify.NotifyPlayingInfoEvent;
import com.westwhale.contollerapp.ui.cloudmusic.adapter.CloudMusicPlayListAdapter;
import com.westwhale.contollerapp.application.WApp;
import com.westwhale.contollerapp.dev.CmdActionLister;
import com.westwhale.contollerapp.dev.ICmdCallback;
import com.westwhale.contollerapp.dev.WRoom;
import com.westwhale.contollerapp.ui.base.dialog.AttachDialogFragment;
import com.westwhale.contollerapp.eventbus.notify.NotifyPlayingMediaEvent;
import com.westwhale.api.protocolapi.bean.media.CloudMusic;
import com.westwhale.api.protocolapi.bean.media.Media;
import com.westwhale.api.protocolapi.bean.hostroom.PlayingInfo;
import com.westwhale.api.protocolapi.bean.hostroom.Room;
import com.westwhale.api.protocolapi.net.Response;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import java.util.ArrayList;
import java.util.List;

/**
 * Description:
 * Author: chenyaoli
 * Date: 2018-11-23
 * History:
 */
public class CloudMusicPlayListDialog extends AttachDialogFragment implements CloudMusicPlayListAdapter.CallBack {
    private static final String TAG = "CloudMusic_PlayList";
    private TextView mTitleTv;
    private ImageView mCancelIv,mDeleteAllIv;
    private RecyclerView mItemRv;
    private RefreshLayout mRefreshLayout;
    private CloudMusicPlayListAdapter mDataAdapter;

    private int mCurPageNo = 1; //记录当前的页面数, 云音乐歌手获取时必须从第一页开始
    private int mPageSize = 50;
    private boolean mHasMoreData = true; // 记录是否还有更多数据

    private CloudMusic mCurrentMusic;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // 背景色，动画效果，通过主题设置
        setStyle(DialogFragment.STYLE_NORMAL,R.style.CommonDialogStyle);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        //布局
        View view = inflater.inflate(R.layout.dialogfrag_cloudmusic_playlist, container);

        initView(view);
        initListener();

        initData();

        return view;
    }

    @Override
    public void onStart() {
        super.onStart();

        //设置fragment高度 、宽度
        double heightPercent = 0.6;
        int dialogHeight = (int) (mContext.getResources().getDisplayMetrics().heightPixels * heightPercent);
        Window window = getDialog().getWindow();
        WindowManager.LayoutParams params = window.getAttributes();
        params.gravity = Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL;
        params.width = WindowManager.LayoutParams.MATCH_PARENT;
        params.height = dialogHeight; // 底部弹出的DialogFragment的高度，如果是MATCH_PARENT则铺满整个窗口
        window.setAttributes(params);
        getDialog().setCanceledOnTouchOutside(true);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();

        // eventbus 取消注册
        EventBus.getDefault().unregister(this);
    }

    @Override
    public void onSongItemClick(CloudMusic songItem) {
        WRoom room = WApp.Instance.getDevManager().getSelectedRoom();
        if (room != null){
            WRoom.cmdPlayCurrentPlayList(songItem, new CmdActionLister<Boolean>(CloudMusicPlayListDialog.this, new ICmdCallback<Boolean>() {
                @Override
                public void onSuccess(Boolean data) {
                }

                @Override
                public void onFailed(int code, String msg) {
                    ToastUtils.showShort("播放失败:%d",code);
                }
            }));
        }
    }

    @Override
    public void onItemDeleteClick(CloudMusic item) {
        WRoom room = WApp.Instance.getDevManager().getSelectedRoom();
        if (room != null){
            WRoom.cmdDelMediaFromPlayMediaList(item, new CmdActionLister<Boolean>(CloudMusicPlayListDialog.this, new ICmdCallback<Boolean>() {
                @Override
                public void onSuccess(Boolean data) {
                    if (data){
                        if (mDataAdapter != null){
                            mDataAdapter.removeItem(item);
                        }
                        ToastUtils.showShort("删除成功");
                    }
                }

                @Override
                public void onFailed(int code, String msg) {
                    ToastUtils.showShort("删除失败:%d",code);
                }
            }));
        }
    }

    private void initView(View view) {
        String title = getString(R.string.cloudmusic_dialog_playlist);
        mTitleTv = view.findViewById(R.id.dialog_playlist_title);
        mTitleTv.setText(title);

        mDeleteAllIv = view.findViewById(R.id.dialog_playlist_deleteall);
        mCancelIv = view.findViewById(R.id.dialog_playlist_cancel);

        mItemRv = view.findViewById(R.id.dialog_playlist_recylerview);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(mContext);
        mItemRv.setLayoutManager(linearLayoutManager);
        mDataAdapter = new CloudMusicPlayListAdapter(this);
        mItemRv.setAdapter(mDataAdapter);
        mItemRv.setHasFixedSize(true);
        mItemRv.addItemDecoration(new DividerItemDecoration(mContext, DividerItemDecoration.VERTICAL));
        // 设置下拉上拉无阴影效果
        mItemRv.setOverScrollMode(View.OVER_SCROLL_NEVER);

        mRefreshLayout = view.findViewById(R.id.dialog_playlist_refresh);
        mRefreshLayout.setDisableContentWhenRefresh(true);
        mRefreshLayout.setEnableLoadMore(true);
        mRefreshLayout.setEnableRefresh(false);

    }

    private void initListener() {
        mDeleteAllIv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //清空播放列表
                WRoom room = WApp.Instance.getDevManager().getSelectedRoom();
                if (room != null){
                    WRoom.cmdClearPlayMediaList( new CmdActionLister<Boolean>(CloudMusicPlayListDialog.this, new ICmdCallback<Boolean>() {
                        @Override
                        public void onSuccess(Boolean data) {
                            if (data){
                                if (mDataAdapter != null){
                                    mDataAdapter.clearDataList();
                                }
                                ToastUtils.showShort("清空成功");
                            }
                        }

                        @Override
                        public void onFailed(int code, String msg) {
                            ToastUtils.showShort("清空失败:%d",code);
                        }
                    }));
                }
            }
        });

        mCancelIv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dismiss();
            }
        });

        mRefreshLayout.setOnLoadMoreListener(new OnLoadMoreListener() {
            @Override
            public void onLoadMore(@NonNull RefreshLayout refreshLayout) {
                //  判断是否还有数据，从而判断是否还需要加载更多数据
                if (mHasMoreData){
                    mCurPageNo++;
                    requestCloudResource();
                }else {
                    mRefreshLayout.finishLoadMoreWithNoMoreData();
                }
            }
        });
    }

    private void initData() {
        // eventbus 注册
        EventBus.getDefault().register(this);

        mCurPageNo = 1;
        mCurrentMusic = null;
        WRoom room = WApp.Instance.getDevManager().getSelectedRoom();
        if (room != null){
            Media media = room.getPlayingMedia();
            if (media instanceof CloudMusic){
                mCurrentMusic = (CloudMusic)media;
            }
        }

        requestCloudResource();
    }


    private void updateDataList(int total,List<Media> list){
        if ( (total > 0) && (list != null) ){

            String title = getString(R.string.cloudmusic_dialog_playlist) + "(" + total + ")";
            mTitleTv.setText(title);

            if (mCurPageNo == 1) {
                mDataAdapter.clearDataList();
            }

            List<CloudMusic> datalist = new ArrayList<>();
            for (int i=0; i < list.size(); i++){
                Media media = list.get(i);
                if (media instanceof CloudMusic){
                    datalist.add((CloudMusic)media);
                }
            }

            int size = datalist.size();
            if (size != 0){
                int startIndex = mDataAdapter.getItemCount();
                mDataAdapter.addToDataList(datalist);

                mDataAdapter.updateSelectedItem(mCurrentMusic);

                mDataAdapter.notifyItemRangeInserted(startIndex,size);
            }else{
                mHasMoreData = false;
            }

            // 更新刷新等待状态
            mRefreshLayout.finishLoadMore();
        }
    }

    private void requestCloudResource(){
        WRoom room = WApp.Instance.getDevManager().getSelectedRoom();
        if (room != null){
            WRoom.cmdGetCurrentPlayList(mCurPageNo, mPageSize, new CmdActionLister<Response<List<Media>>>(this, new ICmdCallback<Response<List<Media>>>() {
                @Override
                public void onSuccess(Response<List<Media>> data) {
                    int total = -1;

                    try {
                        JSONObject jsonObject = JSONObject.parseObject(data.arg);
                        total = jsonObject.getIntValue("total");
                    }catch (Exception e){
                        e.printStackTrace();
                    }

                    updateDataList(total,data.bean);
                }

                @Override
                public void onFailed(int code, String msg) {
                    updateDataList(-1,null);
                    Toast.makeText(getContext(),"GetCurrentPlayList获取失败:"+code,Toast.LENGTH_SHORT).show();
                }
            }));
        }else{
            updateDataList(-1,null);
        }
    }

    private void updatePlayingMedia(Media media) {
        if (media instanceof CloudMusic) {
            mCurrentMusic = (CloudMusic)media;
            mDataAdapter.updateSelectedItem(mCurrentMusic);
        }
    }

    /**  接收所有的广播处理，然后再 调用 mSimplePlayerFragment对象的相关更新方法更新 */
    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onNotifyPlayingMediaEvent(NotifyPlayingMediaEvent event) {
        if (!isVisible()){
            return;
        }
        // 若音源发生变化，则更新对应的Fragment；若只是media变化，则只需要更新对应内容
        updatePlayingMedia(event.getPlayingMedia());
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onNotifyPlayingInfoEvent(NotifyPlayingInfoEvent event) {
        if (!isVisible()){
            return;
        }

        PlayingInfo playingInfo = event.getPlayingInfo();
        if ((null == playingInfo) || !playingInfo.isAvailble()){
            return;
        }

        String roomState = playingInfo.roomState;
        switch(roomState){
            case Room.ChannelState.INCLOSED:
                break;
            case Room.ChannelState.INNORMAL:
                updatePlayingMedia(playingInfo.media);
                break;
            default:
                break;
        }
    }


}
