package com.westwhale.contollerapp.ui.scene.adapter;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.util.SparseBooleanArray;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.TextView;

import com.westwhale.api.protocolapi.bean.media.CloudMusic;
import com.westwhale.api.protocolapi.bean.scene.Scene;
import com.westwhale.contollerapp.R;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Description:
 * Author: chenyaoli
 * Date: 2018-12-12
 * History:
 */
public class SceneAdapter extends RecyclerView.Adapter {

    public final static int ITEM_MODE_NORMAL = 0;
    public final static int ITEM_MODE_DELETE = 1;
    private int mItemMode = ITEM_MODE_NORMAL;
    private List<Scene> mItemList;

    private CallBack mCallBack;
    public interface CallBack{
        void onItemClick(Scene item);
        void onItemStatClick(Scene item);
        void onItemDeleteClick(Scene item);
    }

    public void setCallBack(CallBack callBack){
        mCallBack = callBack;
    }

    public void setItemMode(int mode){
        if ((mode == ITEM_MODE_NORMAL) || (mode == ITEM_MODE_DELETE)){
            mItemMode = mode;
        }
    }

    public void setDataList(List<Scene> dataList){
        if (mItemList != null){
            mItemList.clear();
            mItemList = null;
            notifyDataSetChanged();
        }

        mItemList = dataList;
    }

    public void removeAll(){
        if (mItemList != null){
            mItemList.clear();
            mItemList = null;
            notifyDataSetChanged();
        }
    }

    public void removeSceneItem(int sceneId){
        int pos = -1;
        if (mItemList != null) {
            for (int i = 0; i < mItemList.size(); i++) {
                Scene scene = mItemList.get(i);
                if ((scene != null) && (scene.sceneId == sceneId)){
                    pos = i;
                    break;
                }
            }
        }

        if (pos > -1){
            mItemList.remove(pos);
            notifyItemRemoved(pos);
        }
    }

    public SceneAdapter(){
        this.mItemList = null;
        this.mCallBack = null;
    }

    @NonNull
    @Override
    public ItemHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_scene_scene, viewGroup, false);
        return new ItemHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder viewHolder, int i) {
        if (viewHolder instanceof ItemHolder){
            ItemHolder itemHolder = (ItemHolder) viewHolder;
            Scene item = mItemList.get(i);

            itemHolder.mTitleNoTv.setText(String.valueOf(i+1));
            itemHolder.mTitleTv.setText(item.sceneName);

            itemHolder.mDeleteIv.setVisibility(View.GONE);
            itemHolder.mStatIv.setVisibility(View.GONE);
            if (mItemMode == ITEM_MODE_NORMAL){
                itemHolder.mStatIv.setVisibility(View.VISIBLE);
            }else if (mItemMode == ITEM_MODE_DELETE){
                itemHolder.mDeleteIv.setVisibility(View.VISIBLE);
            }

            itemHolder.mDeleteIv.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (mCallBack != null){
                        mCallBack.onItemDeleteClick(item);
                    }
                }
            });

            itemHolder.mStatIv.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (mCallBack != null){
                        mCallBack.onItemStatClick(item);
                    }
                }
            });

            itemHolder.itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (mCallBack != null){
                        mCallBack.onItemClick(item);
                    }
                }
            });
        }

    }

    @Override
    public int getItemCount() {
        return (null == mItemList) ? 0 : mItemList.size();
    }

    /**************************************   ItemHolder *******************************************/
    public class ItemHolder extends RecyclerView.ViewHolder{
        TextView mTitleTv,mTitleNoTv;
        ImageView mStatIv,mDeleteIv;
        public ItemHolder(@NonNull View itemView) {
            super(itemView);
            mTitleNoTv = itemView.findViewById(R.id.item_scene_no);
            mTitleTv = itemView.findViewById(R.id.item_scene_name);
            mStatIv = itemView.findViewById(R.id.item_scene_stat);
            mDeleteIv = itemView.findViewById(R.id.item_scene_delete);
        }
    }
}
