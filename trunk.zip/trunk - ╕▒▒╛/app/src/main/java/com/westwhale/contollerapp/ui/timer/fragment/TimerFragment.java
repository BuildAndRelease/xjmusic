package com.westwhale.contollerapp.ui.timer.fragment;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.blankj.utilcode.util.ToastUtils;
import com.scwang.smartrefresh.layout.api.RefreshLayout;
import com.scwang.smartrefresh.layout.listener.OnRefreshListener;
import com.westwhale.contollerapp.R;
import com.westwhale.contollerapp.application.WApp;
import com.westwhale.contollerapp.dev.CmdActionLister;
import com.westwhale.contollerapp.dev.ICmdCallback;
import com.westwhale.contollerapp.dev.WRoom;
import com.westwhale.contollerapp.ui.base.fragment.BaseFragment;
import com.westwhale.contollerapp.ui.timer.TimerDefine;
import com.westwhale.contollerapp.ui.timer.activity.TimerActivity;
import com.westwhale.contollerapp.ui.timer.activity.TimerAddEditActivity;
import com.westwhale.contollerapp.ui.timer.adapter.TimerInfoAdapter;
import com.westwhale.api.protocolapi.bean.Timer;

import java.util.List;

public class TimerFragment extends BaseFragment implements TimerInfoAdapter.CallBack {

    public static final int REQUEST_CODE_TIMER_NEW = 1;
    public static final int REQUEST_CODE_TIMER_EDIT = 2;

    public static final int REQUEST_CODE_TIMER_MANAGER = 3;

    private Toolbar mToolBar;
    private RecyclerView mDataRv;
    private ImageView mOperatorIv, mAddTimerIv;
    private RefreshLayout mRefreshLayout;

    private TimerInfoAdapter mAdapter;

    private List<Timer> mDataList;


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.frag_timer_info,container,false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        initView(view);

        initListener();

        initData();
    }

    @Override
    public void onResume() {
        super.onResume();
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if ((requestCode == REQUEST_CODE_TIMER_NEW) && (resultCode == Activity.RESULT_OK)){
            Timer timer = data.getParcelableExtra(TimerDefine.TIMER_INTENT_ARG_KEY_TIMER);
            if (timer == null){
                return;
            }

            // 新建一个定时器
            WRoom room = WApp.Instance.getDevManager().getSelectedRoom();
            if (room != null){
                room.cmdAddTimer(timer,new CmdActionLister<Boolean>(TimerFragment.this, new ICmdCallback<Boolean>() {
                    @Override
                    public void onSuccess(Boolean data) {
                        if (data) {
                            ToastUtils.showShort("添加定时器成功");
                            requestDataResource();
                        }
                    }

                    @Override
                    public void onFailed(int code, String msg) {
                        ToastUtils.showShort("添加定时器失败: %d",code);
                    }
                }));
            }


        }else if ((requestCode == REQUEST_CODE_TIMER_EDIT) && (resultCode == Activity.RESULT_OK)){
            Timer timer = data.getParcelableExtra(TimerDefine.TIMER_INTENT_ARG_KEY_TIMER);
            if (timer == null){
                return;
            }

            // 修改一个定时器, 默认把定时器更改为使能状态
            timer.timerEnable = TimerDefine.TIMER_ENABLE_ENABLE;
            WRoom room = WApp.Instance.getDevManager().getSelectedRoom();
            if (room != null){
                room.cmdModifyTimer(timer,new CmdActionLister<Boolean>(TimerFragment.this, new ICmdCallback<Boolean>() {
                    @Override
                    public void onSuccess(Boolean data) {
                        if (data) {
                            ToastUtils.showShort("修改定时器成功");
                            requestDataResource();
                        }else{
                            ToastUtils.showShort("修改定时器成失败");
                        }
                    }

                    @Override
                    public void onFailed(int code, String msg) {
                        ToastUtils.showShort("修改定时器失败: %d",code);
                    }
                }));
            }
        }else if ((requestCode == REQUEST_CODE_TIMER_MANAGER) && (resultCode == Activity.RESULT_OK)){
            //删除了定时器
            initData();
        }
    }

    @Override
    public void onItemClick(Timer timer) {
        // 编辑指定定时器
        Intent intent = new Intent(mContext, TimerAddEditActivity.class);
        intent.putExtra(TimerDefine.TIMER_INTENT_ARG_KEY_TIMER,timer);
        startActivityForResult(intent,REQUEST_CODE_TIMER_EDIT);
    }

    @Override
    public void onItemEnableClick(Timer timer, boolean enable) {
        // 定时器使能开关
        if (timer != null) {
            timer.timerEnable = enable ? TimerDefine.TIMER_ENABLE_ENABLE : TimerDefine.TIMER_ENABLE_DISABLE;
            WRoom room = WApp.Instance.getDevManager().getSelectedRoom();
            if (room != null) {
                room.cmdModifyTimer(timer, new CmdActionLister<Boolean>(TimerFragment.this, new ICmdCallback<Boolean>() {
                    @Override
                    public void onSuccess(Boolean data) {
                        if (data){
                            ToastUtils.showShort("修改定时器成功");
                        }else{
                            ToastUtils.showShort("修改定时器成失败");
                        }
                    }

                    @Override
                    public void onFailed(int code, String msg) {
                        ToastUtils.showShort("修改定时器成失败: %d",code);
                    }
                }));
            }
        }

    }

    @Override
    public void onItemDeleteClick(Timer timer) {
        // 不响应
    }

    private void initView(View view) {
        mToolBar = view.findViewById(R.id.timer_info_toolbar);
        if (getActivity() != null){
            ((AppCompatActivity) getActivity()).setSupportActionBar(mToolBar);
            ActionBar actionBar = ((AppCompatActivity) getActivity()).getSupportActionBar();
            if (actionBar != null){
                actionBar.setDisplayHomeAsUpEnabled(true);
            }
        }

        mAdapter = new TimerInfoAdapter(this);
        mAdapter.setTimerType(TimerInfoAdapter.TIMER_TYPE_INFO);

        mDataRv = view.findViewById(R.id.timer_info_recylerview);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(mContext);
        mDataRv.setLayoutManager(linearLayoutManager);
        mDataRv.setAdapter(mAdapter);
        mDataRv.setHasFixedSize(true);
        mDataRv.addItemDecoration(new DividerItemDecoration(mContext, DividerItemDecoration.VERTICAL));

        mOperatorIv = view.findViewById(R.id.timer_info_edit);
        mAddTimerIv = view.findViewById(R.id.timer_info_add);

        mRefreshLayout = view.findViewById(R.id.timer_info_refreshlayout);
        mRefreshLayout.setDisableContentWhenRefresh(true);
        mRefreshLayout.setEnableLoadMore(false);
    }

    private void initListener() {
        mToolBar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (getActivity() != null){
                    getActivity().onBackPressed();
                }
            }
        });

        mOperatorIv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 进入批量操作界面
                if (getActivity() instanceof TimerActivity){
                    TimerManagerFragment fragment = new TimerManagerFragment();
                    fragment.setTargetFragment(TimerFragment.this,REQUEST_CODE_TIMER_MANAGER);
                    ((TimerActivity) getActivity()).showFragment(fragment);
                }
            }
        });

        mAddTimerIv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 添加定时器
                startActivityForResult(new Intent(mContext, TimerAddEditActivity.class),REQUEST_CODE_TIMER_NEW);
            }
        });

        mRefreshLayout.setOnRefreshListener(new OnRefreshListener() {
            @Override
            public void onRefresh(@NonNull RefreshLayout refreshLayout) {
                if (mAdapter != null){
                    mDataList.clear();
                    mAdapter.notifyDataSetChanged();
                }
                initData();
            }
        });
    }

    private void initData() {
        if (getActivity() instanceof TimerActivity){
            mDataList = ((TimerActivity) getActivity()).getTimerList();

            if (mAdapter != null){
                mAdapter.setDataList(mDataList);
                mAdapter.notifyDataSetChanged();
            }

            if (mDataList.isEmpty()){
                requestDataResource();
            }else{
                mRefreshLayout.finishRefresh();
                mRefreshLayout.finishLoadMore();
            }
        }
    }

    private void updateData(List<Timer> datalist){
        if (datalist != null ){
            if (mDataList != null) {
                mDataList.clear();
                mDataList.addAll(datalist);
            }
            if (mAdapter != null){
                mAdapter.notifyDataSetChanged();
            }

            mRefreshLayout.finishRefresh();
            mRefreshLayout.finishLoadMore();
        }else{
            mRefreshLayout.finishRefresh();
            mRefreshLayout.finishLoadMore();
        }
    }

    private void requestDataResource() {
        WRoom room = WApp.Instance.getDevManager().getSelectedRoom();
        if (room != null){
            room.cmdGetTimerList(new CmdActionLister<List<Timer>>(TimerFragment.this, new ICmdCallback<List<Timer>>() {
                @Override
                public void onSuccess(List<Timer> data) {
                    updateData(data);
                }

                @Override
                public void onFailed(int code, String msg) {

                }
            }));
        }
    }

}
