package com.westwhale.contollerapp.ui.cloudmusic.adapter;

import android.support.annotation.NonNull;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Base64;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.request.RequestOptions;
import com.westwhale.contollerapp.R;
import com.westwhale.api.protocolapi.bean.albumSet.CloudRadioSet;
import com.westwhale.api.protocolapi.bean.cloudmusic.CloudRadioGroup;

import java.util.List;

public class CloudRadioAdapter extends RecyclerView.Adapter {
    private List<CloudRadioGroup> mItemList;
    private CallBack mCallBack;

    public interface CallBack{
        void onRadioItemClick(CloudRadioSet raidoItem);
    }

    public void upateDataList(List<CloudRadioGroup> itemList){
        if (mItemList != null){
            mItemList.clear();
            notifyDataSetChanged();
        }
        this.mItemList = itemList;
    }

    public CloudRadioAdapter(CallBack callBack){
        this.mItemList = null;
        this.mCallBack = callBack;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        // 默认返回 HOST 类型的 viewHolder
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_netmusic_radio_grid, viewGroup, false);
        return new CloudRadioGridItemHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder viewHolder, int i) {
        if (viewHolder instanceof CloudRadioGridItemHolder){
            final CloudRadioGroup radioGroup = mItemList.get(i);
            CloudRadioGridItemHolder itemHolder = (CloudRadioGridItemHolder)viewHolder;

            // 配置内部的Recyclerview
            RecyclerView recyclerView = itemHolder.mRecyclerView;
            GridLayoutManager gridLayoutManager = new GridLayoutManager(viewHolder.itemView.getContext(),2);
            recyclerView.setLayoutManager(gridLayoutManager);

            GridRecyclerAdapter gridRecyclerAdapter = new GridRecyclerAdapter();
            gridRecyclerAdapter.setCallBack(mCallBack);

            recyclerView.setAdapter(gridRecyclerAdapter);
            recyclerView.setHasFixedSize(true);
            // 设置下拉上拉无阴影效果
            recyclerView.setOverScrollMode(View.OVER_SCROLL_NEVER);

            gridRecyclerAdapter.updateDataList(radioGroup.radioList);
            gridRecyclerAdapter.notifyDataSetChanged();
        }
    }

    @Override
    public int getItemCount() {
        return (null == mItemList) ? 0 : mItemList.size();
    }

    /**************************************   ItemHolder *******************************************/
    private class CloudRadioGridItemHolder extends RecyclerView.ViewHolder{
        RecyclerView mRecyclerView;
        public CloudRadioGridItemHolder(@NonNull View itemView) {
            super(itemView);
            mRecyclerView = itemView.findViewById(R.id.item_netmusic_radio_recyclerview);
        }
    }




    /**************************************   inner adapter *******************************************/
    private class GridRecyclerAdapter extends RecyclerView.Adapter {
        private List<CloudRadioSet> mItemList;
        private CallBack mCallBack;

        public void setCallBack(CallBack callBack){
            mCallBack = callBack;
        }

        public void updateDataList(List<CloudRadioSet> itemList){
            if (mItemList != null){
                mItemList.clear();
                notifyDataSetChanged();
            }
            this.mItemList = itemList;
        }

        @NonNull
        @Override
        public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
            // 默认返回 HOST 类型的 viewHolder
            View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_netmusic_radio, viewGroup, false);
            return new RadioGridItemHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull RecyclerView.ViewHolder viewHolder, int i) {
            if (viewHolder instanceof RadioGridItemHolder){
                final CloudRadioSet radioSet = mItemList.get(i);
                RadioGridItemHolder itemHolder = (RadioGridItemHolder)viewHolder;

                itemHolder.mTitleTv.setText(radioSet.radioName);

                // 首先 base64 解码
                String pic = (radioSet.getPic() != null) ? radioSet.getPic() : "";
                String url = new String(Base64.decode(pic.getBytes(), Base64.DEFAULT));
                RequestOptions mRequestOptions = RequestOptions.circleCropTransform().diskCacheStrategy(DiskCacheStrategy.NONE) //不做磁盘缓存
                        .placeholder(R.drawable.cloud_radio_default)  //未加载图片之前显示的图片
                        .error(R.drawable.cloud_radio_default);       //错误时显示的图片
//                      .skipMemoryCache(true);//不做内存缓存

                Glide.with(viewHolder.itemView)
                        .load(url)
                        .apply(mRequestOptions)
                        .into(itemHolder.mPicIv);


                itemHolder.itemView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Log.e("CloudRadioAdapter","====GridRecyclerAdapter"+"  click" + radioSet.radioName);
                        if (mCallBack != null) {
                            mCallBack.onRadioItemClick(radioSet);
                        }
                    }
                });
            }
        }

        @Override
        public int getItemCount() {
            return (null == mItemList) ? 0 : mItemList.size();
        }


        // ItemHolder
        private class RadioGridItemHolder extends RecyclerView.ViewHolder{
            TextView mTitleTv;
            ImageView mPicIv;
            RadioGridItemHolder(@NonNull View itemView) {
                super(itemView);
                mTitleTv = itemView.findViewById(R.id.item_netmusic_radio_title);
                mPicIv = itemView.findViewById(R.id.item_netmusic_radio_pic);
            }
        }

    }


/*****************************************   采用 GridLayout 方式
    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder viewHolder, int i) {
        if (viewHolder instanceof CloudRadioGridItemHolder){
            final CloudRadioGroup radioGroup = mItemList.get(i);
            CloudRadioGridItemHolder itemHolder = (CloudRadioGridItemHolder)viewHolder;
            // 根据 radioGroup的子项，创建 gridlayout 的子项
            if (radioGroup.radioList != null){
                itemHolder.mGridLayout.removeAllViews();
                for (int index=0; index < radioGroup.radioList.size(); index++){
                    CloudRadioSet radioSet = radioGroup.radioList.get(index);
                    View radioView = createViewByRadioSet(itemHolder.mGridLayout,radioSet);
                    if (radioView != null){
                        // 使用Spec定义子控件的位置和比重
                        GridLayout.Spec rowSpec = GridLayout.spec(index / 2, 1f);
                        GridLayout.Spec columnSpec = GridLayout.spec(index % 2, 1f);
                        //将Spec传入GridLayout.LayoutParams并设置宽高为0，必须设置宽高，否则视图异常
                        GridLayout.LayoutParams layoutParams = new GridLayout.LayoutParams(rowSpec, columnSpec);
                        layoutParams.height = GridLayout.LayoutParams.WRAP_CONTENT;
                        // 在android5.11中，不能直接设置为0，需手动设置 居中 效果
                        //layoutParams.width = 0;
                        layoutParams.width = GridLayout.LayoutParams.WRAP_CONTENT;
                        layoutParams.topMargin = radioView.getResources().getDimensionPixelSize(R.dimen.dp_10);
                        layoutParams.bottomMargin = radioView.getResources().getDimensionPixelSize(R.dimen.dp_5);
                        layoutParams.setGravity(Gravity.CENTER_HORIZONTAL);

                        itemHolder.mGridLayout.addView(radioView, layoutParams);
                        radioView.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                mCallBack.onRadioItemClick(radioSet);
                            }
                        });
                    }
                }
            }// end if(radioGroup.radioList != null)
        }
    }

    private View createViewByRadioSet(@NonNull ViewGroup viewGroup,@NonNull CloudRadioSet radioSet){
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_netmusic_radio,viewGroup,false);
        TextView titleTv = view.findViewById(R.id.item_netmusic_radio_title);
        titleTv.setText(radioSet.radioName);
        ImageView imageView = view.findViewById(R.id.item_netmusic_radio_pic);

        // 首先 base64 解码
        String pic = (radioSet.getPic() != null) ? radioSet.getPic() : "";
        String url = new String(Base64.decode(pic.getBytes(), Base64.DEFAULT));
        RequestOptions mRequestOptions = RequestOptions.circleCropTransform().diskCacheStrategy(DiskCacheStrategy.NONE) //不做磁盘缓存
                      .placeholder(R.drawable.cloud_radio_default)  //未加载图片之前显示的图片
                      .error(R.drawable.cloud_radio_default);       //错误时显示的图片
//                      .skipMemoryCache(true);//不做内存缓存
        Glide.with(viewGroup)
                .load(url)
                .apply(mRequestOptions)
                .into(imageView);

        return view;
    }

    private class CloudRadioGridItemHolder extends RecyclerView.ViewHolder{
        GridLayout mGridLayout;
        public CloudRadioGridItemHolder(@NonNull View itemView) {
            super(itemView);
            mGridLayout = itemView.findViewById(R.id.item_netmusic_radio_grid);
        }
    }

*****************************************/

}
