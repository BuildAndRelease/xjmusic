package com.westwhale.contollerapp.ui.cloudmusic.fragment;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.kingja.loadsir.callback.Callback;
import com.kingja.loadsir.callback.SuccessCallback;
import com.scwang.smartrefresh.layout.api.RefreshLayout;
import com.scwang.smartrefresh.layout.listener.OnLoadMoreListener;
import com.scwang.smartrefresh.layout.listener.OnRefreshListener;
import com.westwhale.contollerapp.R;
import com.westwhale.contollerapp.application.WApp;
import com.westwhale.contollerapp.dev.CmdActionLister;
import com.westwhale.contollerapp.dev.ICmdCallback;
import com.westwhale.contollerapp.dev.WRoom;
import com.westwhale.contollerapp.ui.main.MainRoomActivity;
import com.westwhale.contollerapp.ui.cloudmusic.adapter.CloudSingerAdapter;
import com.westwhale.contollerapp.common.CodeNameGroup;
import com.westwhale.contollerapp.common.CodeNameItem;
import com.westwhale.contollerapp.ui.cloudmusic.dialog.CloudSingerCategoryDialog;
import com.westwhale.contollerapp.ui.base.fragment.TitleBaseFragment;
import com.westwhale.contollerapp.ui.loadsircallback.LoadingCallback;
import com.westwhale.api.protocolapi.bean.albumSet.CloudSingerSet;

import java.util.ArrayList;
import java.util.List;

/**
 * Description:
 * Author: chenyaoli
 * Date: 2018-11-12
 * History:
 */
public class CloudSingerFragment extends TitleBaseFragment implements CloudSingerAdapter.CallBack {
    public static final int REQUEST_CODDE = 0;


    public static final String SINGER_TYPE_AREA = "area";
    public static String SINGER_TYPE_AREA_NAME = "地区";
    public static final String SINGER_TYPE_INDEX = "index";
    public static String SINGER_TYPE_INDEX_NAME = "索引";

    private FrameLayout mFrameLayout;
    private RecyclerView mDataRv;
    private TextView mSingerTypeTv;
    private ImageView mCategoryIv;
    private Toolbar mToolBar;
    private RefreshLayout mRefreshLayout;

    private CloudSingerAdapter mCloudSingerAdapter;

    private ArrayList<CodeNameGroup> mCodeNameGroupList = new ArrayList<>();

    private CodeNameItem mAreaItem;
    private CodeNameItem mIndexItem;
    private int mCurPageNo = 1; //记录当前的页面数, 云音乐歌手获取时必须从第一页开始
    private boolean mHasMoreData = true; // 记录是否还有更多数据


    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        configCategory();
        for (int i=0; i < mCodeNameGroupList.size(); i++){
            CodeNameGroup CodeNameGroup = mCodeNameGroupList.get(i);
            CodeNameItem item = null;
            if ((CodeNameGroup != null) && (CodeNameGroup.mItemList != null) && (CodeNameGroup.mItemList.size() > 0)) {
                item = CodeNameGroup.mItemList.get(0);
            }
            if (item != null) {
                switch (item.mType) {
                    case SINGER_TYPE_AREA:
                        mAreaItem = item;
                        break;
                    case SINGER_TYPE_INDEX:
                        mIndexItem = item;
                        break;
                    default:
                        break;
                }
            }
        }
    }

    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        // 先显示加载动画，针对布局做一些初始化
        return inflater.inflate(R.layout.frag_netmusic_singer,container,false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        mFrameLayout = view.findViewById(R.id.netmusic_singer_content_layout);

        // 创建mLoadService
        mLoadService = mLoadSir.register(mFrameLayout, new Callback.OnReloadListener() {
            @Override
            public void onReload(View v) {
                showLoadCallBack(LoadingCallback.class);

                initData();
            }
        });

        initView(view);

        initListener();

        initData();
    }

    @Override
    public void onResume() {
        super.onResume();
    }

    @Override
    public void onSingerItemClick(CloudSingerSet singerItem) {
        // 进入歌手的歌曲界面
        CloudMusicListSingerFragment musiclistFragment = new CloudMusicListSingerFragment();
        musiclistFragment.updateSingerSet(singerItem);
        if (getActivity() instanceof MainRoomActivity) {
            ((MainRoomActivity) getActivity()).showFragment(musiclistFragment);
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        // 接收分类弹出框的返回结果
        if (REQUEST_CODDE == requestCode){
            mAreaItem = data.getParcelableExtra(SINGER_TYPE_AREA);
            mIndexItem = data.getParcelableExtra(SINGER_TYPE_INDEX);

            showLoadCallBack(LoadingCallback.class);

            initData();
        }
    }

    private void initView(View view) {
        mToolBar = view.findViewById(R.id.netmusic_singer_toolbar);
        configToolBar(mToolBar,getString(R.string.cloudmusic_singer_title));

        mDataRv = view.findViewById(R.id.netmusic_singer_recylerview);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(mContext);
        mDataRv.setLayoutManager(linearLayoutManager);
        mCloudSingerAdapter = new CloudSingerAdapter(this);
        mDataRv.setAdapter(mCloudSingerAdapter);
        mDataRv.setHasFixedSize(true);

        mRefreshLayout = view.findViewById(R.id.netmusic_singer_refresh);
        mRefreshLayout.setDisableContentWhenRefresh(true);
        mRefreshLayout.setEnableLoadMore(true);

        mSingerTypeTv = view.findViewById(R.id.netmusic_singer_type);
        mCategoryIv = view.findViewById(R.id.netmusic_singer_category);
    }

    private void initListener() {
        mCategoryIv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 弹出歌手分类框
                CloudSingerCategoryDialog cloudCategoryDialog = new CloudSingerCategoryDialog();
                // 必须先配置列表，然后再配置选择项
                cloudCategoryDialog.setCategoryGroupList(mCodeNameGroupList);
                cloudCategoryDialog.setSelectItems(mAreaItem,mIndexItem);
                //设置目标Fragment
                cloudCategoryDialog.setTargetFragment(CloudSingerFragment.this, REQUEST_CODDE);
                if (getFragmentManager() != null) {
                    cloudCategoryDialog.show(getFragmentManager(), "CloudSingerCategory_Dialog");
                }
            }
        });

        mDataRv.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(@NonNull RecyclerView recyclerView, int newState) {
                super.onScrollStateChanged(recyclerView, newState);
            }

            @Override
            public void onScrolled(@NonNull RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);
            }
        });

        mRefreshLayout.setOnRefreshListener(new OnRefreshListener() {
            @Override
            public void onRefresh(@NonNull RefreshLayout refreshLayout) {
                initData();
            }
        });

        mRefreshLayout.setOnLoadMoreListener(new OnLoadMoreListener() {
            @Override
            public void onLoadMore(@NonNull RefreshLayout refreshLayout) {
                //  判断是否还有数据，从而判断是否还需要加载更多数据
                if (mHasMoreData){
                    mCurPageNo++;
                    requestCloudResource();
                }else {
                    mRefreshLayout.finishLoadMoreWithNoMoreData();
                }
            }
        });

    }

    private void initData() {
        String area = ((mAreaItem != null) && (mAreaItem.mName != null)) ? mAreaItem.mName : "";
        String index = ((mIndexItem != null) && (mIndexItem.mName != null)) ? mIndexItem.mName : "";
        String type = area + " - " + index;
        mSingerTypeTv.setText(type);

        mCurPageNo = 1;
        mHasMoreData = true;

        // 每次先清空原有数据
        if (mCloudSingerAdapter != null){
            mCloudSingerAdapter.clearDataList();
        }

        requestCloudResource();
    }


    public void updateDataList(List<CloudSingerSet> list){
        if (list != null){
            // 若无法获取到数据，则认为已经到底
            int size = list.size();

            if (mCurPageNo == 0) {
                mCloudSingerAdapter.clearDataList();
            }

            if (size != 0){
                int startIndex = mCloudSingerAdapter.getItemCount();
                mCloudSingerAdapter.addToDataList(list);
                mCloudSingerAdapter.notifyItemRangeInserted(startIndex,size);
            }else{
                mHasMoreData = false;
            }

            // 更新刷新等待状态
            mRefreshLayout.finishRefresh();
            mRefreshLayout.finishLoadMore();

            showLoadCallBack(SuccessCallback.class);
        }else{
            // 当获取数据失败时，则认为无数据了
            mHasMoreData = false;

            // 更新刷新等待状态
            mRefreshLayout.finishRefresh();
            mRefreshLayout.finishLoadMore();

            showLoadCallBack(SuccessCallback.class);

//            showLoadCallBack(ErrorCallback.class);
        }

    }

    public void requestCloudResource() {
        WRoom room = WApp.Instance.getDevManager().getSelectedRoom();
        if (room != null){
            String area = (mAreaItem == null) ? "" : mAreaItem.mCode;
            String index = (mIndexItem == null) ? "" : mIndexItem.mCode;
            int pageNo = mCurPageNo;
            WRoom.cmdGetSingerss(area, index, pageNo, new CmdActionLister<List<CloudSingerSet>>(this, new ICmdCallback<List<CloudSingerSet>>() {
                @Override
                public void onSuccess(List<CloudSingerSet> data) {
                    updateDataList(data);
                }

                @Override
                public void onFailed(int code, String msg) {
                    updateDataList(null);
                    Toast.makeText(getContext(),"GetTopList获取失败:"+code,Toast.LENGTH_SHORT).show();
                }
            }));
        }else{
            updateDataList(null);
        }
    }



    public void configCategory(){
        CodeNameGroup codeNameGroup = null;
        ArrayList<CodeNameItem> itemList = null;
//        String[] tmp1 = {"all_all", "cn_man", "cn_woman", "cn_team", "k_man", "k_woman", "k_team", "j_man", "j_woman", "j_team", "eu_man", "eu_woman", "eu_team", "c_orchestra", "c_performer", "c_composer", "c_cantor", "other_other"};
//        String[] tmp2 = {"全部", "华语男", "华语女", "华语组合", "韩国男", "韩国女", "韩国组合", "日本男", "日本女", "日本组合", "欧美男", "欧美女", "欧美组合", "乐团", "演奏家", "作曲家", "指挥家", "其他",};
        codeNameGroup = new CodeNameGroup();
        itemList = new ArrayList<>();
        codeNameGroup.mType = SINGER_TYPE_AREA;
        codeNameGroup.mTypeName = SINGER_TYPE_AREA_NAME;
        itemList.add(new CodeNameItem(SINGER_TYPE_AREA,"全部","all_all"));
        itemList.add(new CodeNameItem(SINGER_TYPE_AREA,"华语男","cn_man"));
        itemList.add(new CodeNameItem(SINGER_TYPE_AREA,"华语女","cn_woman"));
        itemList.add(new CodeNameItem(SINGER_TYPE_AREA,"华语组合","cn_team"));
        itemList.add(new CodeNameItem(SINGER_TYPE_AREA,"韩国男","k_man"));
        itemList.add(new CodeNameItem(SINGER_TYPE_AREA,"韩国女","k_woman"));
        itemList.add(new CodeNameItem(SINGER_TYPE_AREA,"韩国组合","k_team"));
        itemList.add(new CodeNameItem(SINGER_TYPE_AREA,"日本男","j_man"));
        itemList.add(new CodeNameItem(SINGER_TYPE_AREA,"日本女","j_woman"));
        itemList.add(new CodeNameItem(SINGER_TYPE_AREA,"日本组合","j_team"));
        itemList.add(new CodeNameItem(SINGER_TYPE_AREA,"欧美男","eu_man"));
        itemList.add(new CodeNameItem(SINGER_TYPE_AREA,"欧美女","eu_woman"));
        itemList.add(new CodeNameItem(SINGER_TYPE_AREA,"欧美组合","eu_team"));
        itemList.add(new CodeNameItem(SINGER_TYPE_AREA,"乐团","c_orchestra"));
        itemList.add(new CodeNameItem(SINGER_TYPE_AREA,"演奏家","c_performer"));
        itemList.add(new CodeNameItem(SINGER_TYPE_AREA,"作曲家","c_composer"));
        itemList.add(new CodeNameItem(SINGER_TYPE_AREA,"指挥家","c_cantor"));
        itemList.add(new CodeNameItem(SINGER_TYPE_AREA,"其他","other_other"));

        codeNameGroup.mItemList = itemList;
        mCodeNameGroupList.add(codeNameGroup);

//        String[] tmp3 = {"all", "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z", "9" ,};
//        String[] tmp4 = {"全部", "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z", "#",};
        codeNameGroup = new CodeNameGroup();
        itemList = new ArrayList<>();
        codeNameGroup.mType = SINGER_TYPE_INDEX;
        codeNameGroup.mTypeName = SINGER_TYPE_INDEX_NAME;
        itemList.add(new CodeNameItem(SINGER_TYPE_INDEX,"全部","all"));
        itemList.add(new CodeNameItem(SINGER_TYPE_INDEX,"A","A"));
        itemList.add(new CodeNameItem(SINGER_TYPE_INDEX,"B","B"));
        itemList.add(new CodeNameItem(SINGER_TYPE_INDEX,"C","C"));
        itemList.add(new CodeNameItem(SINGER_TYPE_INDEX,"D","D"));
        itemList.add(new CodeNameItem(SINGER_TYPE_INDEX,"E","E"));
        itemList.add(new CodeNameItem(SINGER_TYPE_INDEX,"F","F"));
        itemList.add(new CodeNameItem(SINGER_TYPE_INDEX,"G","G"));
        itemList.add(new CodeNameItem(SINGER_TYPE_INDEX,"H","H"));
        itemList.add(new CodeNameItem(SINGER_TYPE_INDEX,"I","I"));
        itemList.add(new CodeNameItem(SINGER_TYPE_INDEX,"J","J"));
        itemList.add(new CodeNameItem(SINGER_TYPE_INDEX,"K","K"));
        itemList.add(new CodeNameItem(SINGER_TYPE_INDEX,"L","L"));
        itemList.add(new CodeNameItem(SINGER_TYPE_INDEX,"M","M"));
        itemList.add(new CodeNameItem(SINGER_TYPE_INDEX,"N","N"));
        itemList.add(new CodeNameItem(SINGER_TYPE_INDEX,"O","O"));
        itemList.add(new CodeNameItem(SINGER_TYPE_INDEX,"P","P"));
        itemList.add(new CodeNameItem(SINGER_TYPE_INDEX,"Q","Q"));
        itemList.add(new CodeNameItem(SINGER_TYPE_INDEX,"R","R"));
        itemList.add(new CodeNameItem(SINGER_TYPE_INDEX,"S","S"));
        itemList.add(new CodeNameItem(SINGER_TYPE_INDEX,"T","T"));
        itemList.add(new CodeNameItem(SINGER_TYPE_INDEX,"U","U"));
        itemList.add(new CodeNameItem(SINGER_TYPE_INDEX,"V","V"));
        itemList.add(new CodeNameItem(SINGER_TYPE_INDEX,"W","W"));
        itemList.add(new CodeNameItem(SINGER_TYPE_INDEX,"X","X"));
        itemList.add(new CodeNameItem(SINGER_TYPE_INDEX,"Y","Y"));
        itemList.add(new CodeNameItem(SINGER_TYPE_INDEX,"Z","Z"));
        itemList.add(new CodeNameItem(SINGER_TYPE_INDEX,"#","9"));

        codeNameGroup.mItemList = itemList;
        mCodeNameGroupList.add(codeNameGroup);
    }
}
