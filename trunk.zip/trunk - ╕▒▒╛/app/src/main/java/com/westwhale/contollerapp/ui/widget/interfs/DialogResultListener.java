package com.westwhale.contollerapp.ui.widget.interfs;

public interface DialogResultListener<T> {
    void onResultListener(T value);
}
