package com.westwhale.contollerapp.ui.slider;


import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.widget.NestedScrollView;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.TextView;

import com.blankj.utilcode.util.ActivityUtils;
import com.blankj.utilcode.util.AppUtils;
import com.blankj.utilcode.util.ToastUtils;
import com.tencent.bugly.beta.Beta;
import com.westwhale.contollerapp.R;
import com.westwhale.contollerapp.application.WApp;
import com.westwhale.contollerapp.dev.WHost;
import com.westwhale.contollerapp.eventbus.CheckAppUpdateEvent;
import com.westwhale.contollerapp.ui.base.activity.BaseActivity;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

/**
 * Description:
 * Author: chenyaoli
 * Date: 2018-12-20
 * History
 *
 */
public class AboutActivity extends BaseActivity {


    private Toolbar mToolbar;
    private TextView mAppVersionTv,mAppCheckUpdateTv, mDevNameTv,mDevTypeTv, mDevHardVerTv, mDevSoftVerTv,mDevCheckUpdateTv;
    private NestedScrollView mScrollView;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_slider_about);

        EventBus.getDefault().register(this);

        initView();
        initListener();

        initData();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        EventBus.getDefault().unregister(this);
    }

    private void initView() {
        mToolbar = findViewById(R.id.slider_about_toolbar);
        // 设置toolbar
        setSupportActionBar(mToolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        mScrollView = findViewById(R.id.slider_about_scrollView);
        // 设置下拉上拉无阴影效果
        mScrollView.setOverScrollMode(View.OVER_SCROLL_NEVER);

        mAppVersionTv = findViewById(R.id.slider_about_appver);
        mAppCheckUpdateTv = findViewById(R.id.slider_about_app_checkupdate);

        mDevNameTv = findViewById(R.id.slider_about_devicename);
        mDevTypeTv = findViewById(R.id.slider_about_devicetype);
        mDevSoftVerTv = findViewById(R.id.slider_about_softver);
        mDevHardVerTv = findViewById(R.id.slider_about_hardver);
        mDevCheckUpdateTv = findViewById(R.id.slider_about_dev_checkupdate);

    }

    private void initListener() {
        mToolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        mAppCheckUpdateTv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 检查app更新
                Beta.checkUpgrade();
            }
        });

        mDevCheckUpdateTv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });

    }

    private void initData() {
        String appVer = AppUtils.getAppVersionName();
        mAppVersionTv.setText(appVer);

        WHost host = WApp.Instance.getDevManager().getSelectedHost();
        if (host != null){
            mDevNameTv.setText(host.getHost().name);
            mDevTypeTv.setText(host.getHost().deviceType);
            mDevSoftVerTv.setText(host.getHost().deviceVersion);
            mDevHardVerTv.setText(host.getHost().deviceVersion);
        }
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onCheckAppUpdateEvent(CheckAppUpdateEvent event){
        if (ActivityUtils.getTopActivity() != this){
            return;
        }

        boolean needUpdate = event.getAppUpdateStat();
        String text = "";
        if (needUpdate){
            text = getString(R.string.activity_about_app_needupdate);
        }else{
            text = getString(R.string.activity_about_app_noupdate);
        }
        ToastUtils.showShort(text);
    }

}
