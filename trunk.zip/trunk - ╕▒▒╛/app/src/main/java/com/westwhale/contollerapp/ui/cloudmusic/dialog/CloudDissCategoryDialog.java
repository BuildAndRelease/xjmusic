package com.westwhale.contollerapp.ui.cloudmusic.dialog;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.DialogFragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.TextView;

import com.westwhale.contollerapp.R;
import com.westwhale.contollerapp.ui.cloudmusic.adapter.CloudDissCategoryAdapter;
import com.westwhale.contollerapp.ui.base.dialog.AttachDialogFragment;
import com.westwhale.contollerapp.ui.cloudmusic.fragment.CloudAlbumFragment;
import com.westwhale.api.protocolapi.bean.cloudmusic.DissCategory;
import com.westwhale.api.protocolapi.bean.cloudmusic.DissCategoryGroup;

import java.util.ArrayList;
import java.util.List;

/**
 * Description:
 * Author: chenyaoli
 * Date: 2018-12-01
 * History:
 */
public class CloudDissCategoryDialog extends AttachDialogFragment implements CloudDissCategoryAdapter.CallBack {
    public static final String CATEGORY_ID = "categoryId";
    public static final String CATEGORY_NAME = "categoryName";

    private TextView mTitleTv;
    private ImageView mCancelIv;
    private RecyclerView mItemRv;
    private CloudDissCategoryAdapter mCategoryAdapter;
    private List<DissCategoryGroup> mDissCategoryGroupList;

    public void setDissCategoryGroupList(List<DissCategoryGroup> groupList) {
        mDissCategoryGroupList = groupList;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // 背景色，动画效果，通过主题设置
        setStyle(DialogFragment.STYLE_NORMAL, R.style.CommonDialogStyle);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        //布局
        View view = inflater.inflate(R.layout.dialogfrag_diss_category, container);

        initView(view);
        initListener();

        return view;
    }

    @Override
    public void onStart() {
        super.onStart();

        //设置fragment高度 、宽度
        double heightPercent = 0.8;
        double widthPercent = 0.9;
        int dialogHeight = (int) (mContext.getResources().getDisplayMetrics().heightPixels * heightPercent);
        int dialogWidth = (int) (mContext.getResources().getDisplayMetrics().widthPixels * widthPercent);
        Window window = getDialog().getWindow();
        if (window != null){
            WindowManager.LayoutParams params = window.getAttributes();
            params.gravity = Gravity.CENTER;
            params.width = dialogWidth;
            params.height = dialogHeight;
            window.setAttributes(params);
        }
        getDialog().setCanceledOnTouchOutside(true);

        initData();
    }

    private void initView(View view) {
        String title = getString(R.string.cloudmusic_dialog_diss_title);;
        mTitleTv = view.findViewById(R.id.dialogfrag_category_title);
        mTitleTv.setText(title);

        mCancelIv = view.findViewById(R.id.dialogfrag_category_cancel);

        mItemRv = view.findViewById(R.id.dialogfrag_category_recylerview);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(mContext);
        mItemRv.setLayoutManager(linearLayoutManager);
        mCategoryAdapter = new CloudDissCategoryAdapter(this);
        mItemRv.setAdapter(mCategoryAdapter);
        mItemRv.setHasFixedSize(true);
        // 设置下拉上拉无阴影效果
        mItemRv.setOverScrollMode(View.OVER_SCROLL_NEVER);

    }

    private void initListener() {
        mCancelIv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dismiss();
            }
        });
    }

    private void initData() {
        ArrayList<DissCategoryGroup> itemList = new ArrayList<>(mDissCategoryGroupList);
        if (mCategoryAdapter != null) {
            mCategoryAdapter.updateDataList(itemList);
            mCategoryAdapter.notifyDataSetChanged();
        }
    }


    @Override
    public void onDissItemClick(DissCategory dissItem) {
        // 点击某一项后
        if (getTargetFragment() == null) {
            return;
        }
        Intent intent = new Intent();
        intent.putExtra(CATEGORY_ID, String.valueOf(dissItem.categoryId));
        intent.putExtra(CATEGORY_NAME, dissItem.categoryName);
        //获得目标Fragment,并将数据通过onActivityResult放入到intent中进行传值
        getTargetFragment().onActivityResult(CloudAlbumFragment.REQUEST_CODDE, Activity.RESULT_OK, intent);

        dismiss();
    }
}
