package com.westwhale.contollerapp.dev.player;

import com.westwhale.api.protocolapi.bean.media.CloudNetFm;

public class CloudNetFmPlayer extends WPlayer<CloudNetFm> {
    private final static String TAG = "CloudNetFmPlayer";

}
