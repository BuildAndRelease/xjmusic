package com.westwhale.contollerapp.ui.cloudstory.fragment;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.Toast;

import com.kingja.loadsir.callback.Callback;
import com.kingja.loadsir.callback.SuccessCallback;
import com.scwang.smartrefresh.layout.api.RefreshLayout;
import com.scwang.smartrefresh.layout.listener.OnLoadMoreListener;
import com.scwang.smartrefresh.layout.listener.OnRefreshListener;
import com.westwhale.contollerapp.R;
import com.westwhale.contollerapp.application.WApp;
import com.westwhale.contollerapp.dev.CmdActionLister;
import com.westwhale.contollerapp.dev.ICmdCallback;
import com.westwhale.contollerapp.dev.WRoom;
import com.westwhale.contollerapp.ui.main.MainRoomActivity;
import com.westwhale.contollerapp.ui.cloudstory.adapter.StoryRankAdatper;
import com.westwhale.contollerapp.ui.base.fragment.TitleBaseFragment;
import com.westwhale.contollerapp.ui.loadsircallback.EmptyCallback;
import com.westwhale.contollerapp.ui.loadsircallback.LoadingCallback;
import com.westwhale.api.protocolapi.bean.telling.RankItem;

import java.util.List;

/**
 * Description:
 * Author: chenyaoli
 * Date: 2018-11-12
 * History:
 */
public class CloudStoryRankFragment extends TitleBaseFragment implements StoryRankAdatper.CallBack{
    private static final String TAG = "StoryRank";

    private FrameLayout mFrameLayout;
    private RecyclerView mDataRv;
    private Toolbar mToolBar;
    private StoryRankAdatper mAdapter;
    private RefreshLayout mRefreshLayout;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        // 先显示加载动画，针对布局做一些初始化
        return inflater.inflate(R.layout.frag_cloudstory_rank,container,false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        mFrameLayout = view.findViewById(R.id.cloudstory_rank_frame);

        // 创建mLoadService
        mLoadService = mLoadSir.register(mFrameLayout, new Callback.OnReloadListener() {
            @Override
            public void onReload(View v) {
                showLoadCallBack(LoadingCallback.class);
                initData();
            }
        });

        initView(view);

        initListener();

        initData();
    }

    @Override
    public void onResume() {
        super.onResume();
    }

    @Override
    public void onRankItemClick(RankItem rankItem) {
        // 点击进入榜单的专辑列表
        CloudStoryRankAlbumFragment fragment = new CloudStoryRankAlbumFragment();
        fragment.setRankItem(rankItem);
        ((MainRoomActivity)getActivity()).showFragment(fragment);
    }

    private void initView(View view) {
        mToolBar = view.findViewById(R.id.cloudstory_rank_toolbar);
        configToolBar(mToolBar,"榜单");

        mDataRv = view.findViewById(R.id.cloudstory_rank_recylerview);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(mContext);
        mDataRv.setLayoutManager(linearLayoutManager);
        mAdapter = new StoryRankAdatper(this);
        mDataRv.setAdapter(mAdapter);
        mDataRv.setHasFixedSize(true);

        mRefreshLayout = view.findViewById(R.id.cloudstory_rank_refresh);
        mRefreshLayout.setDisableContentWhenRefresh(true);
        mRefreshLayout.setEnableLoadMore(true);
    }

    private void initListener() {
        mRefreshLayout.setOnRefreshListener(new OnRefreshListener() {
            @Override
            public void onRefresh(@NonNull RefreshLayout refreshLayout) {
                initData();
            }
        });

        mRefreshLayout.setOnLoadMoreListener(new OnLoadMoreListener() {
            @Override
            public void onLoadMore(@NonNull RefreshLayout refreshLayout) {
                mRefreshLayout.finishLoadMoreWithNoMoreData();
            }
        });
    }

    private void initData() {
        requestCloudResource();
    }


    public void updateDataList(List<RankItem> list){
        if (list != null) {
            mAdapter.updateDataList(list);
            mAdapter.notifyDataSetChanged();

            // 更新刷新等待状态
            mRefreshLayout.finishRefresh();

        showLoadCallBack(SuccessCallback.class);
        }else{
            showLoadCallBack(EmptyCallback.class);
        }
    }

    private void requestCloudResource() {
        Log.e(TAG,"----------- requestCloudStoryCategory ------");
        WRoom room = WApp.Instance.getDevManager().getSelectedRoom();
        if (room != null){
            room.cmdGetStoryTellingRankingList(new CmdActionLister<List<RankItem>>(this, new ICmdCallback<List<RankItem>>() {
                @Override
                public void onSuccess(List<RankItem> data) {
                    Log.e(TAG,"-----------onSuccess------" + data.size());
                    updateDataList(data);
                }

                @Override
                public void onFailed(int code, String msg) {
                    Log.e(TAG,"-----------------"+code+msg);
                    updateDataList(null);
                    Toast.makeText(getContext(),"获取失败:"+code,Toast.LENGTH_SHORT).show();
                }
            }));
        }else{
            updateDataList(null);
        }
    }


}
