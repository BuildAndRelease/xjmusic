package com.westwhale.contollerapp.ui.slider.adapter;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.westwhale.api.protocolapi.bean.hostroom.Room;
import com.westwhale.contollerapp.R;

import java.util.List;
import java.util.Locale;

/**
 * Description:
 * Author: chenyaoli
 * Date: 2018-12-20
 * History
 *
 */
public class PartyRoomAdapter extends RecyclerView.Adapter {
    private List<Room> mItemList;
    private CallBack mCallBack;

    public interface CallBack{
        void onRoomStatClick(Room room);
    }

    public void setCallBack(CallBack callBack){
        this.mCallBack = callBack;
    }

    public void updateList(List<Room> itemList){
        this.mItemList = itemList;
    }

    public void clearAllData(){
        if (mItemList != null){
            mItemList.clear();
            mItemList = null;
            notifyDataSetChanged();
        }
    }

    public void updateItem(Room room){
        if (mItemList != null){
            int index = mItemList.indexOf(room);
            if (index > -1){
                notifyItemChanged(index);
            }
        }
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_party_room, viewGroup, false);
        return new ItemHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder viewHolder, int i) {
        if (viewHolder instanceof ItemHolder){
            final Room item = mItemList.get(i);
            ItemHolder itemHolder = (ItemHolder)viewHolder;

            itemHolder.mNameView.setText(item.roomName);

            int statePicResourceId = R.drawable.btn_lock;
            switch(item.devStat){
                case Room.DevState.CLOSE:
                    statePicResourceId = R.drawable.btn_lock;
                    break;
                case Room.DevState.OPEN:
                    statePicResourceId = R.drawable.btn_unlock;
                    break;
                case Room.DevState.UNCONNECTED:
                    statePicResourceId = R.drawable.room_state_unconnect;
                    break;
                default:
                    break;
            }

            int roomInfoResourceId = R.string.activity_party_room_stat_default;
            switch (item.channelStat){
                case Room.ChannelState.INCLOSED:
                    roomInfoResourceId = R.string.activity_party_room_stat_inclose;
                    break;
                case Room.ChannelState.INNORMAL:
                    roomInfoResourceId = R.string.activity_party_room_stat_innormal;
                    break;
                case Room.ChannelState.INTALK:
                    roomInfoResourceId = R.string.activity_party_room_stat_intalk;
                    break;
                case Room.ChannelState.INPARTY:
                    roomInfoResourceId = R.string.activity_party_room_stat_inparty;
                    break;
                case Room.ChannelState.INDLNA:
                    roomInfoResourceId = R.string.activity_party_room_stat_indlna;
                    break;
                case Room.ChannelState.INAIRPLAY:
                    roomInfoResourceId = R.string.activity_party_room_stat_inairplay;
                    break;
                case Room.ChannelState.INBT:
                    roomInfoResourceId = R.string.activity_party_room_stat_inbt;
                    break;
                default:
                    break;
            }

            itemHolder.mInfoView.setText(roomInfoResourceId);
            itemHolder.mStateView.setImageResource(statePicResourceId);

            itemHolder.mStateLayout.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (mCallBack != null){
                        mCallBack.onRoomStatClick(item);
                    }
                }
            });
        }
    }

    @Override
    public int getItemCount() {
        return (mItemList == null) ? 0 : mItemList.size();
    }

    private class ItemHolder extends RecyclerView.ViewHolder{
        private TextView mNameView,mInfoView;
        private ImageView mStateView;
        private RelativeLayout mStateLayout;
        public ItemHolder(@NonNull View itemView) {
            super(itemView);
            mNameView = itemView.findViewById(R.id.item_party_room_name);
            mInfoView = itemView.findViewById(R.id.item_party_room_info);
            mStateLayout = itemView.findViewById(R.id.item_party_room_stat_layout);
            mStateView = itemView.findViewById(R.id.item_party_room_state);
        }
    }
}
