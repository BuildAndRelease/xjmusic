package com.westwhale.contollerapp.ui.localmusic.fragment;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.blankj.utilcode.util.ToastUtils;
import com.westwhale.contollerapp.R;
import com.westwhale.contollerapp.application.WApp;
import com.westwhale.contollerapp.dev.CmdActionLister;
import com.westwhale.contollerapp.dev.ICmdCallback;
import com.westwhale.contollerapp.dev.MachineType;
import com.westwhale.contollerapp.dev.WHost;
import com.westwhale.contollerapp.dev.WRoom;
import com.westwhale.contollerapp.eventbus.notify.NotifyPlayingInfoEvent;
import com.westwhale.contollerapp.ui.base.fragment.LazyBaseFragment;
import com.westwhale.contollerapp.ui.download.fragment.DownloadedListFragment;
import com.westwhale.contollerapp.ui.favorite.songsheet.activity.FavoriteMediaManagerActivity;
import com.westwhale.contollerapp.ui.favorite.songsheet.dialog.FavoriteMediaNameDialog;
import com.westwhale.contollerapp.ui.favorite.songsheet.fragment.FavoriteSongInfoFragment;
import com.westwhale.contollerapp.ui.localmusic.adapter.LocalFavoriteSongAdapter;
import com.westwhale.contollerapp.ui.main.MainRoomActivity;
import com.westwhale.contollerapp.common.ImageTextItem;
import com.westwhale.contollerapp.ui.localmusic.adapter.LocalHomeAdapter;
import com.westwhale.api.protocolapi.bean.media.CloudMusic;
import com.westwhale.api.protocolapi.bean.media.LocalAux;
import com.westwhale.api.protocolapi.bean.media.LocalMusic;
import com.westwhale.api.protocolapi.bean.media.Media;
import com.westwhale.api.protocolapi.bean.PlayList;
import com.westwhale.api.protocolapi.bean.media.CloudNetFm;
import com.westwhale.api.protocolapi.bean.hostroom.PlayingInfo;
import com.westwhale.api.protocolapi.bean.hostroom.Room;
import com.westwhale.api.protocolapi.bean.media.Section;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import java.util.ArrayList;
import java.util.List;

public class LocalHomeFragment extends LazyBaseFragment implements LocalHomeAdapter.CallBack, LocalFavoriteSongAdapter.CallBack {
    private static final String TAG = LocalHomeFragment.class.getName();

    private ImageView mFavoriteMediaExpandIv,mFavoriteMediaAddIv,mFavoriteMediaEditIv;
    private LinearLayout mFavoriteMediaLayout;
    private TextView mSearchTv,mRoomNameTv,mPlayingTv;
    private RecyclerView mItemRv,mFavoriteSongItemRv;
    private LocalHomeAdapter mLocalHomeAdapter;
    private LocalFavoriteSongAdapter mFavoriteSongAdapter;
    private List<ImageTextItem> mItemList = new ArrayList<>(); //“我的” 首页的项

    private List<PlayList> mFavoriteSongSheetList = new ArrayList<>();

    private Media mMedia;

    private final int LOCAL_TYPE_LOCALMUSIC = 1;
    private final int LOCAL_TYPE_AUX = 2;
    private final int LOCAL_TYPE_RECENT = 3;
    private final int LOCAL_TYPE_DOWNLOAD = 4;
    private final int LOCAL_TYPE_MYFAVORITE = 5;
    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        //设置mlistInfo，listview要显示的内容
        WHost host = WApp.Instance.getDevManager().getSelectedHost();
        boolean hasDownloadFun = (host != null) && (MachineType.hasFunc_Download(host.getHost().deviceType));
        boolean hasAux2Src = (host != null) && (MachineType.containMediaSrcAux2(host.getHost().deviceType));


        mItemList.clear();
        mItemList.add(new ImageTextItem(LOCAL_TYPE_LOCALMUSIC,R.drawable.local_localmusic,getString(R.string.local_home_localmusic)));
        mItemList.add(new ImageTextItem(LOCAL_TYPE_AUX,R.drawable.local_aux,getString(R.string.local_home_aux1)));
        mItemList.add(new ImageTextItem(LOCAL_TYPE_RECENT,R.drawable.local_recent,getString(R.string.local_home_recent)));
        if (hasDownloadFun) {
            mItemList.add(new ImageTextItem(LOCAL_TYPE_DOWNLOAD, R.drawable.local_download, getString(R.string.local_home_download)));
        }
        mItemList.add(new ImageTextItem(LOCAL_TYPE_MYFAVORITE,R.drawable.local_favorite_album,getString(R.string.local_home_albumfavorite)));

        // eventbus 注册
        EventBus.getDefault().register(this);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();

        // eventbus 取消注册
        EventBus.getDefault().unregister(this);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        switch(requestCode){
            case FavoriteMediaNameDialog.REQUEST_CODE_NEW: {
                String playlistName = data.getStringExtra(FavoriteMediaNameDialog.PLAYLIST_NAME);
                newFavoritePlaylist(playlistName);

                break;
            }
            case FavoriteMediaNameDialog.DIALOG_TYPE_RENAME: {
                String playlistName = data.getStringExtra(FavoriteMediaNameDialog.PLAYLIST_NAME);
                int playlistId = data.getIntExtra(FavoriteMediaNameDialog.PLAYLIST_ID,-1);
                renameFavoritePlaylist(playlistId,playlistName);

                break;
            }
            case FavoriteMediaManagerActivity.REQUEST_CODE_MANAGER:{

                requestDataResource();

                break;
            }
            default:
                break;
        }
    }

    @Override
    public int getLayoutId() {
        return R.layout.frag_local_home;
    }

    @Override
    public void initView(View view) {
        mSearchTv = view.findViewById(R.id.localmusic_home_search);
        mRoomNameTv = view.findViewById(R.id.localmusic_home_roomname);
        mPlayingTv = view.findViewById(R.id.localmusic_home_playinfo);

        mItemRv = view.findViewById(R.id.localmusic_home_recyclerview);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(mContext);
        mItemRv.setLayoutManager(linearLayoutManager);
        mLocalHomeAdapter = new LocalHomeAdapter();
        mLocalHomeAdapter.setCallBack(this);
        mItemRv.setAdapter(mLocalHomeAdapter);
        mItemRv.setHasFixedSize(true);

        mFavoriteSongItemRv = view.findViewById(R.id.localmusic_home_songfavorite_recyclerview);
        mFavoriteSongItemRv.setLayoutManager(new LinearLayoutManager(mContext));
        mFavoriteSongAdapter = new LocalFavoriteSongAdapter();
        mFavoriteSongAdapter.setCallBack(this);
        mFavoriteSongItemRv.setAdapter(mFavoriteSongAdapter);
        mFavoriteSongItemRv.setHasFixedSize(true);

        mFavoriteMediaLayout = view.findViewById(R.id.localmusic_home_favorite_media_layout);
        mFavoriteMediaExpandIv = view.findViewById(R.id.localmusic_home_favorite_media_expand);
        mFavoriteMediaAddIv = view.findViewById(R.id.localmusic_home_favorite_media_add);
        mFavoriteMediaEditIv = view.findViewById(R.id.localmusic_home_favorite_media_edit);
    }

    @Override
    public void initListener() {
        mSearchTv.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                // 跳转到搜索界面
                LocalMusicSearchFragment fragment = new LocalMusicSearchFragment();
                if (getActivity() instanceof MainRoomActivity) {
                    ((MainRoomActivity) getActivity()).showFragment(fragment);
                }
            }
        });

        mFavoriteMediaAddIv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 新建歌单
                FavoriteMediaNameDialog dialog = new FavoriteMediaNameDialog();
                dialog.configDialogType(FavoriteMediaNameDialog.DIALOG_TYPE_NEW,"",-1);
                dialog.setTargetFragment(LocalHomeFragment.this,FavoriteMediaNameDialog.REQUEST_CODE_NEW);
                if (getFragmentManager() != null) {
                    dialog.show(getFragmentManager(), FavoriteMediaNameDialog.TAG);
                }
            }
        });

        mFavoriteMediaEditIv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 管理歌单,过滤 默认的收藏夹
                Intent intent = new Intent(getContext(),FavoriteMediaManagerActivity.class);
                List<PlayList> datalist = new ArrayList<>();
                for (int i = 0; i < mFavoriteSongSheetList.size(); i++){
                    if ((mFavoriteSongSheetList.get(i) != null) && (!(FavoriteMediaManagerActivity.PLAYLIST_EDIT_STAT_0).equals(mFavoriteSongSheetList.get(i).editStat))){
                        datalist.add(mFavoriteSongSheetList.get(i));
                    }
                }
                FavoriteMediaManagerActivity.setDataList(datalist);
                startActivityForResult(intent,FavoriteMediaManagerActivity.REQUEST_CODE_MANAGER);
            }
        });

        mFavoriteMediaLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 展开/收起
                updateFavoriteListStat();
            }
        });
    }


    @Override
    public void initData() {
        mLocalHomeAdapter.updateList(mItemList);
        mLocalHomeAdapter.notifyDataSetChanged();

        mFavoriteSongAdapter.setDataList(mFavoriteSongSheetList);

        requestDataResource();

        String roomName = "";
        String roomStat = "";
        Media media = null;
        WRoom room = WApp.Instance.getDevManager().getSelectedRoom();
        if (room != null) {
            roomName = room.getRoomName();
            roomStat = room.getChannelStat();
            media = room.getPlayingMedia();
        }
        upateRoomInfo(roomName, roomStat, media);
    }

    @Override
    public void onLazyLoad() {
        initData();
    }

    @Override
    public void onRetryLoad() {
        super.onRetryLoad();

        // 每次到该界面，都重新获取一次自建歌单
        requestDataResource();
    }

    @Override
    public void onItemClick(ImageTextItem item, int pos) {
        if ((item != null) && (pos > -1)){
            switch (item.getType()){
                case LOCAL_TYPE_LOCALMUSIC: {
                    // 本地音乐
                    LocalMusicFragment fragment = new LocalMusicFragment();
                    fragment.updateDirectoryInfo(getString(R.string.localmusic_title), getString(R.string.localmusic_root_dir), "");
                    if (getActivity() instanceof MainRoomActivity) {
                        ((MainRoomActivity) getActivity()).showFragment(fragment);
                    }
                    break;
                }
                case LOCAL_TYPE_AUX: {
                    // AUX, 切换到AUX音源
                    WRoom room = WApp.Instance.getDevManager().getSelectedRoom();
                    if (room != null){
                        room.cmdSwitchToAux1(new CmdActionLister<Boolean>(LocalHomeFragment.this, new ICmdCallback<Boolean>() {
                            @Override
                            public void onSuccess(Boolean data) {

                            }

                            @Override
                            public void onFailed(int code, String msg) {
                                ToastUtils.showShort("SwitchToAux1 failed：%d",code);
                            }
                        }));
                    }
                    break;
                }
                case LOCAL_TYPE_RECENT: {
                    // 最近播放
                    RecentFragment fragment = new RecentFragment();
                    if (getActivity() instanceof MainRoomActivity) {
                        ((MainRoomActivity) getActivity()).showFragment(fragment);
                    }
                    break;
                }
                case LOCAL_TYPE_DOWNLOAD: {
                    // 我的下载
                    DownloadedListFragment fragment = new DownloadedListFragment();
                    if (getActivity() instanceof MainRoomActivity) {
                        ((MainRoomActivity) getActivity()).showFragment(fragment);
                    }
                    break;
                }
                case LOCAL_TYPE_MYFAVORITE:
                    break;
                default:
                    break;
            }
        }
    }

    @Override
    public void onFavoriteSongItemClick(PlayList item) {
        // 点击进入指定的歌单
        FavoriteSongInfoFragment fragment = new FavoriteSongInfoFragment();
        fragment.updateSelectedPlaylist(item);
        if (getActivity() instanceof MainRoomActivity) {
            ((MainRoomActivity) getActivity()).showFragment(fragment);
        }
    }

    /**  接收所有的广播处理，然后再 调用 mSimplePlayerFragment对象的相关更新方法更新 */
    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onNotifyPlayingInfoEvent(NotifyPlayingInfoEvent event) {
        PlayingInfo playingInfo = event.getPlayingInfo();
        if ((null == playingInfo) || !playingInfo.isAvailble()){
            return;
        }

        WRoom room = WApp.Instance.getDevManager().getSelectedRoom();
        String roomName = (room != null) ? room.getRoomName() : "";
        upateRoomInfo(roomName,playingInfo.roomState,playingInfo.media);
    }

    private void upateRoomInfo(String roomName,String roomStat,Media media) {
        String name = (roomName != null) ? roomName : "";
        String statInfo = "(未知)";
        String playingInfo = "";
        if (roomStat != null) {
            switch (roomStat){
                case Room.ChannelState.INNORMAL:
                case Room.ChannelState.INPARTY:
                {
                    statInfo = "";
                    if (Room.ChannelState.INPARTY.equals(roomStat)){
                        statInfo = "(Party)";
                    }

                    if (null == media){
                        playingInfo = "无播放信息";
                    } else {
                        switch(media.mediaSrc){
                            case Media.LOCAL_MUSIC:
                                playingInfo = "本地音乐: " + ((LocalMusic)media).songName;
                                break;
                            case Media.CLOUD_MUSIC:
                                playingInfo = "云音乐: " + ((CloudMusic)media).songName;
                                break;
                            case Media.CLOUD_NETFM:
                                playingInfo = "网络电台: " + ((CloudNetFm)media).programName;
                                break;
                            case Media.CLOUD_STORY_TELLING:
                                playingInfo = "语言节目: " + ((Section)media).sectionName;
                                break;
                            case Media.LOCAL_AUX:
                                playingInfo = "AUX: " + (((LocalAux)media).auxId+1);
                                break;
                            default:
                                playingInfo = "云音乐:";
                                break;
                        }
                    }
                    break;
                }
                case Room.ChannelState.INBT:
                    statInfo = "(蓝牙)";
                    playingInfo = "蓝牙播放中";
                    break;
                case Room.ChannelState.INTALK:
                    statInfo = "(对讲)";
                    playingInfo = "对讲中";
                    break;
                default:
                    statInfo = "(" + roomStat + ")";
                    break;
            }
        }

        name = name + statInfo;
        mRoomNameTv.setText(name);
        mPlayingTv.setText(playingInfo);
    }

    private void updateFavoriteListStat() {
        int visible = mFavoriteSongItemRv.getVisibility();
        if (visible == View.VISIBLE){
            mFavoriteSongItemRv.setVisibility(View.GONE);
            mFavoriteMediaExpandIv.setImageResource(R.drawable.arrow_right);
        }else{
            mFavoriteSongItemRv.setVisibility(View.VISIBLE);
            mFavoriteMediaExpandIv.setImageResource(R.drawable.arrow_down);

        }
    }

    private void updateDataList(List<PlayList> list){
        if (list != null){
            mFavoriteSongSheetList.clear();
            mFavoriteSongSheetList.addAll(list);

            mFavoriteSongAdapter.notifyDataSetChanged();
        }
    }

    private void requestDataResource(){
        WRoom room = WApp.Instance.getDevManager().getSelectedRoom();
        if (room != null){
            room.cmdGetFavoritePlayList(new CmdActionLister<List<PlayList>>(LocalHomeFragment.this, new ICmdCallback<List<PlayList>>() {
                @Override
                public void onSuccess(List<PlayList> data) {
                    updateDataList(data);
                }

                @Override
                public void onFailed(int code, String msg) {
                    updateDataList(null);
                    ToastUtils.showShort("GetFavoritePlayList失败:%d",code);
                }
            }));
        }else{
            updateDataList(null);
        }
    }

    private void newFavoritePlaylist(String name){
        WRoom room = WApp.Instance.getDevManager().getSelectedRoom();
        if (room != null){
            room.cmdAddFavoritePlayList(name, new CmdActionLister<PlayList>(LocalHomeFragment.this, new ICmdCallback<PlayList>() {
                @Override
                public void onSuccess(PlayList data) {
                    mFavoriteSongSheetList.add(data);
                    mFavoriteSongAdapter.notifyItemInserted(mFavoriteSongAdapter.getItemCount());
                }

                @Override
                public void onFailed(int code, String msg) {
                    ToastUtils.showShort("新建歌单失败:%d",code);
                }
            }));
        }
    }

    private void renameFavoritePlaylist(int playlistId,String name){
        WRoom room = WApp.Instance.getDevManager().getSelectedRoom();
        if (room != null){
            room.cmdRenameFavoritePlayList(playlistId,name, new CmdActionLister<Boolean>(LocalHomeFragment.this, new ICmdCallback<Boolean>() {
                @Override
                public void onSuccess(Boolean data) {
                    if (data){
                        for (int i = 0; i < mFavoriteSongSheetList.size(); i++){
                            if (mFavoriteSongSheetList.get(i).playListId == playlistId){
                                mFavoriteSongSheetList.get(i).playListName = name;
                                mFavoriteSongAdapter.notifyItemChanged(i);
                                break;
                            }
                        }
                    }
                }

                @Override
                public void onFailed(int code, String msg) {
                    ToastUtils.showShort("重命名歌单失败:%d",code);
                }
            }));
        }
    }


}

