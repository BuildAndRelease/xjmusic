package com.westwhale.contollerapp.utils;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.util.TypedValue;

import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.List;

import com.alibaba.fastjson.JSON;
import com.westwhale.contollerapp.R;
import com.westwhale.api.protocolapi.bean.Singer;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class CommonUtils {

    public static String getCloudMusicPic(String albumMid, List<Singer> singerList){
        String pic = "";

        if ((singerList != null) && (singerList.size() > 0)){
            Singer singer = singerList.get(0);
            String singerMid = singer.mid;
            if ((singerMid != null) && (singerMid.length() >= 2)){
                String tempStr = singerMid.substring(singerMid.length()-2);
                if (tempStr.length() == 2){
                    pic = "http://i.gtimg.cn/music/photo/mid_singer_150/" + tempStr.charAt(0) + "/" + tempStr.charAt(1) + "/" + singerMid + ".jpg";
                }
            }
        }

        if (pic.isEmpty() && (albumMid != null) && (albumMid.length() >= 2)) {
            String tempStr = albumMid.substring(albumMid.length()-2);
            if (tempStr.length() == 2){
                pic = "http://i.gtimg.cn/music/photo/mid_album_500/" + tempStr.charAt(0) + "/" + tempStr.charAt(1) + "/" + albumMid + ".jpg";
            }
        }
        return pic;
    }

    public static String getIPAddress(Context context) {
        NetworkInfo info = ((ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE)).getActiveNetworkInfo();
        if (info != null && info.isConnected()) {

            if (info.getType() == ConnectivityManager.TYPE_MOBILE) {//当前使用2G/3G/4G网络
                try {
                    for (Enumeration<NetworkInterface> en = NetworkInterface.getNetworkInterfaces(); en.hasMoreElements(); ) {
                        NetworkInterface intf = en.nextElement();
                        for (Enumeration<InetAddress> enumIpAddr = intf.getInetAddresses(); enumIpAddr.hasMoreElements(); ) {
                            InetAddress inetAddress = enumIpAddr.nextElement();
                            if (!inetAddress.isLoopbackAddress() && inetAddress instanceof Inet4Address) {
                                return inetAddress.getHostAddress();
                            }
                        }
                    }
                } catch (SocketException e) {
                    e.printStackTrace();
                }

            } else if (info.getType() == ConnectivityManager.TYPE_WIFI) {//当前使用无线网络
                WifiManager wifiManager = (WifiManager) context.getSystemService(Context.WIFI_SERVICE);
                if (!wifiManager.isWifiEnabled()) {
                    wifiManager.setWifiEnabled(true);
                }
                WifiInfo wifiInfo = wifiManager.getConnectionInfo();
                String ipAddress = intIP2StringIP(wifiInfo.getIpAddress());//得到IPV4地址
                return ipAddress;
            }
        } else {
            //当前无网络连接,请在设置中打开网络
        }

        return null;
    }

    /**
     * 将得到的 int的IP 转换为 String
     */
    public static String intIP2StringIP(int ip) {
        return (ip & 0xFF) + "." +
                ((ip >> 8) & 0xFF) + "." +
                ((ip >> 16) & 0xFF) + "." +
                (ip >> 24 & 0xFF);
    }

    public static int getActionBarHeight(Context context) {
        int mActionBarHeight;
        TypedValue mTypedValue = new TypedValue();

        context.getTheme().resolveAttribute(R.attr.actionBarSize, mTypedValue, true);

        mActionBarHeight = TypedValue.complexToDimensionPixelSize(mTypedValue.data, context.getResources().getDisplayMetrics());

        return mActionBarHeight;
    }


    public static JSONArray converListToJson(List list) throws JSONException {
        if (list == null) {
            return null;
        } else {
            JSONArray jsonArray = new JSONArray();
            for (Object o : list) {
                jsonArray.put(new JSONObject(JSON.toJSONString(o)));
            }

            return jsonArray;
        }
    }
}
