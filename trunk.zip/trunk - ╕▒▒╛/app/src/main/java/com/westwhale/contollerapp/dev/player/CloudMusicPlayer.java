package com.westwhale.contollerapp.dev.player;

import com.westwhale.api.protocolapi.bean.media.CloudMusic;

public class CloudMusicPlayer extends WPlayer<CloudMusic> {
    private final static String TAG = "CloudMusicPlayer";

}
