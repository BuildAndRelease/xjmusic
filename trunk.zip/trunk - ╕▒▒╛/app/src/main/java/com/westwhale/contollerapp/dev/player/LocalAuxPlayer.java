package com.westwhale.contollerapp.dev.player;

import com.westwhale.api.protocolapi.bean.media.LocalAux;

public class LocalAuxPlayer extends WPlayer<LocalAux> {
    private final static String TAG = LocalAux.class.getName();

}
