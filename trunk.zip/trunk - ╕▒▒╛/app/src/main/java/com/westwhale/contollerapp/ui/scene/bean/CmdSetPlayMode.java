package com.westwhale.contollerapp.ui.scene.bean;


import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;

public class CmdSetPlayMode extends CmdActionBase {
    public final static String PLAYMODE_NORMAL = "normal";
    public final static String PLAYMODE_CIRCLE = "circle";
    public final static String PLAYMODE_SINGLE = "single";
    public final static String PLAYMODE_SHUFFLE = "shuffle";

    private String mPlayMode = PLAYMODE_NORMAL;

    public CmdSetPlayMode() {
        mType = CMD_TYPE_SETPLAYMODE;
        mCmdName = getCmdName();
    }

    @Override
    public String toJsonString() {
        JSONObject argObject = new JSONObject();
        argObject.put("playMode",mPlayMode);

        JSONObject jsonObject = new JSONObject();
        jsonObject.put("cmd",mCmdName);
        jsonObject.put("arg",argObject);

        return jsonObject.toJSONString();
    }

    @Override
    public String getActionValue() {
        return getModeName(mPlayMode);
    }

    @Override
    public void parseArgs() {
        if ((mCmdArgs == null) || (mCmdArgs.isEmpty())){
            return;
        }

        try {
            mPlayMode = JSON.parseObject(mCmdArgs).getString("playMode");
        }catch (Exception e){
            mPlayMode = "";
        }
    }

    public void setPlayMode(String playMode){
        mPlayMode = playMode;
    }

    public String getPlayMode(){
        return mPlayMode;
    }

    public static String getModeName(String mode){
        String value = "";
        switch(mode){
            case PLAYMODE_NORMAL:
                value = "顺序播放";
                break;
            case PLAYMODE_CIRCLE:
                value = "循环播放";
                break;
            case PLAYMODE_SINGLE:
                value = "单曲播放";
                break;
            case PLAYMODE_SHUFFLE:
                value = "随机播放";
                break;
            default:
                break;
        }
        return value;
    }
}
