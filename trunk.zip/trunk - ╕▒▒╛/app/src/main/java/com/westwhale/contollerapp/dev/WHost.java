package com.westwhale.contollerapp.dev;

import android.os.Handler;
import android.support.annotation.NonNull;

import com.blankj.utilcode.util.ThreadUtils;
import com.westwhale.api.protocolapi.BaApi;
import com.westwhale.api.protocolapi.bean.ServerIpInfo;
import com.westwhale.api.protocolapi.bean.hostroom.Host;
import com.westwhale.api.protocolapi.bean.hostroom.Room;
import com.westwhale.api.protocolapi.net.Response;
import com.westwhale.contollerapp.application.WApp;


import java.util.List;

/**
 *  虚拟的设备节点，对应主机端的实际设备
 *     1. 一个设备可以允许有多个房间
 *     2. 设备的基本信息：
 *          1）设备名，设备IP，设备UUID，
 */
public class WHost {
    private Host mHost;   // 协议中的主机类

    // 构造函数
    public WHost(@NonNull Host host){
        mHost = host;
    }

    public Host getHost(){
        return mHost;
    }

    public String getHostName() {
        return mHost.name;
    }
    public void setHostName(String devName) {
        mHost.name = devName;
    }
    synchronized private void updaeteHostName(String name){
        mHost.name = name;
    }
    public void cmdSetSystemServerName(String serverName, CmdActionLister<Boolean> actionLister) {
        ThreadUtils.getIoPool().execute(new Runnable() {
            @Override
            public void run() {
                Response<Boolean> response = null;
                try {
                    response = BaApi.getInstance().setSystemServerName(serverName);
                } catch (Exception e) {
                    e.printStackTrace();
                }finally {
                    postCmdResponse(response,actionLister);
                }
            }
        });
    }


    public static void cmdGetHostRoomList(String hostIp, String hostId, CmdActionLister<List<Room>> actionLister) {
        ThreadUtils.getIoPool().execute(new Runnable() {
            @Override
            public void run() {
                Response<List<Room>> response = null;
                try {
                    response = BaApi.getInstance().getRooms(hostIp, hostId);
                } catch (Exception e) {
                    e.printStackTrace();
                }finally {
                    postCmdResponse(response,actionLister);
                }
            }
        });
    }

    public void cmdGetServerIpInfo(CmdActionLister<ServerIpInfo> actionLister) {
        ThreadUtils.getIoPool().execute(new Runnable() {
            @Override
            public void run() {
                Response<ServerIpInfo> response = null;
                try {
                    response = BaApi.getInstance().getServerIpInfo();
                } catch (Exception e) {
                    e.printStackTrace();
                }finally {
                    postCmdResponse(response,actionLister);
                }
            }
        });
    }

    public void cmdSetServerIpInfo(ServerIpInfo serverIpInfo,CmdActionLister<Boolean> actionLister) {
        ThreadUtils.getIoPool().execute(new Runnable() {
            @Override
            public void run() {
                Response<Boolean> response = null;
                try {
                    response = BaApi.getInstance().setServerIpInfo(serverIpInfo);
                } catch (Exception e) {
                    e.printStackTrace();
                }finally {
                    postCmdResponse(response,actionLister);
                }
            }
        });
    }

    public void cmdSystemRestart(CmdActionLister<Boolean> actionLister) {
        ThreadUtils.getIoPool().execute(new Runnable() {
            @Override
            public void run() {
                Response<Boolean> response = null;
                try {
                    response = BaApi.getInstance().restartSystem();
                } catch (Exception e) {
                    e.printStackTrace();
                }finally {
                    postCmdResponse(response,actionLister);
                }
            }
        });
    }


    private static Handler mHandler; // 消息回复处理
    //在泛型类中声明了一个泛型方法，使用泛型E，这种泛型E可以为任意类型。可以类型与T相同，也可以不同。
    //由于泛型方法在声明的时候会声明泛型<E>，因此即使在泛型类中并未声明泛型，编译器也能够正确识别泛型方法中识别的泛型。
    private static <E> void postCmdResponse(Response<E> result, CmdActionLister<E> actionLister) {
        if (null == mHandler) {
            mHandler = new Handler(WApp.Instance.getMainLooper());
        }

        mHandler.post(new Runnable() {
            @Override
            public void run() {
                if (!ThreadUtils.isMainThread() || (null == actionLister)) {
                    return;
                }

                String msg = "";
                E data = null;
                int resultCode = -1;
                if (result != null) {
                    resultCode = result.resultCode;
                    if (0 == resultCode) {
                        data = result.bean;
                    }
                }

                actionLister.callback(resultCode, data, msg);
            }
        });
    }

    private static <E> void postCmdResponseAll(Response<E> result, CmdActionLister<Response<E>> actionLister) {
        if (null == mHandler) {
            mHandler = new Handler(WApp.Instance.getMainLooper());
        }

        mHandler.post(new Runnable() {
            @Override
            public void run() {
                if (!ThreadUtils.isMainThread() || (null == actionLister)) {
                    return;
                }

                String msg = "";
                Response<E> data = null;
                int resultCode = -1;
                if (result != null) {
                    resultCode = result.resultCode;
                    if (0 == resultCode) {
                        data = result;
                    }
                }

                actionLister.callback(resultCode, data, msg);
            }
        });
    }
}
