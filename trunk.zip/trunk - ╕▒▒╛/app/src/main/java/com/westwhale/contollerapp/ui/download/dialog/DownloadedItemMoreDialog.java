package com.westwhale.contollerapp.ui.download.dialog;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.DialogFragment;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.TextView;
import android.widget.Toast;

import com.blankj.utilcode.util.ToastUtils;
import com.westwhale.api.protocolapi.BAKey;
import com.westwhale.contollerapp.R;
import com.westwhale.contollerapp.application.WApp;
import com.westwhale.contollerapp.common.ImageTextItem;
import com.westwhale.contollerapp.dev.CmdActionLister;
import com.westwhale.contollerapp.dev.ICmdCallback;
import com.westwhale.contollerapp.dev.WRoom;
import com.westwhale.contollerapp.ui.base.dialog.AttachDialogFragment;
import com.westwhale.contollerapp.ui.cloudmusic.adapter.ImageTextItemAdapter;
import com.westwhale.contollerapp.ui.download.fragment.DownloadedListFragment;
import com.westwhale.contollerapp.ui.favorite.songsheet.dialog.FavoriteAddMediaDialog;
import com.westwhale.api.protocolapi.bean.media.CloudMusic;
import com.westwhale.api.protocolapi.bean.media.Media;
import com.westwhale.api.protocolapi.bean.download.DownloadItem;

import java.util.ArrayList;
import java.util.List;

/**
 * Description:
 * Author: chenyaoli
 * Date: 2018-11-23
 * History:
 */
public class DownloadedItemMoreDialog extends AttachDialogFragment implements ImageTextItemAdapter.CallBack {
    public static final String TAG = DownloadedItemMoreDialog.class.getName();

    public static final String MUSIC_ITEM = "music";
    private TextView mTitleTv;
    private RecyclerView mItemRv;
    private ImageTextItemAdapter mMoreInfoAdapter;
    private ArrayList<ImageTextItem> mItemList = new ArrayList<>();
    private DownloadItem<CloudMusic> mDownloadData;

    public void setDataItem(DownloadItem<CloudMusic> item){
        mDownloadData = item;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // 背景色，动画效果，通过主题设置
        setStyle(DialogFragment.STYLE_NORMAL,R.style.CommonDialogStyle);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        //布局
        View view = inflater.inflate(R.layout.frag_info_more, container);

        initView(view);
        initListener();

        return view;
    }

    @Override
    public void onStart() {
        super.onStart();

        //设置fragment高度 、宽度
        double heightPercent = 0.5;
        int dialogHeight = (int) (mContext.getResources().getDisplayMetrics().heightPixels * heightPercent);
        Window window = getDialog().getWindow();
        if (window != null) {
            WindowManager.LayoutParams params = window.getAttributes();
            params.gravity = Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL;
            params.width = WindowManager.LayoutParams.MATCH_PARENT;
            params.height = dialogHeight; // 底部弹出的DialogFragment的高度，如果是MATCH_PARENT则铺满整个窗口
            window.setAttributes(params);
            getDialog().setCanceledOnTouchOutside(true);
        }
        initData();
    }

    private void initView(View view) {
        String title = getString(R.string.downloaded_dialog_musicmore_title);
        if (mDownloadData != null){
            CloudMusic cloudMusic = mDownloadData.media;
            title += cloudMusic.songName;
        }
        mTitleTv = view.findViewById(R.id.info_more_title);
        mTitleTv.setText(title);

        mItemRv = view.findViewById(R.id.info_more_recylerview);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(mContext);
        mItemRv.setLayoutManager(linearLayoutManager);
        mMoreInfoAdapter = new ImageTextItemAdapter();
        mMoreInfoAdapter.setCallBack(this);
        mItemRv.setAdapter(mMoreInfoAdapter);
        mItemRv.setHasFixedSize(true);
        mItemRv.addItemDecoration(new DividerItemDecoration(mContext, DividerItemDecoration.VERTICAL));
        // 设置下拉上拉无阴影效果
        mItemRv.setOverScrollMode(View.OVER_SCROLL_NEVER);

        mItemList.clear();
        this.setMusicInfo();

        mMoreInfoAdapter.updateList(mItemList);
        mMoreInfoAdapter.notifyDataSetChanged();
    }

    //设置音乐overflow条目
    private void setMusicInfo() {
        //设置mlistInfo，listview要显示的内容
        setInfo(getString(R.string.downloaded_dialog_musicmore_next), R.drawable.cloudmusic_more_item_next,true);
        setInfo(getString(R.string.downloaded_dialog_musicmore_add), R.drawable.cloudmusic_more_item_favorite,true);
        String singer = "";
        String albumName = "";
        CloudMusic cloudMusic = null;
        if (mDownloadData != null){
            cloudMusic = mDownloadData.media;
            if (cloudMusic != null){
                singer = cloudMusic.getSingersName();
                albumName = cloudMusic.albumName;
            }
        }

        setInfo(getString(R.string.downloaded_dialog_musicmore_delete), R.drawable.local_more_delete,true);
        setInfo(getString(R.string.downloaded_dialog_musicmore_singer) + singer, R.drawable.cloudmusic_more_item_singer,false);
        setInfo(getString(R.string.downloaded_dialog_musicmore_album) + albumName, R.drawable.cloudmusic_more_item_album,false);
    }

    //为info设置数据，并放入mlistInfo
    private void setInfo(String title, int id, boolean usable) {
        ImageTextItem information = new ImageTextItem();
        information.setTitle(title);
        information.setImageRes(id);
        information.setItemStat(usable);
        mItemList.add(information); //将新的info对象加入到信息列表中
    }

    private void initListener() {
    }

    private void initData() {
    }

    @Override
    public void onMoreInfoItemClick(View view, String data) {
        switch (Integer.parseInt(data)) {
            case 0: {
                // 下一首播放 将已选择的歌曲添加到云音乐播放列表
                CloudMusic cloudMusic = null;
                if (mDownloadData != null){
                    cloudMusic = mDownloadData.media;
                }
                List<CloudMusic> itemList = new ArrayList<>();
                itemList.add(cloudMusic);
                WRoom room = WApp.Instance.getDevManager().getSelectedRoom();
                if (room != null) {
                    WRoom.cmdAddToCloudMusicList(itemList, new CmdActionLister<>(DownloadedItemMoreDialog.this, new ICmdCallback<Boolean>() {
                        @Override
                        public void onSuccess(Boolean data) {
                            Toast.makeText(mContext, "添加到云音乐列表成功", Toast.LENGTH_SHORT).show();
                        }

                        @Override
                        public void onFailed(int code, String msg) {
                            Toast.makeText(mContext, "AddToCloudMusicList失败...", Toast.LENGTH_SHORT).show();
                        }
                    }));
                }
                dismiss();
                break;
            }
            case 1: {
                // 收藏到歌单
                CloudMusic cloudMusic = null;
                if (mDownloadData != null){
                    cloudMusic = mDownloadData.media;
                }
                if (cloudMusic != null) {
                    FavoriteAddMediaDialog favoriteDialog = new FavoriteAddMediaDialog();
                    List<CloudMusic> medialist = new ArrayList<>();
                    medialist.add(cloudMusic);
                    favoriteDialog.updateMediaList(Media.CLOUD_MUSIC, medialist);
                    if (getFragmentManager() != null) {
                        favoriteDialog.show(getFragmentManager(), FavoriteAddMediaDialog.TAG);
                    }
                }

                dismiss();
                break;
            }
            case 2: {
                // 删除
                if (mDownloadData != null){
                    WRoom room = WApp.Instance.getDevManager().getSelectedRoom();
                    if (room != null){
                        List<DownloadItem<CloudMusic>> itemList = new ArrayList<>();
                        itemList.add(mDownloadData);

                        room.cmdOperatorDownload(BAKey.ARG_DEL_DOWNLOADED,itemList,new CmdActionLister<Boolean>(this, new ICmdCallback<Boolean>() {
                            @Override
                            public void onSuccess(Boolean data) {
                                if (data) {
                                    ToastUtils.showShort("删除成功");
                                    //获得目标Fragment,并将数据通过onActivityResult放入到intent中进行传值
                                    if (getTargetFragment() != null) {
                                        getTargetFragment().onActivityResult(DownloadedListFragment.REQUEST_CODE_DETELE, Activity.RESULT_OK, new Intent());
                                    }
                                }
                                dismiss();
                            }

                            @Override
                            public void onFailed(int code, String msg) {
                                ToastUtils.showShort("删除失败 %d",code);
                                dismiss();
                            }
                        }));
                    }
                }

                break;
            }
            case 3:
                // TODO: 2018-11-29 查看歌手
//                dismiss();
                break;
            case 4:
                // TODO: 2018-11-29 查看专辑
//                dismiss();
                break;
            default:

                dismiss();
                break;
        }
    }
}
