package com.westwhale.contollerapp.ui.scene.bean;


import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;

//Flat	单调
//Classical	经典
//Club	俱乐部
//Dance	舞曲
//Full bass	全低音
//Full bass and treble	全低高音
//Full treble	全高音
//Headphones	耳机
//Large Hall	大音乐厅
//Live	实况
//Party	聚会
//Pop	流行
//Reggae	雷盖
//Rock	摇滚
//Ska	斯卡
//Soft	柔和
//Soft rock	慢摇
//Techno	电子乐

public class CmdSetEq extends CmdActionBase {
    private String mEq = "";

    public static final String EQ_FLAT = "flat";
    public static final String EQ_CLASSICAL = "Classical";
    public static final String EQ_CLUB = "Club";
    public static final String EQ_PARTY = "Party";
    public static final String EQ_ROCK = "Rock";
    public static final String EQ_SOFT = "Soft";


    public CmdSetEq() {
        mType = CMD_TYPE_SETEQ;
        mCmdName = getCmdName();
    }

    @Override
    public String toJsonString() {
        JSONObject argObject = new JSONObject();
        argObject.put("eq",mEq);

        JSONObject jsonObject = new JSONObject();
        jsonObject.put("cmd",mCmdName);
        jsonObject.put("arg",argObject);

        return jsonObject.toJSONString();
    }

    @Override
    public String getActionValue() {
        String value = getEqName(mEq);
        return value;
    }

    @Override
    public void parseArgs() {
        if ((mCmdArgs == null) || (mCmdArgs.isEmpty())){
            return;
        }

        try {
            mEq = JSON.parseObject(mCmdArgs).getString("eq");
        }catch (Exception e){
            mEq = "";
        }
    }

    public void setEq(String eq){
        mEq = eq;
    }

    public static String getEqName(String eq){
        String value = "无";
        switch(eq){
            case EQ_FLAT:
                value = "单调";
                break;
            case EQ_CLASSICAL:
                value = "经典";
                break;
            case EQ_CLUB:
                value = "俱乐部";
                break;
            case EQ_PARTY:
                value = "聚会";
                break;
            case EQ_ROCK:
                value = "摇滚";
                break;
            case EQ_SOFT:
                value = "柔和";
                break;
            default:
                break;
        }
        return value;
    }
}
