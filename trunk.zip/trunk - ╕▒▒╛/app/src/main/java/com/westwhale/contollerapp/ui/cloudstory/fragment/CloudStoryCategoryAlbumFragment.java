package com.westwhale.contollerapp.ui.cloudstory.fragment;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.View;
import android.widget.Toast;

import com.kingja.loadsir.callback.SuccessCallback;
import com.westwhale.contollerapp.application.WApp;
import com.westwhale.contollerapp.dev.CmdActionLister;
import com.westwhale.contollerapp.dev.ICmdCallback;
import com.westwhale.contollerapp.dev.WRoom;
import com.westwhale.contollerapp.ui.cloudstory.dialog.StoryAlbumCategoryDialog;
import com.westwhale.contollerapp.ui.loadsircallback.LoadingCallback;
import com.westwhale.api.protocolapi.bean.albumSet.StoryTelling;
import com.westwhale.api.protocolapi.bean.telling.CatrgroyGroup;

import java.util.List;


/**
 * Description:
 * Author: chenyaoli
 * Date: 2019-04-06
 * History:
 */
public class CloudStoryCategoryAlbumFragment extends CloudStoryAlbumBaseFragment {
    private static final String TAG = "StoryCategoryAlbum";
    public static final int REQUEST_CODDE = 0;

    private int mCurPageNo = 1; //记录当前的页面数
    private int mPerPage = 50;
    private boolean mHasMoreData = true; // 记录是否还有更多数据

    private CatrgroyGroup mCategoryGroup;
    private CatrgroyGroup.TellingCatrgroy mSelectedTelling = new CatrgroyGroup.TellingCatrgroy();

    public void updateCategoryGroup(CatrgroyGroup group){
        mCategoryGroup = group;

        if (group != null) {
            if ((group.subCategoryList != null) && (group.subCategoryList.size() > 0)) {
                mSelectedTelling.id = group.subCategoryList.get(0).id;
                mSelectedTelling.parentId = group.subCategoryList.get(0).parentId;
                mSelectedTelling.categoryName = group.subCategoryList.get(0).categoryName;
            }
        }
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        String title = (mCategoryGroup != null) ? mCategoryGroup.categoryName : "";
        configToolBar(mToolBar,title);

        mCategoryIv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 弹出类型选择界面
                StoryAlbumCategoryDialog categoryDialog = new StoryAlbumCategoryDialog();
                // 设置目标Fragment
                categoryDialog.updateCategoryGroup(mSelectedTelling,mCategoryGroup);
                categoryDialog.setTargetFragment(CloudStoryCategoryAlbumFragment.this, REQUEST_CODDE);
                if (getFragmentManager() != null) {
                    categoryDialog.show(getFragmentManager(), "StoryCategory_Dialog");
                }
            }
        });
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        // 接收分类弹出框的返回结果
        if (REQUEST_CODDE == requestCode){
            String categoryId = data.getStringExtra(StoryAlbumCategoryDialog.CATEGORY_ID);
            String categoryName = data.getStringExtra(StoryAlbumCategoryDialog.CATEGORY_NAME);
            String parentId = data.getStringExtra(StoryAlbumCategoryDialog.CATEGORY_PARENTID);
            mSelectedTelling.id = Integer.parseInt(categoryId);
            mSelectedTelling.categoryName = categoryName;
            mSelectedTelling.parentId = Integer.parseInt(parentId);

            showLoadCallBack(LoadingCallback.class);

            initData();
        }
    }

    @Override
    protected void initData() {
        mCurPageNo = 1;
        mHasMoreData = true;

        String type = (mSelectedTelling != null) ? mSelectedTelling.categoryName : "";
        mAlbumTypeTv.setText(type);

        // 每次先清空原有数据
        if (mAdapter != null){
            mAdapter.clearDataList();
        }

        requestCloudResource();
    }

    @Override
    protected boolean hasMoreData() {
        return mHasMoreData;
    }

    @Override
    protected void loadMoreData() {
        mCurPageNo++;
        requestCloudResource();
    }

    @Override
    protected void updateDataList(List<StoryTelling> dataList){
        if (dataList != null){
            // 若无法获取到数据，则认为已经到底
            int size = dataList.size();

            if (mCurPageNo == 0) {
                mAdapter.clearDataList();
            }

            if (size != 0){
                int startIndex = mAdapter.getItemCount();
                mAdapter.addToDataList(dataList);
                mAdapter.notifyItemRangeInserted(startIndex,size);
            }else{
                mHasMoreData = false;
            }

            // 更新刷新等待状态
            mRefreshLayout.finishRefresh();
            mRefreshLayout.finishLoadMore();

            showLoadCallBack(SuccessCallback.class);
        }else{
            // 当获取数据失败时，则认为无数据了
            mHasMoreData = false;

            // 更新刷新等待状态
            mRefreshLayout.finishRefresh();
            mRefreshLayout.finishLoadMore();

            showLoadCallBack(SuccessCallback.class);
        }
    }

    @Override
    protected void requestCloudResource(){
        WRoom room = WApp.Instance.getDevManager().getSelectedRoom();
        if (room != null){
            String categoryId = (mSelectedTelling != null) ? String.valueOf(mSelectedTelling.id) : "";
            WRoom.cmdGetStorytelling(categoryId,mPerPage,mCurPageNo, new CmdActionLister<List<StoryTelling>>(this, new ICmdCallback<List<StoryTelling>>() {
                @Override
                public void onSuccess(List<StoryTelling> data) {
                    updateDataList(data);
                }

                @Override
                public void onFailed(int code, String msg) {
                    updateDataList(null);
                    Toast.makeText(getContext(),"获取失败:"+code,Toast.LENGTH_SHORT).show();
                }
            }));
        }else{
            updateDataList(null);
        }
    }


}
