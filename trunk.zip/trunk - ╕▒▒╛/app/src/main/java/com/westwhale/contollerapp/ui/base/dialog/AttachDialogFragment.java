package com.westwhale.contollerapp.ui.base.dialog;

import android.content.Context;
import android.support.v4.app.DialogFragment;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by wm on 2016/3/17.
 */
public class AttachDialogFragment extends DialogFragment {

//    public Activity mContext;

    public Context mContext;

    private List<IDestroyListener> mList = new ArrayList<>();

    // 用于监听当前Fragment销毁事情
    public interface IDestroyListener{
        public void onDialogPrepareDestroy();
    }

    public void registerDestroyedListener(IDestroyListener listener){
        mList.add(listener);
    }
    public void unRegisterDestroyedListener(IDestroyListener listener){
        if (mList.contains(listener)){
            mList.remove(listener);
        }
    }

//    @Override
//    public void onAttach(Activity activity){
//        super.onAttach(activity);
//        this.mContext = activity;
//    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        this.mContext = context;
    }

    @Override
    public void onDetach() {
        for (int i=0; i < mList.size(); i++){
            IDestroyListener listener = mList.get(i);
            if (listener != null){
                listener.onDialogPrepareDestroy();
            }
        }

        mList.clear();

        super.onDetach();
    }
}
