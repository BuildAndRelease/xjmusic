package com.westwhale.contollerapp.ui.favorite.songsheet.adapter;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.westwhale.contollerapp.R;
import com.westwhale.api.protocolapi.bean.PlayList;

import java.util.List;

/**
 * Description:
 * Author: chenyaoli
 * Date: 2018-12-12
 * History:
 */
public class FavoriteMediaManagerAdapter extends RecyclerView.Adapter {
    private List<PlayList> mItemList;
    private CallBack mCallBack;

    public interface CallBack{
        void onItemDeleteClick(PlayList item);
    }

    public void setDataList(List<PlayList> itemList){
        if (mItemList != null){
            mItemList.clear();
            notifyDataSetChanged();
        }
        this.mItemList = itemList;
    }

    public FavoriteMediaManagerAdapter(CallBack callBack){
        this.mItemList = null;
        this.mCallBack = callBack;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_favorite_media_manager, viewGroup, false);
        return new ItemHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder viewHolder, int i) {
        ItemHolder itemHolder = (ItemHolder)viewHolder;
        PlayList item = mItemList.get(i);
        if (item != null){
            itemHolder.mNameTv.setText(item.playListName);
        }

        itemHolder.mDeleteIv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mCallBack != null){
                    mCallBack.onItemDeleteClick(item);
                }
            }
        });
    }

    @Override
    public int getItemCount() {
        return (null == mItemList) ? 0 : mItemList.size();
    }

    /**************************************   ItemHolder *******************************************/
    public class ItemHolder extends RecyclerView.ViewHolder{
        TextView mNameTv;
        ImageView mDeleteIv;
        public ItemHolder(@NonNull View itemView) {
            super(itemView);
            mDeleteIv = itemView.findViewById(R.id.item_favorite_media_manager_delete);
            mNameTv = itemView.findViewById(R.id.item_favorite_media_manager_name);
        }
    }
}
