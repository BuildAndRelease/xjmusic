package com.westwhale.contollerapp.eventbus.notify;

public class NotifyDevInfoEvent {
    private String mMuteStat;

    public NotifyDevInfoEvent(String mutestat){
        mMuteStat = mutestat;
    }
    public String getMuteStat() {
        return mMuteStat;
    }
}
