package com.westwhale.contollerapp.ui.timer.dialog;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.DialogFragment;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.TextView;

import com.blankj.utilcode.util.ToastUtils;
import com.westwhale.api.protocolapi.bean.DelayClose;
import com.westwhale.contollerapp.R;
import com.westwhale.contollerapp.application.WApp;
import com.westwhale.contollerapp.common.ImageTextItem;
import com.westwhale.contollerapp.dev.CmdActionLister;
import com.westwhale.contollerapp.dev.ICmdCallback;
import com.westwhale.contollerapp.dev.WRoom;
import com.westwhale.contollerapp.ui.base.dialog.AttachDialogFragment;
import com.westwhale.contollerapp.ui.timer.activity.TimerActivity;
import com.westwhale.contollerapp.ui.timer.adapter.DelayTimerAdapter;
import com.westwhale.contollerapp.ui.widget.dialog.TextEditDialog;
import com.westwhale.contollerapp.ui.widget.interfs.DialogResultListener;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Description:
 * Author: chenyaoli
 * Date: 2018-11-23
 * History:
 */
public class DelayTimerDialog extends AttachDialogFragment implements DelayTimerAdapter.CallBack {
    public static final String TAG = DelayTimerDialog.class.getName();

    private ImageView mSettingIv,mCancelIv;
    private TextView mTitleTv;

    private RecyclerView mDataItemRv;
    private DelayTimerAdapter mAdapter;

    private final String DELAYTIMER_ENABLE = "enable";
    private final String DELAYTIMER_DISABLE = "disable";

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // 背景色，动画效果，通过主题设置
        setStyle(DialogFragment.STYLE_NORMAL,R.style.CommonDialogStyle);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        //布局
        View view = inflater.inflate(R.layout.dialog_delaytimer, container);
        return view;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        initView(view);
        initListener();

        initData();
    }

    @Override
    public void onStart() {
        super.onStart();

        //设置fragment高度 、宽度
        double heightPercent = 0.5;
        int dialogHeight = (int) (mContext.getResources().getDisplayMetrics().heightPixels * heightPercent);
        Window window = getDialog().getWindow();
        if (window != null) {
            WindowManager.LayoutParams params = window.getAttributes();
            params.gravity = Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL;
            params.width = WindowManager.LayoutParams.MATCH_PARENT;
            params.height = dialogHeight; // 底部弹出的DialogFragment的高度，如果是MATCH_PARENT则铺满整个窗口
            window.setAttributes(params);
            getDialog().setCanceledOnTouchOutside(true);
        }
    }

    @Override
    public void onItemClick(DelayTimerType item, int pos) {
        if ((item != null) && (pos > -1)){
            if (item.getType() != DelayTimerType.DELAY_TIMER_TYPE_UNDEFINE) {
                String timerEnable = (item.getType() == DelayTimerType.DELAY_TIMER_TYPE_0) ? DELAYTIMER_DISABLE : DELAYTIMER_ENABLE;
                int delayCloseAfterTimes = item.getDelayCloseAfterTimes();

                setSelectedItem(item);

                modifyDelayTimer(timerEnable, delayCloseAfterTimes);
            }else{
                TextEditDialog dialog = new TextEditDialog();
                Bundle bundle = new Bundle();
                bundle.putString(TextEditDialog.DIALOG_TITLE,"自定义时间");
                bundle.putString(TextEditDialog.TEXT_HINT,"请输入时间(分钟)");
                dialog.setArguments(bundle);

                dialog.setOnDialogResultListener(new DialogResultListener<String>() {
                    @Override
                    public void onResultListener(String value) {
                        try {
                            int time = Integer.parseInt(value);
                            item.setDelayCloseAfterTimes(time);

                            String timerEnable = (item.getType() == DelayTimerType.DELAY_TIMER_TYPE_0) ? DELAYTIMER_DISABLE : DELAYTIMER_ENABLE;
                            int delayCloseAfterTimes = item.getDelayCloseAfterTimes();

                            setSelectedItem(item);

                            modifyDelayTimer(timerEnable, delayCloseAfterTimes);
                        }catch (Exception e){
                            e.printStackTrace();
                        }
                    }
                });
                dialog.show(getChildFragmentManager(),"DelayTimer");
            }
        }
    }


    private void initView(View view) {
        mTitleTv = view.findViewById(R.id.dialog_title);
        mSettingIv = view.findViewById(R.id.dialog_setting);
        mCancelIv = view.findViewById(R.id.dialog_cancel);

        mDataItemRv = view.findViewById(R.id.dialog_recylerview);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(mContext);
        mDataItemRv.setLayoutManager(linearLayoutManager);
        mAdapter = new DelayTimerAdapter();
        mAdapter.setCallBack(this);
        mDataItemRv.setAdapter(mAdapter);
        mDataItemRv.setHasFixedSize(true);
        mDataItemRv.addItemDecoration(new DividerItemDecoration(mContext, DividerItemDecoration.VERTICAL));
        // 设置下拉上拉无阴影效果
        mDataItemRv.setOverScrollMode(View.OVER_SCROLL_NEVER);
    }

    private void initListener() {
        mSettingIv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //
                startActivity(new Intent(mContext, TimerActivity.class));
                dismiss();
            }
        });

        mCancelIv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dismiss();
            }
        });
    }

    List<DelayTimerType> mDataList = new ArrayList<>();
    private void initData() {
        mTitleTv.setText("延时关机");

        mDataList.clear();
        mDataList.add(new DelayTimerType(DelayTimerType.DELAY_TIMER_TYPE_0));
        mDataList.add(new DelayTimerType(DelayTimerType.DELAY_TIMER_TYPE_10));
        mDataList.add(new DelayTimerType(DelayTimerType.DELAY_TIMER_TYPE_20));
        mDataList.add(new DelayTimerType(DelayTimerType.DELAY_TIMER_TYPE_30));
        mDataList.add(new DelayTimerType(DelayTimerType.DELAY_TIMER_TYPE_60));
        mDataList.add(new DelayTimerType(DelayTimerType.DELAY_TIMER_TYPE_90));
        mDataList.add(new DelayTimerType(DelayTimerType.DELAY_TIMER_TYPE_UNDEFINE));

        mAdapter.setDataList(mDataList);
        mAdapter.notifyDataSetChanged();

        requestData();


//        List<DelayClose> dataList = new ArrayList<>();
//        DelayClose data = new DelayClose();
//        data.timerEnable = DELAYTIMER_DISABLE;
//        data.delayCloseAfterTimes = TIMER_TYPE_0;
//        data.remainTime = 0;
//        dataList.add(data);
//
//        data = new DelayClose();
//        data.timerEnable = DELAYTIMER_ENABLE;
//        data.delayCloseAfterTimes = TIMER_TYPE_10;
//        data.remainTime = 0;
//        dataList.add(data);
//
//        data = new DelayClose();
//        data.timerEnable = DELAYTIMER_ENABLE;
//        data.delayCloseAfterTimes = TIMER_TYPE_20;
//        data.remainTime = 0;
//        dataList.add(data);
//
//        data = new DelayClose();
//        data.timerEnable = DELAYTIMER_ENABLE;
//        data.delayCloseAfterTimes = TIMER_TYPE_30;
//        data.remainTime = 0;
//        dataList.add(data);
//
//        data = new DelayClose();
//        data.timerEnable = DELAYTIMER_ENABLE;
//        data.delayCloseAfterTimes = TIMER_TYPE_60;
//        data.remainTime = 0;
//        dataList.add(data);
//
//        data = new DelayClose();
//        data.timerEnable = DELAYTIMER_ENABLE;
//        data.delayCloseAfterTimes = TIMER_TYPE_90;
//        data.remainTime = 0;
//        dataList.add(data);
    }


    private void updateData(DelayClose delayClose) {
        DelayTimerType delayTimerType = new DelayTimerType(DelayTimerType.DELAY_TIMER_TYPE_0);
        if ((delayClose != null) && ((delayClose.remainTime != 0))) {
            delayTimerType = new DelayTimerType(delayClose.delayCloseAfterTimes,delayClose.remainTime);
        }

        setSelectedItem(delayTimerType);
    }

    private void setSelectedItem(DelayTimerType delayTimerType) {
        if ((delayTimerType != null) && (mDataList != null)){
            for(DelayTimerType item : mDataList){
                if ((item != null) && (item.getType() == delayTimerType.getType())){
                    item.setDelayCloseAfterTimes(delayTimerType.getDelayCloseAfterTimes());
                    item.setRemainTime(delayTimerType.getRemainTime());

                    mAdapter.setSelectedItem(item);
                    break;
                }
            }
        }
    }

    private void requestData(){
        WRoom room = WApp.Instance.getDevManager().getSelectedRoom();
        if (room != null){
            WRoom.cmdGetDelayCloseTimer(new CmdActionLister<DelayClose>(DelayTimerDialog.this, new ICmdCallback<DelayClose>() {
                @Override
                public void onSuccess(DelayClose data) {
                    updateData(data);
                }

                @Override
                public void onFailed(int code, String msg) {
                    updateData(null);
                }
            }));
        }
    }

    private void modifyDelayTimer(String timerEnable,int delayTime){
        WRoom room = WApp.Instance.getDevManager().getSelectedRoom();
        if (room != null){
            WRoom.cmdModifyDelayCloseTimer(timerEnable,delayTime,new CmdActionLister<Boolean>(DelayTimerDialog.this, new ICmdCallback<Boolean>() {
                @Override
                public void onSuccess(Boolean data) {
                    dismiss();
                }

                @Override
                public void onFailed(int code, String msg) {
                    ToastUtils.showShort("修改延时关机失败：%d",code);
                    dismiss();
                }
            }));
        }
    }


    public class DelayTimerType{
        public static final int DELAY_TIMER_TYPE_0 = 0;
        public static final int DELAY_TIMER_TYPE_10 = 10;
        public static final int DELAY_TIMER_TYPE_20 = 20;
        public static final int DELAY_TIMER_TYPE_30 = 30;
        public static final int DELAY_TIMER_TYPE_60 = 60;
        public static final int DELAY_TIMER_TYPE_90 = 90;
        public static final int DELAY_TIMER_TYPE_UNDEFINE = 10000;

        private int mType;
        private int mDelayCloseAfterTimes;
        private int mRemainTime;

        public DelayTimerType(int type){
            mType = DELAY_TIMER_TYPE_UNDEFINE;
            mRemainTime = 0;
            mDelayCloseAfterTimes = 0;
            switch (type){
                case DELAY_TIMER_TYPE_0:
                    mType = DELAY_TIMER_TYPE_0;
                    mDelayCloseAfterTimes = 0;
                    break;
                case DELAY_TIMER_TYPE_10:
                    mType = DELAY_TIMER_TYPE_10;
                    mDelayCloseAfterTimes = 10;
                    break;
                case DELAY_TIMER_TYPE_20:
                    mType = DELAY_TIMER_TYPE_20;
                    mDelayCloseAfterTimes = 20;
                    break;
                case DELAY_TIMER_TYPE_30:
                    mType = DELAY_TIMER_TYPE_30;
                    mDelayCloseAfterTimes = 30;
                    break;
                case DELAY_TIMER_TYPE_60:
                    mType = DELAY_TIMER_TYPE_60;
                    mDelayCloseAfterTimes = 60;
                    break;
                case DELAY_TIMER_TYPE_90:
                    mType = DELAY_TIMER_TYPE_90;
                    mDelayCloseAfterTimes = 90;
                    break;
                default:
                    break;
            }
        }

        public DelayTimerType(int delayTime,int remainTime){
            mType = DELAY_TIMER_TYPE_UNDEFINE;
            mRemainTime = remainTime;
            mDelayCloseAfterTimes = delayTime;
            switch (delayTime){
                case DELAY_TIMER_TYPE_0:
                    mType = DELAY_TIMER_TYPE_0;
                    mDelayCloseAfterTimes = 0;
                    mRemainTime = 0;
                    break;
                case DELAY_TIMER_TYPE_10:
                    mType = DELAY_TIMER_TYPE_10;
                    break;
                case DELAY_TIMER_TYPE_20:
                    mType = DELAY_TIMER_TYPE_20;
                    break;
                case DELAY_TIMER_TYPE_30:
                    mType = DELAY_TIMER_TYPE_30;
                    break;
                case DELAY_TIMER_TYPE_60:
                    mType = DELAY_TIMER_TYPE_60;
                    break;
                case DELAY_TIMER_TYPE_90:
                    mType = DELAY_TIMER_TYPE_90;
                    break;
                default:
                    break;
            }
        }

        public int getType(){
            return mType;
        }



        public String getName(){
            String name = "";
            switch (mType){
                case DELAY_TIMER_TYPE_0:
                    name = "无";
                    break;
                case DELAY_TIMER_TYPE_10:
                    name = "10分钟";
                    break;
                case DELAY_TIMER_TYPE_20:
                    name = "20分钟";
                    break;
                case DELAY_TIMER_TYPE_30:
                    name = "30分钟";
                    break;
                case DELAY_TIMER_TYPE_60:
                    name = "60分钟";
                    break;
                case DELAY_TIMER_TYPE_90:
                    name = "90分钟";
                    break;
                case DELAY_TIMER_TYPE_UNDEFINE:
                    name = "自定义";
                    if (mDelayCloseAfterTimes != 0){
                        name = name + "(" + mDelayCloseAfterTimes + ")";
                    }
                    break;
                default:
                    break;
            }
            return name;
        }

        public String getRemainTimeInfo(){
            String info = "";
            switch (mType){
                case DELAY_TIMER_TYPE_0:
                    info = "";
                    break;
                case DELAY_TIMER_TYPE_10:
                case DELAY_TIMER_TYPE_20:
                case DELAY_TIMER_TYPE_30:
                case DELAY_TIMER_TYPE_60:
                case DELAY_TIMER_TYPE_90:
                case DELAY_TIMER_TYPE_UNDEFINE:
                    info = String.format(Locale.getDefault(),"(剩:%d分钟)",mRemainTime);
                    break;
                default:
                    break;
            }
            return info;
        }

        public void setRemainTime(int remainTime){
            mRemainTime = remainTime;
        }

        public int getRemainTime(){
            return mRemainTime;
        }

        public int getDelayCloseAfterTimes(){
            return mDelayCloseAfterTimes;
        }
        public void setDelayCloseAfterTimes(int times){
            mDelayCloseAfterTimes = times;
        }

    }
}
