package com.westwhale.contollerapp.ui.cloudstory.adapter;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.util.Base64;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.load.resource.bitmap.RoundedCorners;
import com.bumptech.glide.request.RequestOptions;
import com.westwhale.contollerapp.R;
import com.westwhale.api.protocolapi.bean.telling.RankItem;

import java.util.List;

/**
 * Description:
 * Author: chenyaoli
 * Date: 2018-12-06
 * History:
 */
public class StoryRankAdatper extends RecyclerView.Adapter{

    private List<RankItem> mItemList;
    private CallBack mCallBack;

    public StoryRankAdatper(CallBack callBack){
        this.mCallBack = callBack;
    }

    public interface CallBack{
        void onRankItemClick(RankItem rankItem);
    }

    public void updateDataList(List<RankItem> dataList){
        if (mItemList != null){
            mItemList.clear();
            notifyDataSetChanged();
        }
        mItemList = dataList;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_cloudstory_rank, viewGroup, false);
        return new StoryRankItemHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder viewHolder, int i) {
        final RankItem item = mItemList.get(i);
        StoryRankItemHolder itemHolder = (StoryRankItemHolder)viewHolder;
        itemHolder.mTitleTv.setText(item.title);
        if (item.firstKResults != null){
            if (item.firstKResults.size() >= 1){
                String title = "1." + item.firstKResults.get(0).title;
                itemHolder.mFirstItemTv.setText(title);
            }
            if (item.firstKResults.size() >= 2){
                String title = "2." + item.firstKResults.get(1).title;
                itemHolder.mSecondItemTv.setText(title);
            }
            if (item.firstKResults.size() >= 3){
                String title = "3." + item.firstKResults.get(2).title;
                itemHolder.mThirdItemTv.setText(title);
            }
        }

        // 首先 base64 解码
        String pic = (item.pic != null) ? item.pic : "";
        String url = pic;
        try{
            if (!pic.startsWith("http://")){
                url = new String(Base64.decode(pic.getBytes(), Base64.DEFAULT));
            }
        }catch (Exception e){
            url = "";
            e.printStackTrace();
        }
        //设置图片圆角角度
        RoundedCorners roundedCorners= new RoundedCorners(6);
        //通过RequestOptions扩展功能,override:采样率,因为ImageView就这么大,可以压缩图片,降低内存消耗
        RequestOptions mRequestOptions = RequestOptions.bitmapTransform(roundedCorners).diskCacheStrategy(DiskCacheStrategy.NONE) //不做磁盘缓存
                .placeholder(R.drawable.cloud_album_default)  //未加载图片之前显示的图片
                .error(R.drawable.cloud_album_default)     //错误时显示的图片
                .override(350, 350);
//                      .skipMemoryCache(true);//不做内存缓存
        Glide.with(itemHolder.itemView)
                .load(url)
                .apply(mRequestOptions)
                .into(itemHolder.mRankItemPicIv);

        viewHolder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mCallBack.onRankItemClick(item);
            }
        });
    }

    @Override
    public int getItemCount() {
        return (mItemList == null) ? 0 : mItemList.size();
    }


    private class StoryRankItemHolder extends RecyclerView.ViewHolder{
        ImageView mRankItemPicIv;
        TextView mTitleTv, mFirstItemTv,mSecondItemTv,mThirdItemTv;
        public StoryRankItemHolder(@NonNull View itemView) {
            super(itemView);
            mRankItemPicIv = itemView.findViewById(R.id.item_story_rank_pic);
            mTitleTv = itemView.findViewById(R.id.item_story_rank_title);
            mFirstItemTv = itemView.findViewById(R.id.item_story_rank_one);
            mSecondItemTv = itemView.findViewById(R.id.item_story_rank_two);
            mThirdItemTv = itemView.findViewById(R.id.item_story_rank_three);
        }
    }
}