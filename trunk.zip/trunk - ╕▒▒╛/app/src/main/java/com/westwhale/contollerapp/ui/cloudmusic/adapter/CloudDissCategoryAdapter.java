package com.westwhale.contollerapp.ui.cloudmusic.adapter;

import android.support.annotation.NonNull;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.westwhale.contollerapp.R;
import com.westwhale.api.protocolapi.bean.cloudmusic.DissCategory;
import com.westwhale.api.protocolapi.bean.cloudmusic.DissCategoryGroup;

import java.util.ArrayList;
import java.util.List;

public class CloudDissCategoryAdapter extends RecyclerView.Adapter {
    private ArrayList<DissCategoryGroup> mItemList;
    private CallBack mCallBack;

    public interface CallBack{
        void onDissItemClick(DissCategory dissItem);
    }

    public void updateDataList(ArrayList<DissCategoryGroup> itemList){
        if (mItemList != null){
            mItemList.clear();
            notifyDataSetChanged();
        }
        this.mItemList = itemList;
    }

    public CloudDissCategoryAdapter(CallBack callBack){
        this.mItemList = null;
        this.mCallBack = callBack;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        // 默认返回 HOST 类型的 viewHolder
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_netmusic_diss_category, viewGroup, false);
        return new CloudDissCategoryItemHolder(view);
    }

    @Override
    public int getItemCount() {
        return (null == mItemList) ? 0 : mItemList.size();
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder viewHolder, int i) {
        if (viewHolder instanceof CloudDissCategoryItemHolder) {
            final DissCategoryGroup dissCategoryGroup = mItemList.get(i);
            CloudDissCategoryItemHolder itemHolder = (CloudDissCategoryItemHolder) viewHolder;

            itemHolder.mTitleTv.setText(dissCategoryGroup.categoryGroupName);

            // 配置内部的Recyclerview
            RecyclerView recyclerView = itemHolder.mRecyclerView;
            GridLayoutManager gridLayoutManager = new GridLayoutManager(viewHolder.itemView.getContext(),4);
            recyclerView.setLayoutManager(gridLayoutManager);
            GridRecyclerAdapter gridRecyclerAdapter = new GridRecyclerAdapter();
            gridRecyclerAdapter.setCallBack(mCallBack);
            recyclerView.setAdapter(gridRecyclerAdapter);
            recyclerView.setHasFixedSize(true);
            recyclerView.setNestedScrollingEnabled(false);

            gridRecyclerAdapter.updateDataList(dissCategoryGroup.items);
            gridRecyclerAdapter.notifyDataSetChanged();
        }
    }

    //  ItemHolder
    private class CloudDissCategoryItemHolder extends RecyclerView.ViewHolder{
        RecyclerView mRecyclerView;
        TextView mTitleTv;
        CloudDissCategoryItemHolder(@NonNull View itemView) {
            super(itemView);
            mRecyclerView = itemView.findViewById(R.id.netmusic_diss_category_recyclerview);
            mTitleTv = itemView.findViewById(R.id.netmusic_diss_category_item_title);
        }
    }



    /**************************************   inner adapter *******************************************/
    private class GridRecyclerAdapter extends RecyclerView.Adapter {
        private List<DissCategory> mItemList;
        private CallBack mCallBack;

        public void setCallBack(CallBack callBack){
            mCallBack = callBack;
        }

        public void updateDataList(List<DissCategory> itemList){
            if (mItemList != null){
                mItemList.clear();
                notifyDataSetChanged();
            }
            this.mItemList = itemList;
        }

        @NonNull
        @Override
        public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
            // 默认返回 HOST 类型的 viewHolder
            View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_netmusic_category_item, viewGroup, false);
            return new DissGridItemHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull RecyclerView.ViewHolder viewHolder, int i) {
            if (viewHolder instanceof DissGridItemHolder){
                final DissCategory dissCategory = mItemList.get(i);
                DissGridItemHolder itemHolder = (DissGridItemHolder)viewHolder;

                itemHolder.mContentTv.setText(dissCategory.categoryName);

                itemHolder.mContentTv.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (mCallBack != null){
                            mCallBack.onDissItemClick(dissCategory);
                        }
                    }
                });
            }
        }

        @Override
        public int getItemCount() {
            return (null == mItemList) ? 0 : mItemList.size();
        }


        // ItemHolder
        private class DissGridItemHolder extends RecyclerView.ViewHolder{
            TextView mContentTv;
            DissGridItemHolder(@NonNull View itemView) {
                super(itemView);
                mContentTv = itemView.findViewById(R.id.item_cloud_category_text);
            }
        }

    }
}
