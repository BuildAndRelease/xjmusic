package com.westwhale.contollerapp.ui.loadsircallback;

import com.kingja.loadsir.callback.Callback;
import com.westwhale.contollerapp.R;


public class EmptyCallback extends Callback {

    @Override
    protected int onCreateView() {
        return R.layout.frag_load_empty;
    }

}
