package com.westwhale.contollerapp.ui.talk.adapter;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.util.SparseBooleanArray;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.westwhale.api.protocolapi.bean.hostroom.Room;
import com.westwhale.contollerapp.R;

import java.util.ArrayList;
import java.util.List;

/**
 * Description:
 * Author: chenyaoli
 * Date: 2018-12-20
 * History
 *
 */
public class TalkNewRoomAdapter extends RecyclerView.Adapter {
    private List<Room> mItemList;
    private CallBack mCallBack;

    private SparseBooleanArray mCheckStatList = new SparseBooleanArray();  // 与 mItemList 一一对应，记录每个Item的被选择状态

    public interface CallBack{
        void onItemClick(Room room,boolean checkStat);
    }

    public void setCallBack(CallBack callBack){
        this.mCallBack = callBack;
    }

    public void setDataList(List<Room> itemList){
        this.mItemList = itemList;

        mCheckStatList.clear();
        if (mItemList != null){
            for(int i=0; i < mItemList.size(); i++){
                mCheckStatList.put(i,false);
            }
        }
    }

    public void clearAllData(){
        mCheckStatList.clear();
        if (mItemList != null){
            mItemList.clear();
            mItemList = null;
            notifyDataSetChanged();
        }
    }

    public List<Room> getSelectedList(){
        List<Room> dataList = new ArrayList<>();
        for (int i=0; i < mCheckStatList.size(); i++){
            boolean isChecked = mCheckStatList.valueAt(i);
            if (isChecked){
                dataList.add(mItemList.get(i));
            }
        }

        return dataList;
    }

    public void updateItem(Room room){
        if (mItemList != null){
            int index = mItemList.indexOf(room);
            if (index > -1){
                notifyItemChanged(index);
            }
        }
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_talk_new_room, viewGroup, false);
        return new ItemHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder viewHolder, int i) {
        if (viewHolder instanceof ItemHolder){
            int pos = viewHolder.getAdapterPosition();
            final Room item = mItemList.get(pos);
            ItemHolder itemHolder = (ItemHolder)viewHolder;

            itemHolder.mNameView.setText(item.roomName);
            itemHolder.mCheckBox.setChecked(mCheckStatList.get(pos));

            itemHolder.itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    boolean newCheckStat = !itemHolder.mCheckBox.isChecked();
                    mCheckStatList.put(pos,newCheckStat);
                    itemHolder.mCheckBox.setChecked(newCheckStat);
                }
            });
        }
    }

    @Override
    public int getItemCount() {
        return (mItemList == null) ? 0 : mItemList.size();
    }

    private class ItemHolder extends RecyclerView.ViewHolder{
        private CheckBox mCheckBox;
        private TextView mNameView;
        public ItemHolder(@NonNull View itemView) {
            super(itemView);
            mCheckBox = itemView.findViewById(R.id.item_talk_new_room_checkbox);
            mNameView = itemView.findViewById(R.id.item_talk_new_room_name);
        }
    }
}
