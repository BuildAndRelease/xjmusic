package com.westwhale.contollerapp.dev.resourcecenter;

import android.os.Handler;

import com.blankj.utilcode.util.ThreadUtils;
import com.westwhale.contollerapp.application.WApp;
import com.westwhale.contollerapp.dev.CmdActionLister;
import com.westwhale.api.protocolapi.BaApi;
import com.westwhale.api.protocolapi.bean.media.CloudNetFm;
import com.westwhale.api.protocolapi.bean.cloudnetfm.GetNetFmCategoryResult;
import com.westwhale.api.protocolapi.bean.cloudnetfm.Province;
import com.westwhale.api.protocolapi.net.Response;

import java.util.List;

public class CloudNetFmResource {
    // 获取所有电台总目录ID,本地台，热门台
    public static void cmdGetNetFmCategory(CmdActionLister<GetNetFmCategoryResult> actionLister){
        ThreadUtils.getIoPool().execute(new Runnable() {
            @Override
            public void run() {
                Response<GetNetFmCategoryResult> response = null;
                try {
                    response = BaApi.getInstance().getNetFmCategory();
                } catch (Exception e) {
                    e.printStackTrace();
                }finally {
                    postCmdResponse(response,actionLister);
                }
            }
        });
    }

    // 获取电台总目下子电台分类
    public static void cmdGetNetFmByCategory(int categoryId, int pageNum, int pageSize,CmdActionLister<List<CloudNetFm>> actionLister){
        ThreadUtils.getIoPool().execute(new Runnable() {
            @Override
            public void run() {
                Response<List<CloudNetFm>> response = null;
                try {
                    response = BaApi.getInstance().getNetFmByCategory(categoryId, pageNum, pageSize);
                } catch (Exception e) {
                    e.printStackTrace();
                }finally {
                    postCmdResponse(response,actionLister);
                }
            }
        });
    }

    // 排行榜
    public static void cmdGetNetFmTopList(int pageNum, int pageSize,CmdActionLister<List<CloudNetFm>> actionLister){
        ThreadUtils.getIoPool().execute(new Runnable() {
            @Override
            public void run() {
                Response<List<CloudNetFm>> response = null;
                try {
                    response = BaApi.getInstance().getNetFmTopList(pageNum, pageSize);
                } catch (Exception e) {
                    e.printStackTrace();
                }finally {
                    postCmdResponse(response,actionLister);
                }
            }
        });
    }

    // 国家台
    public static void cmdGetNetFmNational(int pageNum, int pageSize,CmdActionLister<List<CloudNetFm>> actionLister){
        ThreadUtils.getIoPool().execute(new Runnable() {
            @Override
            public void run() {
                Response<List<CloudNetFm>> response = null;
                try {
                    response = BaApi.getInstance().getNetFmNational(pageNum, pageSize);
                } catch (Exception e) {
                    e.printStackTrace();
                }finally {
                    postCmdResponse(response,actionLister);
                }
            }
        });
    }

    // 网络台
    public static void cmdGetNetFmNetwork(int pageNum, int pageSize,CmdActionLister<List<CloudNetFm>> actionLister){
        ThreadUtils.getIoPool().execute(new Runnable() {
            @Override
            public void run() {
                Response<List<CloudNetFm>> response = null;
                try {
                    response = BaApi.getInstance().getNetFmNetwork(pageNum, pageSize);
                } catch (Exception e) {
                    e.printStackTrace();
                }finally {
                    postCmdResponse(response,actionLister);
                }
            }
        });
    }

    // 所有省市列表
    public static void cmdGetNetFmProvinceCodeCategory(CmdActionLister<List<Province>> actionLister){
        ThreadUtils.getIoPool().execute(new Runnable() {
            @Override
            public void run() {
                Response<List<Province>> response = null;
                try {
                    response = BaApi.getInstance().getProvinceCodeCategory();
                } catch (Exception e) {
                    e.printStackTrace();
                }finally {
                    postCmdResponse(response,actionLister);
                }
            }
        });
    }

    // 省市台
    public static void cmdGetNetFmByCode(int provinceCode, int pageNum, int pageSize,CmdActionLister<List<CloudNetFm>> actionLister){
        ThreadUtils.getIoPool().execute(new Runnable() {
            @Override
            public void run() {
                Response<List<CloudNetFm>> response = null;
                try {
                    response = BaApi.getInstance().getNetFmByCode(provinceCode,pageNum, pageSize);
                } catch (Exception e) {
                    e.printStackTrace();
                }finally {
                    postCmdResponse(response,actionLister);
                }
            }
        });
    }



    /*********************************************************************************************************/
    private static Handler mHandler; // 消息处理，用于当某个cmd执行完成后，在主线程中调用接口回调

    //在泛型类中声明了一个泛型方法，使用泛型E，这种泛型E可以为任意类型。可以类型与T相同，也可以不同。
    //由于泛型方法在声明的时候会声明泛型<E>，因此即使在泛型类中并未声明泛型，编译器也能够正确识别泛型方法中识别的泛型。
    private static <E> void postCmdResponse(Response<E> result, CmdActionLister<E> actionLister) {
        if (null == mHandler) {
            mHandler = new Handler(WApp.Instance.getMainLooper());
        }

        mHandler.post(new Runnable() {
            @Override
            public void run() {
                if (!ThreadUtils.isMainThread() || (null == actionLister)) {
                    return;
                }

                String msg = "";
                E data = null;
                int resultCode = -1;
                if (result != null) {
                    resultCode = result.resultCode;
                    // 针对云音乐的某些resultCode 为-2的特殊情况
                    if ((0 == resultCode) || (-2 == resultCode)) {
                        resultCode = 0;
                        data = result.bean;
                    }
                }

                actionLister.callback(resultCode, data, msg);
            }
        });
    }

    private static <E> void postCmdResponseAll(Response<E> result, CmdActionLister<Response<E>> actionLister) {
        if (null == mHandler) {
            mHandler = new Handler(WApp.Instance.getMainLooper());
        }

        mHandler.post(new Runnable() {
            @Override
            public void run() {
                if (!ThreadUtils.isMainThread() || (null == actionLister)) {
                    return;
                }

                String msg = "";
                Response<E> data = null;
                int resultCode = -1;
                if (result != null) {
                    resultCode = result.resultCode;
                    // 针对云音乐的某些resultCode 为-2的特殊情况
                    if ((0 == resultCode) || (-2 == resultCode)) {
                        resultCode = 0;
                        data = result;
                    }
                }

                actionLister.callback(resultCode, data, msg);
            }
        });
    }

}
