package com.westwhale.contollerapp.ui.localmusic.activity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;

import com.westwhale.contollerapp.R;
import com.westwhale.contollerapp.ui.base.activity.BaseActivity;
import com.westwhale.contollerapp.ui.base.fragment.BaseFragment;
import com.westwhale.contollerapp.ui.timer.TimerDefine;
import com.westwhale.contollerapp.ui.localmusic.fragment.SelectLocalMusicFragment;
import com.westwhale.api.protocolapi.bean.media.LocalMusic;

public class SelectLocalMusicActivity extends BaseActivity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_empty);

        initView();
        initListener();
        initData();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    private void initData() {
        SelectLocalMusicFragment fragment = new SelectLocalMusicFragment();
        Bundle bundle = new Bundle();
        bundle.putString(SelectLocalMusicFragment.ARG_KEY_DIRECTORYNAME,"本地音乐");
        bundle.putString(SelectLocalMusicFragment.ARG_KEY_DIRECTORYMID,"");
        fragment.setArguments(bundle);
        showFragmentNoBack(fragment);
    }

    private void initListener() {

    }

    private void initView() {

    }

    public void showFragment(BaseFragment fragment) {
        getSupportFragmentManager()
                .beginTransaction()
                .add(R.id.main_container, fragment)
                .addToBackStack(null)
                .commit();
    }

    public void showFragmentNoBack(BaseFragment fragment) {
        getSupportFragmentManager()
                .beginTransaction()
                .add(R.id.main_container, fragment)
                .commit();
    }

    public void onMediaItemClick(LocalMusic item){
        Intent intent = new Intent();

        intent.putExtra("media",item);

        setResult(Activity.RESULT_OK,intent);

        finish();
    }


}
