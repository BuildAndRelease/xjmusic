package com.westwhale.contollerapp.ui.cloudstory.adapter;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.westwhale.contollerapp.R;
import com.westwhale.api.protocolapi.bean.media.Section;

import java.util.ArrayList;
import java.util.List;

/**
 * Description:
 * Author: chenyaoli
 * Date: 2018-11-17
 * History:
 */
public class CloudStoryPlayListAdapter extends RecyclerView.Adapter {

    private List<Section> mItemList;
    private CallBack mCallBack;
    private int mSelectedIndex;
    private Section mSelectedItem;

    public interface CallBack {
        void onMediaItemClick(Section item);
    }

    public void updateSelectedItem(Section item){
        if ((null == item) || (mItemList == null)){
            return;
        }
        int oldIndex = -1;
        if (mSelectedItem != null){
            oldIndex = mItemList.indexOf(mSelectedItem);
        }

        int newIndex = -1;
        for (int i=0; i < mItemList.size(); i++){
            Section section = mItemList.get(i);
            if (section != null){
                // section.mid 每次获取的都会稍有不同，因此，采用 id，parentId，albumId 三个字段联合判断
                if (section.id.equals(item.id) && section.albumId.equals(item.albumId) && section.parentId.equals(item.parentId)){
                    newIndex = i;
                    mSelectedItem = section;
                    break;
                }

            }
        }

        if ((newIndex != -1) && (newIndex != oldIndex)){
            if (oldIndex != -1){
                notifyItemChanged(oldIndex);
            }

            notifyItemChanged(newIndex);
        }
    }

    public void updateDataList(List<Section> itemList){
        this.mItemList = itemList;
    }

    public void clearDataList(){
        if (mItemList != null){
            this.mItemList.clear();
        }
        notifyDataSetChanged();
    }

    public void addToDataList(List<Section> itemList){
        if (mItemList == null){
            mItemList = new ArrayList<>();
            notifyDataSetChanged();
        }
        mItemList.addAll(itemList);
    }

    public CloudStoryPlayListAdapter(CallBack callBack) {
        this.mItemList = null;
        this.mCallBack = callBack;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_cloudstory_item_1, viewGroup, false);
        return new MusicListItemHolder(view);

    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder viewHolder, int i) {
        // 在此处，处理默认类型的 viewHolder
        Section item = mItemList.get(i);
        MusicListItemHolder itemHolder = (MusicListItemHolder) viewHolder;

        if (item == mSelectedItem){
            //设置选中颜色
            int selectColor = itemHolder.itemView.getResources().getColor(R.color.colorAccent);
            itemHolder.mItemNo.setTextColor(selectColor);
            itemHolder.mTitleTv.setTextColor(selectColor);
            itemHolder.mSubtitle.setTextColor(selectColor);
        }else{
            //设置未选中颜色
            int selectColor = itemHolder.itemView.getResources().getColor(R.color.searchdev_text);
            itemHolder.mItemNo.setTextColor(selectColor);
            itemHolder.mTitleTv.setTextColor(selectColor);
            itemHolder.mSubtitle.setTextColor(selectColor);
        }

        itemHolder.mItemNo.setText(String.valueOf(i+1));
        itemHolder.mTitleTv.setText(item.sectionName);
        String subtitle = item.anchorName;
        itemHolder.mSubtitle.setText(subtitle);

        viewHolder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mCallBack.onMediaItemClick(item);
            }
        });

    }

    @Override
    public int getItemCount() {
        return (mItemList == null) ? 0 : mItemList.size();
    }


    private class MusicListItemHolder extends RecyclerView.ViewHolder {
        TextView mItemNo, mTitleTv, mSubtitle;

        MusicListItemHolder(@NonNull View itemView) {
            super(itemView);
            mItemNo = itemView.findViewById(R.id.item_story_item_no);
            mTitleTv = itemView.findViewById(R.id.item_story_item_name);
            mSubtitle = itemView.findViewById(R.id.item_story_item_artist);
        }
    }
}
