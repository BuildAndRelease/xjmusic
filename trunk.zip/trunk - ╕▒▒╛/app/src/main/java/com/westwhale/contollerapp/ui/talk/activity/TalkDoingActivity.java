package com.westwhale.contollerapp.ui.talk.activity;


import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.AccelerateInterpolator;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.blankj.utilcode.constant.PermissionConstants;
import com.blankj.utilcode.util.ActivityUtils;
import com.blankj.utilcode.util.LogUtils;
import com.blankj.utilcode.util.PermissionUtils;
import com.blankj.utilcode.util.ThreadUtils;
import com.blankj.utilcode.util.ToastUtils;
import com.westwhale.api.protocolapi.bean.Talk;
import com.westwhale.api.protocolapi.bean.hostroom.PlayingInfo;
import com.westwhale.api.protocolapi.bean.hostroom.Room;
import com.westwhale.contollerapp.R;
import com.westwhale.contollerapp.application.WApp;
import com.westwhale.contollerapp.dev.CmdActionLister;
import com.westwhale.contollerapp.dev.ICmdCallback;
import com.westwhale.contollerapp.dev.WHost;
import com.westwhale.contollerapp.dev.WRoom;
import com.westwhale.contollerapp.eventbus.notify.NotifyPlayingInfoEvent;
import com.westwhale.contollerapp.ui.base.activity.BaseActivity;
import com.westwhale.contollerapp.ui.talk.adapter.TalkNewRoomAdapter;
import com.westwhale.contollerapp.ui.talk.adapter.TalkingRoomAdapter;
import com.westwhale.contollerapp.ui.widget.WaveView;
import com.westwhale.contollerapp.utils.SAudioClient;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import java.util.ArrayList;
import java.util.List;


public class TalkDoingActivity extends BaseActivity implements TalkingRoomAdapter.CallBack {
    public final static String TAG = TalkDoingActivity.class.getName();

    public static final String TALK_STAT_OPEN = "open";
    public static final String TALK_STAT_CLOSE = "close";

    private Toolbar mToolbar;
    private ImageView mTalkDownIv,mTalkStatIv;
    private WaveView mTalkingWaveView;
    private RecyclerView mDataRv;
    private TalkingRoomAdapter mAdapter;

    private int mRequestTalkInfoCount = 0;  //记录对讲数据的重连次数
    private int mTalkId = -1;
    private String mTalkStat = "";
    private String mTalkMulticastIp = "";
    private int mTalkPort = -1;
    private SAudioClient mTalkAudioClient = null;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_talk_doing);

        Intent intent = getIntent();
        if (intent != null){
            mTalkId = intent.getIntExtra("talkId",-1);
        }

        initView();
        initListener();

        // eventbus 注册
        EventBus.getDefault().register(this);

        initData();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        EventBus.getDefault().unregister(this);

        stopTalking();
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }

    private void quitTalkGroup() {
        WRoom room = WApp.Instance.getDevManager().getSelectedRoom();
        if ( (mTalkId != -1) && (room != null) ){
            WRoom.cmdSetTalkStat(mTalkId,TALK_STAT_CLOSE,new CmdActionLister<Talk>(TalkDoingActivity.this, new ICmdCallback<Talk>() {
                @Override
                public void onSuccess(Talk data) {
                    Intent intent = new Intent();
                    intent.putExtra("talkId",mTalkId);
                    setResult(Activity.RESULT_OK,intent);

                    finish();
                }

                @Override
                public void onFailed(int code, String msg) {
                    finish();
                }
            }));
        }else{
            finish();
        }
    }

    @Override
    public void onItemClick(Room room) {

    }

    private void initView() {
        mToolbar = findViewById(R.id.talk_doing_toolbar);
        // 设置toolbar
        setSupportActionBar(mToolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        mTalkStatIv = findViewById(R.id.talk_doing_state);
        mTalkDownIv = findViewById(R.id.talk_doing_icon_iv);

        mTalkingWaveView = findViewById(R.id.talk_doing_waveview);
        mTalkingWaveView.setInitialRadius(70);
        mTalkingWaveView.setDuration(2000);
        mTalkingWaveView.setStyle(Paint.Style.STROKE);
        mTalkingWaveView.setSpeed(400);
        mTalkingWaveView.setColor(ContextCompat.getColor(TalkDoingActivity.this, R.color.colorPrimary));
        mTalkingWaveView.setInterpolator(new AccelerateInterpolator(1.2f));

        mDataRv = findViewById(R.id.talk_doing_room_recyclerview);
        GridLayoutManager gridLayoutManager = new GridLayoutManager(this,4);
        mDataRv.setLayoutManager(gridLayoutManager);
        mAdapter = new TalkingRoomAdapter();
        mAdapter.setCallBack(this);
        mDataRv.setAdapter(mAdapter);
        mDataRv.setHasFixedSize(true);
//        mDataRv.setNestedScrollingEnabled(false);
        // 设置下拉上拉无阴影效果
        mDataRv.setOverScrollMode(View.OVER_SCROLL_NEVER);

    }

//    @SuppressLint("ClickableViewAccessibility")
    @SuppressLint("ClickableViewAccessibility")
    private void initListener() {
        mToolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        mTalkStatIv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                quitTalkGroup();
            }
        });

        mTalkDownIv.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN: {
                        // 开始对讲，说话
                        mTalkDownIv.setImageResource(R.drawable.talking_down);

                        startTalking();
                        break;
                    }
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        mTalkDownIv.setImageResource(R.drawable.talking);

                        stopTalking();
                        break;
                }
                return true;
            }
        });

        // 权限配置及申请
        if (!PermissionUtils.isGranted(PermissionConstants.MICROPHONE)){
            PermissionUtils.permission(PermissionConstants.MICROPHONE)
                    .callback(new PermissionUtils.SimpleCallback() {
                        @Override
                        public void onGranted() {

                        }

                        @Override
                        public void onDenied() {
                            ToastUtils.showShort("请配置 麦克风 权限");
                        }
                    })
                    .request();
        }
    }

    private void initData() {
        if (mTalkId != -1) {
            requestDataTalkInfo();
            requestDataTalkRooms();
        }else{
            ToastUtils.showShort("对讲组ID不对:"+mTalkId);
        }
    }

    private void requestDataTalkInfo() {
        // 获取房间列表信息
        WHost host = WApp.Instance.getDevManager().getSelectedHost();
        if ( (host != null) && (host.getHost() != null)){
            WRoom.cmdGetTalkStat(mTalkId,new CmdActionLister<Talk>(TalkDoingActivity.this, new ICmdCallback<Talk>() {
                @Override
                public void onSuccess(Talk data) {
                    updateTalkInfo(data);
                }

                @Override
                public void onFailed(int code, String msg) {
                    updateTalkInfo(null);
                }
            }));
        }
    }

    private void requestDataTalkRooms() {
        // 获取房间列表信息
        WHost host = WApp.Instance.getDevManager().getSelectedHost();
        if ( (host != null) && (host.getHost() != null)){
            WRoom.cmdGetTalkRoomList(mTalkId,new CmdActionLister<List<Room>>(TalkDoingActivity.this, new ICmdCallback<List<Room>>() {
                @Override
                public void onSuccess(List<Room> data) {
                    updateDataList(data);
                }

                @Override
                public void onFailed(int code, String msg) {
                    updateDataList(null);
                }
            }));
        }
    }


    private void updateTalkInfo(Talk talk) {
        // 若获取失败，则重新获取数据
        if (mRequestTalkInfoCount > 2){
            ToastUtils.showShort("对讲信息不匹配");
            onBackPressed();
            return;
        }else{
            mRequestTalkInfoCount++;
        }

        boolean needReload = true;
        if (talk != null){
            mTalkStat = talk.talkStat;
            if (talk.talkId == mTalkId){
                needReload = false;
                int statePicResourceId = R.drawable.btn_unlock;
                if (!TALK_STAT_OPEN.equals(mTalkStat)){
                    statePicResourceId = R.drawable.btn_lock;
                    return;
                }

                mRequestTalkInfoCount = 0;
                mTalkStatIv.setImageResource(statePicResourceId);

                mTalkMulticastIp = talk.talkMulticastIp;
                mTalkPort = Integer.parseInt(talk.talkPort);

                if ((talk.talkName != null) && !talk.talkName.isEmpty()){
                    String title = mToolbar.getTitle().toString();
                    title = title + "-" + talk.talkName;
                    mToolbar.setTitle(title);
                }
            }
        }

        if (needReload){
            requestDataTalkInfo();
        }
    }

    private void updateDataList(List<Room> roomlist){
        if (mAdapter != null){
            mAdapter.clearAllData();

            mAdapter.setDataList(roomlist);
            mAdapter.notifyDataSetChanged();
        }
    }


    private void startTalking() {
        stopTalking();

        if (!TALK_STAT_OPEN.equals(mTalkStat) || mTalkMulticastIp.isEmpty() || (mTalkId == -1)){
            ToastUtils.showShort("对讲信息不匹配");
            return;
        }

        mTalkingWaveView.start();

        mTalkAudioClient = new SAudioClient(mTalkMulticastIp, mTalkPort);
        ThreadUtils.getIoPool().execute(new Runnable() {
            @Override
            public void run() {
                if (mTalkAudioClient != null) {
                    mTalkAudioClient.start();
                }
            }
        });

    }

    private void stopTalking() {
//        mTalkingWaveView.stop();
        mTalkingWaveView.stopImmediately();

        if (mTalkAudioClient != null) {
            mTalkAudioClient.free();
            mTalkAudioClient = null;
        }
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onNotifyPlayingInfoEvent(NotifyPlayingInfoEvent event) {
        if (ActivityUtils.getTopActivity() != this){
            return;
        }

        updatePlayingInfo(event.getPlayingInfo());
    }

    private void updatePlayingInfo(PlayingInfo playingInfo){
        if ((null == playingInfo) || !playingInfo.isAvailble()){
            return;
        }

        boolean needQuitTalk = true;
        String roomState = playingInfo.roomState;
        int talkId = -1;
        try {
            talkId = Integer.parseInt(playingInfo.talkId);
        }catch (Exception e){
            e.printStackTrace();
        }
        if (Room.ChannelState.INTALK.equals(roomState) && (talkId == mTalkId)){
            needQuitTalk = false;
        }

        if (needQuitTalk){
            stopTalking();
            quitTalkGroup();
        }
    }

}
