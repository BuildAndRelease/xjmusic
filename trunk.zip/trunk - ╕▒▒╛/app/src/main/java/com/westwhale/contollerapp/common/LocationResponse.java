package com.westwhale.contollerapp.common;

public class LocationResponse {
    /**
     * success : true
     * data : {"province":"湖南省","adcode":430000}
     */

    public boolean success;
    public DataEntity data;

    public static class DataEntity {
        /**
         * province : 湖南省
         * adcode : 430000
         */

        public String province;
        public String adcode;
    }
}