package com.westwhale.contollerapp.ui.download.adapter;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.westwhale.contollerapp.R;
import com.westwhale.contollerapp.common.ImageTextItem;

import java.util.ArrayList;

/**
 * Description:
 * Author: chenyaoli
 * Date: 2018-11-27
 * History:
 */
public class DownloadedMoreItemAdapter extends RecyclerView.Adapter {
    private ArrayList<ImageTextItem> mItemList;
    private CallBack mMoreInfoItemClick;

    public interface CallBack{
        void onMoreInfoItemClick(View view, String data);
    }

    public void setCallBack(CallBack callBack){
        this.mMoreInfoItemClick = callBack;
    }

    public void updateList(ArrayList<ImageTextItem> itemList){
        this.mItemList = itemList;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_more_info, viewGroup, false);
        return new ItemHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder viewHolder, int i) {
        if (viewHolder instanceof ItemHolder){
            final ImageTextItem item = mItemList.get(i);
            ItemHolder itemHolder = (ItemHolder)viewHolder;
            itemHolder.mHintTextTv.setText(item.getTitle());
            int defaultTextColor = itemHolder.mHintTextTv.getTextColors().getDefaultColor();
            if (item.getItemStat()){
                itemHolder.mHintTextTv.setTextColor(defaultTextColor);
            }else{
                itemHolder.mHintTextTv.setTextColor(itemHolder.itemView.getResources().getColor(R.color.colorGrey));
            }
            itemHolder.mPicIv.setImageResource(item.getImageRes());
            itemHolder.itemView.setTag(i + "");
            itemHolder.itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (mMoreInfoItemClick != null){
                        mMoreInfoItemClick.onMoreInfoItemClick(v,(String)v.getTag());
                    }
                }
            });
        }
    }

    @Override
    public int getItemCount() {
        return (mItemList == null) ? 0 : mItemList.size();
    }

    private class ItemHolder extends RecyclerView.ViewHolder{
        private ImageView mPicIv;
        private TextView mHintTextTv;
        public ItemHolder(@NonNull View itemView) {
            super(itemView);
            mPicIv = itemView.findViewById(R.id.item_more_info_pic);
            mHintTextTv = itemView.findViewById(R.id.item_more_info_text);
        }
    }
}
