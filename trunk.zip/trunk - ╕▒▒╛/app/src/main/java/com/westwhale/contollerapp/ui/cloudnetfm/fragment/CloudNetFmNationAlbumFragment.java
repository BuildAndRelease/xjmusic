package com.westwhale.contollerapp.ui.cloudnetfm.fragment;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.View;
import android.widget.Toast;

import com.kingja.loadsir.callback.SuccessCallback;
import com.westwhale.contollerapp.application.WApp;
import com.westwhale.contollerapp.dev.CmdActionLister;
import com.westwhale.contollerapp.dev.ICmdCallback;
import com.westwhale.contollerapp.dev.WRoom;
import com.westwhale.contollerapp.ui.loadsircallback.EmptyCallback;
import com.westwhale.api.protocolapi.bean.media.CloudNetFm;

import java.util.List;

public class CloudNetFmNationAlbumFragment extends CloudNetFmBaseFragment {

    private int mCurPageNo = 1; //记录当前的页面数, 云音乐歌手获取时必须从第一页开始
    private int mPageSize = 50;
    private boolean mHasMoreData = true; // 记录是否还有更多数据

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        //初始化 toolbar
        configToolBar(mToolBar,"国家台");

        mCategoryLayout.setVisibility(View.GONE);
    }

    @Override
    protected void initData() {
        mCurPageNo = 1;
        mHasMoreData = true;

        // 每次先清空原有数据
        if (mAdapter != null){
            mAdapter.clearDataList();
        }

        requestCloudResource();
    }

    @Override
    protected boolean hasMoreData() {
        return mHasMoreData;
    }

    @Override
    protected void loadMoreData() {
        mCurPageNo++;
        requestCloudResource();
    }

    @Override
    protected void updateDataList(List<CloudNetFm> list) {
        if (list != null) {
            // 若无法获取到数据，则认为已经到底
            int size = list.size();

            if (mCurPageNo == 0) {
                mAdapter.clearDataList();
            }

            if (size != 0){
                int startIndex = mAdapter.getItemCount();
                mAdapter.addToDataList(list);
                mAdapter.notifyItemRangeInserted(startIndex,size);
            }else{
                mHasMoreData = false;
            }

            // 更新刷新等待状态
            mRefreshLayout.finishRefresh();
            mRefreshLayout.finishLoadMore();

            showLoadCallBack(SuccessCallback.class);
        }else{
            // 当获取数据失败时，则认为无数据了
            mHasMoreData = false;

            // 更新刷新等待状态
            mRefreshLayout.finishRefresh();
            mRefreshLayout.finishLoadMore();

            showLoadCallBack(EmptyCallback.class);
        }
    }

    @Override
    protected void requestCloudResource() {
        WRoom room = WApp.Instance.getDevManager().getSelectedRoom();
        if (room != null){
            room.cmdGetNetFmNational(mCurPageNo,mPageSize, new CmdActionLister<List<CloudNetFm>>(this, new ICmdCallback<List<CloudNetFm>>() {
                @Override
                public void onSuccess(List<CloudNetFm> data) {
                    updateDataList(data);
                }

                @Override
                public void onFailed(int code, String msg) {
                    updateDataList(null);
                    Toast.makeText(getContext(),"GetNetFmNational获取失败:"+code,Toast.LENGTH_SHORT).show();
                }
            }));
        }else{
            updateDataList(null);
        }
    }
}
