package com.westwhale.contollerapp.ui.scene.bean;


import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.westwhale.api.protocolapi.bean.media.CloudMusic;
import com.westwhale.api.protocolapi.bean.media.LocalMusic;
import com.westwhale.api.protocolapi.bean.media.Media;


public class CmdPlayMedia extends CmdActionBase {

    private String mMediaSrc = "";
    private Media mMedia = null;

    public CmdPlayMedia() {
        mType = CMD_TYPE_PLAYMEDIA;
        mCmdName = getCmdName();
    }

    @Override
    public String toJsonString() {
        JSONObject argObject = new JSONObject();
        argObject.put("mediaSrc",mMediaSrc);
        argObject.put("media",mMedia);

        JSONObject jsonObject = new JSONObject();
        jsonObject.put("cmd",mCmdName);
        jsonObject.put("arg",argObject);

        return jsonObject.toJSONString();
    }

    @Override
    public String getActionValue() {
        String value = "无";
        if (mMedia != null){
            switch (mMediaSrc){
                case Media.LOCAL_MUSIC:
                    value = ((LocalMusic)mMedia).songName;
                    break;
                case Media.CLOUD_MUSIC:
                    value = ((CloudMusic)mMedia).songName;
                    break;
                default:
                    break;
            }
        }
        return value;
    }

    @Override
    public void parseArgs() {
        if ((mCmdArgs == null) || (mCmdArgs.isEmpty())){
            return;
        }

        try {
            JSONObject jsonObject = JSON.parseObject(mCmdArgs);
            mMediaSrc = jsonObject.getString("mediaSrc");
            switch (mMediaSrc){
                case Media.LOCAL_MUSIC:
                    mMedia = JSON.parseObject(jsonObject.getString("media"),LocalMusic.class);
                    break;
                case Media.CLOUD_MUSIC:
                    mMedia = JSON.parseObject(jsonObject.getString("media"), CloudMusic.class);
                    break;
                default:
                    break;
            }
        }catch (Exception e){
            mMediaSrc = "";
            mMedia = null;
        }
    }

    public void setMedia(String mediaSrc,Media media){
        mMediaSrc = mediaSrc;
        mMedia = media;
    }
}
