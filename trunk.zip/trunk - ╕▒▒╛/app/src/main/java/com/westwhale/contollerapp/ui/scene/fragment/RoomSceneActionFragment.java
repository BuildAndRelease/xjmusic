package com.westwhale.contollerapp.ui.scene.fragment;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;

import com.alibaba.fastjson.JSON;
import com.blankj.utilcode.util.LogUtils;
import com.westwhale.api.protocolapi.bean.media.LocalMusic;
import com.westwhale.api.protocolapi.bean.scene.RoomSceneAction;
import com.westwhale.contollerapp.R;
import com.westwhale.contollerapp.common.ImageTextItem;
import com.westwhale.contollerapp.ui.base.fragment.BaseFragment;
import com.westwhale.contollerapp.ui.scene.activity.SceneOpenMediaActivity;
import com.westwhale.contollerapp.ui.scene.adapter.RoomSceneActionAdatper;
import com.westwhale.contollerapp.ui.scene.bean.CmdActionBase;
import com.westwhale.contollerapp.ui.scene.bean.CmdPlayLocalMusic;
import com.westwhale.contollerapp.ui.scene.bean.CmdPlayInfo;
import com.westwhale.contollerapp.ui.scene.bean.CmdPlayMedia;
import com.westwhale.contollerapp.ui.scene.bean.CmdSetAudioSource;
import com.westwhale.contollerapp.ui.scene.bean.CmdSetDevStat;
import com.westwhale.contollerapp.ui.scene.bean.CmdSetEq;
import com.westwhale.contollerapp.ui.scene.bean.CmdSetMute;
import com.westwhale.contollerapp.ui.scene.bean.CmdSetPlayMode;
import com.westwhale.contollerapp.ui.scene.bean.CmdSetVolume;
import com.westwhale.contollerapp.ui.widget.dialog.ImageTextItemDialog;
import com.westwhale.contollerapp.ui.widget.dialog.SeekbarDialog;
import com.westwhale.contollerapp.ui.widget.interfs.DialogResultListener;
import com.westwhale.contollerapp.utils.CommonUtils;

import org.json.JSONException;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class RoomSceneActionFragment extends BaseFragment implements RoomSceneActionAdatper.CallBack{
    public static final int REQUEST_CODDE = 0;

    public static final int REQUEST_CODE_OPEN_MEDIA = 1;

    private final int CMD_EQ_TYPE_CLASSICAL = 1;
    private final int CMD_EQ_TYPE_CLUB = 2;
    private final int CMD_EQ_TYPE_PARTY = 3;
    private final int CMD_EQ_TYPE_ROCK = 4;
    private final int CMD_EQ_TYPE_SOFT = 5;

    private final int CMD_PLAYMODE_TYPE_CIRCLE = 1;
    private final int CMD_PLAYMODE_TYPE_NORMAL = 2;
    private final int CMD_PLAYMODE_TYPE_SINGLE = 3;
    private final int CMD_PLAYMODE_TYPE_SHUFFLE = 4;

    private FrameLayout mFrameLayout;
    private RecyclerView mDataRv;
    private RoomSceneActionAdatper mAdapter;

    private String mRoomSceneActionStr;
    private String mRoomId;
    private int mSceneId = -1;

    private List<ImageTextItem> mEqDataList = new ArrayList<>();  // Eq选项列表
    private List<ImageTextItem> mPlayModeDataList = new ArrayList<>();  // 播放模式选项列表

    private CmdActionBase mCurrentSelectItem = null; // 标记当前已选择的项
    private int mPos = -1; // 标记当前已选择项的pos

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        mEqDataList.clear();
        mEqDataList.add(new ImageTextItem(CMD_EQ_TYPE_CLASSICAL,CmdSetEq.getEqName(CmdSetEq.EQ_CLASSICAL)));
        mEqDataList.add(new ImageTextItem(CMD_EQ_TYPE_CLUB,CmdSetEq.getEqName(CmdSetEq.EQ_CLUB)));
        mEqDataList.add(new ImageTextItem(CMD_EQ_TYPE_PARTY,CmdSetEq.getEqName(CmdSetEq.EQ_PARTY)));
        mEqDataList.add(new ImageTextItem(CMD_EQ_TYPE_ROCK,CmdSetEq.getEqName(CmdSetEq.EQ_ROCK)));
        mEqDataList.add(new ImageTextItem(CMD_EQ_TYPE_SOFT,CmdSetEq.getEqName(CmdSetEq.EQ_SOFT)));

        mPlayModeDataList.clear();
        mPlayModeDataList.add(new ImageTextItem(CMD_PLAYMODE_TYPE_CIRCLE, CmdSetPlayMode.getModeName(CmdSetPlayMode.PLAYMODE_CIRCLE)));
        mPlayModeDataList.add(new ImageTextItem(CMD_PLAYMODE_TYPE_NORMAL,CmdSetPlayMode.getModeName(CmdSetPlayMode.PLAYMODE_NORMAL)));
        mPlayModeDataList.add(new ImageTextItem(CMD_PLAYMODE_TYPE_SINGLE,CmdSetPlayMode.getModeName(CmdSetPlayMode.PLAYMODE_SINGLE)));
        mPlayModeDataList.add(new ImageTextItem(CMD_PLAYMODE_TYPE_SHUFFLE,CmdSetPlayMode.getModeName(CmdSetPlayMode.PLAYMODE_SHUFFLE)));
    }

    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        // 先显示加载动画，针对布局做一些初始化
        return inflater.inflate(R.layout.frag_scene_roomsceneaction,container,false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        initView(view);

        initListener();

        initData();
    }



    @Override
    public void onResume() {
        super.onResume();
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if ((requestCode == REQUEST_CODE_OPEN_MEDIA) && (resultCode == Activity.RESULT_OK)) {
            // 更新 播放媒体信息
            if ((mCurrentSelectItem instanceof CmdPlayInfo) && (mPos > -1)){
                CmdPlayInfo cmdPlayInfo = (CmdPlayInfo)mCurrentSelectItem;
                CmdActionBase cmdActionBase = null;
                if (data != null){
                    int cmdType = data.getIntExtra("cmdType",-1);
                    if (cmdType == CmdActionBase.CMD_TYPE_SETAUDIOSOURCE){
                        String mediaSrc = data.getStringExtra("mediaSrc");

                        cmdActionBase = new CmdSetAudioSource();
                        ((CmdSetAudioSource)cmdActionBase).setAudioSource(mediaSrc);
                    } else if (cmdType == CmdActionBase.CMD_TYPE_PLAYMEDIA){
                        LocalMusic localMusic = data.getParcelableExtra("media");
                        String mediaSrc = data.getStringExtra("mediaSrc");

                        cmdActionBase = new CmdPlayMedia();
                        ((CmdPlayMedia)cmdActionBase).setMedia(mediaSrc,localMusic);
                    }
                }

                cmdPlayInfo.setCmdAction(cmdActionBase);
                mAdapter.notifyItemChanged(mPos);
            }
        }
    }


    @Override
    public void onItemClick(CmdActionBase item,int pos) {
        mCurrentSelectItem = item;
        mPos = pos;
        if (item != null){
            switch (item.getType()){
                case CmdActionBase.CMD_TYPE_SETDEVSTAT: {
                    // 开关机功能
                    CmdSetDevStat cmdSetDevStat = (CmdSetDevStat) item;
                    String devStat = CmdSetDevStat.DEV_STAT_CLOSE;
                    if (CmdSetDevStat.DEV_STAT_CLOSE.equals(cmdSetDevStat.getDevStat())){
                        devStat = CmdSetDevStat.DEV_STAT_OPEN;
                    }
                    cmdSetDevStat.setDevStat(devStat);
                    mAdapter.notifyItemChanged(pos);
                    break;
                }
                case CmdActionBase.CMD_TYPE_SETVOLUME: {
                    // 弹出音量功能
                    CmdSetVolume cmdSetVolume = (CmdSetVolume) item;

                    SeekbarDialog seekbarDialog = new SeekbarDialog();
                    seekbarDialog.setOnDialogResultListener(new DialogResultListener<Integer>() {
                        @Override
                        public void onResultListener(Integer value) {
                            cmdSetVolume.setVolume(value);
                            mAdapter.notifyItemChanged(pos);
                        }
                    });
                    Bundle bundle = new Bundle();
                    bundle.putString(SeekbarDialog.DIALOG_TITLE,"音量");
                    bundle.putInt(SeekbarDialog.SEEKBAR_VALUE,cmdSetVolume.getVolume());
                    bundle.putInt(SeekbarDialog.SEEKBAR_MAXVALUE,31);
                    seekbarDialog.setArguments(bundle);
                    seekbarDialog.show(getChildFragmentManager(), "volumeDialog");

                    break;
                }
                case CmdActionBase.CMD_TYPE_SETEQ: {
                    // 弹出音效功能
                    CmdSetEq cmdSetEq = (CmdSetEq) item;
                    showEqDialog(new DialogResultListener<ImageTextItem>() {
                        @Override
                        public void onResultListener(ImageTextItem value) {
                            if (value != null) {
                                String eq = "";
                                switch (value.getType()){
                                    case CMD_EQ_TYPE_CLASSICAL:
                                        eq = CmdSetEq.EQ_CLASSICAL;
                                        break;
                                    case CMD_EQ_TYPE_CLUB:
                                        eq = CmdSetEq.EQ_CLUB;
                                        break;
                                    case CMD_EQ_TYPE_PARTY:
                                        eq = CmdSetEq.EQ_PARTY;
                                        break;
                                    case CMD_EQ_TYPE_ROCK:
                                        eq = CmdSetEq.EQ_ROCK;
                                        break;
                                    case CMD_EQ_TYPE_SOFT:
                                        eq = CmdSetEq.EQ_SOFT;
                                        break;
                                    default:
                                        break;

                                }
                                cmdSetEq.setEq(eq);
                                mAdapter.notifyItemChanged(pos);
                            }
                        }
                    });

                    break;
                }
                case CmdActionBase.CMD_TYPE_SETPLAYMODE: {
                    // 弹出播放模式功能
                    CmdSetPlayMode cmdSetPlayMode = (CmdSetPlayMode) item;

                    showPlayModeDialog(new DialogResultListener<ImageTextItem>() {
                        @Override
                        public void onResultListener(ImageTextItem value) {
                            if (value != null) {
                                String playMode = "";
                                switch (value.getType()){
                                    case CMD_PLAYMODE_TYPE_CIRCLE:
                                        playMode = CmdSetPlayMode.PLAYMODE_CIRCLE;
                                        break;
                                    case CMD_PLAYMODE_TYPE_NORMAL:
                                        playMode = CmdSetPlayMode.PLAYMODE_NORMAL;
                                        break;
                                    case CMD_PLAYMODE_TYPE_SINGLE:
                                        playMode = CmdSetPlayMode.PLAYMODE_SINGLE;
                                        break;
                                    case CMD_PLAYMODE_TYPE_SHUFFLE:
                                        playMode = CmdSetPlayMode.PLAYMODE_SHUFFLE;
                                        break;
                                    default:
                                        break;
                                }
                                cmdSetPlayMode.setPlayMode(playMode);
                                mAdapter.notifyItemChanged(pos);
                            }
                        }
                    });

                    break;
                }
                case CmdActionBase.CMD_TYPE_SETMUTE: {
                    // 静音功能
                    CmdSetMute cmdSetMute = (CmdSetMute) item;
                    String muteStat = CmdSetMute.MUTE_STAT_MUTE;
                    if (CmdSetMute.MUTE_STAT_MUTE.equals(cmdSetMute.getMuteStat())){
                        muteStat = CmdSetMute.MUTE_STAT_NORMAL;
                    }
                    cmdSetMute.setMuteStat(muteStat);
                    mAdapter.notifyItemChanged(pos);
                    break;
                }
                case CmdActionBase.CMD_TYPE_PLAYINFO: {
                    // 媒体选择
                    startActivityForResult(new Intent(mContext,SceneOpenMediaActivity.class),REQUEST_CODE_OPEN_MEDIA);
                }
                default:
                    break;
            }
        }
    }

    private void initView(View view) {

        mDataRv = view.findViewById(R.id.scene_roomsceneaction_recylerview);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(mContext);
        mDataRv.setLayoutManager(linearLayoutManager);
        mAdapter = new RoomSceneActionAdatper();
        mAdapter.setCallBack(this);
        mDataRv.setAdapter(mAdapter);
        mDataRv.setHasFixedSize(true);
        mDataRv.addItemDecoration(new DividerItemDecoration(mContext, DividerItemDecoration.VERTICAL));
        // 设置下拉上拉无阴影效果
        mDataRv.setOverScrollMode(View.OVER_SCROLL_NEVER);
    }

    private void initListener() {

    }

    private void initData() {
        String actionList = "";
        Bundle bundle = getArguments();
        if (bundle != null){
            mSceneId = bundle.getInt("sceneId",-1);
            actionList = bundle.getString("actionList","");
        }
        LogUtils.e("----------"+mSceneId+"  \n"+ actionList);

        List<CmdActionBase> cmdDataList = new ArrayList<>();
        Map<CmdActionBase,Boolean> dataMap = new HashMap<>();

        CmdSetDevStat cmdSetDevStat = new CmdSetDevStat();
        boolean containSetDevStat = false;

        CmdSetVolume cmdSetVolume = new CmdSetVolume();
        boolean containSetVolume = false;

        CmdSetEq cmdSetEq = new CmdSetEq();
        boolean containSetEq = false;

        CmdSetPlayMode cmdSetPlayMode = new CmdSetPlayMode();
        boolean containSetPlayMode = false;

        CmdSetMute cmdSetMute = new CmdSetMute();
        boolean containSetMute = false;

        CmdPlayInfo cmdPlayInfo = new CmdPlayInfo();
        boolean containPlayInfo = false;

        try{
            List<RoomSceneAction.CmdAction> cmdActionList = JSON.parseArray(actionList,RoomSceneAction.CmdAction.class);
            if (cmdActionList != null) {
                for (RoomSceneAction.CmdAction action : cmdActionList) {
                    if (action != null) {
                        switch (action.cmd) {
                            case CmdActionBase.CMD_NAME_SETDEVSTAT:
                                cmdSetDevStat.setCmdArgsByJson(action.arg.toString());
                                containSetDevStat = true;

                                break;
                            case CmdActionBase.CMD_NAME_SETVOLUME:
                                cmdSetVolume.setCmdArgsByJson(action.arg.toString());
                                containSetVolume = true;
                                break;
                            case CmdActionBase.CMD_NAME_SETEQ:
                                cmdSetEq.setCmdArgsByJson(action.arg.toString());
                                containSetEq = true;
                                break;
                            case CmdActionBase.CMD_NAME_SETPLAYMODE:
                                cmdSetPlayMode.setCmdArgsByJson(action.arg.toString());
                                containSetPlayMode = true;
                                break;
                            case CmdActionBase.CMD_NAME_SETMUTE:
                                cmdSetMute.setCmdArgsByJson(action.arg.toString());
                                containSetMute = true;
                                break;
                            case CmdActionBase.CMD_NAME_SETAUDIOSOURCE:
                                CmdSetAudioSource cmdSetAudioSource = new CmdSetAudioSource();
                                cmdSetAudioSource.setCmdArgsByJson(action.arg.toString());

                                cmdPlayInfo.setCmdAction(cmdSetAudioSource);
                                containPlayInfo = true;
                                break;
                            case CmdActionBase.CMD_NAME_PLAYMEDIA:
                                CmdPlayMedia cmdPlayMedia = new CmdPlayMedia();
                                cmdPlayMedia.setCmdArgsByJson(action.arg.toString());

                                cmdPlayInfo.setCmdAction(cmdPlayMedia);
                                containPlayInfo = true;
                                break;
                            default:
                                break;
                        }
                    }
                }
            }
        }catch (Exception e){
            e.printStackTrace();
        }

        cmdDataList.clear();
        cmdDataList.add(cmdSetDevStat);
        cmdDataList.add(cmdSetVolume);
        cmdDataList.add(cmdSetEq);
        cmdDataList.add(cmdSetPlayMode);
        cmdDataList.add(cmdSetMute);
        cmdDataList.add(cmdPlayInfo);


        dataMap.clear();
        dataMap.put(cmdSetDevStat,containSetDevStat);
        dataMap.put(cmdSetVolume,containSetVolume);
        dataMap.put(cmdSetEq,containSetEq);
        dataMap.put(cmdSetPlayMode,containSetPlayMode);
        dataMap.put(cmdSetMute,containSetMute);
        dataMap.put(cmdPlayInfo,containPlayInfo);

        // 更新数据
        mAdapter.setDataList(cmdDataList,dataMap);
        mAdapter.notifyDataSetChanged();
    }

    private void showEqDialog(DialogResultListener<ImageTextItem> listener){
        ImageTextItemDialog imageTextItemDialog = new ImageTextItemDialog();
        imageTextItemDialog.setOnDialogResultListener(listener);
        imageTextItemDialog.setDataList(mEqDataList);

        Bundle bundle = new Bundle();
        bundle.putString(ImageTextItemDialog.DIALOG_TITLE,"音效");

        imageTextItemDialog.setArguments(bundle);
        imageTextItemDialog.show(getChildFragmentManager(), "eqDialog");
    }

    private void showPlayModeDialog(DialogResultListener<ImageTextItem> listener){
        ImageTextItemDialog imageTextItemDialog = new ImageTextItemDialog();
        imageTextItemDialog.setOnDialogResultListener(listener);
        imageTextItemDialog.setDataList(mPlayModeDataList);

        Bundle bundle = new Bundle();
        bundle.putString(ImageTextItemDialog.DIALOG_TITLE,"播放模式");
        imageTextItemDialog.setArguments(bundle);
        imageTextItemDialog.show(getChildFragmentManager(), "playModeDialog");
    }

    public String getActionList(){
        String actionListJsonStr = "";
        if (mAdapter != null){
            try {
                List<CmdActionBase> selectedCmdList = mAdapter.getSelectedList();
                List<String> cmdActionList = new ArrayList<>();
                for (CmdActionBase cmdActionBase:selectedCmdList){
                    if (cmdActionBase != null) {
                        cmdActionList.add(cmdActionBase.toJsonString());
                    }
                }

                actionListJsonStr = cmdActionList.toString();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        return actionListJsonStr;
    }
}
