package com.westwhale.contollerapp.ui.main;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;

import com.westwhale.contollerapp.R;
import com.westwhale.contollerapp.application.WApp;
import com.westwhale.contollerapp.dev.CmdActionLister;
import com.westwhale.contollerapp.dev.ICmdCallback;
import com.westwhale.contollerapp.dev.WRoom;
import com.westwhale.contollerapp.eventbus.notify.NotifyPlayModeEvent;
import com.westwhale.contollerapp.eventbus.notify.NotifyPlayStateEvent;
import com.westwhale.contollerapp.eventbus.notify.NotifyPlayTimeEvent;
import com.westwhale.contollerapp.eventbus.notify.NotifyPlayingInfoEvent;
import com.westwhale.contollerapp.eventbus.notify.NotifyPlayingMediaDuration;
import com.westwhale.contollerapp.ui.base.activity.BaseActivity;
import com.westwhale.contollerapp.ui.base.fragment.BaseFragment;
import com.westwhale.contollerapp.ui.base.fragment.PlayerBaseFragment;
import com.westwhale.contollerapp.ui.cloudmusic.fragment.PlayerCloudMusicFragment;
import com.westwhale.contollerapp.ui.cloudstory.fragment.PlayerStoryFragment;
import com.westwhale.contollerapp.ui.localmusic.fragment.PlayerLocalMusicFragment;
import com.westwhale.contollerapp.utils.StatusBarUtil;
import com.westwhale.api.protocolapi.bean.media.Media;
import com.westwhale.api.protocolapi.bean.hostroom.PlayingInfo;
import com.westwhale.api.protocolapi.bean.hostroom.Room;
import com.westwhale.api.protocolapi.bean.hostroom.RoomStatInfo;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

/**
 * Description:
 * Author: chenyaoli
 * Date: 2018-12-03
 * History:
 */
public class PlayerActivity extends BaseActivity {

    private PlayerBaseFragment mPlayerFragment;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_player_playing);

        initView();
        initListener();

        initData();
    }

    @Override
    protected void onResume() {
        super.onResume();

//            WApp.Instance.getDevManager().getSelectedRoom().cmdGetRoomStatInfo();
        // 当显示该界面时，重新刷新歌曲信息
        if (WApp.Instance.getDevManager().getSelectedRoom() != null){
            WApp.Instance.getDevManager().getSelectedRoom().cmdGetRoomStatInfo(new CmdActionLister<RoomStatInfo>(PlayerActivity.this, new ICmdCallback<RoomStatInfo>() {
                @Override
                public void onSuccess(RoomStatInfo data) {
                    if (data != null) {

                        PlayingInfo playingInfo = new PlayingInfo();
                        playingInfo.roomState = data.roomStat;
                        playingInfo.media = data.media;
                        updatePlayingInfo(playingInfo);

                        if (mPlayerFragment != null){
                            mPlayerFragment.updatePlayMode(data.playMode);
                            mPlayerFragment.updatePlayStat(data.playStat);
                            mPlayerFragment.updatePlayTime(data.playTime);
                        }
                    }
                }

                @Override
                public void onFailed(int code, String msg) {

                }
            }));
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        // eventbus 取消注册
        EventBus.getDefault().unregister(this);
    }

    private void initData() {
        // eventbus 注册
        EventBus.getDefault().register(this);

        // 通过 WRoom 更新 media 信息，加快显示
        WRoom room = WApp.Instance.getDevManager().getSelectedRoom();
        if ( room != null ){
            PlayingInfo playingInfo = new PlayingInfo();
            playingInfo.roomState = room.getChannelStat();
            playingInfo.media = room.getPlayingMedia();

            updatePlayingInfo(playingInfo);

            updatePlayMode(room.getPlayMode());

            updatePlayStat(room.getPlayStat());

        }
    }

    private void initView() {

    }

    private void initListener() {

    }


    // 根据状态切换不同的底部 fragment
    public void switchPlayerFragment(BaseFragment fragment){
        getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.activity_player_container,fragment)
                .commit();

    }

    private void updatePlayingInfo(PlayingInfo playingInfo){
        if ((null == playingInfo) || !playingInfo.isAvailble()){
            return;
        }

        String roomState = playingInfo.roomState;
        String mediaSrc = (playingInfo.media != null) ? playingInfo.media.mediaSrc : "";
        boolean needCreateFragment = true;
        // 若当前SimpleFragment不为空，则判断当前房间状态及当前音源是否匹配，来更新信息
        if ( (mPlayerFragment != null) && (mPlayerFragment.getRoomStat().equals(roomState))) {
            if ((Room.ChannelState.INNORMAL).equals(roomState) || (Room.ChannelState.INPARTY).equals(roomState) ){
                if (mPlayerFragment.getMediaSrc().equals(mediaSrc)){
                    needCreateFragment = false;
                    mPlayerFragment.updateMedia(playingInfo.media);
                }
            }else {
                needCreateFragment = false;
                mPlayerFragment.updateMedia(playingInfo.media);
            }
        }

        if (needCreateFragment){
            mPlayerFragment = null;

            switch (roomState) {
                case Room.ChannelState.INCLOSED:
                    backToSearch();
                    break;
                case Room.ChannelState.INNORMAL:
                case Room.ChannelState.INPARTY:
                {
                    switch (mediaSrc){
                        case Media.CLOUD_MUSIC:
                            mPlayerFragment = new PlayerCloudMusicFragment();
                            mPlayerFragment.setRoomStat(Room.ChannelState.INNORMAL);
                            mPlayerFragment.updateMedia(playingInfo.media);
                            break;
                        case Media.LOCAL_MUSIC:
                            mPlayerFragment = new PlayerLocalMusicFragment();
                            mPlayerFragment.setRoomStat(Room.ChannelState.INNORMAL);
                            mPlayerFragment.updateMedia(playingInfo.media);
                            break;
                        case Media.CLOUD_STORY_TELLING:
                            mPlayerFragment = new PlayerStoryFragment();
                            mPlayerFragment.setRoomStat(Room.ChannelState.INNORMAL);
                            mPlayerFragment.updateMedia(playingInfo.media);
                            break;
                        case Media.CLOUD_NETFM:
                            break;
                        default:
                            break;
                    }


                    break;
                }
                case Room.ChannelState.INBT:
                    break;
                default:
                    break;
            }

            if (mPlayerFragment != null) {
                switchPlayerFragment(mPlayerFragment);
            }else{
                // 当无法创建对应的fragment时，则结束当前activity，以便返回上一个activity
                this.finish();
            }
        }
    }

    private void updatePlayMode(String playmode){
        if (mPlayerFragment != null){
            mPlayerFragment.updatePlayMode(playmode);
        }
    }

    private void updatePlayStat(String playstat){
        if (mPlayerFragment != null){
            mPlayerFragment.updatePlayStat(playstat);
        }
    }


    /**  接收所有的广播处理，然后再 调用 mSimplePlayerFragment对象的相关更新方法更新 */
    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onNotifyPlayingInfoEvent(NotifyPlayingInfoEvent event) {
        updatePlayingInfo(event.getPlayingInfo());
    }


    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onNotifyPlayingMediaDuration(NotifyPlayingMediaDuration event) {
        if (mPlayerFragment != null){
            mPlayerFragment.updatePlayingMediaDuration(event.getDuration());
        }
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onNotifyPlayStateEvent(NotifyPlayStateEvent event){
        updatePlayStat(event.getPlayStat());
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onNotifyPlayModeEvent(NotifyPlayModeEvent event){
        updatePlayMode(event.getPlayMode());
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onNotifyPlayTimeEvent(NotifyPlayTimeEvent event){
        if (mPlayerFragment != null){
            mPlayerFragment.updatePlayTime(event.getPlayTime());
        }
    }

    private void backToSearch(){
        Intent intent = new Intent(PlayerActivity.this, SearchDevActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);

        startActivity(intent);
    }

    @Override
    protected void setStatusBar() {
        StatusBarUtil.setTranslucentForImageViewInFragment(PlayerActivity.this,0, null);
    }
}
