package com.westwhale.contollerapp.ui.cloudmusic.fragment;

import android.util.Base64;
import android.widget.Toast;

import com.kingja.loadsir.callback.SuccessCallback;
import com.westwhale.contollerapp.R;
import com.westwhale.contollerapp.dev.CmdActionLister;
import com.westwhale.contollerapp.dev.ICmdCallback;
import com.westwhale.contollerapp.dev.WRoom;
import com.westwhale.contollerapp.ui.loadsircallback.EmptyCallback;
import com.westwhale.contollerapp.ui.loadsircallback.LoadingCallback;
import com.westwhale.api.protocolapi.bean.media.CloudMusic;
import com.westwhale.api.protocolapi.bean.albumSet.CloudAlbumSet;

import java.util.List;


public class CloudMusicListAlbumFragment extends CloudMusicListBaseFragment {

    private CloudAlbumSet mAlbumSet;

    public void updateAlbumSet(CloudAlbumSet albumSet){
        mAlbumSet = albumSet;
    }

    @Override
    public void initData() {
        showLoadCallBack(LoadingCallback.class);

        updateHeaderInfo();

        // 每次先清空原有数据
        if (mMusicAdapter != null){
            mMusicAdapter.clearDataList();
        }

        requestCloudResource();
    }

    @Override
    public boolean hasMoreData() {
        return false;
    }

    @Override
    public void loadMoreData() {
    }

    @Override
    public void requestCloudResource() {
        String albumMid = (mAlbumSet != null) ? mAlbumSet.albumMID : "";
        WRoom.cmdGetAlbumSong(albumMid, new CmdActionLister<List<CloudMusic>>(this, new ICmdCallback<List<CloudMusic>>() {
            @Override
            public void onSuccess(List<CloudMusic> data) {
                updateDataList(data);
            }

            @Override
            public void onFailed(int code, String msg) {
                updateDataList(null);
                Toast.makeText(getContext(),"GetAlbumSong获取失败:"+code,Toast.LENGTH_SHORT).show();
            }
        }));
    }

    @Override
    public void updateDataList(List<CloudMusic> list){
        if (list != null){

            mMusicAdapter.updateDataList(list);
            mMusicAdapter.notifyDataSetChanged();

            // 更新刷新等待状态
            mRefreshLayout.finishRefresh();
            mRefreshLayout.finishLoadMore();

            showLoadCallBack(SuccessCallback.class);
        }else{
            // 更新刷新等待状态
            mRefreshLayout.finishRefresh();
            mRefreshLayout.finishLoadMore();

            showLoadCallBack(EmptyCallback.class);
        }
    }

    private void updateHeaderInfo(){

        String toolbarTitle = getString(R.string.cloudmusic_album_title);
        String title = (mAlbumSet != null) ? mAlbumSet.name : "";
        String subTitle = (mAlbumSet != null) ? mAlbumSet.singer_name : "";
        String picUrl = "";
        if (mAlbumSet != null) {
            String pic = (mAlbumSet.pic_url != null) ? mAlbumSet.pic_url : "";
            picUrl = new String(Base64.decode(pic, Base64.DEFAULT));
        }

        updateHeader(toolbarTitle,title,subTitle,picUrl);
    }
}
