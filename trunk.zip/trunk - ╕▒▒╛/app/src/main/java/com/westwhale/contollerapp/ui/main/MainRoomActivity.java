package com.westwhale.contollerapp.ui.main;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.blankj.utilcode.util.ActivityUtils;
import com.kingja.loadsir.callback.Callback;
import com.kingja.loadsir.callback.SuccessCallback;
import com.kingja.loadsir.core.LoadService;
import com.kingja.loadsir.core.LoadSir;
import com.westwhale.contollerapp.R;
import com.westwhale.contollerapp.common.ImageTextItem;
import com.westwhale.contollerapp.dev.API_DEFINE;
import com.westwhale.contollerapp.dev.CmdActionLister;
import com.westwhale.contollerapp.dev.ICmdCallback;
import com.westwhale.contollerapp.dev.MachineType;
import com.westwhale.contollerapp.dev.WHost;
import com.westwhale.contollerapp.dev.WRoom;
import com.westwhale.contollerapp.eventbus.notify.NotifyDevStatEvent;
import com.westwhale.contollerapp.eventbus.notify.NotifyMuteEvent;
import com.westwhale.contollerapp.eventbus.notify.NotifyPlayingInfoEvent;
import com.westwhale.contollerapp.ui.airplayer.SimplePlayerAirplayFragment;
import com.westwhale.contollerapp.ui.auxiliary.SimplePlayerAuxFragment;
import com.westwhale.contollerapp.ui.bluetooth.SimplePlayerBTFragment;
import com.westwhale.contollerapp.ui.dlna.SimplePlayerDlnaFragment;
import com.westwhale.contollerapp.ui.loadsircallback.SimplePlayerPlaceholderCallback;
import com.westwhale.contollerapp.ui.main.adapter.SliderMenuAdapter;
import com.westwhale.contollerapp.ui.main.fragment.SimplePlayerDefaultFragment;
import com.westwhale.contollerapp.ui.scene.activity.SceneActivity;
import com.westwhale.contollerapp.ui.slider.AboutActivity;
import com.westwhale.contollerapp.ui.slider.DeviceNameActivity;
import com.westwhale.contollerapp.ui.slider.IpConfigActivity;
import com.westwhale.contollerapp.ui.slider.PartyActivity;
import com.westwhale.contollerapp.ui.slider.SwitchSourceActivity;
import com.westwhale.contollerapp.application.WApp;
import com.westwhale.contollerapp.eventbus.notify.NotifyPlayStateEvent;
import com.westwhale.contollerapp.eventbus.notify.NotifyPlayTimeEvent;
import com.westwhale.contollerapp.eventbus.notify.NotifyPlayingMediaDuration;
import com.westwhale.contollerapp.ui.base.activity.BaseActivity;
import com.westwhale.contollerapp.ui.base.fragment.BaseFragment;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import com.westwhale.contollerapp.ui.cloudmusic.fragment.SimplePlayerCloudMusicFragment;
import com.westwhale.contollerapp.ui.base.fragment.PlayerBaseFragment;
import com.westwhale.contollerapp.ui.cloudnetfm.fragment.SimplePlayerNetFmFragment;
import com.westwhale.contollerapp.ui.cloudstory.fragment.SimplePlayerStoryFragment;
import com.westwhale.contollerapp.ui.localmusic.fragment.SimplePlayerLocalMusicFragment;
import com.westwhale.contollerapp.ui.talk.activity.TalkActivity;
import com.westwhale.contollerapp.ui.talk.fragment.SimplePlayerTalkFragment;
import com.westwhale.contollerapp.ui.timer.activity.TimerActivity;
import com.westwhale.contollerapp.ui.timer.fragment.SimplePlayerClockTimerFragment;
import com.westwhale.contollerapp.utils.StatusBarUtil;
import com.westwhale.api.protocolapi.bean.media.CloudMusic;
import com.westwhale.api.protocolapi.bean.media.LocalAux;
import com.westwhale.api.protocolapi.bean.media.LocalMusic;
import com.westwhale.api.protocolapi.bean.media.Media;
import com.westwhale.api.protocolapi.bean.media.CloudNetFm;
import com.westwhale.api.protocolapi.bean.hostroom.PlayingInfo;
import com.westwhale.api.protocolapi.bean.hostroom.Room;
import com.westwhale.api.protocolapi.bean.hostroom.RoomStatInfo;
import com.westwhale.api.protocolapi.bean.media.Section;

import java.util.ArrayList;
import java.util.List;

/**
 * 指定房间的主界面： 在搜索界面，选择指定房间后，跳转到该界面中
 */
public class MainRoomActivity extends BaseActivity implements SliderMenuAdapter.CallBack {
    private static final String TAG = "MainRoomActivity";
    private DrawerLayout mDrawerLayout;
    private FrameLayout mSimplePlayerLayout;
    private RelativeLayout mRightMenuLayout;
    private TextView mRoomNameTv,mPlayingTv;
    private LinearLayout mSliderRebootLv,mSliderCloseLv;

    private SliderMenuAdapter mAdapter;
    private RecyclerView mMenuDataRv;

    private PlayerBaseFragment mSimplePlayerFragment;

    private String mMuteStat;

    protected LoadService mLoadService;

    private final int SLIDER_MENU_TYPE_SWITCHSRC = 1;
    private final int SLIDER_MENU_TYPE_MUTE = 2;
    private final int SLIDER_MENU_TYPE_PARTY = 3;
    private final int SLIDER_MENU_TYPE_TLAK = 4;
    private final int SLIDER_MENU_TYPE_TIMER = 5;
    private final int SLIDER_MENU_TYPE_SCENE = 6;
    private final int SLIDER_MENU_TYPE_IP = 7;
    private final int SLIDER_MENU_TYPE_DEVICENAME = 8;
    private final int SLIDER_MENU_TYPE_ABOUT = 9;
    private ImageTextItem mMuteMenuItem; // 静音状态Item


    public void showLoadCallBack(Class<? extends Callback> callback){
        if (mLoadService != null){
            mLoadService.showCallback(callback);
        }
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_room);

        initView();
        initListener();

        LoadSir mLoadSir = new LoadSir.Builder()
                .addCallback(new SimplePlayerPlaceholderCallback())
                .setDefaultCallback(SimplePlayerPlaceholderCallback.class)
                .build();

        FrameLayout frameLayout = findViewById(R.id.main_content_simpleplayer);
        mLoadService = mLoadSir.register(frameLayout, new Callback.OnReloadListener() {
            @Override
            public void onReload(View v) {
                requestRoomInfo();
            }
        });

        // eventbus 注册
        EventBus.getDefault().register(this);

        initData();

    }

    @Override
    protected void setStatusBar() {
//        StatusBarUtil.setColorForDrawerLayout(this, findViewById(R.id.main_room_drawerlayout), getResources().getColor(R.color.colorPrimary), 0);
        StatusBarUtil.setTranslucentForImageViewInFragment(MainRoomActivity.this,0, null);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        // eventbus 取消注册
        EventBus.getDefault().unregister(this);
    }

    @Override
    protected void onStart() {
        super.onStart();
    }

    @Override
    protected void onStop() {
        super.onStop();
    }

    @Override
    protected void onResume() {
        super.onResume();

        requestRoomInfo();
    }

    @Override
    protected void onPause() {
        super.onPause();
    }

    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
    }

    @Override
    public void onItemClick(ImageTextItem item, int pos) {
        if ((item != null) && (pos > -1)){
            switch (item.getType()){
                case SLIDER_MENU_TYPE_SWITCHSRC: {
                    mDrawerLayout.closeDrawer(Gravity.END);

                    Intent intent = new Intent(MainRoomActivity.this, SwitchSourceActivity.class);
                    startActivity(intent);
                    break;
                }
                case SLIDER_MENU_TYPE_MUTE: {
                    String newStat = API_DEFINE.CMD_MUTESTAT_MUTE;
                    if ((API_DEFINE.CMD_MUTESTAT_MUTE).equals(mMuteStat)){
                        newStat = API_DEFINE.CMD_MUTESTAT_NORMAL;
                    }
                    WRoom room = WApp.Instance.getDevManager().getSelectedRoom();
                    if (room != null){
                        WRoom.cmdSetMuteStat(newStat,new CmdActionLister<Boolean>(MainRoomActivity.this, new ICmdCallback<Boolean>() {
                            @Override
                            public void onSuccess(Boolean data) {

                            }

                            @Override
                            public void onFailed(int code, String msg) {
                                Toast.makeText(MainRoomActivity.this,"SetMuteStat失败:"+code,Toast.LENGTH_SHORT).show();
                            }
                        }));
                    }
                    updateMuteStat(newStat);
                    break;
                }
                case SLIDER_MENU_TYPE_PARTY: {
                    mDrawerLayout.closeDrawer(Gravity.END);
                    // 进入 Party
                    Intent intent = new Intent(MainRoomActivity.this, PartyActivity.class);
                    startActivity(intent);
                    break;
                }
                case SLIDER_MENU_TYPE_TLAK: {
                    mDrawerLayout.closeDrawer(Gravity.END);
                    // 进入 对讲管理
                    Intent intent = new Intent(MainRoomActivity.this, TalkActivity.class);
                    startActivity(intent);

                    break;
                }
                case SLIDER_MENU_TYPE_TIMER: {
                    mDrawerLayout.closeDrawer(Gravity.END);
                    // 进入 闹钟界面
                    Intent intent = new Intent(MainRoomActivity.this, TimerActivity.class);
                    startActivity(intent);

                    break;
                }
                case SLIDER_MENU_TYPE_SCENE: {
                    mDrawerLayout.closeDrawer(Gravity.END);
                    // 进入 场景管理
                    Intent intent = new Intent(MainRoomActivity.this, SceneActivity.class);
                    startActivity(intent);
                    break;
                }
                case SLIDER_MENU_TYPE_IP: {
                    mDrawerLayout.closeDrawer(Gravity.END);
                    // 进入IP配置界面
                    Intent intent = new Intent(MainRoomActivity.this, IpConfigActivity.class);
                    startActivity(intent);

                    break;
                }
                case SLIDER_MENU_TYPE_DEVICENAME: {
                    mDrawerLayout.closeDrawer(Gravity.END);

                    Intent intent = new Intent(MainRoomActivity.this, DeviceNameActivity.class);
                    startActivity(intent);
                    break;
                }
                case SLIDER_MENU_TYPE_ABOUT: {
                    mDrawerLayout.closeDrawer(Gravity.END);

                    Intent intent = new Intent(MainRoomActivity.this, AboutActivity.class);
                    startActivity(intent);
                    break;
                }
                default:
                    break;
            }
        }
    }

    private void initView() {
        // 主容器
        mDrawerLayout = findViewById(R.id.main_room_drawerlayout);

        // 侧边栏及相关控件
        mRightMenuLayout = findViewById(R.id.main_room_rightmenu);

        mMenuDataRv = findViewById(R.id.slider_menu_recyclerview);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        mMenuDataRv.setLayoutManager(linearLayoutManager);
        mAdapter = new SliderMenuAdapter();
        mAdapter.setCallBack(this);
        mMenuDataRv.setAdapter(mAdapter);
        mMenuDataRv.setHasFixedSize(true);
        // 设置下拉上拉无阴影效果
        mMenuDataRv.setOverScrollMode(View.OVER_SCROLL_NEVER);
        // 设置不可滑动
        mMenuDataRv.setNestedScrollingEnabled(false);


        mRoomNameTv = findViewById(R.id.slider_menu_title_name);
        mPlayingTv = findViewById(R.id.slider_menu_subtitle);

        mSliderRebootLv = findViewById(R.id.slider_menu_reboot_layout);
        mSliderCloseLv = findViewById(R.id.slider_menu_close_layout);

        // 简单播放器显示容器
        mSimplePlayerLayout = findViewById(R.id.main_content_simpleplayer);


    }


    private void initListener() {
        // 侧边栏中的 控件事件监听
        mSliderCloseLv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                WRoom room = WApp.Instance.getDevManager().getSelectedRoom();
                if (room != null){
                    WRoom.cmdSetDevStat(API_DEFINE.CMD_DEVSTAT_CLOSE,new CmdActionLister<Boolean>(MainRoomActivity.this, new ICmdCallback<Boolean>() {
                        @Override
                        public void onSuccess(Boolean data) {

                        }

                        @Override
                        public void onFailed(int code, String msg) {
                            Toast.makeText(MainRoomActivity.this,"SetDevStat失败:"+code,Toast.LENGTH_SHORT).show();
                        }
                    }));
                }
            }
        });

        mSliderRebootLv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 重启
                WHost host = WApp.Instance.getDevManager().getSelectedHost();
                if (host != null) {
                    host.cmdSystemRestart(null);
                }
            }
        });
    }


    private void initData() {
        boolean hasPartyFunc = false;
        boolean hasTalkFunc = false;
        boolean hasSceneFunc = false;
        WHost host = WApp.Instance.getDevManager().getSelectedHost();
        if (host != null) {
            hasPartyFunc = MachineType.hasFunc_Party(host.getHost().deviceType);
            hasTalkFunc = MachineType.hasFunc_Talk(host.getHost().deviceType);
            hasSceneFunc = MachineType.hasFunc_Scene(host.getHost().deviceType);
        }

        List<ImageTextItem> dataList = new ArrayList<>();

        dataList.add(new ImageTextItem(SLIDER_MENU_TYPE_SWITCHSRC, R.drawable.slider_menu_switch, getString(R.string.slider_menu_switchsource)));
        mMuteMenuItem = new ImageTextItem(SLIDER_MENU_TYPE_MUTE, R.drawable.volume_normal, getString(R.string.slider_menu_mute));
        dataList.add(mMuteMenuItem);
        if (hasPartyFunc){
            dataList.add(new ImageTextItem(SLIDER_MENU_TYPE_PARTY, R.drawable.slider_menu_party, getString(R.string.slider_menu_party)));
        }
        if (hasTalkFunc) {
            dataList.add(new ImageTextItem(SLIDER_MENU_TYPE_TLAK, R.drawable.slider_menu_talk, getString(R.string.slider_menu_talk)));
        }

        dataList.add(new ImageTextItem(SLIDER_MENU_TYPE_TIMER,R.drawable.slider_menu_clock,getString(R.string.slider_menu_timer)));
        if (hasSceneFunc) {
            dataList.add(new ImageTextItem(SLIDER_MENU_TYPE_SCENE, R.drawable.slider_menu_scene, getString(R.string.slider_menu_scene)));
        }
        dataList.add(new ImageTextItem(SLIDER_MENU_TYPE_IP,R.drawable.slider_menu_ip,getString(R.string.slider_menu_ipconfig)));
        dataList.add(new ImageTextItem(SLIDER_MENU_TYPE_DEVICENAME,R.drawable.slider_menu_device,getString(R.string.slider_menu_devicename)));
        dataList.add(new ImageTextItem(SLIDER_MENU_TYPE_ABOUT,R.drawable.slider_menu_about,getString(R.string.slider_menu_about)));

        mAdapter.setDataList(dataList);
        mAdapter.notifyDataSetChanged();

        // 初始化时，以 frag_main_tab 为第一个Fragment
        this.showFragmentNoBack(new MainRoomTabFragment());
    }

    public void showFragment(BaseFragment fragment) {
        getSupportFragmentManager()
                .beginTransaction()
                .add(R.id.main_content_container, fragment)
                .addToBackStack(null)
                .commit();
    }

    public void showFragmentNoBack(BaseFragment fragment) {
        getSupportFragmentManager()
                .beginTransaction()
                .add(R.id.main_content_container, fragment)
                .commit();
    }

    public void showDrawer() {
        mDrawerLayout.openDrawer(Gravity.END);
    }

    // 根据状态切换不同的底部 fragment
    public void switchSimplerPlayerFragment(BaseFragment fragment){
        getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.main_content_simpleplayer,fragment)
                .commit();

    }

    public void requestRoomInfo(){
        // 当显示该界面时，重新刷新歌曲信息
        if (WApp.Instance.getDevManager().getSelectedRoom() != null){
//            WApp.Instance.getDevManager().getSelectedRoom().cmdGetRoomStatInfo();
            WApp.Instance.getDevManager().getSelectedRoom().cmdGetRoomStatInfo(new CmdActionLister<RoomStatInfo>(MainRoomActivity.this, new ICmdCallback<RoomStatInfo>() {
                @Override
                public void onSuccess(RoomStatInfo data) {
                    if (data != null) {
                        updateMuteStat(data.muteStat);

                        PlayingInfo playingInfo = new PlayingInfo();
                        playingInfo.roomState = data.roomStat;
                        playingInfo.media = data.media;
                        playingInfo.talkId = data.talkId;
                        playingInfo.partyId = data.partyId;
                        updatePlayingInfo(playingInfo);

                        if (mSimplePlayerFragment != null){
                            mSimplePlayerFragment.updatePlayMode(data.playMode);
                            // 做了更新优化，避免在该cmd中获取的播放状态与实际的播放状态不一致
                            String playStat = WApp.Instance.getDevManager().getSelectedRoom().getPlayStat();
//                            mSimplePlayerFragment.updatePlayStat(data.playStat);
                            mSimplePlayerFragment.updatePlayStat(playStat);
                            mSimplePlayerFragment.updatePlayTime(data.playTime);
                        }
                    }
                }

                @Override
                public void onFailed(int code, String msg) {

                }
            }));
        }
    }


    /**  接收所有的广播处理，然后再 调用 mSimplePlayerFragment对象的相关更新方法更新 */
//    @Subscribe(threadMode = ThreadMode.MAIN)
//    public void onNotifyPlayingMediaEvent(NotifyPlayingMediaEvent event) {
//        // 若音源发生变化，则更新对应的Fragment；若只是media变化，则只需要更新对应内容
//        updatePlayingMedia(event.getPlayingMedia());
//
//    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onNotifyPlayingInfoEvent(NotifyPlayingInfoEvent event) {
        if (ActivityUtils.getTopActivity() != this){
            return;
        }

        updatePlayingInfo(event.getPlayingInfo());
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onNotifyPlayingMediaDuration(NotifyPlayingMediaDuration event) {
        if (ActivityUtils.getTopActivity() != this){
            return;
        }


        if (mSimplePlayerFragment != null){
            mSimplePlayerFragment.updatePlayingMediaDuration(event.getDuration());
        }
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onNotifyPlayStateEvent(NotifyPlayStateEvent event){
        if (ActivityUtils.getTopActivity() != this){
            return;
        }

        if (mSimplePlayerFragment != null){
            mSimplePlayerFragment.updatePlayStat(event.getPlayStat());
        }
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onNotifyPlayTimeEvent(NotifyPlayTimeEvent event){
        if (ActivityUtils.getTopActivity() != this){
            return;
        }


        if (mSimplePlayerFragment != null){
            mSimplePlayerFragment.updatePlayTime(event.getPlayTime());
        }
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onNotifyDevStatEvent(NotifyDevStatEvent event){
        if (ActivityUtils.getTopActivity() != this){
            return;
        }


        String devstat = event.getDevStat();
        if ((API_DEFINE.CMD_DEVSTAT_CLOSE).equals(devstat)){
            backToSearch();
        }
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onNotifyMuteEvent(NotifyMuteEvent event){
        if (ActivityUtils.getTopActivity() != this){
            return;
        }

        updateMuteStat(event.getMuteStat());
    }

    private void updateMuteStat(String mutestat){
        mMuteStat = mutestat;
        int mutePicResourceId = R.drawable.volume_mute;
        if (!(API_DEFINE.CMD_MUTESTAT_MUTE).equals(mutestat)){
            mutePicResourceId = R.drawable.volume_normal;
        }

        if (mMuteMenuItem != null){
            mMuteMenuItem.setImageRes(mutePicResourceId);
        }

        if (mAdapter != null){
            mAdapter.updateItem(mMuteMenuItem);
        }

    }

    private void updatePlayingInfo(PlayingInfo playingInfo){
        if ((null == playingInfo) || !playingInfo.isAvailble()){
            return;
        }

        showLoadCallBack(SuccessCallback.class);

        WRoom room = WApp.Instance.getDevManager().getSelectedRoom();
        String roomName = (room != null) ? room.getRoomName() : "";
        updateSliderHeaderInfo(roomName,playingInfo.roomState,playingInfo.media);

        String roomState = playingInfo.roomState;
        String mediaSrc = (playingInfo.media != null) ? playingInfo.media.mediaSrc : "";

        boolean needCreateFragment = true;
        // 若当前SimpleFragment不为空，则判断当前房间状态及当前音源是否匹配，来更新信息
        if ( (mSimplePlayerFragment != null) && (mSimplePlayerFragment.getRoomStat().equals(roomState))) {
            if ((Room.ChannelState.INNORMAL).equals(roomState) || (Room.ChannelState.INPARTY).equals(roomState) ){
                if (mSimplePlayerFragment.getMediaSrc().equals(mediaSrc)){
                    needCreateFragment = false;
                    mSimplePlayerFragment.updateMedia(playingInfo.media);
                }
            }else {
                needCreateFragment = false;
                mSimplePlayerFragment.updateMedia(playingInfo.media);
            }
        }

        if (needCreateFragment){
            mSimplePlayerFragment = null;

            switch (roomState) {
                case Room.ChannelState.INCLOSED:
                    backToSearch();
                    break;
                case Room.ChannelState.INNORMAL:
                case Room.ChannelState.INPARTY:
                {
                    switch (mediaSrc){
                        case Media.CLOUD_MUSIC:
                            mSimplePlayerFragment = new SimplePlayerCloudMusicFragment();
                            mSimplePlayerFragment.setRoomStat(Room.ChannelState.INNORMAL);
                            mSimplePlayerFragment.updateMedia(playingInfo.media);
                            break;
                        case Media.LOCAL_MUSIC:
                            mSimplePlayerFragment = new SimplePlayerLocalMusicFragment();
                            mSimplePlayerFragment.setRoomStat(Room.ChannelState.INNORMAL);
                            mSimplePlayerFragment.updateMedia(playingInfo.media);
                            break;
                        case Media.CLOUD_STORY_TELLING:
                            mSimplePlayerFragment = new SimplePlayerStoryFragment();
                            mSimplePlayerFragment.setRoomStat(Room.ChannelState.INNORMAL);
                            mSimplePlayerFragment.updateMedia(playingInfo.media);
                            break;
                        case Media.CLOUD_NETFM:
                            mSimplePlayerFragment = new SimplePlayerNetFmFragment();
                            mSimplePlayerFragment.setRoomStat(Room.ChannelState.INNORMAL);
                            mSimplePlayerFragment.updateMedia(playingInfo.media);
                            break;
                        case Media.LOCAL_AUX:
                            mSimplePlayerFragment = new SimplePlayerAuxFragment();
                            mSimplePlayerFragment.setRoomStat(Room.ChannelState.INNORMAL);
                            mSimplePlayerFragment.updateMedia(playingInfo.media);
                            break;
                        default:
                            break;
                    }


                    break;
                }
                case Room.ChannelState.INBT:
                    mSimplePlayerFragment = new SimplePlayerBTFragment();
                    mSimplePlayerFragment.setRoomStat(Room.ChannelState.INBT);
                    break;
                case Room.ChannelState.INAIRPLAY:
                    mSimplePlayerFragment = new SimplePlayerAirplayFragment();
                    mSimplePlayerFragment.setRoomStat(Room.ChannelState.INAIRPLAY);
                    break;
                case Room.ChannelState.INDLNA:
                    mSimplePlayerFragment = new SimplePlayerDlnaFragment();
                    mSimplePlayerFragment.setRoomStat(Room.ChannelState.INDLNA);
                    break;
                case Room.ChannelState.INTALK:
                    mSimplePlayerFragment = new SimplePlayerTalkFragment();
                    mSimplePlayerFragment.setRoomStat(Room.ChannelState.INTALK);
                    break;
                case Room.ChannelState.INCLOCK:
                    mSimplePlayerFragment = new SimplePlayerClockTimerFragment();
                    mSimplePlayerFragment.setRoomStat(Room.ChannelState.INCLOCK);
                    break;
                default:
                    break;
            }

            if (mSimplePlayerFragment == null){
                mSimplePlayerFragment = new SimplePlayerDefaultFragment();
                mSimplePlayerFragment.setRoomStat(roomState);
            }

            if (mSimplePlayerFragment != null) {
                switchSimplerPlayerFragment(mSimplePlayerFragment);
            }
        }
    }

    private void backToSearch(){
        Intent intent = new Intent(MainRoomActivity.this, SearchDevActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);

        startActivity(intent);
    }

    private void updateSliderHeaderInfo(String roomName,String roomStat,Media media) {
        String name = (roomName != null) ? roomName : "";
        String statInfo = "(未知)";
        String playingInfo = "";
        if (roomStat != null) {
            switch (roomStat){
                case Room.ChannelState.INNORMAL:
                case Room.ChannelState.INPARTY:
                {
                    statInfo = "";
                    if (Room.ChannelState.INPARTY.equals(roomStat)){
                        statInfo = "(Party)";
                    }

                    if (null == media){
                        playingInfo = "无播放信息";
                    } else {
                        switch(media.mediaSrc){
                            case Media.LOCAL_MUSIC:
                                playingInfo = "本地音乐: " + ((LocalMusic)media).songName;
                                break;
                            case Media.CLOUD_MUSIC:
                                playingInfo = "云音乐: " + ((CloudMusic)media).songName;
                                break;
                            case Media.CLOUD_NETFM:
                                playingInfo = "网络电台: " + ((CloudNetFm)media).programName;
                                break;
                            case Media.CLOUD_STORY_TELLING:
                                playingInfo = "语言节目: " + ((Section)media).sectionName;
                                break;
                            case Media.LOCAL_AUX:
                                playingInfo = "AUX: " + (((LocalAux)media).auxId+1);
                                break;
                            default:
                                playingInfo = "云音乐:";
                                break;
                        }
                    }
                    break;
                }
                case Room.ChannelState.INBT:
                    statInfo = "(蓝牙)";
                    playingInfo = "蓝牙播放中";
                    break;
                case Room.ChannelState.INTALK:
                    statInfo = "(对讲)";
                    playingInfo = "对讲中";
                    break;
                default:
                    statInfo = "(" + roomStat + ")";
                    break;
            }
        }

        name = name + statInfo;
        mRoomNameTv.setText(name);
        mPlayingTv.setText(playingInfo);
    }


}
