package com.westwhale.contollerapp.eventbus.notify;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.westwhale.api.protocolapi.BaProtocolBean;
import com.westwhale.contollerapp.dev.API_DEFINE;

public class NotifyDevStatJsonEvent {
    private BaProtocolBean mHead;

    public NotifyDevStatJsonEvent(BaProtocolBean head){
        mHead = head;
    }

    public String getDevStat() {
        String devStat = null;
        if (mHead != null){
            String argStr = mHead.arg;
            try {
                JSONObject argJson = JSON.parseObject(argStr);
                devStat = argJson.getString(API_DEFINE.CMD_KEY_DEVSTAT);
            }catch (Exception e){
                e.printStackTrace();
            }
        }

        return devStat;
    }

    public String getSendId(){
        String sendId = null;
        if (mHead != null){
            sendId = mHead.sendId;
        }

        return sendId;
    }
}
