package com.westwhale.contollerapp.ui.cloudmusic.fragment;

import android.animation.ObjectAnimator;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.view.ViewPager;
import android.util.Base64;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.LinearInterpolator;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.SeekBar;
import android.widget.TextView;

import com.blankj.utilcode.util.BarUtils;
import com.blankj.utilcode.util.ToastUtils;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.request.RequestOptions;
import com.westwhale.contollerapp.R;
import com.westwhale.contollerapp.application.WApp;
import com.westwhale.contollerapp.dev.API_DEFINE;
import com.westwhale.contollerapp.dev.CmdActionLister;
import com.westwhale.contollerapp.dev.ICmdCallback;
import com.westwhale.contollerapp.dev.MachineType;
import com.westwhale.contollerapp.dev.WHost;
import com.westwhale.contollerapp.dev.WRoom;
import com.westwhale.contollerapp.ui.cloudmusic.adapter.CloudPlayerPagerAdapter;
import com.westwhale.contollerapp.ui.favorite.songsheet.dialog.FavoriteAddMediaDialog;
import com.westwhale.contollerapp.ui.main.dialog.VolumeDialog;
import com.westwhale.contollerapp.ui.cloudmusic.dialog.CloudMusicPlayListDialog;
import com.westwhale.contollerapp.ui.base.fragment.PlayerBaseFragment;
import com.westwhale.contollerapp.ui.scene.dialog.SceneExecuteDialog;
import com.westwhale.contollerapp.ui.timer.dialog.DelayTimerDialog;
import com.westwhale.contollerapp.ui.widget.lrcview.LrcView;
import com.westwhale.contollerapp.utils.CommonUtils;
import com.westwhale.api.protocolapi.bean.media.CloudMusic;
import com.westwhale.api.protocolapi.bean.media.Media;
import com.westwhale.api.protocolapi.bean.hostroom.Room;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;

import jp.wasabeef.glide.transformations.BlurTransformation;

public class PlayerCloudMusicFragment extends PlayerBaseFragment {
    private final static String TAG = "CloudMusicPlayer";

    private RelativeLayout mPlayerContentLayout;
    private ImageView mBackgroudIv,mBackgroudMongoIv,mPlayPicIv,mBackforwardIv;
    private ImageView mPlayModeIv,mPlayPrevIv,mPlayNextIv,mPlayStatIv,mPlaylistIv;
    private ImageView mVolumeIv,mAddFavoriteIv,mDownloadIv,mSceneIv,mRoomTimerIv;

    private TextView mTitleTv,mSubTitleTv, mPlayTimeTv,mDurationTv;
    private SeekBar mSeekbar;
    private ViewPager mViewPager;
    private LrcView mLrcView;
    private LinearLayout mCenterAlbumInfoLv,mCenterLrcLv;

    private ObjectAnimator mProgressAnimator;   //进度条旋转动画
    private ObjectAnimator mCircleAnimator;    //图片旋转动画

    private List<View> mViewPagerContent;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        // 先显示加载动画，针对布局做一些初始化
        View view = inflater.inflate(R.layout.frag_netmusic_player,container,false);

        initView(view);

        initSystemBar();

        initListener();

        updateMediaInfo();
        updatePlayStatInfo();
        updatePlayModeInfo();

        return view;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
    }

    @Override
    public void onPause() {
        super.onPause();
    }

    @Override
    public void onResume() {
        super.onResume();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();

        if (mProgressAnimator != null) {
            mProgressAnimator.cancel();
        }
        if (mCircleAnimator != null) {
            mCircleAnimator.cancel();
        }
    }

    private void initView(View view) {
        if (null == view) {
            return;
        }

        mPlayerContentLayout = view.findViewById(R.id.player_content_layout);
        mTitleTv = view.findViewById(R.id.player_title);

        mBackforwardIv = view.findViewById(R.id.player_back);
        mBackgroudIv = view.findViewById(R.id.player_bg);
        mBackgroudMongoIv = view.findViewById(R.id.player_bg_mongo);

        mViewPager = view.findViewById(R.id.player_center_viewpager);

        View coverView = LayoutInflater.from(getContext()).inflate(R.layout.frag_netmusic_player_albumpic, null);
        View lrcView = LayoutInflater.from(getContext()).inflate(R.layout.frag_netmusic_player_lrc, null);
        mCenterAlbumInfoLv = coverView.findViewById(R.id.player_center_album_layout);
        mPlayPicIv = coverView.findViewById(R.id.player_media_pic);
        mSubTitleTv = coverView.findViewById(R.id.player_center_title);

        mViewPagerContent = new ArrayList<>(2);
        mViewPagerContent.add(coverView);
        mViewPagerContent.add(lrcView);
        mViewPager.setAdapter(new CloudPlayerPagerAdapter(mViewPagerContent));
        mViewPager.setOffscreenPageLimit(mViewPagerContent.size());


        mCenterLrcLv = lrcView.findViewById(R.id.player_center_lrc_layout);
        mLrcView = lrcView.findViewById(R.id.player_center_lrc);

        mPlayModeIv = view.findViewById(R.id.player_mode);
        mPlayPrevIv = view.findViewById(R.id.player_pre);
        mPlayStatIv = view.findViewById(R.id.player_play);
        mPlayNextIv = view.findViewById(R.id.playing_next);
        mPlaylistIv = view.findViewById(R.id.playing_playlist);

        mVolumeIv = view.findViewById(R.id.player_volume);
        mAddFavoriteIv = view.findViewById(R.id.player_add);
        mDownloadIv = view.findViewById(R.id.player_down);
        mSceneIv = view.findViewById(R.id.player_scene);
        mRoomTimerIv = view.findViewById(R.id.player_timer);

        mPlayTimeTv = view.findViewById(R.id.player_playtime);
        mDurationTv = view.findViewById(R.id.player_duration);

        mSeekbar = view.findViewById(R.id.player_seekbar);

        initCireAnimator(mPlayPicIv);
    }

    private void initListener() {

        mBackforwardIv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 返回按钮
                if (getActivity() != null){
                    getActivity().onBackPressed();
                }
            }
        });

        mCenterAlbumInfoLv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 显示歌词界面
                mViewPager.setCurrentItem(1);
            }
        });

        mCenterLrcLv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 显示专辑图片界面
                mViewPager.setCurrentItem(0);
            }
        });

        mLrcView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 显示专辑图片界面
                mViewPager.setCurrentItem(0);
            }
        });

        mLrcView.setDraggable(true, new LrcView.OnPlayClickListener() {
            @Override
            public boolean onPlayClick(long time) {
                setPlayTime((int)(time/1000),new CmdActionLister<Boolean>(PlayerCloudMusicFragment.this, new ICmdCallback<Boolean>() {
                    @Override
                    public void onSuccess(Boolean data) {
                    }

                    @Override
                    public void onFailed(int code, String msg) {

                    }
                }));

                return true;
            }
        });

        mPlayModeIv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 设置播放模式
                String nextPlayMode = "";
                switch (mPlayMode){
                    case  API_DEFINE.CMD_PLAYMODE_CIRCLE:
                        nextPlayMode = API_DEFINE.CMD_PLAYMODE_NORMAL;
                        break;
                    case  API_DEFINE.CMD_PLAYMODE_NORMAL:
                        nextPlayMode = API_DEFINE.CMD_PLAYMODE_SHUFFLE;
                        break;
                    case  API_DEFINE.CMD_PLAYMODE_SHUFFLE:
                        nextPlayMode = API_DEFINE.CMD_PLAYMODE_SINGLE;
                        break;
                    case  API_DEFINE.CMD_PLAYMODE_SINGLE:
                        nextPlayMode = API_DEFINE.CMD_PLAYMODE_CIRCLE;
                        break;
                    default:
                        break;
                }

                if (!nextPlayMode.isEmpty()){
                    setPlayMode(nextPlayMode,null);
                    updatePlayMode(nextPlayMode);
                }
            }
        });

        mPlayPrevIv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 上一首
                playPre();
            }
        });

        mPlayStatIv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 点击播放/暂停，需设置播放按钮（因为Frame的可触控面积大于播放按钮）
                if ((API_DEFINE.CMD_PLAYSTAT_PLAY).equals(mPlayStat)){
                    playPause();
                    updatePlayStat(API_DEFINE.CMD_PLAYSTAT_PAUSE);
                }else{
                    playResume();
                    updatePlayStat(API_DEFINE.CMD_PLAYSTAT_PLAY);
                }
            }
        });

        mPlayNextIv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 下一首
                playNext();
            }
        });

        mPlaylistIv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 弹出播放列表
                CloudMusicPlayListDialog dialog = new CloudMusicPlayListDialog();
                dialog.show(getChildFragmentManager(),"Playlist Dialog");
            }
        });

        mVolumeIv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //  音量
                VolumeDialog volumeDialog = new VolumeDialog();
                volumeDialog.show(getChildFragmentManager(),"Volume Dialog");
            }
        });
        
        mAddFavoriteIv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 收藏
                if (mMedia != null){
                    FavoriteAddMediaDialog favoriteDialog = new FavoriteAddMediaDialog();
                    List<Media> medialist = new ArrayList<>();
                    medialist.add(mMedia);
                    favoriteDialog.updateMediaList(Media.CLOUD_MUSIC, medialist);
                    favoriteDialog.show(getChildFragmentManager(),FavoriteAddMediaDialog.TAG);
                }
            }
        });
        
        mDownloadIv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 下载
                if (mMedia instanceof CloudMusic){
                    WRoom room = WApp.Instance.getDevManager().getSelectedRoom();
                    if (room != null){
                        List<CloudMusic> medialist = new ArrayList<>();
                        medialist.add((CloudMusic) mMedia);

                        room.cmdDownloadMusicList("",medialist,new CmdActionLister<Boolean>(PlayerCloudMusicFragment.this, new ICmdCallback<Boolean>() {
                            @Override
                            public void onSuccess(Boolean data) {
                                if (data) {
                                    ToastUtils.showShort("下载成功");
                                }
                            }

                            @Override
                            public void onFailed(int code, String msg) {
                                ToastUtils.showShort("下载失败:%d",code);
                            }
                        }));
                    }
                }
            }
        });
        
        mSceneIv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 场景
                boolean hasFunc_Scene = false;
                WHost host = WApp.Instance.getDevManager().getSelectedHost();
                if (host != null) {
                    hasFunc_Scene = MachineType.hasFunc_Scene(host.getHost().deviceType);
                }
                if (hasFunc_Scene) {
                    SceneExecuteDialog dialog = new SceneExecuteDialog();
                    dialog.show(getChildFragmentManager(), SceneExecuteDialog.TAG);
                }
            }
        });
        
        mRoomTimerIv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 定时器
                DelayTimerDialog dialog = new DelayTimerDialog();
                dialog.show(getChildFragmentManager(),DelayTimerDialog.TAG);
            }
        });

        mSeekbar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (seekBar != null){
                    long millisecond = progress * 1000;
                    SimpleDateFormat timeFormat = new SimpleDateFormat("mm:ss", Locale.CHINA);
                    if (progress >= 60*60){
                        timeFormat =  new SimpleDateFormat("hh:mm:ss", Locale.CHINA);
                    }
                    timeFormat.setTimeZone(TimeZone.getTimeZone("GMT+00:00"));
                    // time为转换格式后的字符串
                    String timeStr = timeFormat.format(new Date(millisecond));

                    mPlayTimeTv.setText(String.valueOf(timeStr));

                    mLrcView.updateTime(millisecond);
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                if (seekBar != null){
                    int playtime = seekBar.getProgress();
                    setPlayTime(playtime,null);
                    updatePlayTime(playtime);
                }
            }
        });
    }

    @Override
    public boolean isPlayerValid() {
        if ((Room.ChannelState.INNORMAL).equals(mRoomStat) || (Room.ChannelState.INPARTY).equals(mRoomStat) ){
            return true;
        }

        return false;
    }

    @NonNull
    @Override
    public String getMediaSrc() {
        return Media.CLOUD_MUSIC;
    }

    @Override
    public void updateMediaInfo() {
        if (mMedia instanceof CloudMusic) {
            CloudMusic media = (CloudMusic)mMedia;
            // 设置主标题和副标题
            String songName = (media.songName==null) ? getString(R.string.cloudmusic_unknown) : media.songName;
            String subtitle = songName + "-" + media.getSingersName();

            mTitleTv.setText(songName);
            mSubTitleTv.setText(subtitle);

            // 设置图片,首先 base64 解码
            String pic = (media.picUrl != null) ? media.picUrl : "";
            String url = pic;
            if (pic.isEmpty()){
                // 则根据歌曲信息 生成一个picUrl
                url = CommonUtils.getCloudMusicPic(media.albumMid,media.singer);
            }else {
                if (!url.startsWith("http://")) {
                    url = new String(Base64.decode(pic.getBytes(), Base64.DEFAULT));
                }
            }
            RequestOptions requestOptions = RequestOptions.circleCropTransform().diskCacheStrategy(DiskCacheStrategy.NONE) //不做磁盘缓存
                    .placeholder(R.drawable.simple_player_default)  //未加载图片之前显示的图片
                    .error(R.drawable.simple_player_default);       //错误时显示的图片
//                      .skipMemoryCache(true);//不做内存缓存
            // 在Fragment未 attach Activity时，会抛出activity null 异常
            Glide.with(this)
                    .load(url)
                    .apply(requestOptions)
                    .into(mPlayPicIv);


            RequestOptions blurRequestOptions = RequestOptions.bitmapTransform(new BlurTransformation( 22, 3)).diskCacheStrategy(DiskCacheStrategy.NONE) //不做磁盘缓存
                    .override(600, 600);
            Glide.with(mContext)
                    .load(url)
                    .apply(blurRequestOptions)
                    .into(mBackgroudIv);

            //加载歌词
            loadSongLyric(media.songMid);

            // 更新总时长
            mPlayTime = 0;
            mDuration = 0;
            try{
                int duration = Integer.parseInt(media.duration);
                this.updatePlayingMediaDuration(duration);
            }catch (Exception e){
                e.printStackTrace();
            }
        }
    }

    private void loadSongLyric(String songMid) {
        WRoom room = WApp.Instance.getDevManager().getSelectedRoom();
        if (room != null){
            WRoom.cmdGetSongLyric(songMid,new CmdActionLister<String>(PlayerCloudMusicFragment.this, new ICmdCallback<String>() {
                @Override
                public void onSuccess(String data) {
                    mLrcView.loadLrc(data);
                }

                @Override
                public void onFailed(int code, String msg) {

                }
            }));
        }
    }

    @Override
    public void updateMediaDurationInfo() {
        // 更新总时长时，重新获取当前播放时间
        if (mDuration > 0) {
            getPlayTime();
        }
    }

    @Override
    public void updatePlayStatInfo() {
        // 更新播放状态
        if ((API_DEFINE.CMD_PLAYSTAT_PLAY).equals(mPlayStat)){
            mPlayStatIv.setImageDrawable(getResources().getDrawable(R.drawable.player_pause));

            resumeCircleAnimator();

            resumeProgressAnimator();
        }else {
            mPlayStatIv.setImageDrawable(getResources().getDrawable(R.drawable.player_play));

            pauseCircleAnimator();

            pauseProgressAnimator();
        }
    }

    @Override
    public void updatePlayTimeInfo() {
        updateProgress();

        if (mLrcView.hasLrc()) {
            mLrcView.updateTime(mPlayTime*1000);
        }
    }

    @Override
    public void updatePlayModeInfo() {
        int drawableId = R.drawable.player_mode_circle;
        if (mPlayMode != null) {
            switch (mPlayMode) {
                case API_DEFINE.CMD_PLAYMODE_NORMAL:
                    drawableId = R.drawable.player_mode_normal;
                    break;
                case API_DEFINE.CMD_PLAYMODE_CIRCLE:
                    drawableId = R.drawable.player_mode_circle;
                    break;
                case API_DEFINE.CMD_PLAYMODE_SHUFFLE:
                    drawableId = R.drawable.player_mode_random;
                    break;
                case API_DEFINE.CMD_PLAYMODE_SINGLE:
                    drawableId = R.drawable.player_mode_single;
                    break;
                default:
                    break;
            }
        }

        mPlayModeIv.setImageDrawable(getResources().getDrawable(drawableId));
    }

    public void updateProgress(){
        // 500秒
        long millisecond = mPlayTime * 1000;
        SimpleDateFormat timeFormat = new SimpleDateFormat("mm:ss", Locale.CHINA);
        if (mPlayTime >= 60*60){
            timeFormat =  new SimpleDateFormat("hh:mm:ss", Locale.CHINA);
        }
        timeFormat.setTimeZone(TimeZone.getTimeZone("GMT+00:00"));
        // time为转换格式后的字符串
        String timeStr = timeFormat.format(new Date(millisecond));
        mPlayTimeTv.setText(String.valueOf(timeStr));


        SimpleDateFormat dateFormat = new SimpleDateFormat("mm:ss", Locale.CHINA);
        if (mDuration >= 60*60){
            dateFormat =  new SimpleDateFormat("hh:mm:ss", Locale.CHINA);
        }
        dateFormat.setTimeZone(TimeZone.getTimeZone("GMT+00:00"));
        millisecond = mDuration * 1000;
        String durationStr = dateFormat.format(new Date(millisecond));
        mDurationTv.setText(String.valueOf(durationStr));

        initProgressAnimator(mPlayTime,mDuration);

        if ((API_DEFINE.CMD_PLAYSTAT_PLAY).equals(mPlayStat)) {
            resumeProgressAnimator();
        }

    }

    /******************************** 进度条转动 ***********************************/
    private void initProgressAnimator(int beginTime, int duration) {
        if (mProgressAnimator != null){
            mProgressAnimator.removeAllListeners();
            mProgressAnimator.cancel();
            mProgressAnimator = null;
        }
        if ((duration <= 0) || (beginTime > duration)){
            return;
        }

        mSeekbar.setMax(duration);
        mProgressAnimator = ObjectAnimator.ofInt(mSeekbar, "progress", beginTime,duration);
        mProgressAnimator.setInterpolator(new LinearInterpolator());
        mProgressAnimator.setRepeatCount(0);
        mProgressAnimator.setDuration((duration - beginTime)*1000);
    }


    private void resumeProgressAnimator() {
        if (mProgressAnimator != null){
            if (mProgressAnimator.isStarted()){
                mProgressAnimator.resume();
            }else{
                mProgressAnimator.start();
            }
        }
    }

    private void pauseProgressAnimator() {
        if (mProgressAnimator != null){
            mProgressAnimator.pause();
        }
    }


    /******************************** 图片转动 ***********************************/
    private void initCireAnimator(@NonNull View view) {
        mCircleAnimator = ObjectAnimator.ofFloat(view, "rotation", 0.0f, 360.0f);
        mCircleAnimator.setDuration(30*1000);
        mCircleAnimator.setInterpolator(new LinearInterpolator());
        mCircleAnimator.setRepeatCount(-1);
        mCircleAnimator.setRepeatMode(ObjectAnimator.RESTART);
    }

    private void resumeCircleAnimator() {
        if (mCircleAnimator != null){
            if (mCircleAnimator.isStarted()){
                mCircleAnimator.resume();
            }else{
                mCircleAnimator.start();
            }
        }
    }

    private void pauseCircleAnimator() {
        if (mCircleAnimator != null){
            mCircleAnimator.pause();
        }
    }


    /**
     * 沉浸式状态栏
     */
    private void initSystemBar() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            int top = BarUtils.getStatusBarHeight();
            mPlayerContentLayout.setPadding(0, top, 0, 0);
        }
    }
}
