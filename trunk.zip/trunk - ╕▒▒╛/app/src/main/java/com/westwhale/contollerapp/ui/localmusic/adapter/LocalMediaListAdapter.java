package com.westwhale.contollerapp.ui.localmusic.adapter;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.westwhale.contollerapp.R;
import com.westwhale.api.protocolapi.bean.LocalDirectory;
import com.westwhale.api.protocolapi.bean.media.LocalMusic;
import com.westwhale.api.protocolapi.bean.media.Media;

import java.util.ArrayList;
import java.util.List;

/**
 * Description:
 * Author: chenyaoli
 * Date: 2018-12-14
 * History
 *
 */
public class LocalMediaListAdapter extends RecyclerView.Adapter {
    private final static int TYPE_ITEM_MUSIC = 1;
    private final static int TYPE_ITEM_DIRECTORY = 2;

    private List<Object> mItemList;
    private CallBack mCallBack;
    private int mLastDirectoryIndex = 0;

    public interface CallBack{
        void onSongItemClick(LocalMusic songItem);
        void onSongItemMoreClick(LocalMusic songItem);
        void onDirectoryClick(LocalDirectory.Directory item);
        void onDirecotryMoreClick(LocalDirectory.Directory item);
    }

    public List<Object> getDataList(){
        return mItemList;
    }

    public void clearDataList(){
        if (mItemList != null){
            this.mItemList.clear();
            mItemList = null;
        }
        notifyDataSetChanged();
    }

    public void addToDataList(List<Object> itemList){
        if (mItemList == null){
            mItemList = new ArrayList<>();
        }
        mItemList.addAll(itemList);
    }

    public void addToDataList(LocalDirectory directory){
        if (mItemList == null){
            mItemList = new ArrayList<>();
        }

        int lastNum = getItemCount();
        List<LocalDirectory.Directory> directories = directory.directoryList;
        mItemList.addAll(directories);
        mLastDirectoryIndex = mLastDirectoryIndex + directories.size();

        List<Media> mediaList = directory.mediaList;
        List<LocalMusic> musicList = new ArrayList<>();
        if (mediaList != null){
            for (int i=0; i < mediaList.size(); i++){
                if (mediaList.get(i) instanceof LocalMusic){
                    musicList.add((LocalMusic)mediaList.get(i));
                }
            }
        }
        mItemList.addAll(musicList);

        int itemCount = directories.size()+musicList.size();
        notifyItemRangeInserted(lastNum,itemCount);
    }

    public void upateDataList(LocalDirectory directory){
        if (directory == null){
            return;
        }

        if (mItemList != null){
            mItemList.clear();
        }else{
            mItemList = new ArrayList<>();
        }

        List<LocalDirectory.Directory> directories = directory.directoryList;
        ArrayList<LocalDirectory.Directory> arrayList = new ArrayList<>(directories);
        mItemList.addAll(arrayList);

        List<Media> mediaList = directory.mediaList;
        ArrayList<LocalMusic> musicList = new ArrayList<>();
        if (mediaList != null){
            for (int i=0; i < mediaList.size(); i++){
                if (mediaList.get(i) instanceof LocalMusic){
                    musicList.add((LocalMusic)mediaList.get(i));
                }
            }
        }
        mItemList.addAll(musicList);
    }

    public LocalMediaListAdapter(CallBack callBack){
        this.mItemList = null;
        this.mCallBack = callBack;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        switch (i){
            case TYPE_ITEM_MUSIC:
                View v1 = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_local_song, viewGroup, false);
                return new MusicListItemHolder(v1);
            case TYPE_ITEM_DIRECTORY:
                View v2 = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_local_directory, viewGroup, false);
                return new DirectoryItemHolder(v2);
            default:
                // 默认返回 HOST 类型的 viewHolder
                View v3 = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_local_directory, viewGroup, false);
                return new DirectoryItemHolder(v3);
        }
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder viewHolder, int i) {
        switch (getItemViewType(i)) {
            case TYPE_ITEM_MUSIC:
                if (viewHolder instanceof MusicListItemHolder) {
                    // 在此处，处理默认类型的 viewHolder
                    LocalMusic item = (LocalMusic) mItemList.get(i);
                    MusicListItemHolder itemHolder = (MusicListItemHolder) viewHolder;

                    int index = i + 1;
                    if (index - mLastDirectoryIndex >=1 ){
                        index = index - mLastDirectoryIndex;
                    }
                    itemHolder.mSongNoTv.setText(String.valueOf(index));
                    itemHolder.mSongNameTv.setText(item.songName);
//                    itemHolder.mSongSingerTv.setText(item.getSingersName());

                    viewHolder.itemView.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            mCallBack.onSongItemClick(item);
                        }
                    });

                    ((MusicListItemHolder) viewHolder).mItemMoreIv.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            mCallBack.onSongItemMoreClick(item);
                        }
                    });
                }
                break;
            case TYPE_ITEM_DIRECTORY:
                if (viewHolder instanceof DirectoryItemHolder){
                    DirectoryItemHolder itemHolder = (DirectoryItemHolder)viewHolder;
                    LocalDirectory.Directory item = (LocalDirectory.Directory)mItemList.get(i);
                    itemHolder.mDirectoryNameTv.setText(item.directoryName);

                    itemHolder.mItemMoreIv.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            if (mCallBack != null){
                                mCallBack.onDirecotryMoreClick(item);
                            }
                        }
                    });

                    itemHolder.mDirectoryNameTv.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            if (mCallBack != null){
                                mCallBack.onDirectoryClick(item);
                            }
                        }
                    });
                }
                break;
            default:
                break;
        }
    }

    @Override
    public int getItemCount() {
        return (mItemList == null) ? 0 : mItemList.size();
    }

    @Override
    public int getItemViewType(int position) {
        if ( mItemList != null ){
            if (mItemList.get(position) instanceof LocalMusic){
                return TYPE_ITEM_MUSIC;
            }
            if (mItemList.get(position) instanceof LocalDirectory.Directory){
                return TYPE_ITEM_DIRECTORY;
            }
        }
        return TYPE_ITEM_DIRECTORY;
    }


    /********************************  ItemHolder *******************************/
    private class MusicListItemHolder extends RecyclerView.ViewHolder{
        ImageView mItemMoreIv;
        TextView mSongNoTv, mSongNameTv, mSongSingerTv;
        MusicListItemHolder(@NonNull View itemView) {
            super(itemView);
            mItemMoreIv = itemView.findViewById(R.id.item_local_song_more);
            mSongNoTv = itemView.findViewById(R.id.item_local_song_no);
            mSongNameTv = itemView.findViewById(R.id.item_local_song_name);
            mSongSingerTv = itemView.findViewById(R.id.item_local_song_artist);
        }
    }

    private class DirectoryItemHolder extends RecyclerView.ViewHolder{
        ImageView mItemMoreIv;
        TextView mDirectoryNameTv;
        DirectoryItemHolder(@NonNull View itemView) {
            super(itemView);
            mItemMoreIv = itemView.findViewById(R.id.item_local_directory_more);
            mDirectoryNameTv = itemView.findViewById(R.id.item_local_directory_name);
        }
    }
}
