package com.westwhale.contollerapp.ui.timer.activity;


import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.TimePicker;

import com.blankj.utilcode.util.ToastUtils;
import com.westwhale.contollerapp.R;
import com.westwhale.contollerapp.ui.base.activity.BaseActivity;
import com.westwhale.contollerapp.ui.localmusic.activity.SelectLocalMusicActivity;
import com.westwhale.contollerapp.ui.scene.bean.CmdSetVolume;
import com.westwhale.contollerapp.ui.timer.TimerDefine;
import com.westwhale.contollerapp.ui.timer.dialog.DelayTimerDialog;
import com.westwhale.contollerapp.ui.timer.dialog.TimerFunctionDialog;
import com.westwhale.contollerapp.ui.timer.dialog.TimerNameDialog;
import com.westwhale.api.protocolapi.bean.media.LocalMusic;
import com.westwhale.api.protocolapi.bean.Timer;
import com.westwhale.contollerapp.ui.widget.dialog.SeekbarDialog;
import com.westwhale.contollerapp.ui.widget.dialog.TextEditDialog;
import com.westwhale.contollerapp.ui.widget.interfs.DialogResultListener;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

/**
 * Description:
 * Author: chenyaoli
 * Date: 2018-12-20
 * History
 */
public class TimerAddEditActivity extends BaseActivity {

    public static final int REQUEST_CODE_TIMER_REPEAT = 3;
    public static final int REQUEST_CODE_CLOCL_MEDIA = 4;
    public static final int REQUEST_CODE_OPEN_MEDIA = 5;

    private Toolbar mToolbar;
    private ImageView mSaveTimerIv;
    private TextView mRemainTimerTv,mNameTv,mFunctionTv,mRepeatTv,mClockMediaTv,mOpenMediaTv,mVolumeTv,mClockTimeTv;
    private LinearLayout mNameLayout,mFunctionLayout,mRepeatLayout,mClockMediaLayout,mOpenMediaLayout,mVolumeLayout,mClockTimeLayout;
    private TimePicker mTimePick;

    private final int TIMER_EDIT_NEW = 1;
    private final int TIMER_EDIT_EDIT = 2;
    private Timer mTimer;
    private int mTimerType = TIMER_EDIT_NEW;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_timer_edit);

        Intent intent = getIntent();
        mTimer = intent.getParcelableExtra(TimerDefine.TIMER_INTENT_ARG_KEY_TIMER);

        initView();
        initListener();

        initData();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        switch (requestCode){
            case REQUEST_CODE_TIMER_REPEAT: {
                if ((resultCode == Activity.RESULT_OK) && (data != null)){
                    int circleday = data.getIntExtra(TimerDefine.TIMER_INTENT_ARG_KEY_REPEAT_CIRCLEDAY,0);
                    String specialDate = data.getStringExtra(TimerDefine.TIMER_INTENT_ARG_KEY_REPEAT_SPECIALDATE);

                    updateTimerRepeat(circleday,specialDate);
                    mRepeatTv.setText(TimerDefine.getTimerRepeat(circleday,specialDate));
                }
                break;
            }
            case REQUEST_CODE_CLOCL_MEDIA:{
                if ((resultCode == Activity.RESULT_OK) && (data != null)){
                    LocalMusic localMusic = data.getParcelableExtra(TimerDefine.TIMER_INTENT_ARG_KEY_MEDIA);
                    if (localMusic != null){
                        updateClockMedia(localMusic);

                        mClockMediaTv.setText(localMusic.songName);
                    }
                }
                break;
            }
            case REQUEST_CODE_OPEN_MEDIA:{
                if ((resultCode == Activity.RESULT_OK)  && (data != null)){
                    LocalMusic localMusic = data.getParcelableExtra(TimerDefine.TIMER_INTENT_ARG_KEY_MEDIA);
                    updateClockMedia(localMusic);
                    if (localMusic != null){
                        mOpenMediaTv.setText(localMusic.songName);
                    }else{
                        mOpenMediaTv.setText(R.string.timer_openmedia_item_default);
                    }
                }
                break;
            }
            default:
                break;
        }

    }

    @Override
    protected void onPause() {
        super.onPause();
    }


    private void initView() {
        mToolbar = findViewById(R.id.timer_edit_toolbar);
        // 设置toolbar
        setSupportActionBar(mToolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        mSaveTimerIv = findViewById(R.id.timer_edit_ok);

        mTimePick = findViewById(R.id.timer_edit_timepicker);
        mTimePick.setIs24HourView(true);

        mNameTv = findViewById(R.id.timer_edit_name);
        mFunctionTv = findViewById(R.id.timer_edit_function);
        mRepeatTv = findViewById(R.id.timer_edit_repeat);
        mClockMediaTv = findViewById(R.id.timer_edit_clockmedia);
        mOpenMediaTv = findViewById(R.id.timer_edit_media);
        mVolumeTv = findViewById(R.id.timer_edit_volume);
        mClockTimeTv = findViewById(R.id.timer_edit_clocktime);


        mNameLayout = findViewById(R.id.timer_edit_name_layout);
        mFunctionLayout = findViewById(R.id.timer_edit_function_layout);
        mRepeatLayout = findViewById(R.id.timer_edit_repeat_layout);
        mClockMediaLayout = findViewById(R.id.timer_edit_clockmedia_layout);
        mOpenMediaLayout = findViewById(R.id.timer_edit_media_layout);
        mVolumeLayout = findViewById(R.id.timer_edit_volume_layout);
        mClockTimeLayout = findViewById(R.id.timer_edit_clocktime_layout);
    }

    private void initListener() {
        mToolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        mSaveTimerIv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 点击保存按钮
                if (!isTimerValid()){
                    ToastUtils.showShort("未选择播放媒体");
                    return;
                }

                Intent intent = new Intent();
                intent.putExtra(TimerDefine.TIMER_INTENT_ARG_KEY_TIMER,mTimer);
                setResult(Activity.RESULT_OK,intent);

                finish();
            }
        });

         mTimePick.setOnTimeChangedListener(new TimePicker.OnTimeChangedListener() {
             @Override
             public void onTimeChanged(TimePicker view, int hourOfDay, int minute) {
                 updateTimerPreSetTime(String.format(Locale.getDefault(),"%02d:%02d",hourOfDay,minute));
             }
         });

        mNameLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //弹出名字输入框
                TimerNameDialog dialog = new TimerNameDialog();
                Bundle bundle = new Bundle();
                bundle.putString(TimerNameDialog.TEXT_NAME,mNameTv.getText().toString());
                dialog.setArguments(bundle);
                if (getFragmentManager() != null) {
                    dialog.show(getSupportFragmentManager(),TimerNameDialog.TAG);
                }
            }
        });

        mFunctionLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 弹出功能选择框
                TimerFunctionDialog dialog = new TimerFunctionDialog();
                if (getFragmentManager() != null) {
                    dialog.show(getSupportFragmentManager(),TimerFunctionDialog.TAG);
                }
            }
        });

        mRepeatLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(TimerAddEditActivity.this,TimerRepeatActivity.class);
                intent.putExtra(TimerDefine.TIMER_INTENT_ARG_KEY_REPEAT_CIRCLEDAY,mTimer.circleDay);
                intent.putExtra(TimerDefine.TIMER_INTENT_ARG_KEY_REPEAT_SPECIALDATE,mTimer.specialDate);
                startActivityForResult(intent, REQUEST_CODE_TIMER_REPEAT);
            }
        });

        mClockMediaLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 闹钟媒体选择
                startActivityForResult(new Intent(TimerAddEditActivity.this, SelectLocalMusicActivity.class),REQUEST_CODE_CLOCL_MEDIA);
            }
        });

        mOpenMediaLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 开机媒体选择
                startActivityForResult(new Intent(TimerAddEditActivity.this,TimerOpenMediaActivity.class),REQUEST_CODE_OPEN_MEDIA);
            }
        });

        mVolumeLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 弹出音量功能
                SeekbarDialog seekbarDialog = new SeekbarDialog();
                seekbarDialog.setOnDialogResultListener(new DialogResultListener<Integer>() {
                    @Override
                    public void onResultListener(Integer value) {
                        int volume = value;

                        if (mTimer != null) {
                            mVolumeTv.setText(String.valueOf(volume));
                            mTimer.volume = volume;
                        }
                    }
                });

                Bundle bundle = new Bundle();
                bundle.putString(SeekbarDialog.DIALOG_TITLE,"音量");
                bundle.putInt(SeekbarDialog.SEEKBAR_VALUE,mTimer.volume);
                bundle.putInt(SeekbarDialog.SEEKBAR_MAXVALUE,31);
                seekbarDialog.setArguments(bundle);
                seekbarDialog.show(getSupportFragmentManager(), "volumeDialog");
            }
        });

        mClockTimeLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //时间设置
                TextEditDialog dialog = new TextEditDialog();
                Bundle bundle = new Bundle();
                bundle.putString(TextEditDialog.DIALOG_TITLE,"响铃时间");
                bundle.putString(TextEditDialog.TEXT_VALUE,String.valueOf(mTimer.clockTime));
                bundle.putString(TextEditDialog.TEXT_HINT,"请输入时间(分钟)");
                dialog.setArguments(bundle);

                dialog.setOnDialogResultListener(new DialogResultListener<String>() {
                    @Override
                    public void onResultListener(String value) {
                        if (mTimer != null) {
                            try {
                                int time = Integer.parseInt(value);

                                mTimer.clockTime = time;
                                mClockTimeTv.setText(String.format(Locale.getDefault(),"%d分钟", time));
                            }catch (Exception e){
                                e.printStackTrace();
                            }
                        }
                    }
                });
                dialog.show(getSupportFragmentManager(),"ClockTimerTime");
            }
        });
    }


    private void initData() {
        String toolbartitle = "";
        String name = "";
        String function = "";
        String repeat = "";
        String clockmedia = "";
        String openmedia = "";
        Calendar calendar = Calendar.getInstance();
        String volume = "";
        String clockTime = "";

        try {
            if (mTimer == null) {
                mTimerType = TIMER_EDIT_NEW;
                toolbartitle = getString(R.string.timer_edit_title_new);
                calendar.setTimeInMillis(System.currentTimeMillis());

                mTimer = new Timer();
                mTimer.timerId = -1;
                mTimer.actionName = TimerDefine.TIMER_FUNC_OPEN;
                mTimer.timerEnable = TimerDefine.TIMER_ENABLE_ENABLE;
                mTimer.music = null;
                mTimer.timerName = "闹钟";
                mTimer.circleDay = TimerDefine.TIMER_REPEAT_NOREPEAT;
                mTimer.preSetTime = new SimpleDateFormat("HH:mm",Locale.getDefault()).format(calendar.getTime());
                mTimer.specialDate = "";
                mTimer.volume = 25;
                mTimer.clockTime = 10;
            } else {
                mTimerType = TIMER_EDIT_EDIT;
                toolbartitle = getString(R.string.timer_edit_title_edit);
            }

            name = mTimer.timerName;
            function = TimerDefine.getTimerFuncName(mTimer.actionName);
            repeat = TimerDefine.getTimerRepeat(mTimer.circleDay, mTimer.specialDate);
            volume = mTimer.volume + "";
            clockTime = mTimer.clockTime + "分钟";

            try {
                calendar.setTime(new SimpleDateFormat("HH:mm",Locale.getDefault()).parse(mTimer.preSetTime));
            } catch (Exception e) {
                e.printStackTrace();
                calendar.setTimeInMillis(System.currentTimeMillis());
            }
            switch (mTimer.actionName) {
                case TimerDefine.TIMER_FUNC_OPEN:
                    openmedia = (mTimer.music == null) ? getString(R.string.timer_openmedia_item_default) : mTimer.music.songName;
                    break;
                case TimerDefine.TIMER_FUNC_ALARM:
                    clockmedia = (mTimer.music == null) ? "" : mTimer.music.songName;
                    break;
                case TimerDefine.TIMER_FUNC_CLOCKPLAY:
                    clockmedia = (mTimer.music == null) ? "" : mTimer.music.songName;
                    break;
                default:
                    break;
            }

            mTimePick.setCurrentHour(calendar.get(Calendar.HOUR_OF_DAY));
            mTimePick.setCurrentMinute(calendar.get(Calendar.MINUTE));

            mToolbar.setTitle(toolbartitle);
            mNameTv.setText(name);
            mFunctionTv.setText(function);
            mRepeatTv.setText(repeat);
            mClockMediaTv.setText(clockmedia);
            mOpenMediaTv.setText(openmedia);
            mVolumeTv.setText(volume);
            mClockTimeTv.setText(clockTime);

            switchTimerFunc(mTimer.actionName);
        }catch (Exception e){
            e.printStackTrace();
        }

    }

    private void switchTimerFunc(String actionName){
        int clockMediaLayoutVisible = View.GONE;
        int openMediaLayoutVisible = View.GONE;
        int volumeLayoutVisible = View.GONE;
        int clockTimeLayoutVisible = View.GONE;

        switch (actionName) {
            case TimerDefine.TIMER_FUNC_OPEN:
                openMediaLayoutVisible = View.VISIBLE;
                break;
            case TimerDefine.TIMER_FUNC_ALARM:
            case TimerDefine.TIMER_FUNC_CLOCKPLAY:
                clockMediaLayoutVisible = View.VISIBLE;
                volumeLayoutVisible = View.VISIBLE;
                clockTimeLayoutVisible = View.VISIBLE;
                break;
            case TimerDefine.TIMER_FUNC_CLOSE:
                break;
            default:
                break;
        }

        mClockMediaLayout.setVisibility(clockMediaLayoutVisible);
        mOpenMediaLayout.setVisibility(openMediaLayoutVisible);
        mVolumeLayout.setVisibility(volumeLayoutVisible);
        mClockTimeLayout.setVisibility(clockTimeLayoutVisible);
    }

    private boolean isTimerValid(){
        boolean isValid = false;
        if (mTimer != null){
            switch (mTimer.actionName) {
                case TimerDefine.TIMER_FUNC_OPEN:
                    isValid = true;
                    break;
                case TimerDefine.TIMER_FUNC_ALARM:
                    isValid = (mTimer.music != null);
                    break;
                case TimerDefine.TIMER_FUNC_CLOCKPLAY:
                    isValid = (mTimer.music != null);
                    break;
                case TimerDefine.TIMER_FUNC_CLOSE:
                    isValid = true;
                    break;
                default:
                    break;
            }
        }

        return isValid;
    }

    private void updateTimerPreSetTime(String time) {
        if (mTimer != null){
            mTimer.preSetTime = time;
        }
    }

    public void updateTimerName(String name){
        if ((name == null) || name.isEmpty()){
            return;
        }

        if (mTimer != null){
            mTimer.timerName = name;
            mNameTv.setText(name);
        }
    }

    public void updateTimerRepeat(int circleday, String date){
        if (mTimer != null){
            if ((date != null) && !date.isEmpty()){
                mTimer.circleDay = 0;
                mTimer.specialDate = date;
            }else{
                mTimer.circleDay = circleday;
                mTimer.specialDate = "";
            }
        }

    }

    public void updateTimerFunction(String actionName){
        if (TimerDefine.checkActionName(actionName) && (mTimer != null)){
            mTimer.actionName = actionName;
            switchTimerFunc(mTimer.actionName);
            mFunctionTv.setText(TimerDefine.getTimerFuncName(mTimer.actionName));
        }
    }

    public void updateClockMedia(LocalMusic localMusic){
        if (mTimer != null){
            mTimer.music = localMusic;
        }
    }

    public void updateOpenMedia(LocalMusic localMusic){
        if (mTimer != null){
            mTimer.music = localMusic;
        }
    }

}
