package com.westwhale.contollerapp.ui.timer.adapter;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.westwhale.api.protocolapi.bean.DelayClose;
import com.westwhale.contollerapp.R;
import com.westwhale.contollerapp.ui.timer.dialog.DelayTimerDialog;

import java.util.List;
import java.util.Locale;

/**
 * Description:
 * Author: chenyaoli
 * Date: 2018-12-20
 * History
 *
 */
public class DelayTimerAdapter extends RecyclerView.Adapter {
    private List<DelayTimerDialog.DelayTimerType> mItemList;
    private CallBack mCallBack;
    private DelayTimerDialog.DelayTimerType mSelectedItem = null;

    public interface CallBack {
        void onItemClick(DelayTimerDialog.DelayTimerType item, int pos);
    }

    public void setCallBack(CallBack callBack){
        this.mCallBack = callBack;
    }

    public void setDataList(List<DelayTimerDialog.DelayTimerType> itemList){
        this.mItemList = itemList;
    }

    public void setSelectedItem(DelayTimerDialog.DelayTimerType delayTimerType) {
        if ( (delayTimerType != null) && (mItemList != null) ){
            if (mSelectedItem != null){
                int pos = mItemList.indexOf(mSelectedItem);
                mSelectedItem = null;
                if (pos > -1){
                    notifyItemChanged(pos);
                }
            }

            mSelectedItem = delayTimerType;
            int pos = mItemList.indexOf(mSelectedItem);
            if (pos > -1){
                notifyItemChanged(pos);
            }
        }
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_delaytimer, viewGroup, false);
        return new ItemHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder viewHolder, int i) {
        if (viewHolder instanceof ItemHolder){
            int pos = viewHolder.getAdapterPosition();
            final DelayTimerDialog.DelayTimerType item = mItemList.get(pos);
            ItemHolder itemHolder = (ItemHolder)viewHolder;

            int visible = View.INVISIBLE;
            int colorResourceId = R.color.searchdev_text;
            String secondTitle = "";
            if (item == mSelectedItem){
                visible = View.VISIBLE;
                colorResourceId = R.color.colorPrimary;
                secondTitle = item.getRemainTimeInfo();
            }

            itemHolder.mTextView.setText(item.getName());
            itemHolder.mImageView.setVisibility(visible);
            itemHolder.mTextView.setTextColor(itemHolder.itemView.getResources().getColor(colorResourceId));
            itemHolder.mSecondTv.setTextColor(itemHolder.itemView.getResources().getColor(colorResourceId));
            itemHolder.mSecondTv.setText(secondTitle);

            itemHolder.itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (mCallBack != null){
                        mCallBack.onItemClick(item,pos);
                    }
                }
            });
        }
    }

    @Override
    public int getItemCount() {
        return (mItemList == null) ? 0 : mItemList.size();
    }

    private class ItemHolder extends RecyclerView.ViewHolder{
        private ImageView mImageView;
        private TextView mTextView,mSecondTv;
        public ItemHolder(@NonNull View itemView) {
            super(itemView);
            mImageView = itemView.findViewById(R.id.item_imagetext_pic);
            mTextView = itemView.findViewById(R.id.item_imagettext_text);
            mSecondTv = itemView.findViewById(R.id.item_imagettext_sceond_text);
        }
    }
}
