package com.westwhale.contollerapp.dev;

public interface ICmdCallback<T> {
    public void onSuccess(T data);

    public void onFailed(int code,String msg);
}
