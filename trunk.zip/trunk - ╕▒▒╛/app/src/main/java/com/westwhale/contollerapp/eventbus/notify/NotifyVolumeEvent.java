package com.westwhale.contollerapp.eventbus.notify;


public class NotifyVolumeEvent {
    private int mVolume;

    public NotifyVolumeEvent(int volume){
        mVolume = volume;
    }
    public int getVolume() {
        return mVolume;
    }
}
