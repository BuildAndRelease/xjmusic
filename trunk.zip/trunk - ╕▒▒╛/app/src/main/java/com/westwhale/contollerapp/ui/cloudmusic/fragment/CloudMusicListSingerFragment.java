package com.westwhale.contollerapp.ui.cloudmusic.fragment;

import android.util.Base64;
import android.widget.Toast;

import com.kingja.loadsir.callback.SuccessCallback;
import com.westwhale.contollerapp.R;
import com.westwhale.contollerapp.application.WApp;
import com.westwhale.contollerapp.dev.CmdActionLister;
import com.westwhale.contollerapp.dev.ICmdCallback;
import com.westwhale.contollerapp.dev.WRoom;
import com.westwhale.contollerapp.ui.loadsircallback.EmptyCallback;
import com.westwhale.contollerapp.ui.loadsircallback.LoadingCallback;
import com.westwhale.api.protocolapi.bean.media.CloudMusic;
import com.westwhale.api.protocolapi.bean.albumSet.CloudSingerSet;

import java.util.List;

public class CloudMusicListSingerFragment extends CloudMusicListBaseFragment {

    private final String DEFAULT_SINGER_SORT = "3";

    private int mBegin = 0;
    private int mPageSize = 100;
    private boolean mHasMoreData = true; // 记录是否还有更多数据

    private CloudSingerSet mSingerSet;

    public void updateSingerSet(CloudSingerSet singerSet){
        mSingerSet = singerSet;
    }

    @Override
    public void initData() {
        showLoadCallBack(LoadingCallback.class);

        updateHeaderInfo();

        // 每次先清空原有数据
        mBegin = 0;
        mHasMoreData = true;
        if (mMusicAdapter != null){
            mMusicAdapter.clearDataList();
        }

        requestCloudResource();
    }

    @Override
    public boolean hasMoreData() {
        return mHasMoreData;
    }

    @Override
    public void loadMoreData() {
        requestCloudResource();
    }

    @Override
    public void requestCloudResource() {
        WRoom room = WApp.Instance.getDevManager().getSelectedRoom();
        if (room != null){
            String singerMid = (mSingerSet != null) ? mSingerSet.Fsinger_mid : "";
            WRoom.cmdGetSingerSong(singerMid,DEFAULT_SINGER_SORT, mBegin,mPageSize, new CmdActionLister<List<CloudMusic>>(this, new ICmdCallback<List<CloudMusic>>() {
                @Override
                public void onSuccess(List<CloudMusic> data) {
                    updateDataList(data);
                }

                @Override
                public void onFailed(int code, String msg) {
                    updateDataList(null);
                    Toast.makeText(getContext(),"GetSingerSong获取失败:"+code,Toast.LENGTH_SHORT).show();
                }
            }));
        }else{
            updateDataList(null);
        }
    }

    @Override
    public void updateDataList(List<CloudMusic> list){
        if (list != null){
            // 若无法获取到数据，则认为已经到底
            int size = list.size();

            if (mBegin == 0) {
                mMusicAdapter.clearDataList();
            }

            mBegin = mBegin + size;

            if (size != 0){
                int startIndex = mMusicAdapter.getItemCount();
                mMusicAdapter.addToDataList(list);
                mMusicAdapter.notifyItemRangeInserted(startIndex,size);
            }else{
                mHasMoreData = false;
            }

            // 更新刷新等待状态
            mRefreshLayout.finishRefresh();
            mRefreshLayout.finishLoadMore();

            showLoadCallBack(SuccessCallback.class);
        }else{
            mHasMoreData = false;

            // 更新刷新等待状态
            mRefreshLayout.finishRefresh();
            mRefreshLayout.finishLoadMore();

            showLoadCallBack(EmptyCallback.class);
        }
    }

    private void updateHeaderInfo(){

        String toolbarTitle = getString(R.string.cloudmusic_singer_title);
        String title = (mSingerSet != null) ? mSingerSet.Fsinger_name : "";
        String subTitle = (mSingerSet != null) ? mSingerSet.Fother_name : "";
        String picUrl = "";
        if (mSingerSet != null){
            String pic = (mSingerSet.getPic() != null) ? mSingerSet.getPic() : "";
            picUrl = new String(Base64.decode(pic, Base64.DEFAULT));
        }

        updateHeader(toolbarTitle,title,subTitle,picUrl);
    }
}
