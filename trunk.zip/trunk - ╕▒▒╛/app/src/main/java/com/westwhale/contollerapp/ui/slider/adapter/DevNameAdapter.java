package com.westwhale.contollerapp.ui.slider.adapter;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.TextView;

import com.westwhale.contollerapp.R;
import com.westwhale.api.protocolapi.bean.hostroom.Room;

import java.util.List;
import java.util.Locale;

/**
 * Description:
 * Author: chenyaoli
 * Date: 2018-12-20
 * History
 *
 */
public class DevNameAdapter extends RecyclerView.Adapter {
    private List<Room> mItemList;
    private CallBack mRoomItemClick;

    public interface CallBack{
        void onRoomItemClick(Room room,String name);
    }

    public void setCallBack(CallBack callBack){
        this.mRoomItemClick = callBack;
    }

    public void updateList(List<Room> itemList){
        this.mItemList = itemList;
    }

    public void updateItem(Room room){
        if (mItemList != null){
            int index = mItemList.indexOf(room);
            if (index > -1){
                notifyItemChanged(index);
            }
        }
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_devname_room, viewGroup, false);
        return new ItemHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder viewHolder, int i) {
        if (viewHolder instanceof ItemHolder){
            final Room item = mItemList.get(i);
            ItemHolder itemHolder = (ItemHolder)viewHolder;
            String title = String.format(Locale.getDefault(),"房间%d:",(i+1));
            itemHolder.mTextView.setText(title);
            itemHolder.mEditText.setText(item.roomName);
            itemHolder.itemView.setTag(i + "");

            itemHolder.mEditText.setOnEditorActionListener(new TextView.OnEditorActionListener() {
                @Override
                public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                    // 完成
                    if (actionId == EditorInfo.IME_ACTION_DONE){
                        itemHolder.mEditText.clearFocus();

                        String text = v.getText().toString();
                        if (mRoomItemClick != null){
                            mRoomItemClick.onRoomItemClick(item,text);
                        }

                        return true;
                    }

                    return false;
                }
            });
            itemHolder.itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                }
            });
        }
    }

    @Override
    public int getItemCount() {
        return (mItemList == null) ? 0 : mItemList.size();
    }

    private class ItemHolder extends RecyclerView.ViewHolder{
        private TextView mTextView;
        private EditText mEditText;
        public ItemHolder(@NonNull View itemView) {
            super(itemView);
            mTextView = itemView.findViewById(R.id.devname_room_title);
            mEditText = itemView.findViewById(R.id.devname_room_edit);
        }
    }
}
