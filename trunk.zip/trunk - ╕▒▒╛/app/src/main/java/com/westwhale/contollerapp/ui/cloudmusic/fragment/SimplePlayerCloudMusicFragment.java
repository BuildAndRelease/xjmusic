package com.westwhale.contollerapp.ui.cloudmusic.fragment;

import android.animation.ObjectAnimator;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.text.TextUtils;
import android.util.Base64;
import android.view.GestureDetector;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.LinearInterpolator;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.request.RequestOptions;
import com.github.lzyzsd.circleprogress.DonutProgress;
import com.westwhale.contollerapp.R;
import com.westwhale.contollerapp.ui.main.PlayerActivity;
import com.westwhale.contollerapp.dev.API_DEFINE;
import com.westwhale.contollerapp.ui.cloudmusic.dialog.CloudMusicPlayListDialog;
import com.westwhale.contollerapp.ui.base.fragment.PlayerBaseFragment;
import com.westwhale.contollerapp.utils.CommonUtils;
import com.westwhale.api.protocolapi.bean.media.CloudMusic;
import com.westwhale.api.protocolapi.bean.media.Media;
import com.westwhale.api.protocolapi.bean.hostroom.Room;

public class SimplePlayerCloudMusicFragment extends PlayerBaseFragment implements View.OnTouchListener, GestureDetector.OnGestureListener {
    private final static String TAG = "CloudMusicSimple";

    private ImageView mMediaIv,mMediaListIv;
    private TextView mTitleTv,mSubTitleTv;
    private DonutProgress mSimplePlayProgress;
    private FrameLayout mPlayerButtonLayout;
    private LinearLayout mTitleLayout,mNavLayout;

    protected ObjectAnimator mCircleAnimator;    //图片旋转动画
    private ObjectAnimator mDonutProgressAnimator;   //进度条旋转动画

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        // 先显示加载动画，针对布局做一些初始化
        View view = inflater.inflate(R.layout.frag_netmusic_player_simple,container,false);

        return view;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        initView(view);

        initListener();

        updateMediaInfo();
        updatePlayStatInfo();

        updateMediaDurationInfo();
    }

    @Override
    public void onPause() {
        super.onPause();
    }

    @Override
    public void onResume() {
        super.onResume();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();

        if (mDonutProgressAnimator != null) {
            mDonutProgressAnimator.cancel();
        }

        if (mCircleAnimator != null) {
            mCircleAnimator.cancel();
        }
    }

    private void initView(View view) {
        if (null == view){
            return;
        }

        mMediaIv = view.findViewById(R.id.simple_player_img);
        mMediaListIv = view.findViewById(R.id.simple_player_playlist);
        mTitleTv = view.findViewById(R.id.simple_player_title);
        mSubTitleTv = view.findViewById(R.id.simple_player_subtitle);
        mPlayerButtonLayout = view.findViewById(R.id.simple_player_playframe);

        mTitleLayout = view.findViewById(R.id.simple_player_title_layout);
        mNavLayout = view.findViewById(R.id.simple_player_nav);

        mSimplePlayProgress = view.findViewById(R.id.simple_player_play);
        // 调整起始点的位置
        mSimplePlayProgress.setStartingDegree(-90);

        initCireAnimator(mMediaIv);
    }

    private void initListener() {
        mNavLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 点击进入云音乐详细播放界面
                Intent intent = new Intent(getContext(), PlayerActivity.class);
                startActivity(intent);
            }
        });

        mPlayerButtonLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 点击播放/暂停，需设置播放按钮（因为Frame的可触控面积大于播放按钮）
                if ((API_DEFINE.CMD_PLAYSTAT_PLAY).equals(mPlayStat)){
                    playPause();

                    updatePlayStat(API_DEFINE.CMD_PLAYSTAT_PAUSE);
                }else{
                    playResume();
                    updatePlayStat(API_DEFINE.CMD_PLAYSTAT_PLAY);
                }
            }
        });

        mMediaListIv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 弹出播放列表界面
                CloudMusicPlayListDialog dialog = new CloudMusicPlayListDialog();
                dialog.show(getChildFragmentManager(),"Playlist Dialog");
            }
        });

        mTitleLayout.setOnTouchListener(this);
    }

    @Override
    public boolean isPlayerValid() {
        if ((Room.ChannelState.INNORMAL).equals(mRoomStat) || (Room.ChannelState.INPARTY).equals(mRoomStat) ){
            return true;
        }

        return false;
    }

    @NonNull
    @Override
    public String getMediaSrc() {
        return Media.CLOUD_MUSIC;
    }

    @Override
    public void updateMediaInfo(){
        if (mMedia instanceof CloudMusic) {
            CloudMusic media = (CloudMusic)mMedia;
            // 设置主标题和副标题
            StringBuilder stringBuilder = new StringBuilder("");
            stringBuilder.append(TextUtils.isEmpty(media.songName) ? getString(R.string.cloudmusic_unknown) : media.songName);
            mTitleTv.setText(stringBuilder.toString());
            mSubTitleTv.setText(media.getSingersName());

            // 设置图片,首先 base64 解码
            String pic = (media.picUrl != null) ? media.picUrl : "";
            String url = pic;
            if (pic.isEmpty()){
                // 则根据歌曲信息 生成一个picUrl
                url = CommonUtils.getCloudMusicPic(media.albumMid,media.singer);
            }else {
                if (!url.startsWith("http://")) {
                    url = new String(Base64.decode(pic.getBytes(), Base64.DEFAULT));
                }
            }
            RequestOptions mRequestOptions = RequestOptions.circleCropTransform().diskCacheStrategy(DiskCacheStrategy.NONE) //不做磁盘缓存
                    .placeholder(R.drawable.simple_player_default)  //未加载图片之前显示的图片
                    .error(R.drawable.simple_player_default);       //错误时显示的图片
//                      .skipMemoryCache(true);//不做内存缓存

            // 在Fragment未 attach Activity时，会抛出activity null 异常
            Glide.with(this)
                    .load(url)
                    .apply(mRequestOptions)
                    .into(mMediaIv);

            // 更新总时长
            mPlayTime = 0;
            mDuration = 0;
            try{
                int duration = Integer.parseInt(media.duration);
                this.updatePlayingMediaDuration(duration);
            }catch (Exception e){
                e.printStackTrace();
            }
        }
    }

    @Override
    public void updateMediaDurationInfo() {
//        updateProgress();
        // 更新总时长时，重新获取当前播放时间
        if (mDuration > 0) {
            getPlayTime();
        }
    }

    @Override
    public void updatePlayTimeInfo() {
        updateProgress();
    }

    @Override
    public void updatePlayModeInfo() {
    }

    @Override
    public void updatePlayStatInfo() {
        // 更新播放状态
        if ((API_DEFINE.CMD_PLAYSTAT_PLAY).equals(mPlayStat)){
            mSimplePlayProgress.setAttributeResourceId(R.drawable.simple_player_pause);
            mSimplePlayProgress.invalidate();

            resumeCircleAnimator();

            resumeDonutAnimator();
        }else {
            mSimplePlayProgress.setAttributeResourceId(R.drawable.simple_player_play);
            mSimplePlayProgress.invalidate();

            pauseCircleAnimator();

            pauseDonutAnimator();
        }
    }

    public void updateProgress(){
        int progress = (mDuration==0) ? 0 : (mPlayTime*100/mDuration);
        mSimplePlayProgress.setDonut_progress(String.valueOf(progress));

        initDonutAnimator(mPlayTime,mDuration);

        if ((API_DEFINE.CMD_PLAYSTAT_PLAY).equals(mPlayStat)) {
            resumeDonutAnimator();
        }
    }


    /******************************** 进度条转动 ***********************************/
    private void initDonutAnimator(int beginTime,int times) {
        if (mDonutProgressAnimator != null){
            mDonutProgressAnimator.removeAllListeners();
            mDonutProgressAnimator.cancel();
            mDonutProgressAnimator = null;
        }
        if ((times <= 0) || (beginTime > times)){
            return;
        }

        int progress = beginTime*100/times;
        mDonutProgressAnimator = ObjectAnimator.ofFloat(mSimplePlayProgress, "progress", progress,100);
        mDonutProgressAnimator.setInterpolator(new LinearInterpolator());
//        mDonutProgressAnimator.setDuration(10*1000);
        mDonutProgressAnimator.setRepeatCount(0);
        mDonutProgressAnimator.setDuration((times - beginTime)*1000);
    }

    private void resumeDonutAnimator() {
        if (mDonutProgressAnimator != null){
            if (mDonutProgressAnimator.isStarted()){
                mDonutProgressAnimator.resume();
            }else{
                mDonutProgressAnimator.start();
            }
        }
    }

    private void pauseDonutAnimator() {
        if (mDonutProgressAnimator != null){
            mDonutProgressAnimator.pause();
        }
    }


    /******************************** 图片转动 ***********************************/
    private void initCireAnimator(@NonNull View view) {
        mCircleAnimator = ObjectAnimator.ofFloat(view, "rotation", 0.0f, 360.0f);
        mCircleAnimator.setDuration(20*1000);
        mCircleAnimator.setInterpolator(new LinearInterpolator());
        mCircleAnimator.setRepeatCount(-1);
        mCircleAnimator.setRepeatMode(ObjectAnimator.RESTART);
    }

    private void resumeCircleAnimator() {
        if (mCircleAnimator != null){
            if (mCircleAnimator.isStarted()){
                mCircleAnimator.resume();
            }else{
                mCircleAnimator.start();
            }
        }
    }

    private void pauseCircleAnimator() {
        if (mCircleAnimator != null){
            mCircleAnimator.pause();
        }
    }

    /******************************** 手势 ***********************************/
    private static final int FLING_MIN_DISTANCE = 80;// 移动最小距离
    private static final int FLING_MIN_VELOCITY = 200;// 移动最大速度
    //构建手势探测器
    GestureDetector mGesture = new GestureDetector(this);
    @Override
    public boolean onDown(MotionEvent e) {
        // 默认为false，最好设置为true，触发 performClick
        return true;
    }

    @Override
    public void onShowPress(MotionEvent e) {

    }

    @Override
    public boolean onSingleTapUp(MotionEvent e) {
        return false;
    }

    @Override
    public boolean onScroll(MotionEvent e1, MotionEvent e2, float distanceX, float distanceY) {
        return false;
    }

    @Override
    public void onLongPress(MotionEvent e) {

    }

    @Override
    public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX, float velocityY) {
        // e1：第1个ACTION_DOWN MotionEvent
        // e2：最后一个ACTION_MOVE MotionEvent
        // velocityX：X轴上的移动速度（像素/秒）
        // velocityY：Y轴上的移动速度（像素/秒）
        if (e2.getX() -e1.getX() >FLING_MIN_DISTANCE) {
            // 向右手势
            playNext();
        } else if (e1.getX() -e2.getX() > FLING_MIN_DISTANCE){
            // 向左手势
            playPre();
        }

        return false;
    }

    @Override
    public boolean onTouch(View v, MotionEvent event) {
        return mGesture.onTouchEvent(event);
    }
}
