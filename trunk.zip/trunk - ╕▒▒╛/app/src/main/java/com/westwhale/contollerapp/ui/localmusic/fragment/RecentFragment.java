package com.westwhale.contollerapp.ui.localmusic.fragment;

import android.content.Context;
import android.graphics.Color;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.westwhale.contollerapp.R;
import com.westwhale.contollerapp.ui.base.fragment.TitleBaseFragment;
import com.westwhale.contollerapp.ui.main.adapter.CustomViewPagerAdapter;

import net.lucode.hackware.magicindicator.MagicIndicator;
import net.lucode.hackware.magicindicator.ViewPagerHelper;
import net.lucode.hackware.magicindicator.buildins.commonnavigator.CommonNavigator;
import net.lucode.hackware.magicindicator.buildins.commonnavigator.abs.CommonNavigatorAdapter;
import net.lucode.hackware.magicindicator.buildins.commonnavigator.abs.IPagerIndicator;
import net.lucode.hackware.magicindicator.buildins.commonnavigator.abs.IPagerTitleView;
import net.lucode.hackware.magicindicator.buildins.commonnavigator.indicators.LinePagerIndicator;
import net.lucode.hackware.magicindicator.buildins.commonnavigator.titles.ColorTransitionPagerTitleView;
import net.lucode.hackware.magicindicator.buildins.commonnavigator.titles.SimplePagerTitleView;

import java.util.Arrays;
import java.util.List;

public class RecentFragment extends TitleBaseFragment {
    private static final String TAG = "RecentFragment";

    private static final Integer[] TITLE_NAME = new Integer[]{R.string.recent_tab_cloudmusic,R.string.recent_tab_cloudstory,R.string.recent_tab_localmusic};
    private List<Integer> mDataList = Arrays.asList(TITLE_NAME);

    private ViewPager mViewPager;
    private Toolbar mToolBar;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.frag_recent_tab,container,false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        initView(view);
        initListener();
        initData();
    }

    private void initView(View view) {
        try{
            mToolBar = view.findViewById(R.id.frag_recent_toolbar);
            configToolBar(mToolBar,getString(R.string.recent_title));

            mViewPager = view.findViewById(R.id.frag_recent_viewpager);
            CustomViewPagerAdapter customViewPagerAdapter = new CustomViewPagerAdapter(getChildFragmentManager());
            //待添加需要添加的Fragment
            customViewPagerAdapter.addFragment( new RecentCloudMusicFragment());
            customViewPagerAdapter.addFragment(new RecentCloudStoryFragment());
//            customViewPagerAdapter.addFragment(new CloudStoryHomeFragment());
//            customViewPagerAdapter.addFragment(new CloudNetFmHomeFragment());

            mViewPager.setAdapter(customViewPagerAdapter);
            mViewPager.setOffscreenPageLimit(customViewPagerAdapter.getCount());

            // 配置 magicIndicator
            MagicIndicator magicIndicator = view.findViewById(R.id.frag_recent_magicindicator);
            CommonNavigator commonNavigator = new CommonNavigator(mContext);
            commonNavigator.setAdjustMode(true);
            commonNavigator.setAdapter(new CommonNavigatorAdapter() {
                @Override
                public int getCount() {
                    return mDataList.size();
                }

                @Override
                public IPagerTitleView getTitleView(Context context, final int index) {
                    SimplePagerTitleView simplePagerTitleView = new ColorTransitionPagerTitleView(context);
                    simplePagerTitleView.setText(mDataList.get(index));
                    simplePagerTitleView.setNormalColor(getResources().getColor(R.color.recent_nav_unselect));
                    simplePagerTitleView.setSelectedColor(getResources().getColor(R.color.recent_nav_select));
                    simplePagerTitleView.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            mViewPager.setCurrentItem(index);
                        }
                    });
                    return simplePagerTitleView;
                }

                @Override
                public IPagerIndicator getIndicator(Context context) {
                    LinePagerIndicator indicator = new LinePagerIndicator(context);
                    indicator.setColors(getResources().getColor(R.color.recent_nav_underline));
                    return indicator;
                }
            });
            magicIndicator.setNavigator(commonNavigator);
            ViewPagerHelper.bind(magicIndicator, mViewPager);

        }catch (Exception e){
            e.printStackTrace();
        }
    }

    private void initListener() {

    }

    private void initData() {
        mViewPager.setCurrentItem(0);
    }
}
