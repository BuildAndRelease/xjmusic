package com.westwhale.contollerapp.ui.loadsircallback;


import com.kingja.loadsir.callback.Callback;
import com.westwhale.contollerapp.R;


/**
 * Description:TODO
 * Create Time:2017/9/4 10:20
 * Author:KingJA
 * Email:kingjavip@gmail.com
 */

public class ErrorCallback extends Callback {
    @Override
    protected int onCreateView() {
        return R.layout.frag_load_error;
    }
}
