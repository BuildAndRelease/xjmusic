package com.westwhale.contollerapp.ui.scene.bean;


import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;

public class CmdPlayInfo extends CmdActionBase {

    private CmdActionBase mCmdMedia; // CmdPlayMedia or CmdSetAudioSource

    public CmdPlayInfo() {
        mType = CMD_TYPE_PLAYINFO;
    }

    @Override
    public String toJsonString() {
        String result = (mCmdMedia != null) ? mCmdMedia.toJsonString() : "";
        return result;
    }

    @Override
    public String getActionValue() {
        String value = "无";
        if ((mCmdMedia instanceof CmdPlayMedia) || (mCmdMedia instanceof CmdSetAudioSource) ){
            value = mCmdMedia.getActionValue();
        }

        return value;
    }

    @Override
    public void parseArgs() {
        if ((mCmdArgs == null) || (mCmdArgs.isEmpty())){
            return;
        }

    }

    public void setCmdAction(CmdActionBase cmdAction){
        mCmdMedia = cmdAction;
    }
}
