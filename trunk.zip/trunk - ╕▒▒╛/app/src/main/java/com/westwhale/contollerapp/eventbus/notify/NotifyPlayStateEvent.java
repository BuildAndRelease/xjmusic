package com.westwhale.contollerapp.eventbus.notify;

public class NotifyPlayStateEvent {
    private String mPlayStat;

    public NotifyPlayStateEvent(String playStat){
        mPlayStat = playStat;
    }
    public String getPlayStat() {
        return mPlayStat;
    }
}
