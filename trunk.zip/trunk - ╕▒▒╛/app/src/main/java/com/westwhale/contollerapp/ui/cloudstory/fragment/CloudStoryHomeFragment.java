package com.westwhale.contollerapp.ui.cloudstory.fragment;

import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.kingja.loadsir.callback.Callback;
import com.kingja.loadsir.callback.SuccessCallback;
import com.kingja.loadsir.core.LoadService;
import com.kingja.loadsir.core.LoadSir;
import com.westwhale.contollerapp.R;
import com.westwhale.contollerapp.ui.base.fragment.LazyBaseFragment;
import com.westwhale.contollerapp.ui.main.MainRoomActivity;
import com.westwhale.contollerapp.ui.cloudstory.adapter.StoryAlbumAdapter;
import com.westwhale.contollerapp.application.WApp;
import com.westwhale.contollerapp.dev.CmdActionLister;
import com.westwhale.contollerapp.dev.ICmdCallback;
import com.westwhale.contollerapp.dev.WRoom;
import com.westwhale.contollerapp.ui.loadsircallback.EmptyCallback;
import com.westwhale.contollerapp.ui.loadsircallback.ErrorCallback;
import com.westwhale.contollerapp.ui.loadsircallback.LoadingCallback;
import com.westwhale.contollerapp.ui.loadsircallback.TimeoutCallback;
import com.westwhale.api.protocolapi.bean.albumSet.StoryTelling;

import java.util.List;

/**
 * Description:
 * Author: chenyaoli
 * Date: 2019-04-06
 * History:
 */
public class CloudStoryHomeFragment extends LazyBaseFragment implements StoryAlbumAdapter.CallBack {
    private static final String TAG = CloudStoryHomeFragment.class.getName();

    private ImageView mStoryCategoryIv,mStoryRankIv,mStoryAnchorIv;
    private TextView mSearchTv;
    private RelativeLayout mTopRankRv;
    private RecyclerView mDataRv;
    private StoryAlbumAdapter mAdapter;

    private LoadSir mLoadSir;
    private LoadService mAlbumLoadService;

    List<StoryTelling> mItemlist;

    @Override
    public int getLayoutId() {
        return R.layout.frag_cloudstory_home;
    }

    @Override
    public void initView(View view) {
        try {
            // 界面的加载等待框架配置
            mLoadSir = new LoadSir.Builder()
                    .addCallback(new LoadingCallback())
                    .addCallback(new TimeoutCallback())
                    .addCallback(new ErrorCallback())
                    .addCallback(new EmptyCallback())
                    .setDefaultCallback(LoadingCallback.class)
                    .build();

            mSearchTv = view.findViewById(R.id.cloudstory_home_search);

            mStoryCategoryIv = view.findViewById(R.id.cloudstory_home_category);
            mStoryRankIv = view.findViewById(R.id.cloudstory_home_rank);
            mStoryAnchorIv = view.findViewById(R.id.cloudstory_home_anchor);

            mTopRankRv = view.findViewById(R.id.cloudstory_home_rank_layout);

            mDataRv = view.findViewById(R.id.cloudstory_home_recyclerview);
            GridLayoutManager gridLayoutManager = new GridLayoutManager(mContext, 3);
            mDataRv.setLayoutManager(gridLayoutManager);
            mAdapter = new StoryAlbumAdapter(9,this);
            mDataRv.setAdapter(mAdapter);
            mDataRv.setHasFixedSize(true);
            mDataRv.setNestedScrollingEnabled(false);

            mAlbumLoadService = mLoadSir.register(mDataRv, new Callback.OnReloadListener() {
                @Override
                public void onReload(View v) {
                    showLoadCallBack(mAlbumLoadService, LoadingCallback.class);
                    requestCloudResource();
                }
            });

        }catch (Exception e){
            e.printStackTrace();
        }
    }

    @Override
    public void initListener() {
        mSearchTv.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                // 跳转到搜索界面
                CloudStorySearchFragment fragment = new CloudStorySearchFragment();
                if (getActivity() instanceof MainRoomActivity) {
                    ((MainRoomActivity) getActivity()).showFragment(fragment);
                }
            }
        });

        mStoryCategoryIv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 分类界面
                CloudStoryCategoryFragment fragment = new CloudStoryCategoryFragment();
                if (getActivity() instanceof MainRoomActivity) {
                    ((MainRoomActivity) getActivity()).showFragment(fragment);
                }
            }
        });

        mStoryRankIv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 榜单界面
                CloudStoryRankFragment fragment = new CloudStoryRankFragment();
                if (getActivity() instanceof MainRoomActivity) {
                    ((MainRoomActivity) getActivity()).showFragment(fragment);
                }
            }
        });

        mStoryAnchorIv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 进入主播界面
                CloudStoryAnchorFragment fragment = new CloudStoryAnchorFragment();
                if (getActivity() instanceof MainRoomActivity) {
                    ((MainRoomActivity) getActivity()).showFragment(fragment);
                }
            }
        });

        mTopRankRv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 进入热门榜单
                CloudStoryRecommandAlbumFragment fragment = new CloudStoryRecommandAlbumFragment();
                if (getActivity() instanceof MainRoomActivity) {
                    ((MainRoomActivity) getActivity()).showFragment(fragment);
                }
            }
        });
    }

    @Override
    public void initData() {
        requestCloudResource();
    }

    @Override
    public void onLazyLoad() {
        initData();
    }


    @Override
    public void onRetryLoad() {
        super.onRetryLoad();
        if (mItemlist == null){
            requestCloudResource();
        }
    }

    @Override
    public void onAlbumItemClick(StoryTelling storyTellingItem) {
        // 进入专辑的媒体列表
        CloudStoryMediaListAlbumFragment fragment = new CloudStoryMediaListAlbumFragment();
        fragment.updateStoryTellingSet(storyTellingItem);
        if (getActivity() instanceof MainRoomActivity) {
            ((MainRoomActivity) getActivity()).showFragment(fragment);
        }
    }

    /********************************    **************************************/
    public void showLoadCallBack(LoadService loadService,Class<? extends Callback> callback){
        if (loadService != null){
            loadService.showCallback(callback);
        }
    }

    public void updateDataList(List<StoryTelling> list){
        if (list != null) {
            mItemlist = list;
            mAdapter.updateDataList(list);
            mAdapter.notifyDataSetChanged();

            showLoadCallBack(mAlbumLoadService,SuccessCallback.class);
        }else{
            showLoadCallBack(mAlbumLoadService,EmptyCallback.class);
        }
    }

    private void requestCloudResource(){
        showLoadCallBack(mAlbumLoadService,LoadingCallback.class);
        WRoom room = WApp.Instance.getDevManager().getSelectedRoom();
        if (room != null){
            String pushType = "recommend";
            WRoom.cmdGetStorytellingPush(pushType,9,1, new CmdActionLister<List<StoryTelling>>(this, new ICmdCallback<List<StoryTelling>>() {
                @Override
                public void onSuccess(List<StoryTelling> data) {
                    updateDataList(data);
                }

                @Override
                public void onFailed(int code, String msg) {
                    updateDataList(null);
                    Toast.makeText(getContext(),"GetStorytellingPush获取失败:"+code,Toast.LENGTH_SHORT).show();
                }
            }));
        }else{
            updateDataList(null);
        }
    }
}
