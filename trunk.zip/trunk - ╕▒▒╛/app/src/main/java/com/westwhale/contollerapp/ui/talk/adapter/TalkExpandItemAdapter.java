package com.westwhale.contollerapp.ui.talk.adapter;

import android.view.View;
import android.widget.ImageView;

import com.chad.library.adapter.base.BaseMultiItemQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.chad.library.adapter.base.entity.AbstractExpandableItem;
import com.chad.library.adapter.base.entity.MultiItemEntity;
import com.westwhale.api.protocolapi.bean.Talk;
import com.westwhale.api.protocolapi.bean.hostroom.Host;
import com.westwhale.api.protocolapi.bean.hostroom.Room;
import com.westwhale.contollerapp.R;

import java.util.Iterator;
import java.util.List;

public class TalkExpandItemAdapter extends BaseMultiItemQuickAdapter<MultiItemEntity, BaseViewHolder> {
    public final static int ITEM_TYPE_TALK = 0;
    public final static int ITEM_TYPE_ROOM = 1;

    public final static int ITEM_MODE_NORMAL = 0;
    public final static int ITEM_MODE_DELETE = 1;
    private int mItemMode = ITEM_MODE_NORMAL;

    private CallBack mCallBack;

    public interface CallBack{
        void onTalkItemClick(Talk item);
        void onTalkItemStatClick(Talk item);
        void onTalkItemDeleteClick(Talk item);
    }

    public void setCallBack(CallBack callBack){
        mCallBack = callBack;
    }

    public void setItemMode(int mode){
        if ((mode == ITEM_MODE_NORMAL) || (mode == ITEM_MODE_DELETE)){
            mItemMode = mode;
        }
    }

    public void addTalkItem(List<Talk> talkList){
        if (talkList != null){
            for (Talk talk: talkList) {
                TalkItem talkItem = new TalkItem(talk);
                addData(talkItem);
            }
        }
    }

    public void addTalkRoomItem(Talk talk,List<Room> roomList){
        int pos = -1;
        TalkItem targetItem = null;
        if ((roomList != null) && (mData != null)) {
            for (int i=0; i < mData.size(); i++){
                if (mData.get(i) instanceof TalkItem){
                    TalkItem item = (TalkItem)mData.get(i);
                    if (item.mTalk == talk){
                        pos = i;
                        targetItem = item;
                        break;
                    }
                }
            }

            if (targetItem != null){
                for (Room room : roomList) {
                    if (room != null) {
                        targetItem.addSubItem(new RoomItem(room));
                    }
                }
                expand(pos);
            }
        }
    }

    public void addDataItem(Talk talk,List<Room> roomList){
        if (talk != null ){
            TalkItem talkItem = new TalkItem(talk);
            if (roomList != null) {
                for (Room room : roomList) {
                    if (room != null) {
                        talkItem.addSubItem(new RoomItem(room));
                    }
                }
            }

            addData(talkItem);
            expand(mData.size()-1);
        }
    }

    public void updateTalkItem(int talkId, String preSetTalkStat) {
        int pos = -1;
        for (int i=0; i < mData.size(); i++){
            if (mData.get(i) instanceof TalkItem){
                if (((TalkItem) mData.get(i)).mTalk.talkId == talkId){
                    ((TalkItem) mData.get(i)).mTalk.talkStat = preSetTalkStat;
                    pos = i;
                    break;
                }
            }
        }

        notifyItemChanged(pos);
    }

    public void removeTalkItem(int talkId) {
        int pos = -1;
        for (int i=0; i < mData.size(); i++){
            if (mData.get(i) instanceof TalkItem){
                if (((TalkItem) mData.get(i)).mTalk.talkId == talkId){
                    pos = i;
                    break;
                }
            }
        }

        remove(pos);
    }

    public void removeALl(){
        if (mData != null) {
            mData.clear();
        }
        notifyDataSetChanged();
    }


    public TalkExpandItemAdapter(List<MultiItemEntity> list){
        super(list);

        addItemType(ITEM_TYPE_TALK,R.layout.item_talk_talk);
        addItemType(ITEM_TYPE_ROOM,R.layout.item_talk_room);
    }

    @Override
    protected void convert(BaseViewHolder helper, MultiItemEntity item) {
        switch (helper.getItemViewType()) {
            case ITEM_TYPE_TALK:


                final TalkItem hostItem = (TalkItem) item;

                if (hostItem.mTalk != null) {
                    helper.setText(R.id.item_talk_name, hostItem.mTalk.talkName);
                }

                helper.itemView.findViewById(R.id.item_talk_stat).setVisibility(View.GONE);
                helper.itemView.findViewById(R.id.item_talk_delete).setVisibility(View.GONE);

                if (mItemMode == ITEM_MODE_NORMAL){
                    helper.itemView.findViewById(R.id.item_talk_stat).setVisibility(View.VISIBLE);
                    int statPicResourceId = R.drawable.btn_lock;
                    if (hostItem.mTalk.talkStat.equals("open")){
                        statPicResourceId = R.drawable.btn_unlock;
                    }
                    ((ImageView)helper.itemView.findViewById(R.id.item_talk_stat)).setImageResource(statPicResourceId);

                }else if (mItemMode == ITEM_MODE_DELETE){
                    helper.itemView.findViewById(R.id.item_talk_delete).setVisibility(View.VISIBLE);
                }

                helper.itemView.findViewById(R.id.item_talk_stat).setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (mCallBack != null){
                            mCallBack.onTalkItemStatClick(hostItem.mTalk);
                        }
                    }
                });

                helper.itemView.findViewById(R.id.item_talk_delete).setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (mCallBack != null){
                            mCallBack.onTalkItemDeleteClick(hostItem.mTalk);
                        }
                    }
                });

                helper.itemView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        // 展开或收起
//                        int pos = helper.getAdapterPosition();
//                        if (hostItem.isExpanded()) {
//                            collapse(pos);
//                        } else {
//                            expand(pos);
//                        }
                        if (mCallBack != null){
                            mCallBack.onTalkItemClick(hostItem.mTalk);
                        }
                    }
                });
                break;
            case ITEM_TYPE_ROOM:
                final RoomItem roomItem = (RoomItem) item;
                if (roomItem.mRoom != null){
                    helper.setText(R.id.item_talk_room_name,roomItem.mRoom.roomName);
                }

                break;
        }
    }


    class RoomItem implements MultiItemEntity{
        private Room mRoom;
        RoomItem(Room room){
            mRoom = room;
        }

        @Override
        public int getItemType() {
            return ITEM_TYPE_ROOM;
        }
    }

    class TalkItem extends AbstractExpandableItem<RoomItem> implements MultiItemEntity{
        private Talk mTalk;

        TalkItem(Talk talk){
            mTalk = talk;
        }

        @Override
        public int getLevel() {
            return 0;
        }

        @Override
        public int getItemType() {
            return ITEM_TYPE_TALK;
        }
    }


}
