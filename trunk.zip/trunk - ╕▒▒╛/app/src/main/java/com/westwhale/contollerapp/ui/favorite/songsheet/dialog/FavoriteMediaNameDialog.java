package com.westwhale.contollerapp.ui.favorite.songsheet.dialog;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.DialogFragment;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.TextView;

import com.westwhale.contollerapp.R;
import com.westwhale.contollerapp.ui.base.dialog.AttachDialogFragment;

/**
 * Description:
 * Author: chenyaoli
 * Date: 2018-12-01
 * History:
 */
public class FavoriteMediaNameDialog extends AttachDialogFragment {
    public static final String TAG = FavoriteMediaNameDialog.class.getName();

    public static final String PLAYLIST_NAME = "playlistName";
    public static final String PLAYLIST_ID = "playlistId";

    public static final int REQUEST_CODE_NEW = 1;
    public static final int DIALOG_TYPE_NEW = 1;

    public static final int DIALOG_TYPE_RENAME = 2;
    public static final int REQUEST_CODE_EDIT = 2;

    private EditText mNameEv;
    private TextView mTitleTv, mCancelTv,mOKTv;

    private int mDialogType = DIALOG_TYPE_NEW;
    private String mPlaylistName;
    private int mPlaylistId;
    public void configDialogType(int type,String name,int id){
        if (type == DIALOG_TYPE_NEW){
            mDialogType = type;
            mPlaylistName = name;
            mPlaylistId = -1;
        }else if (type == DIALOG_TYPE_RENAME){
            mDialogType = type;
            mPlaylistName = name;
            mPlaylistId = id;
        }
    }

    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);
        if (!isVisibleToUser){
            // 隐藏虚拟键盘
            if (getActivity() != null){
                InputMethodManager imm = (InputMethodManager)getActivity().getSystemService(Context.INPUT_METHOD_SERVICE);
                if (imm != null) {
                    imm.hideSoftInputFromWindow(mNameEv.getWindowToken(), 0);
                }
            }
        }
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // 背景色，动画效果，通过主题设置
        setStyle(DialogFragment.STYLE_NORMAL, R.style.CommonDialogStyle);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        //布局
        View view = inflater.inflate(R.layout.dialogfrag_textedit, container);

        initView(view);
        initListener();

        return view;
    }

    @Override
    public void onStart() {
        super.onStart();

        //设置fragment高度 、宽度
        double heightPercent = 0.5;
        double widthPercent = 0.85;
        int dialogHeight = (int) (mContext.getResources().getDisplayMetrics().heightPixels * heightPercent);
        int dialogWidth = (int) (mContext.getResources().getDisplayMetrics().widthPixels * widthPercent);
        Window window = getDialog().getWindow();
        if (window != null) {
            WindowManager.LayoutParams params = window.getAttributes();
            params.gravity = Gravity.CENTER;
            params.width = dialogWidth;
//            params.height = dialogHeight;
            params.height = ViewGroup.LayoutParams.WRAP_CONTENT;
            window.setAttributes(params);
        }
        getDialog().setCanceledOnTouchOutside(true);

        initData();
    }

    private void initView(View view) {

        mTitleTv = view.findViewById(R.id.dialog_textedit_title);
        mNameEv = view.findViewById(R.id.dialog_textedit_edit);
        mCancelTv = view.findViewById(R.id.dialog_textedit_cancel);
        mOKTv = view.findViewById(R.id.dialog_textedit_ok);
    }

    private void initListener() {
        mCancelTv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dismiss();
            }
        });

        mOKTv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 把选中的结果传递出去
                if ( getTargetFragment() == null) {
                    return ;
                }

                String name = mNameEv.getText().toString();
                if (name.isEmpty()){
                    return;
                }

                Intent intent = new Intent();
                intent.putExtra(PLAYLIST_NAME,name);
                intent.putExtra(PLAYLIST_ID,mPlaylistId);

                int requestCode = REQUEST_CODE_NEW;
                if (DIALOG_TYPE_RENAME == mDialogType){
                    requestCode = REQUEST_CODE_EDIT;
                }

                //获得目标Fragment,并将数据通过onActivityResult放入到intent中进行传值
                getTargetFragment().onActivityResult(requestCode, Activity.RESULT_OK, intent);

                dismiss();
            }
        });
    }

    private void initData() {
        mNameEv.setHint(R.string.favorite_media_name_songsheet_name_hint);

        if (mDialogType == DIALOG_TYPE_NEW){
            mTitleTv.setText(R.string.favorite_media_name_songsheet_new_title);
        }else if (mDialogType == DIALOG_TYPE_RENAME){
            mTitleTv.setText(R.string.favorite_media_name_songsheet_rename_title);
            mNameEv.setText(mPlaylistName);

        }
    }

}
