package com.westwhale.contollerapp.ui.scene.bean;


import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;

public class CmdSetVolume extends CmdActionBase {

    private int mVolume = 10;

    public CmdSetVolume() {
        mType = CMD_TYPE_SETVOLUME;
        mCmdName = getCmdName();
    }

    @Override
    public String toJsonString() {
        JSONObject argObject = new JSONObject();
        argObject.put("volume",mVolume);

        JSONObject jsonObject = new JSONObject();
        jsonObject.put("cmd",mCmdName);
        jsonObject.put("arg",argObject);

        return jsonObject.toJSONString();
    }

    @Override
    public String getActionValue() {
        String value = String.valueOf(mVolume);

        return value;
    }

    @Override
    public void parseArgs() {
        if ((mCmdArgs == null) || (mCmdArgs.isEmpty())){
            return;
        }

        try {
            mVolume = JSON.parseObject(mCmdArgs).getIntValue("volume");
        }catch (Exception e){
            mVolume = 0;
        }
    }

    public void setVolume(int volume){
        mVolume = volume;
    }

    public int getVolume(){
        return mVolume;
    }
}
