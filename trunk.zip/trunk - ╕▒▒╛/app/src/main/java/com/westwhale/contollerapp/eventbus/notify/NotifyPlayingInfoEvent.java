package com.westwhale.contollerapp.eventbus.notify;

import com.westwhale.api.protocolapi.bean.hostroom.PlayingInfo;

/**
 * Description:
 * Author: chenyaoli
 * Date: 2018-12-24
 * History:
 */
public class NotifyPlayingInfoEvent {
    PlayingInfo mPlaingInfo;
    public NotifyPlayingInfoEvent(PlayingInfo playingInfo){
        mPlaingInfo = playingInfo;
    }
    public PlayingInfo getPlayingInfo() {
        return mPlaingInfo;
    }
}
