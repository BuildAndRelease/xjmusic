package com.westwhale.contollerapp.ui.localmusic.adapter;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.westwhale.contollerapp.R;
import com.westwhale.api.protocolapi.bean.media.LocalMusic;

import java.util.ArrayList;
import java.util.List;

/**
 * Description:
 * Author: chenyaoli
 * Date: 2018-12-14
 * History
 *
 */
public class LocalMusicAdapter extends RecyclerView.Adapter {
    private List<LocalMusic> mItemList;
    private CallBack mCallBack;

    public interface CallBack{
        void onSongItemClick(LocalMusic songItem);
        void onSongItemMoreClick(LocalMusic songItem);
    }

    public void upateDataList(ArrayList<LocalMusic> itemList){
        this.mItemList = itemList;
    }

    public void clearDataList(){
        if (mItemList != null){
            this.mItemList.clear();
        }
        notifyDataSetChanged();
    }

    public void addToDataList(List<LocalMusic> itemList){
        if (mItemList == null){
            mItemList = new ArrayList<>();
            notifyDataSetChanged();
        }
        mItemList.addAll(itemList);
    }

    public LocalMusicAdapter(CallBack callBack){
        this.mItemList = null;
        this.mCallBack = callBack;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_local_song, viewGroup, false);
        return new MusicListItemHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder viewHolder, int i) {
        if (viewHolder instanceof MusicListItemHolder){
            if (mItemList.get(i) != null){
                // 在此处，处理默认类型的 viewHolder
                LocalMusic item = (LocalMusic)mItemList.get(i);
                MusicListItemHolder itemHolder = (MusicListItemHolder)viewHolder;
                itemHolder.mSongNoTv.setText(String.valueOf(i));
                itemHolder.mSongNameTv.setText(item.songName);
                itemHolder.mSongSingerTv.setText(item.getSingersName());

                viewHolder.itemView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        mCallBack.onSongItemClick(item);
                    }
                });

                ((MusicListItemHolder) viewHolder).mItemMoreIv.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        mCallBack.onSongItemMoreClick(item);
                    }
                });
            }
        }
    }

    @Override
    public int getItemCount() {
        return (mItemList == null) ? 0 : mItemList.size();
    }

    /********************************  ItemHolder *******************************/
    private class MusicListItemHolder extends RecyclerView.ViewHolder{
        ImageView mItemMoreIv;
        TextView mSongNoTv, mSongNameTv, mSongSingerTv;
        MusicListItemHolder(@NonNull View itemView) {
            super(itemView);
            mItemMoreIv = itemView.findViewById(R.id.item_local_song_more);
            mSongNoTv = itemView.findViewById(R.id.item_local_song_no);
            mSongNameTv = itemView.findViewById(R.id.item_local_song_name);
            mSongSingerTv = itemView.findViewById(R.id.item_local_song_artist);
        }
    }
}
