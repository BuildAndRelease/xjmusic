package com.westwhale.contollerapp.ui.scene.activity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.ActionBar;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.View;

import com.westwhale.api.protocolapi.bean.media.Media;
import com.westwhale.contollerapp.R;
import com.westwhale.contollerapp.common.ImageTextItem;
import com.westwhale.contollerapp.ui.base.activity.BaseActivity;
import com.westwhale.contollerapp.ui.widget.adapter.ImageTextItemAdapter;

import java.util.ArrayList;
import java.util.List;


public class SceneSwitchSourceActivity extends BaseActivity implements ImageTextItemAdapter.CallBack {
    public static final String RESULT_KEY_MEDIASRC = "mediaSrc";

    private final int SOURCE_TYPE_CLOUDMUSIC = 1;
    private final int SOURCE_TYPE_LOCALMUSIC = 2;
    private final int SOURCE_TYPE_CLOUDNETFM = 3;
    private final int SOURCE_TYPE_CLOUDSTORYTELLING = 4;
    private final int SOURCE_TYPE_AUX1 = 5;
    private final int SOURCE_TYPE_AUX2 = 6;

    private Toolbar mToolbar;
    private RecyclerView mDataRv;
    private ImageTextItemAdapter mAdapter;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_slider_switchsource);

        initView();
        initListener();

        initData();
    }

    @Override
    public void onItemClick(ImageTextItem item, int pos) {
        if ((item != null) && (pos > -1)){
            String mediaSrcName = "";
            switch (item.getType()){
                case SOURCE_TYPE_CLOUDMUSIC:
                    mediaSrcName = Media.CLOUD_MUSIC;
                    break;
                case SOURCE_TYPE_CLOUDSTORYTELLING:
                    mediaSrcName = Media.CLOUD_STORY_TELLING;
                    break;
                case SOURCE_TYPE_CLOUDNETFM:
                    mediaSrcName = Media.CLOUD_NETFM;
                    break;
                case SOURCE_TYPE_LOCALMUSIC:
                    mediaSrcName = Media.LOCAL_MUSIC;
                    break;
                case SOURCE_TYPE_AUX1:
                    mediaSrcName = Media.AUX1;
                    break;
                case SOURCE_TYPE_AUX2:
                    mediaSrcName = Media.AUX2;
                    break;
                default:
                    break;
            }

            Intent intent= new Intent();
            intent.putExtra(RESULT_KEY_MEDIASRC,mediaSrcName);
            setResult(Activity.RESULT_OK,intent);

            finish();
        }
    }

    private void initView() {
        mToolbar = findViewById(R.id.slider_switchsource_toolbar);
        // 设置toolbar
        setSupportActionBar(mToolbar);
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(true);
        }

        mDataRv = findViewById(R.id.slider_switchsource_recyclerview);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        mDataRv.setLayoutManager(linearLayoutManager);
        mAdapter = new ImageTextItemAdapter();
        mAdapter.setCallBack(this);
        mDataRv.setAdapter(mAdapter);
        mDataRv.setHasFixedSize(true);
        mDataRv.addItemDecoration(new DividerItemDecoration(this, DividerItemDecoration.VERTICAL));
        // 设置下拉上拉无阴影效果
        mDataRv.setOverScrollMode(View.OVER_SCROLL_NEVER);
    }

    private void initListener() {
        mToolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

    }

    private void initData() {
        List<ImageTextItem> dataList = new ArrayList<>();

        dataList.add(new ImageTextItem(SOURCE_TYPE_CLOUDMUSIC,R.drawable.switchsource_cloudmusic,getString(R.string.switchsoure_cloudmusic)));
        dataList.add(new ImageTextItem(SOURCE_TYPE_CLOUDSTORYTELLING,R.drawable.switchsource_story,getString(R.string.switchsoure_story)));
        dataList.add(new ImageTextItem(SOURCE_TYPE_CLOUDNETFM,R.drawable.switchsource_netfm,getString(R.string.switchsoure_netfm)));
        dataList.add(new ImageTextItem(SOURCE_TYPE_LOCALMUSIC,R.drawable.switchsource_lcoalmusic,getString(R.string.switchsoure_localmusic)));
        dataList.add(new ImageTextItem(SOURCE_TYPE_AUX1,R.drawable.switchsource_aux,getString(R.string.switchsoure_aux0)));
        dataList.add(new ImageTextItem(SOURCE_TYPE_AUX2,R.drawable.switchsource_aux,getString(R.string.switchsoure_aux1)));

        mAdapter.setDataList(dataList);
        mAdapter.notifyDataSetChanged();
    }


}
