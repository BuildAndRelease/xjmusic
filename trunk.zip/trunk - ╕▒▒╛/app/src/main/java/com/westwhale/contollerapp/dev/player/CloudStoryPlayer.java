package com.westwhale.contollerapp.dev.player;

import com.westwhale.contollerapp.dev.CmdActionLister;
import com.westwhale.api.protocolapi.bean.media.Section;

public class CloudStoryPlayer extends WPlayer<Section> {
    private final static String TAG = "CloudStoryPlayer";

    @Override
    public synchronized void updatePlayMode(String playMode) {

    }

    @Override
    public void cmdSetPlayMode(String playmode) {

    }

    @Override
    public void cmdSetPlayMode(String playmode, CmdActionLister<Boolean> actionLister) {

    }
}
