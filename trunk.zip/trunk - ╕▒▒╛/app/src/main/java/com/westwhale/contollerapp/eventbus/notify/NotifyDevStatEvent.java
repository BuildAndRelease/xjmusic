package com.westwhale.contollerapp.eventbus.notify;

public class NotifyDevStatEvent {
    private String mDevStat;

    public NotifyDevStatEvent(String devstat){
        mDevStat = devstat;
    }
    public String getDevStat() {
        return mDevStat;
    }
}
