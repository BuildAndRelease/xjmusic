package com.westwhale.contollerapp.ui.main.adapter;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.westwhale.contollerapp.R;
import com.westwhale.api.protocolapi.bean.hostroom.Host;
import com.westwhale.api.protocolapi.bean.hostroom.Room;

import java.util.ArrayList;
import java.util.HashMap;

public class SearchDevItemAdapter extends RecyclerView.Adapter {
    private final static int ITEM_TYPE_HOST = 1;
    private final static int ITEM_TYPE_ROOM = 2;
    private final static int ITEM_TYPE_DEFAULT = -1;

    public ArrayList<Object> mItemList = new ArrayList<>();
    private CallBack mCallBack;

    public interface CallBack{
        void onHostItemClick(Host host);
        void onRoomItemClick(Room room);
        void onRoomStatClick(Room room);
    }

    public void setCallBack(CallBack callBack){
        mCallBack = callBack;
    }

    public void addHostItem(Host host){
        if (host != null){
            int index = mItemList.size();
            mItemList.add(host);
            mItemList.addAll(host.rooms);
            notifyItemRangeInserted(index,host.rooms.size()+1);
//            notifyItemRangeInserted(index,host.rooms.size());
        }

    }
    public void updateHostItem(Object object){
        int index = mItemList.indexOf(object);
        if (index > -1){
            mItemList.set(index,object);
            notifyItemChanged(index);
        }
    }

    public void updateItemList(HashMap<String, Host>  hostMap) {
        mItemList.clear();
        for (Host host : hostMap.values()) {
            mItemList.addAll(host.rooms);
            if (mItemList.add(host)) {
                mItemList.addAll(host.rooms);
            }
        }
        notifyDataSetChanged();
    }


    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        switch (i) {
            case ITEM_TYPE_HOST: {
                View v0 = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_search_host, viewGroup, false);
                return new HostItemViewHolder(v0);
            }
            case ITEM_TYPE_ROOM: {
                View v1 = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_search_room, viewGroup, false);
                return new RoomItemViewHolder(v1);
            }
            default:
                // 默认返回 HOST 类型的 viewHolder
                View v2 = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_search_host, viewGroup, false);
                return new HostItemViewHolder(v2);
        }
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder viewHolder, int i) {
        switch (getItemViewType(i)) {
            case ITEM_TYPE_HOST:
                if (viewHolder instanceof HostItemViewHolder) {
                    // 在此处，处理默认类型的 viewHolder
                    if (mItemList.get(i) instanceof Host) {
                        Host host = (Host) mItemList.get(i);
                        HostItemViewHolder hostItemView = (HostItemViewHolder) viewHolder;
                        hostItemView.hostNameView.setText(host.name);
                        hostItemView.hostTypeView.setText(host.deviceType);

                        hostItemView.itemView.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                if (mCallBack != null){
                                    mCallBack.onHostItemClick(host);
                                }
                            }
                        });
                    }
                }
                break;
            case ITEM_TYPE_ROOM:
                if (viewHolder instanceof RoomItemViewHolder) {
                    Room room = (Room) mItemList.get(i);
                    RoomItemViewHolder roomItemView = (RoomItemViewHolder) viewHolder;
                    roomItemView.roomNameView.setText(room.roomName);

                    if (room.devStat.equals(Room.DevState.CLOSE)) {
                        roomItemView.roomDevStateView.setImageResource(R.drawable.btn_lock);
                    }else if (room.devStat.equals(Room.DevState.OPEN)) {
                        roomItemView.roomDevStateView.setImageResource(R.drawable.btn_unlock);
                    }else{
                        roomItemView.roomDevStateView.setImageResource(R.drawable.room_state_unconnect);
                    }

                    roomItemView.roomDevStateView.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            if (mCallBack != null){
                                mCallBack.onRoomStatClick(room);
                            }
                        }
                    });

                    roomItemView.itemView.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            if (mCallBack != null){
                                mCallBack.onRoomItemClick(room);
                            }
                        }
                    });
                }
                break;
            default:
                break;
        }

    }

    @Override
    public int getItemCount() {
        return (mItemList == null) ? 0 : mItemList.size();
    }

    @Override
    public int getItemViewType(int position) {
        if (getItemCount() == 0) {
            return ITEM_TYPE_DEFAULT;
        }
        if (mItemList.get(position) instanceof Host) {
            return ITEM_TYPE_HOST;
        }
        if (mItemList.get(position) instanceof Room) {
            return ITEM_TYPE_ROOM;
        }

        return ITEM_TYPE_DEFAULT;
    }


    /******************************** ItemHolder  *************************************/
    private class HostItemViewHolder extends RecyclerView.ViewHolder{
        TextView hostNameView;
        TextView hostTypeView;
        ImageView moreView;

        HostItemViewHolder(@NonNull View itemView) {
            super(itemView);
            hostNameView = itemView.findViewById(R.id.item_search_host_name);
            hostTypeView = itemView.findViewById(R.id.item_search_host_type);
            moreView = itemView.findViewById(R.id.item_search_more_menu);
        }
    }

    private class RoomItemViewHolder extends RecyclerView.ViewHolder {
        TextView roomNameView;
        ImageView roomDevStateView;

        RoomItemViewHolder(@NonNull View itemView) {
            super(itemView);
            roomNameView = itemView.findViewById(R.id.item_search_room_name);
            roomDevStateView = itemView.findViewById(R.id.item_search_room_state);
        }
    }
}
