package com.westwhale.contollerapp.ui.favorite.songsheet.adapter;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.westwhale.contollerapp.R;
import com.westwhale.api.protocolapi.bean.PlayList;

import java.util.List;

/**
 * Description:
 * Author: chenyaoli
 * Date: 2018-11-30
 * History:
 */
public class FavoriteAddMediaAdapter extends RecyclerView.Adapter {
    private List<PlayList> mItemList;
    private CallBack mPlayListItemClick;

    public interface CallBack{
        void onPlayListItemClick(PlayList playList);
    }

    public void setCallBack(CallBack callBack){
        this.mPlayListItemClick = callBack;
    }

    public void setDataList(List<PlayList> itemList){
        this.mItemList = itemList;
    }
    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_favorite_media_addmedia, viewGroup, false);
        return new ItemHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder viewHolder, int i) {
        if (viewHolder instanceof ItemHolder){
            final PlayList item = mItemList.get(i);
            ItemHolder itemHolder = (ItemHolder)viewHolder;
            itemHolder.mHintTextTv.setText(item.playListName);
            if (0 == item.playListId){
                itemHolder.mPicIv.setImageResource(R.drawable.favorite_default);
            }else{
                itemHolder.mPicIv.setImageResource(R.drawable.favorite_common);
            }

            itemHolder.itemView.setTag(i + "");
            itemHolder.itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (mPlayListItemClick != null){
                        mPlayListItemClick.onPlayListItemClick(item);
                    }
                }
            });
        }
    }

    @Override
    public int getItemCount() {
        return (mItemList == null) ? 0 : mItemList.size();
    }

    private class ItemHolder extends RecyclerView.ViewHolder{
        private ImageView mPicIv;
        private TextView mHintTextTv;
        public ItemHolder(@NonNull View itemView) {
            super(itemView);
            mPicIv = itemView.findViewById(R.id.item_favorite_media_addmedia_pic);
            mHintTextTv = itemView.findViewById(R.id.item_favorite_media_addmedia_text);
        }
    }
}
