package com.westwhale.contollerapp.common;

/**
 * Created
 */
public class ImageTextItem {

    private int mType;
    private String mTitle;   //信息标题
    private int mImageRes; //图片ID
    private boolean mStat = true;

    public ImageTextItem(){
        this(-1,-1,"",true);
    }

    public ImageTextItem(int type,String title){
        this(type,-1,title,true);
    }

    public ImageTextItem(int type,int imgResId,String title){
        this(type,imgResId,title,true);
    }

    public ImageTextItem(int type,int imgResId,String title,boolean stat){
        mType = type;
        mImageRes = imgResId;
        mTitle = title;
        mStat = stat;
    }

    public int getType(){
        return mType;
    }

    public void setItemStat(boolean stat){
        mStat = stat;
    }

    public boolean getItemStat(){
        return mStat;
    }

    public String getTitle() {
        return mTitle;
    }

    //标题
    public void setTitle(String mTitle) {
        this.mTitle = mTitle;
    }

    public int getImageRes() {
        return mImageRes;
    }

    //图片
    public void setImageRes(int mImageRes) {
        this.mImageRes = mImageRes;
    }

}
