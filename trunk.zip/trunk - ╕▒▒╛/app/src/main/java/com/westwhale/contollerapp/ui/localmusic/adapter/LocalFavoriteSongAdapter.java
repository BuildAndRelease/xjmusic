package com.westwhale.contollerapp.ui.localmusic.adapter;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.westwhale.contollerapp.R;
import com.westwhale.api.protocolapi.bean.PlayList;

import java.util.ArrayList;
import java.util.List;

/**
 * Description: 
 * Author: chenyaoli
 * Date: 2018-12-14
 * History
 *
 */
public class LocalFavoriteSongAdapter extends RecyclerView.Adapter {
    private List<PlayList> mItemList;
    private CallBack mLocalHomeItemClick;

    public interface CallBack{
        void onFavoriteSongItemClick(PlayList item);
    }

    public void setCallBack(CallBack callBack){
        this.mLocalHomeItemClick = callBack;
    }

    public void setDataList(List<PlayList> datalist){
        mItemList = datalist;
    }
    public void updateList(ArrayList<PlayList> itemList){
        this.mItemList = itemList;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_local_favorite_song, viewGroup, false);
        return new ItemHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder viewHolder, int i) {
        if (viewHolder instanceof ItemHolder){
            final PlayList item = mItemList.get(i);
            ItemHolder itemHolder = (ItemHolder)viewHolder;
            String itemNo = (i+1)+"";
            itemHolder.mItemNo.setText(itemNo);
            itemHolder.mItemName.setText(item.playListName);
            itemHolder.itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (mLocalHomeItemClick != null){
                        mLocalHomeItemClick.onFavoriteSongItemClick(item);
                    }
                }
            });
        }
    }

    @Override
    public int getItemCount() {
        return (mItemList == null) ? 0 : mItemList.size();
    }

    private class ItemHolder extends RecyclerView.ViewHolder{
        private TextView mItemNo,mItemName;
        public ItemHolder(@NonNull View itemView) {
            super(itemView);
            mItemNo = itemView.findViewById(R.id.item_local_song_no);
            mItemName = itemView.findViewById(R.id.item_local_song_name);
        }
    }
}
