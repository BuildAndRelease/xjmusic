package com.westwhale.contollerapp.ui.favorite.songsheet.dialog;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.DialogFragment;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.blankj.utilcode.util.ToastUtils;
import com.westwhale.contollerapp.R;
import com.westwhale.contollerapp.application.WApp;
import com.westwhale.contollerapp.dev.CmdActionLister;
import com.westwhale.contollerapp.dev.ICmdCallback;
import com.westwhale.contollerapp.dev.WRoom;
import com.westwhale.contollerapp.ui.base.dialog.AttachDialogFragment;
import com.westwhale.contollerapp.ui.favorite.songsheet.adapter.FavoriteAddMediaAdapter;
import com.westwhale.api.protocolapi.bean.media.Media;
import com.westwhale.api.protocolapi.bean.PlayList;

import java.util.List;

/**
 * Description:
 * Author: chenyaoli
 * Date: 2018-11-30
 * History:
 */
public class FavoriteAddMediaDialog extends AttachDialogFragment implements FavoriteAddMediaAdapter.CallBack{
    public static final String TAG = FavoriteAddMediaDialog.class.getName();

    private TextView mTitleTv;
    private ImageView mCancelIv;
    private RecyclerView mItemRv;
    private FavoriteAddMediaAdapter mFavoriteAdapter;

    private String mMediaSrc;
    private List<? extends Media> mMediaList;
    public <T extends Media> void updateMediaList(String mediaSrc,List<T> list){
        mMediaSrc = mediaSrc;
        mMediaList = list;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // 背景色，动画效果，通过主题设置
        setStyle(DialogFragment.STYLE_NORMAL,R.style.CommonDialogStyle);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.dialogfrag_favorite, container);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        initView(view);
        initListener();
    }

    @Override
    public void onStart() {
        super.onStart();

        //设置fragment高度 、宽度
        double heightPercent = 0.4;
        double widthPercent = 0.9;
        int dialogHeight = (int) (mContext.getResources().getDisplayMetrics().heightPixels * heightPercent);
        int dialogWidth = (int) (mContext.getResources().getDisplayMetrics().widthPixels * widthPercent);
        Window window = getDialog().getWindow();
        assert window != null;
        WindowManager.LayoutParams params = window.getAttributes();
        params.gravity = Gravity.CENTER;
        params.width = dialogWidth;
        params.height = dialogHeight;
        window.setAttributes(params);
        getDialog().setCanceledOnTouchOutside(true);

        initData();
    }

    private void initView(View view) {
        mTitleTv = view.findViewById(R.id.dialogfrag_favorite_title);
        mTitleTv.setText(getString(R.string.favorite_media_add_title));

        mCancelIv = view.findViewById(R.id.dialogfrag_favorite_cancel);

        mItemRv = view.findViewById(R.id.dialogfrag_favorite_recylerview);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(mContext);
        mItemRv.setLayoutManager(linearLayoutManager);
        mFavoriteAdapter = new FavoriteAddMediaAdapter();
        mFavoriteAdapter.setCallBack(this);
        mItemRv.setAdapter(mFavoriteAdapter);
        mItemRv.setHasFixedSize(true);
        mItemRv.addItemDecoration(new DividerItemDecoration(mContext, DividerItemDecoration.VERTICAL));
        // 设置下拉上拉无阴影效果
        mItemRv.setOverScrollMode(View.OVER_SCROLL_NEVER);
    }

    private void initListener() {
        mCancelIv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dismiss();
            }
        });
    }

    private void initData() {
        requestDataResource();
    }

    @Override
    public void onPlayListItemClick(PlayList playList) {
        // 收藏到指定的收藏夹中
        if (playList == null){
            return;
        }
        if ((mMediaList == null) || (mMediaList.size() == 0)){
            return;
        }
        if (!(Media.CLOUD_MUSIC).equals(mMediaSrc)){
            return;
        }
        WRoom room = WApp.Instance.getDevManager().getSelectedRoom();
        if (room != null){
            room.cmdAddFavoriteMedia(playList.playListId,mMediaSrc,mMediaList, new CmdActionLister<Boolean>(FavoriteAddMediaDialog.this, new ICmdCallback<Boolean>() {
                @Override
                public void onSuccess(Boolean data) {
                    ToastUtils.showShort(getString(R.string.favorite_media_add_result_success));
                    dismiss();
                }
                @Override
                public void onFailed(int code, String msg) {
                    ToastUtils.showShort("AddFavoriteMedia failed %d ...", code);
                }
            }));
        }
    }


    private void updateDataList(List<PlayList> list){
        mFavoriteAdapter.setDataList(list);
        mFavoriteAdapter.notifyDataSetChanged();
    }

    private void requestDataResource(){
        WRoom room = WApp.Instance.getDevManager().getSelectedRoom();
        if (room != null){
            room.cmdGetFavoritePlayList(new CmdActionLister<List<PlayList>>(FavoriteAddMediaDialog.this, new ICmdCallback<List<PlayList>>() {
                @Override
                public void onSuccess(List<PlayList> data) {
                    updateDataList(data);
                }

                @Override
                public void onFailed(int code, String msg) {
                    updateDataList(null);
                    Toast.makeText(getContext(),"GetFavoritePlayList获取失败:"+code,Toast.LENGTH_SHORT).show();
                }
            }));
        }else{
            updateDataList(null);
        }
    }
}
