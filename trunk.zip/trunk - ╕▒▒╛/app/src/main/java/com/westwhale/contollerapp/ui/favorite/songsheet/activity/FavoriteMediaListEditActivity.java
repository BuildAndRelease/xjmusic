package com.westwhale.contollerapp.ui.favorite.songsheet.activity;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.LinearLayout;

import com.blankj.utilcode.util.ToastUtils;
import com.westwhale.contollerapp.R;
import com.westwhale.contollerapp.application.WApp;
import com.westwhale.contollerapp.dev.CmdActionLister;
import com.westwhale.contollerapp.dev.ICmdCallback;
import com.westwhale.contollerapp.dev.WRoom;
import com.westwhale.contollerapp.ui.base.activity.BaseActivity;
import com.westwhale.contollerapp.ui.favorite.songsheet.adapter.FavoriteMediaListEditAdapter;
import com.westwhale.contollerapp.ui.favorite.songsheet.dialog.FavoriteAddMediaDialog;
import com.westwhale.api.protocolapi.bean.media.CloudMusic;
import com.westwhale.api.protocolapi.bean.media.Media;
import com.westwhale.api.protocolapi.bean.PlayList;

import java.util.ArrayList;
import java.util.List;

/**
 * Description:
 * Author: chenyaoli
 * Date: 2018-12-12
 * History:
 */
public class FavoriteMediaListEditActivity extends BaseActivity implements FavoriteMediaListEditAdapter.CallBack {
    private Toolbar mToolbar;
    private RecyclerView mDataRecyclerView;
    private LinearLayout mDeleteLayout,mFavoriteLayout,mDownloadLayout;
    private FavoriteMediaListEditAdapter mAdapter;
    private Menu mMenu;

    private static List<Media> mItemList;
    private static PlayList mPlaylist;

    public static void setDataList(PlayList playlist, List<Media> list){
        mPlaylist = playlist;
        mItemList = list;
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_favorite_media_media_edit);

        initView();
        initListener();
        initData();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        mPlaylist = null;
        mItemList = null;
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        super.onCreateOptionsMenu(menu);

        getMenuInflater().inflate(R.menu.menu_batch, menu);

        mMenu = menu;
        return true;
    }

    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {
        MenuItem item = menu.findItem(R.id.menu_select_all);

        return super.onPrepareOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.menu_select_all){
            if (mAdapter.getSelectedNum() == mAdapter.getItemCount()){
                // 全不选
                mAdapter.cancelAllItem();
            }else{
                // 全选
                mAdapter.selectAllItem();
            }
        }
        return super.onOptionsItemSelected(item);
    }

    private void initView() {
        mToolbar = findViewById(R.id.favorite_media_media_edit_toolbar);
        // 设置toolbar
        setSupportActionBar(mToolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        mDeleteLayout = findViewById(R.id.favorite_media_media_edit_delete);
        mFavoriteLayout = findViewById(R.id.favorite_media_media_edit_favorite);
        mDownloadLayout = findViewById(R.id.favorite_media_media_edit_download);

        mDataRecyclerView = findViewById(R.id.favorite_media_media_edit_recyclerview);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        mDataRecyclerView.setLayoutManager(linearLayoutManager);
        mAdapter = new FavoriteMediaListEditAdapter(this);
        mDataRecyclerView.setAdapter(mAdapter);
        mDataRecyclerView.setHasFixedSize(true);
        mDataRecyclerView.addItemDecoration(new DividerItemDecoration(this, DividerItemDecoration.VERTICAL));
    }

    private void initListener() {
        mToolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        mDeleteLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 批量删除已选择的歌单
                mDeleteLayout.setEnabled(false);
                mDataRecyclerView.setEnabled(false);
                List<Media> itemList = null;
                if (mAdapter != null){
                    itemList = mAdapter.getSelectedList();
                    if (itemList == null || itemList.size() == 0){
                        ToastUtils.showShort("没有选择任何一项，请先选择");
                    }
                    WRoom room = WApp.Instance.getDevManager().getSelectedRoom();
                    if (room != null){
                        int playListId = (mPlaylist != null) ? mPlaylist.playListId : -1;
                        room.cmdDelFavoriteMedia(playListId,Media.CLOUD_MUSIC,itemList,new CmdActionLister<>(FavoriteMediaListEditActivity.this, new ICmdCallback<Boolean>() {
                            @Override
                            public void onSuccess(Boolean data) {
                                mItemList.removeAll(mAdapter.getSelectedList());
                                mAdapter.cancelAllItem();
//                                mAdapter.notifyDataSetChanged();

                                mDeleteLayout.setEnabled(true);
                                mDataRecyclerView.setEnabled(true);
                            }

                            @Override
                            public void onFailed(int code, String msg) {
                                mDeleteLayout.setEnabled(true);
                                mDataRecyclerView.setEnabled(true);

                                ToastUtils.showShort("DelFavoriteMedia failed %d...",code);
                            }
                        }));
                    }
                }
            }
        });

        mFavoriteLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 将已选择的歌曲添加到自建歌单
                List<CloudMusic> itemList = new ArrayList<>();
                if ((mAdapter != null) && (mAdapter.getSelectedList() != null)){
                    List<Media> medialist = mAdapter.getSelectedList();
                    for (int i=0; i < medialist.size(); i++){
                        if (medialist.get(i) instanceof CloudMusic){
                            itemList.add((CloudMusic)medialist.get(i));
                        }
                    }
                }

                if (itemList.size() == 0){
                    ToastUtils.showShort("列表为空");
                    return;
                }
                FavoriteAddMediaDialog favoriteDialog = new FavoriteAddMediaDialog();
                favoriteDialog.updateMediaList(Media.CLOUD_MUSIC,itemList);
                favoriteDialog.show(getSupportFragmentManager(),FavoriteAddMediaDialog.TAG);
            }
        });

        mDownloadLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 下载
                List<CloudMusic> itemList = new ArrayList<>();
                if ((mAdapter != null) && (mAdapter.getSelectedList() != null)){
                    List<Media> medialist = mAdapter.getSelectedList();
                    for (int i=0; i < medialist.size(); i++){
                        if (medialist.get(i) instanceof CloudMusic){
                            itemList.add((CloudMusic)medialist.get(i));
                        }
                    }
                }

                if (itemList.size() == 0){
                    ToastUtils.showShort("列表为空");
                    return;
                }
                // 开始下载已选择的歌曲
                WRoom room = WApp.Instance.getDevManager().getSelectedRoom();
                if (room != null){
                    room.cmdDownloadMusicList("",itemList,new CmdActionLister<Boolean>(FavoriteMediaListEditActivity.this, new ICmdCallback<Boolean>() {
                        @Override
                        public void onSuccess(Boolean data) {
                            if (data) {
                                ToastUtils.showShort("下载成功");
                            }
                        }

                        @Override
                        public void onFailed(int code, String msg) {
                            ToastUtils.showShort("下载失败");
                        }
                    }));
                }
            }
        });
    }

    private void initData() {
        if (mItemList != null) {
            mAdapter.setDataList(mItemList);
            mAdapter.notifyDataSetChanged();
        }
    }

    @Override
    public void onItemClick(Media item, boolean selected) {

    }

    @Override
    public void onCheckedNumChanged(int selectednum) {
        String title = getString(R.string.toolbar_menu_all_select);
        if (selectednum == mAdapter.getItemCount()){
            title = getString(R.string.toolbar_menu_all_un_select);
        }
        updateMenuTitle(title);

        String toolbarTitle = getString(R.string.favorite_media_manager_title);
        if (selectednum > 0){
            toolbarTitle = toolbarTitle + "(" + selectednum +")";
        }
        mToolbar.setTitle(toolbarTitle);
    }

    private void updateMenuTitle(String title){
        if (mMenu != null) {
            MenuItem menuItem = mMenu.findItem(R.id.menu_select_all);
            if (menuItem != null) {
                menuItem.setTitle(title);
            }
        }
    }
}
