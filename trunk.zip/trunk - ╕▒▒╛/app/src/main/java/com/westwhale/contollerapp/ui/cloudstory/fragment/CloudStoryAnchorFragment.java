package com.westwhale.contollerapp.ui.cloudstory.fragment;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.kingja.loadsir.callback.Callback;
import com.kingja.loadsir.callback.SuccessCallback;
import com.scwang.smartrefresh.layout.api.RefreshLayout;
import com.scwang.smartrefresh.layout.listener.OnLoadMoreListener;
import com.scwang.smartrefresh.layout.listener.OnRefreshListener;
import com.westwhale.contollerapp.R;
import com.westwhale.contollerapp.application.WApp;
import com.westwhale.contollerapp.dev.CmdActionLister;
import com.westwhale.contollerapp.dev.ICmdCallback;
import com.westwhale.contollerapp.dev.WRoom;
import com.westwhale.contollerapp.ui.main.MainRoomActivity;
import com.westwhale.contollerapp.ui.cloudstory.adapter.StoryAnchorAdapter;
import com.westwhale.contollerapp.ui.cloudstory.dialog.StoryAnchorCategoryDialog;
import com.westwhale.contollerapp.ui.base.fragment.TitleBaseFragment;
import com.westwhale.contollerapp.ui.loadsircallback.EmptyCallback;
import com.westwhale.contollerapp.ui.loadsircallback.LoadingCallback;
import com.westwhale.api.protocolapi.bean.telling.Anchor;
import com.westwhale.api.protocolapi.bean.telling.AnchorCategroy;

import java.util.ArrayList;
import java.util.List;

/**
 * Description:
 * Author: chenyaoli
 * Date: 2018-11-12
 * History:
 */
public class CloudStoryAnchorFragment extends TitleBaseFragment implements StoryAnchorAdapter.CallBack {
    private static final String TAG = "StoryAnchor";

    public static final int REQUEST_CODDE = 0;


    private FrameLayout mFrameLayout;
    private RecyclerView mDataRv;
    private TextView mTypeTv;
    private ImageView mCategoryIv;
    private Toolbar mToolBar;
    private RefreshLayout mRefreshLayout;

    private StoryAnchorAdapter mAdapter;

    private int mCurPageNo = 1; //记录当前的页面数, 云音乐歌手获取时必须从第一页开始
    private int mPageSize = 50;
    private boolean mHasMoreData = true; // 记录是否还有更多数据

    private List<AnchorCategroy> mCategoryList = new ArrayList<>();
    private AnchorCategroy mSelectedCateogyItem = new AnchorCategroy();

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


    }

    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        // 先显示加载动画，针对布局做一些初始化
        return inflater.inflate(R.layout.frag_cloudstory_anchor,container,false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        mFrameLayout = view.findViewById(R.id.cloudstory_anchor_content_layout);

        // 创建mLoadService
        mLoadService = mLoadSir.register(mFrameLayout, new Callback.OnReloadListener() {
            @Override
            public void onReload(View v) {
                showLoadCallBack(LoadingCallback.class);

                initData();
            }
        });

        initView(view);

        initListener();

        requestStoryAnchorCateogry();
    }

    @Override
    public void onResume() {
        super.onResume();
    }

    @Override
    public void onAnchorItemClick(Anchor item) {
        // 点击主播，进入主播的专辑列表界面
        CloudStoryAnchorAlbumFragment fragment = new CloudStoryAnchorAlbumFragment();
        fragment.setAnchorItem(item);
        ((MainRoomActivity)getActivity()).showFragment(fragment);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        // 接收分类弹出框的返回结果
        if (REQUEST_CODDE == requestCode){
            String categoryId = data.getStringExtra(StoryAnchorCategoryDialog.CATEGORY_ID);
            String name = data.getStringExtra(StoryAnchorCategoryDialog.CATEGORY_NAME);
            String type = data.getStringExtra(StoryAnchorCategoryDialog.CATEGORY_TYPE);
            String title = data.getStringExtra(StoryAnchorCategoryDialog.CATEGORY_TITLE);
            mSelectedCateogyItem.id = Integer.parseInt(categoryId);
            mSelectedCateogyItem.name = name;
            mSelectedCateogyItem.type = type;
            mSelectedCateogyItem.title = title;

            showLoadCallBack(LoadingCallback.class);

            initData();
        }
    }

    private void initView(View view) {
        mToolBar = view.findViewById(R.id.cloudstory_anchor_toolbar);
        configToolBar(mToolBar,"主播");

        mDataRv = view.findViewById(R.id.cloudstory_anchor_recylerview);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(mContext);
        mDataRv.setLayoutManager(linearLayoutManager);
        mAdapter = new StoryAnchorAdapter(this);
        mDataRv.setAdapter(mAdapter);
        mDataRv.setHasFixedSize(true);

        mRefreshLayout = view.findViewById(R.id.cloudstory_anchor_refresh);
        mRefreshLayout.setDisableContentWhenRefresh(true);
        mRefreshLayout.setEnableLoadMore(true);

        mTypeTv = view.findViewById(R.id.cloudstory_anchor_type);
        mCategoryIv = view.findViewById(R.id.cloudstory_anchor_category);
    }

    private void initListener() {
        mCategoryIv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 弹出类型选择界面
                StoryAnchorCategoryDialog categoryDialog = new StoryAnchorCategoryDialog();
                // 设置目标Fragment
                categoryDialog.updateCategory(mSelectedCateogyItem,mCategoryList);
                categoryDialog.setTargetFragment(CloudStoryAnchorFragment.this, REQUEST_CODDE);
                if (getFragmentManager() != null) {
                    categoryDialog.show(getFragmentManager(), "StoryAnchorCategory_Dialog");
                }
            }
        });

        mRefreshLayout.setOnRefreshListener(new OnRefreshListener() {
            @Override
            public void onRefresh(@NonNull RefreshLayout refreshLayout) {
                initData();
            }
        });

        mRefreshLayout.setOnLoadMoreListener(new OnLoadMoreListener() {
            @Override
            public void onLoadMore(@NonNull RefreshLayout refreshLayout) {
                //  判断是否还有数据，从而判断是否还需要加载更多数据
                if (mHasMoreData){
                    mCurPageNo++;
                    requestCloudResource();
                }else {
                    mRefreshLayout.finishLoadMoreWithNoMoreData();
                }

                String msg = "=======mRefreshLayout.setOnLoadMoreListener=====CurrentPageNo: " + mCurPageNo;
                Log.e("CloudSinger",msg);
            }
        });

    }

    private void initData() {
        String type = (mSelectedCateogyItem != null) ? mSelectedCateogyItem.title : "";
        mTypeTv.setText(type);

        mCurPageNo = 1;
        mHasMoreData = true;

        // 每次先清空原有数据
        if (mAdapter != null){
            mAdapter.clearDataList();
        }

        requestCloudResource();
    }

    private void updateAnchorCategoryList(List<AnchorCategroy> list){
        if (list != null){
            mCategoryList = list;
//            if (mCategoryList.size() > 1){
//                mSelectedCateogyItem.id = mCategoryList.get(1).id;
//                mSelectedCateogyItem.type = mCategoryList.get(1).type;
//                mSelectedCateogyItem.title = mCategoryList.get(1).title;
//                mSelectedCateogyItem.name = mCategoryList.get(1).name;
//            }else
            if (mCategoryList.size() > 0){
                mSelectedCateogyItem.id = mCategoryList.get(0).id;
                mSelectedCateogyItem.type = mCategoryList.get(0).type;
                mSelectedCateogyItem.title = mCategoryList.get(0).title;
                mSelectedCateogyItem.name = mCategoryList.get(0).name;
            }

            initData();
        }else{
            showLoadCallBack(EmptyCallback.class);
        }
    }

    public void updateDataList(List<Anchor> list){
        if (list != null){

            // 若无法获取到数据，则认为已经到底
            int size = list.size();

            if (mCurPageNo == 0) {
                mAdapter.clearDataList();
            }

            if (size != 0){
                int startIndex = mAdapter.getItemCount();
                mAdapter.addToDataList(list);
                mAdapter.notifyItemRangeInserted(startIndex,size);
            }else{
                mHasMoreData = false;
            }

            // 更新刷新等待状态
            mRefreshLayout.finishRefresh();
            mRefreshLayout.finishLoadMore();

            showLoadCallBack(SuccessCallback.class);
        }else{
            // 当获取数据失败时，则认为无数据了
            mHasMoreData = false;

            // 更新刷新等待状态
            mRefreshLayout.finishRefresh();
            mRefreshLayout.finishLoadMore();

            showLoadCallBack(SuccessCallback.class);

//            showLoadCallBack(ErrorCallback.class);
        }

    }



    private void requestStoryAnchorCateogry() {
        Log.e(TAG,"----------- requestStoryAnchorCateogry ------");
        WRoom room = WApp.Instance.getDevManager().getSelectedRoom();
        if (room != null){
            room.cmdGetStoryTellingAnchorCategory(new CmdActionLister<List<AnchorCategroy>>(this, new ICmdCallback<List<AnchorCategroy>>() {
                @Override
                public void onSuccess(List<AnchorCategroy> data) {
                    Log.e(TAG,"-----------onSuccess------" + data.size());
                    updateAnchorCategoryList(data);
                }

                @Override
                public void onFailed(int code, String msg) {
                    Log.e(TAG,"-----------------"+code+msg);
                }
            }));
        }else{
            updateDataList(null);
        }
    }


    private void requestCloudResource() {
        Log.e(TAG,"----------- requestCloudStoryCategory ------");
        WRoom room = WApp.Instance.getDevManager().getSelectedRoom();
        if ((room != null) && (mSelectedCateogyItem != null)){
            if ((AnchorCategroy.FAMOUS).equals(mSelectedCateogyItem.type)){
                int category = mSelectedCateogyItem.id;
                int pageSize = mPageSize;
                int pageNum = mCurPageNo;
                room.cmdGetStoryTellingAnchor(category,pageSize,pageNum, new CmdActionLister<List<Anchor>>(this, new ICmdCallback<List<Anchor>>() {
                    @Override
                    public void onSuccess(List<Anchor> data) {
                        Log.e(TAG,"-----------onSuccess------" + data.size());
                        updateDataList(data);
                    }

                    @Override
                    public void onFailed(int code, String msg) {
                        Log.e(TAG,"-----------------"+code+msg);
                    }
                }));
            }else if ((AnchorCategroy.NORMAL).equals(mSelectedCateogyItem.type)){
                String categoryName = mSelectedCateogyItem.name;
                String type = "hot";
                int pageSize = mPageSize;
                int pageNum = mCurPageNo;
                room.cmdGetStoryTellingAnchorByNormal(categoryName,type,pageSize,pageNum, new CmdActionLister<List<Anchor>>(this, new ICmdCallback<List<Anchor>>() {
                    @Override
                    public void onSuccess(List<Anchor> data) {
                        Log.e(TAG,"-----------onSuccess------" + data.size());
                        updateDataList(data);
                    }

                    @Override
                    public void onFailed(int code, String msg) {
                        Log.e(TAG,"-----------------"+code+msg);
                        updateDataList(null);
                        Toast.makeText(getContext(),"获取失败:"+code,Toast.LENGTH_SHORT).show();
                    }
                }));
            }else{
                updateDataList(null);
            }

        }else{
            updateDataList(null);
        }
    }

}
