package com.westwhale.contollerapp.ui.main.adapter;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.westwhale.contollerapp.R;
import com.westwhale.contollerapp.common.ImageTextItem;

import java.util.ArrayList;

/**
 * Description:
 * Author: chenyaoli
 * Date: 2018-12-20
 * History
 *
 */
public class SearchHostMoreAdapter extends RecyclerView.Adapter {
    private ArrayList<ImageTextItem> mItemList;
    private CallBack mHostMoreItemClick;

    public interface CallBack{
        void onHostMoreItemClick(View view, String data);
    }

    public void setCallBack(CallBack callBack){
        this.mHostMoreItemClick = callBack;
    }

    public void updateList(ArrayList<ImageTextItem> itemList){
        this.mItemList = itemList;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_search_hostmore, viewGroup, false);
        return new ItemHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder viewHolder, int i) {
        if (viewHolder instanceof ItemHolder){
            final ImageTextItem item = mItemList.get(i);
            ItemHolder itemHolder = (ItemHolder)viewHolder;
            itemHolder.mTextView.setText(item.getTitle());
            int defaultTextColor = itemHolder.mTextView.getTextColors().getDefaultColor();
            if (item.getItemStat()){
                itemHolder.mTextView.setTextColor(defaultTextColor);
            }else{
                itemHolder.mTextView.setTextColor(itemHolder.itemView.getResources().getColor(R.color.colorGrey));
            }

            itemHolder.mImageView.setImageResource(item.getImageRes());
            itemHolder.itemView.setTag(i + "");
            itemHolder.itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (mHostMoreItemClick != null){
                        mHostMoreItemClick.onHostMoreItemClick(v,(String)v.getTag());
                    }
                }
            });
        }
    }

    @Override
    public int getItemCount() {
        return (mItemList == null) ? 0 : mItemList.size();
    }

    private class ItemHolder extends RecyclerView.ViewHolder{
        private ImageView mImageView;
        private TextView mTextView;
        public ItemHolder(@NonNull View itemView) {
            super(itemView);
            mImageView = itemView.findViewById(R.id.item_search_host_more_pic);
            mTextView = itemView.findViewById(R.id.item_search_host_more_name);
        }
    }
}
