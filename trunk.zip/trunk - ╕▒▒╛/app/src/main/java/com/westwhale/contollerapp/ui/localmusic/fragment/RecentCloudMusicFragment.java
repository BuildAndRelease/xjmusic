package com.westwhale.contollerapp.ui.localmusic.fragment;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;

import com.blankj.utilcode.util.ToastUtils;
import com.kingja.loadsir.callback.Callback;
import com.kingja.loadsir.callback.SuccessCallback;
import com.kingja.loadsir.core.LoadService;
import com.kingja.loadsir.core.LoadSir;
import com.scwang.smartrefresh.layout.api.RefreshLayout;
import com.scwang.smartrefresh.layout.listener.OnLoadMoreListener;
import com.scwang.smartrefresh.layout.listener.OnRefreshListener;
import com.westwhale.contollerapp.R;
import com.westwhale.contollerapp.application.WApp;
import com.westwhale.contollerapp.dev.CmdActionLister;
import com.westwhale.contollerapp.dev.ICmdCallback;
import com.westwhale.contollerapp.dev.WRoom;
import com.westwhale.contollerapp.ui.base.fragment.LazyBaseFragment;
import com.westwhale.contollerapp.ui.cloudmusic.adapter.CloudSongAdapter;
import com.westwhale.contollerapp.ui.cloudmusic.dialog.CloudMusicMoreDialog;
import com.westwhale.contollerapp.ui.loadsircallback.EmptyCallback;
import com.westwhale.contollerapp.ui.loadsircallback.ErrorCallback;
import com.westwhale.contollerapp.ui.loadsircallback.LoadingCallback;
import com.westwhale.contollerapp.ui.loadsircallback.TimeoutCallback;
import com.westwhale.api.protocolapi.bean.media.CloudMusic;
import com.westwhale.api.protocolapi.bean.media.Media;

import java.util.ArrayList;
import java.util.List;

public class RecentCloudMusicFragment extends LazyBaseFragment implements CloudSongAdapter.CallBack {
    private static final String TAG = "RecentCloudMusic";

    private RecyclerView mDataRv;
    private RefreshLayout mRefreshLayout;
    private LoadSir mLoadSir;
    private LoadService mLoadService;

    private CloudSongAdapter mAdapter;

    private boolean mHasMoreData;
    private int mPageNo = 1;
    private static final int PAGE_SIZE = 50;

    List<CloudMusic> mItemList = new ArrayList<>();


    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // 创建mLoadService
        // 界面的加载等待框架配置
        mLoadSir = new LoadSir.Builder()
                .addCallback(new LoadingCallback())
                .addCallback(new TimeoutCallback())
                .addCallback(new ErrorCallback())
                .addCallback(new EmptyCallback())
                .setDefaultCallback(SuccessCallback.class)
                .build();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
    }

    @Override
    public int getLayoutId() {
        return R.layout.frag_recent_content;
    }

    @Override
    public void initView(View view) {
        mRefreshLayout = view.findViewById(R.id.recent_content_refresh);
        mRefreshLayout.setDisableContentWhenRefresh(true);
        mRefreshLayout.setEnableLoadMore(true);

        mDataRv = view.findViewById(R.id.recent_content_recylerview);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(mContext);
        mDataRv.setLayoutManager(linearLayoutManager);
        mAdapter = new CloudSongAdapter(this);
        mDataRv.setAdapter(mAdapter);
        mDataRv.setHasFixedSize(true);
        mDataRv.addItemDecoration(new DividerItemDecoration(mContext, DividerItemDecoration.VERTICAL));

        // 创建mLoadService
        mLoadService = mLoadSir.register(mDataRv, new Callback.OnReloadListener() {
            @Override
            public void onReload(View v) {
                showLoadCallBack(mLoadService, LoadingCallback.class);
                requestData();
            }
        });
    }

    @Override
    public void initListener() {
        mRefreshLayout.setOnRefreshListener(new OnRefreshListener() {
            @Override
            public void onRefresh(@NonNull RefreshLayout refreshLayout) {
                initData();
                requestData();
            }
        });

        mRefreshLayout.setOnLoadMoreListener(new OnLoadMoreListener() {
            @Override
            public void onLoadMore(@NonNull RefreshLayout refreshLayout) {
                //  判断是否还有数据，从而判断是否还需要加载更多数据
                if (hasMoreData()){
                    loadMoreData();
                }else {
                    mRefreshLayout.finishLoadMoreWithNoMoreData();
                }
            }
        });
    }

    @Override
    public void initData() {
        showLoadCallBack(mLoadService,LoadingCallback.class);

        mHasMoreData = true;
        mPageNo = 1;

        mItemList.clear();
        if (mAdapter != null){
            mAdapter.updateDataList(mItemList);

            mAdapter.notifyDataSetChanged();
        }
    }

    @Override
    public void onLazyLoad() {
        requestData();
    }

    @Override
    public void onSongItemClick(List<CloudMusic> itemList, CloudMusic songItem) {
        // 点击推荐歌曲的某歌曲，开始播放
        WRoom room = WApp.Instance.getDevManager().getSelectedRoom();
        if (room != null) {
            WRoom.cmdPlayCloudMusicList(songItem, itemList, new CmdActionLister<>(RecentCloudMusicFragment.this, new ICmdCallback<Boolean>() {
                @Override
                public void onSuccess(Boolean data) {

                }

                @Override
                public void onFailed(int code, String msg) {
                    ToastUtils.showShort("播放歌曲失败...%d",code);
                }
            }));
        }
    }

    @Override
    public void onSongItemMoreClick(CloudMusic songItem) {
        // 点击推荐歌曲的某Item项的更多按钮时，弹出更多选项框
        CloudMusicMoreDialog moreDialog = new CloudMusicMoreDialog();
        Bundle bundle = new Bundle();
        bundle.putString("music",songItem.toString());
        moreDialog.setArguments(bundle);
        moreDialog.show(getChildFragmentManager(),CloudMusicMoreDialog.TAG);
    }

    public void showLoadCallBack(LoadService loadService,Class<? extends Callback> callback){
        if (loadService != null){
            loadService.showCallback(callback);
        }
    }

    private boolean hasMoreData(){
        return mHasMoreData;
    }

    private void loadMoreData(){
        mPageNo++;
        requestData();
    }

    private void updateData(List<CloudMusic> datalist){
        if (datalist != null){

            int size = datalist.size();

            if (size != 0){
                int count = mAdapter.getItemCount();

                mAdapter.addToDataList(datalist);
                mAdapter.notifyItemRangeInserted(count,size);
            }else{
                mHasMoreData = false;
            }

            mRefreshLayout.finishRefresh();
            mRefreshLayout.finishLoadMore();

            showLoadCallBack(mLoadService,SuccessCallback.class);
        }else{
            mHasMoreData = false;

            mRefreshLayout.finishRefresh();
            mRefreshLayout.finishLoadMore();

            showLoadCallBack(mLoadService,SuccessCallback.class);
        }
    }

    private void requestData(){
        WRoom room = WApp.Instance.getDevManager().getSelectedRoom();
        if (room != null){
            room.cmdGetHistoryPlayList(Media.CLOUD_MUSIC,mPageNo,PAGE_SIZE,new CmdActionLister<List<Media>>(RecentCloudMusicFragment.this, new ICmdCallback<List<Media>>() {
                @Override
                public void onSuccess(List<Media> data) {
                    List<CloudMusic> mediaList = null;
                    if (data != null){
                        mediaList = new ArrayList<>();
                        for (int i=0; i < data.size(); i++){
                            if (data.get(i) instanceof CloudMusic){
                                mediaList.add((CloudMusic)(data.get(i)));
                            }
                        }
                    }

                    updateData(mediaList);
                }

                @Override
                public void onFailed(int code, String msg) {
                    ToastUtils.showShort("GetHistory Failed.. %d",code);
                    updateData(null);
                }
            }));
        }
    }

}
