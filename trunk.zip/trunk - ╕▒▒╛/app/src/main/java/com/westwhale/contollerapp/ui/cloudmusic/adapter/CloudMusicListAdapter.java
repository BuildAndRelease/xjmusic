package com.westwhale.contollerapp.ui.cloudmusic.adapter;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.westwhale.contollerapp.R;
import com.westwhale.api.protocolapi.bean.media.CloudMusic;

import java.util.ArrayList;
import java.util.List;

/**
 * Description:
 * Author: chenyaoli
 * Date: 2018-11-17
 * History:
 */
public class CloudMusicListAdapter extends RecyclerView.Adapter {
    private final static int TYPE_HEADER = 0;
    private final static int TYPE_ITEM = 1;

    private ArrayList<CloudMusic> mItemList;
    private CallBack mCallBack;

    public interface CallBack{
        void onSongItemClick(List<CloudMusic> itemList, CloudMusic songItem);

        void onSongItemMoreClick(CloudMusic songItem);
    }

    public void upateDataList(ArrayList<CloudMusic> itemList){
        this.mItemList = itemList;
    }

    public CloudMusicListAdapter(CallBack callBack){
        this.mItemList = null;
        this.mCallBack = callBack;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        switch (i){
            case TYPE_HEADER:
                View v0 = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_netmusic_list_header, viewGroup, false);
                return new HeaderItemHolder(v0);
            case TYPE_ITEM:
                View v1 = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_netmusic_song, viewGroup, false);
                return new MusicListItemHolder(v1);
            default:
                // 默认返回 HOST 类型的 viewHolder
                View v2 = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_netmusic_song, viewGroup, false);
                return new MusicListItemHolder(v2);
        }
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder viewHolder, int i) {
        switch (getItemViewType(i)){
            case TYPE_ITEM:
                if (viewHolder instanceof MusicListItemHolder){
                    // 在此处，处理默认类型的 viewHolder
                    CloudMusic item = mItemList.get(i-1);
                    MusicListItemHolder itemHolder = (MusicListItemHolder)viewHolder;
                    itemHolder.mSongNoTv.setText(String.valueOf(i));
                    itemHolder.mSongNameTv.setText(item.songName);
                    itemHolder.mSongSingerTv.setText(item.getSingersName());

                    viewHolder.itemView.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            mCallBack.onSongItemClick(mItemList,item);
                        }
                    });

                    ((MusicListItemHolder) viewHolder).mItemMoreIv.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            mCallBack.onSongItemMoreClick(item);
                        }
                    });
                }
                break;
            case TYPE_HEADER:
                break;
            default:
                break;
        }
    }

    @Override
    public int getItemCount() {
        return (mItemList == null) ? 0 : mItemList.size()+1;
    }

    @Override
    public int getItemViewType(int position) {
        return position == TYPE_HEADER ? TYPE_HEADER : TYPE_ITEM;
    }

    private class MusicListItemHolder extends RecyclerView.ViewHolder{
        ImageView mItemMoreIv;
        TextView mSongNoTv, mSongNameTv, mSongSingerTv;
        MusicListItemHolder(@NonNull View itemView) {
            super(itemView);
            mItemMoreIv = itemView.findViewById(R.id.netmusic_song_item_more);
            mSongNoTv = itemView.findViewById(R.id.netmusic_song_item_no);
            mSongNameTv = itemView.findViewById(R.id.netmusic_song_item_name);
            mSongSingerTv = itemView.findViewById(R.id.netmusic_song_item_artist);
        }
    }

    private class HeaderItemHolder extends RecyclerView.ViewHolder{
        HeaderItemHolder(@NonNull View itemView) {
            super(itemView);
        }
    }
}
