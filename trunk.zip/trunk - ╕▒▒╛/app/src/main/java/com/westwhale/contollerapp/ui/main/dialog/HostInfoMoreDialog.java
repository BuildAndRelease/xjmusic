package com.westwhale.contollerapp.ui.main.dialog;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.DialogFragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.TextView;

import com.blankj.utilcode.util.ThreadUtils;
import com.westwhale.api.protocolapi.BaApi;
import com.westwhale.contollerapp.R;
import com.westwhale.contollerapp.common.ImageTextItem;
import com.westwhale.contollerapp.dev.MachineType;
import com.westwhale.contollerapp.ui.base.dialog.AttachDialogFragment;
import com.westwhale.contollerapp.ui.main.adapter.SearchHostMoreAdapter;

import java.util.ArrayList;


public class HostInfoMoreDialog extends AttachDialogFragment implements SearchHostMoreAdapter.CallBack {
    public final static String ARG_HOST_NAME = "hostName";
    public final static String ARG_HOST_TYPE = "hostType";
    public final static String ARG_HOST_IP = "hostIp";
    public final static String ARG_HOST_ID = "hostId";
    public final static String ARG_HOST_ROOMNUMS = "hostRoomNums";

    private String mHostName;
    private String mHostDeviceType;
    private String mHostIp;
    private String mHostId;
    private int mHostRoomNums;

    private SearchHostMoreAdapter mHostMoreAdapter;
    private ArrayList<ImageTextItem> mItemList = new ArrayList<>();
    private RecyclerView mDataRecyclerView;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // 背景色，动画效果，通过主题设置
        setStyle(DialogFragment.STYLE_NORMAL,R.style.CommonDialogStyle);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.frag_search_hostinfo_more, container);

        initView(view);
        initListener();

        initData();

        return view;
    }

    private void initView(View view) {
        if (getArguments() != null) {
            mHostName = getArguments().getString(ARG_HOST_NAME);
            mHostDeviceType = getArguments().getString(ARG_HOST_TYPE);
            mHostIp = getArguments().getString(ARG_HOST_IP);
            mHostRoomNums = getArguments().getInt(ARG_HOST_ROOMNUMS);
            mHostId = getArguments().getString(ARG_HOST_ID);
        }

        TextView hostNameTextView = view.findViewById(R.id.search_hostinfo_name);
        hostNameTextView.setText(mHostName);

        mDataRecyclerView = view.findViewById(R.id.search_hostinfo_recyclerview);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(mContext);

        mDataRecyclerView.setLayoutManager(linearLayoutManager);
        mHostMoreAdapter = new SearchHostMoreAdapter();
        mHostMoreAdapter.setCallBack(this);
        mDataRecyclerView.setAdapter(mHostMoreAdapter);
        mDataRecyclerView.setHasFixedSize(true);
        // 设置下拉上拉无阴影效果
        mDataRecyclerView.setOverScrollMode(View.OVER_SCROLL_NEVER);

        mItemList.clear();
        this.setItemInfo();

        mHostMoreAdapter.updateList(mItemList);
        mHostMoreAdapter.notifyDataSetChanged();
    }

    private void initListener() {

    }

    private void setItemInfo() {
        // 配置Item项， 注意加入列表的先后顺序
        String rooms = getResources().getString(R.string.host_more_dev_rooms) + "  " + mHostRoomNums;
        setInfo(rooms, R.drawable.host_more_room,true);

        String type = getResources().getString(R.string.host_more_dev_type) + "  "  + mHostDeviceType;
        setInfo(type, R.drawable.host_more_type,true);

        String ipStr = getResources().getString(R.string.host_more_dev_ip) + "  "  + mHostIp;
        setInfo(ipStr, R.drawable.host_more_ip,true);

        String rebootStr = getResources().getString(R.string.host_more_reboot);
        // 加入机型判断
        boolean usable = false;
        if (MachineType.hasFunc_HostRestart(mHostDeviceType)) {
            usable = true;
        }
        setInfo(rebootStr, R.drawable.host_more_reboot, usable);
    }

    //为info设置数据，并放入mlistInfo
    private void setInfo(String title, int id, boolean usable) {
        ImageTextItem information = new ImageTextItem();
        information.setTitle(title);
        information.setImageRes(id);
        information.setItemStat(usable);
        mItemList.add(information); //将新的info对象加入到信息列表中
    }


    private void initData() {

    }

    @Override
    public void onStart() {
        super.onStart();

        //设置fragment高度 、宽度, 设置底部居中显示
        double heightPercent = 0.5;
        int dialogHeight = (int) (mContext.getResources().getDisplayMetrics().heightPixels * heightPercent);
        Window window = getDialog().getWindow();
        WindowManager.LayoutParams params = window.getAttributes();
        params.gravity = Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL;
        params.width = WindowManager.LayoutParams.MATCH_PARENT;
        params.height = dialogHeight; // 底部弹出的DialogFragment的高度，如果是MATCH_PARENT则铺满整个窗口
        window.setAttributes(params);
        getDialog().setCanceledOnTouchOutside(true);
    }


    @Override
    public void onHostMoreItemClick(View view, String data) {
        switch (Integer.parseInt(data)) {
            case 0:
                break;
            case 1:
                break;
            case 2:
                break;
            case 3: {
                // 重启
                ThreadUtils.getIoPool().execute(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            // 重启设备
                            BaApi.getInstance().setRoomInfo(mHostIp, mHostId);
                            BaApi.getInstance().restartSystem();
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                });

                dismiss();
                break;
            }
            case 4:
                break;
            default:

                dismiss();
                break;
        }
    }
}
