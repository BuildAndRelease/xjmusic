package com.westwhale.contollerapp.ui.base.activity;

import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.WindowManager;

import com.westwhale.contollerapp.R;
import com.westwhale.contollerapp.application.WApp;
import com.westwhale.contollerapp.utils.StatusBarUtil;

import java.util.ArrayList;
import java.util.List;


public class BaseActivity extends AppCompatActivity {
    public WApp mMyApp;  // Application的引用

    private List<IDestroyListener> mList = new ArrayList<>();

    // 用于监听当前Activity销毁事情
    public interface IDestroyListener{
        public void onActivityPrepareDestroy();
    }

    public void registerDestroyedListener(IDestroyListener listener){
        mList.add(listener);
    }
    public void unRegisterDestroyedListener(IDestroyListener listener){
        if (mList.contains(listener)){
            mList.remove(listener);
        }
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        mMyApp = (WApp) getApplication();
    }

    @Override
    public void setContentView(int layoutResID) {
        super.setContentView(layoutResID);
        setStatusBar();
    }

    protected void setStatusBar() {
        StatusBarUtil.setColor(this, getResources().getColor(R.color.colorPrimary),0);
    }

    @Override
    protected void onDestroy() {
        for (int i=0; i < mList.size(); i++){
            IDestroyListener listener = mList.get(i);
            if (listener != null){
                listener.onActivityPrepareDestroy();
            }
        }

        mList.clear();

        super.onDestroy();
    }



}
