package com.westwhale.contollerapp.ui.timer.fragment;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.blankj.utilcode.util.ToastUtils;
import com.scwang.smartrefresh.layout.api.RefreshLayout;
import com.scwang.smartrefresh.layout.listener.OnRefreshListener;
import com.westwhale.contollerapp.R;
import com.westwhale.contollerapp.application.WApp;
import com.westwhale.contollerapp.dev.CmdActionLister;
import com.westwhale.contollerapp.dev.ICmdCallback;
import com.westwhale.contollerapp.dev.WRoom;
import com.westwhale.contollerapp.ui.base.fragment.BaseFragment;
import com.westwhale.contollerapp.ui.timer.activity.TimerActivity;
import com.westwhale.contollerapp.ui.timer.adapter.TimerInfoAdapter;
import com.westwhale.api.protocolapi.bean.Timer;

import java.util.List;

public class TimerManagerFragment extends BaseFragment implements TimerInfoAdapter.CallBack {
    private Toolbar mToolBar;
    private RecyclerView mDataRv;
    private RefreshLayout mRefreshLayout;

    private TimerInfoAdapter mAdapter;


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.frag_timer_manager,container,false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        initView(view);

        initListener();

        initData();

    }

    @Override
    public void onResume() {
        super.onResume();
    }

    @Override
    public void onItemClick(Timer timer) {
        // 编辑指定定时器  不响应
    }

    @Override
    public void onItemEnableClick(Timer timer, boolean enable) {
        // 定时器使能开关 不响应
    }

    @Override
    public void onItemDeleteClick(Timer timer) {
        // 删除定时器
        if (timer != null) {
            WRoom room = WApp.Instance.getDevManager().getSelectedRoom();
            if (room != null) {
                room.cmdDelTimer(timer.timerId, new CmdActionLister<Boolean>(TimerManagerFragment.this, new ICmdCallback<Boolean>() {
                    @Override
                    public void onSuccess(Boolean data) {
                        if (data){
                            if (getActivity() instanceof TimerActivity){
                                ((TimerActivity) getActivity()).removeTimer(timer);
                                
                                initData();

                                if (getTargetFragment() != null){
                                    getTargetFragment().onActivityResult(TimerFragment.REQUEST_CODE_TIMER_MANAGER, Activity.RESULT_OK, new Intent());
                                }
                            }
                            ToastUtils.showShort("删除定时器成功");
                        }else{
                            ToastUtils.showShort("删除定时器成失败");
                        }
                    }

                    @Override
                    public void onFailed(int code, String msg) {
                        ToastUtils.showShort("删除定时器成失败: %d",code);
                    }
                }));
            }
        }
    }

    private void initView(View view) {
        mToolBar = view.findViewById(R.id.timer_manager_toolbar);
        if (getActivity() != null){
            ((AppCompatActivity) getActivity()).setSupportActionBar(mToolBar);
            ActionBar actionBar = ((AppCompatActivity) getActivity()).getSupportActionBar();
            if (actionBar != null){
                actionBar.setDisplayHomeAsUpEnabled(true);
            }
        }

        mAdapter = new TimerInfoAdapter(this);
        mAdapter.setTimerType(TimerInfoAdapter.TIMER_TYPE_DELETE);

        mDataRv = view.findViewById(R.id.timer_manager_recylerview);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(mContext);
        mDataRv.setLayoutManager(linearLayoutManager);
        mDataRv.setAdapter(mAdapter);
        mDataRv.setHasFixedSize(true);
        mDataRv.addItemDecoration(new DividerItemDecoration(mContext, DividerItemDecoration.VERTICAL));

        mRefreshLayout = view.findViewById(R.id.timer_manager_refreshlayout);
        mRefreshLayout.setDisableContentWhenRefresh(true);
        mRefreshLayout.setEnableLoadMore(false);
    }

    private void initListener() {
        mToolBar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (getActivity() != null){
                    getActivity().onBackPressed();
                }
            }
        });

        mRefreshLayout.setOnRefreshListener(new OnRefreshListener() {
            @Override
            public void onRefresh(@NonNull RefreshLayout refreshLayout) {
                initData();
            }
        });
    }

    private void initData() {
        if (getActivity() instanceof TimerActivity){
            updateData(((TimerActivity) getActivity()).getTimerList());
        }
    }

    private void updateData(List<Timer> datalist){
        if (datalist != null ){
            if (mAdapter != null){
                mAdapter.setDataList(datalist);
                mAdapter.notifyDataSetChanged();
            }

            mRefreshLayout.finishRefresh();
        }
    }

}
