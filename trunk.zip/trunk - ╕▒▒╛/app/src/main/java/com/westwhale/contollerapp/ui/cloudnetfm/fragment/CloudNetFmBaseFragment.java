package com.westwhale.contollerapp.ui.cloudnetfm.fragment;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.kingja.loadsir.callback.Callback;
import com.scwang.smartrefresh.layout.api.RefreshLayout;
import com.scwang.smartrefresh.layout.listener.OnLoadMoreListener;
import com.scwang.smartrefresh.layout.listener.OnRefreshListener;
import com.westwhale.contollerapp.R;
import com.westwhale.contollerapp.ui.cloudnetfm.adapter.CloudNetFmAdatper;
import com.westwhale.contollerapp.application.WApp;
import com.westwhale.contollerapp.dev.CmdActionLister;
import com.westwhale.contollerapp.dev.ICmdCallback;
import com.westwhale.contollerapp.dev.WRoom;
import com.westwhale.contollerapp.ui.base.fragment.TitleBaseFragment;
import com.westwhale.contollerapp.ui.loadsircallback.LoadingCallback;
import com.westwhale.api.protocolapi.bean.media.CloudNetFm;

import java.util.List;

/**
 * Description:
 * Author: chenyaoli
 * Date: 2018-11-12
 * History:
 */
public abstract class CloudNetFmBaseFragment extends TitleBaseFragment implements CloudNetFmAdatper.CallBack{
    protected static final String TAG = "NetFmBase";

    protected FrameLayout mFrameLayout;
    protected RecyclerView mDataRv;
    protected Toolbar mToolBar;
    protected RefreshLayout mRefreshLayout;
    protected LinearLayout mCategoryLayout;
    protected TextView mAlbumTypeTv;
    protected ImageView mCategoryIv;
    protected CloudNetFmAdatper mAdapter;

    protected abstract void initData();
    protected abstract boolean hasMoreData();
    protected abstract void loadMoreData();
    protected abstract void updateDataList(List<CloudNetFm> list);
    protected abstract void requestCloudResource();

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        // 先显示加载动画，针对布局做一些初始化
        return inflater.inflate(R.layout.frag_cloudnetfm_album,container,false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        mFrameLayout = view.findViewById(R.id.cloudnetfm_album_frame);

        // 创建mLoadService
        mLoadService = mLoadSir.register(mFrameLayout, new Callback.OnReloadListener() {
            @Override
            public void onReload(View v) {
                showLoadCallBack(LoadingCallback.class);
                initData();
            }
        });

        initView(view);

        initListener();

        initData();
    }

    @Override
    public void onResume() {
        super.onResume();
    }


    @Override
    public void onItemClick(CloudNetFm item) {
        // 播放网络电台
        WRoom room = WApp.Instance.getDevManager().getSelectedRoom();
        if (room != null){
            room.cmdPlayMedia(item,new CmdActionLister<Boolean>(this, new ICmdCallback<Boolean>() {
                @Override
                public void onSuccess(Boolean data) {
                }

                @Override
                public void onFailed(int code, String msg) {
                    Toast.makeText(getActivity(),"网络电台播放失败"+code,Toast.LENGTH_SHORT).show();
                }
            }));
        }
    }

    protected void initView(View view) {
        mToolBar = view.findViewById(R.id.cloudnetfm_album_toolbar);

        mDataRv = view.findViewById(R.id.cloudnetfm_album_recylerview);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(mContext);
        mDataRv.setLayoutManager(linearLayoutManager);
        mAdapter = new CloudNetFmAdatper(this);
        mDataRv.setAdapter(mAdapter);
        mDataRv.setHasFixedSize(true);

        mRefreshLayout = view.findViewById(R.id.cloudnetfm_album_refresh);
        mRefreshLayout.setDisableContentWhenRefresh(true);
        mRefreshLayout.setEnableLoadMore(true);

        mCategoryLayout = view.findViewById(R.id.cloudnetfm_album_nav);
        mAlbumTypeTv = view.findViewById(R.id.cloudnetfm_album_type);
        mCategoryIv = view.findViewById(R.id.cloudnetfm_album_category);
    }

    protected void initListener() {
        mRefreshLayout.setOnRefreshListener(new OnRefreshListener() {
            @Override
            public void onRefresh(@NonNull RefreshLayout refreshLayout) {
                initData();
            }
        });

        mRefreshLayout.setOnLoadMoreListener(new OnLoadMoreListener() {
            @Override
            public void onLoadMore(@NonNull RefreshLayout refreshLayout) {
                if (hasMoreData()){
                    loadMoreData();
                }else {
                    mRefreshLayout.finishLoadMoreWithNoMoreData();
                }
            }
        });
    }
}
