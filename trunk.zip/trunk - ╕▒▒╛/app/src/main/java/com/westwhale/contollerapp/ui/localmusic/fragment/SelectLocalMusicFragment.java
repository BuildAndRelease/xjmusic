package com.westwhale.contollerapp.ui.localmusic.fragment;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.Toast;

import com.kingja.loadsir.callback.Callback;
import com.kingja.loadsir.callback.SuccessCallback;
import com.kingja.loadsir.core.LoadService;
import com.kingja.loadsir.core.LoadSir;
import com.scwang.smartrefresh.layout.api.RefreshLayout;
import com.scwang.smartrefresh.layout.listener.OnLoadMoreListener;
import com.scwang.smartrefresh.layout.listener.OnRefreshListener;
import com.westwhale.contollerapp.R;
import com.westwhale.contollerapp.application.WApp;
import com.westwhale.contollerapp.dev.CmdActionLister;
import com.westwhale.contollerapp.dev.ICmdCallback;
import com.westwhale.contollerapp.dev.WRoom;
import com.westwhale.contollerapp.ui.base.fragment.BaseFragment;
import com.westwhale.contollerapp.ui.loadsircallback.EmptyCallback;
import com.westwhale.contollerapp.ui.loadsircallback.ErrorCallback;
import com.westwhale.contollerapp.ui.loadsircallback.LoadingCallback;
import com.westwhale.contollerapp.ui.loadsircallback.TimeoutCallback;
import com.westwhale.contollerapp.ui.localmusic.adapter.LocalMediaListAdapter;
import com.westwhale.contollerapp.ui.localmusic.activity.SelectLocalMusicActivity;
import com.westwhale.api.protocolapi.bean.LocalDirectory;
import com.westwhale.api.protocolapi.bean.media.LocalMusic;
import com.westwhale.api.protocolapi.net.Response;

/**
 * Description:
 * Author: chenyaoli
 * Date: 2018-11-16
 * History:
 */
public class SelectLocalMusicFragment extends BaseFragment implements LocalMediaListAdapter.CallBack{
    private final static String TAG = SelectLocalMusicFragment.class.getName();

    public static final String ARG_KEY_DIRECTORYMID = "directoryMid";
    public static final String ARG_KEY_DIRECTORYNAME = "directoryName";

    private Toolbar mToolBar;
    private FrameLayout mLoadingFLayout;
    private RecyclerView mRecyclerView;
    private RefreshLayout mRefreshLayout;
    protected LoadService mLoadService;

    private LocalMediaListAdapter mMediaListAdapter;

    private String mDirectoryName;
    private String mDirectoryMid;


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        // 先显示加载动画，针对布局做一些初始化
        return inflater.inflate(R.layout.frag_timer_localmusic, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        initView(view);
        initListener();



        initData();
    }

    @Override
    public void onResume() {
        super.onResume();
    }

    public void showLoadCallBack(Class<? extends Callback> callback){
        if (mLoadService != null){
            mLoadService.showCallback(callback);
        }
    }

    private void initView(View view) {
        mDirectoryMid = "";
        mDirectoryName = "";
        if (getArguments() != null){
            mDirectoryMid = getArguments().getString(ARG_KEY_DIRECTORYMID);
            mDirectoryName = getArguments().getString(ARG_KEY_DIRECTORYNAME);
        }

        mToolBar = view.findViewById(R.id.timer_localmusic_toolbar);
        if (getActivity() != null) {
            ((AppCompatActivity) getActivity()).setSupportActionBar(mToolBar);
            ActionBar actionBar = ((AppCompatActivity) getActivity()).getSupportActionBar();
            if (actionBar != null) {
                actionBar.setDisplayHomeAsUpEnabled(true);
            }
        }

        mRecyclerView = view.findViewById(R.id.timer_localmusic_recyclerview);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(mContext);
        mRecyclerView.setLayoutManager(linearLayoutManager);
        mMediaListAdapter = new LocalMediaListAdapter(this);
        mRecyclerView.setAdapter(mMediaListAdapter);
        mRecyclerView.setHasFixedSize(true);
        mRecyclerView.addItemDecoration(new DividerItemDecoration(mContext, DividerItemDecoration.VERTICAL));

        mRefreshLayout = view.findViewById(R.id.timer_localmusic_refreshlayout);
        mRefreshLayout.setEnableRefresh(true);
        mRefreshLayout.setDisableContentWhenRefresh(true);
        mRefreshLayout.setEnableLoadMore(true);

        LoadSir loadSir = new LoadSir.Builder()
                .addCallback(new LoadingCallback())
                .addCallback(new TimeoutCallback())
                .addCallback(new ErrorCallback())
                .addCallback(new EmptyCallback())
                .setDefaultCallback(LoadingCallback.class)
                .build();

        mLoadingFLayout = view.findViewById(R.id.timer_localmusic_frame);
//         创建mLoadService
        mLoadService = loadSir.register(mLoadingFLayout, new Callback.OnReloadListener() {
            @Override
            public void onReload(View v) {
                initData();
            }
        });

    }

    private void initListener() {
        mToolBar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (getActivity() != null){
                    getActivity().onBackPressed();
                }
            }
        });

        mRefreshLayout.setOnRefreshListener(new OnRefreshListener() {
            @Override
            public void onRefresh(@NonNull RefreshLayout refreshLayout) {
                initData();
            }
        });

        mRefreshLayout.setOnLoadMoreListener(new OnLoadMoreListener() {
            @Override
            public void onLoadMore(@NonNull RefreshLayout refreshLayout) {
                //  判断是否还有数据，从而判断是否还需要加载更多数据
                if( hasMoreData() ){
                    loadMoreData();
                }else {
                    mRefreshLayout.finishLoadMoreWithNoMoreData();
                }
            }
        });
    }

    private void initData() {
        mToolBar.setTitle(mDirectoryName);

        mBeginIndex = 0;
        mHasMoreData = true;

        if (mMediaListAdapter != null){
            mMediaListAdapter.clearDataList();
        }

        requestDataResource();
    }

    /*************************************    *****************************/
    @Override
    public void onDirectoryClick(LocalDirectory.Directory item) {
        SelectLocalMusicFragment fragment = new SelectLocalMusicFragment();
        String directoryName = (item != null) ? item.directoryName : "未知";
        String directoryMid = (item != null) ? item.directoryMid : "未知";
        Bundle bundle = new Bundle();
        bundle.putString(ARG_KEY_DIRECTORYMID,directoryMid);
        bundle.putString(ARG_KEY_DIRECTORYNAME,directoryName);
        fragment.setArguments(bundle);

        if (getActivity() instanceof SelectLocalMusicActivity) {
            ((SelectLocalMusicActivity) getActivity()).showFragment(fragment);
        }
    }

    @Override
    public void onDirecotryMoreClick(LocalDirectory.Directory item) {

    }


    @Override
    public void onSongItemClick(LocalMusic songItem) {
        if (getActivity() instanceof SelectLocalMusicActivity) {
            ((SelectLocalMusicActivity) getActivity()).onMediaItemClick(songItem);
        }
    }

    @Override
    public void onSongItemMoreClick(LocalMusic songItem) {

    }




    private int mBeginIndex = 0;
    private int mNum = 50;
    private boolean mHasMoreData = true; // 记录是否还有更多数据

    private boolean hasMoreData() {
        return mHasMoreData;
    }

    private void loadMoreData() {
        requestDataResource();
    }

    private void updateDataList(LocalDirectory directory) {
        if (directory != null) {
            // 若无法获取到数据，则认为已经到底
            int mediaListsize = (directory.mediaList != null) ? directory.mediaList.size(): 0;
            int diretoryListsize = (directory.directoryList != null) ? directory.directoryList.size() : 0;

            // 若刚开始加载数据，则先清空数据
            if (mBeginIndex == 0){
                mMediaListAdapter.clearDataList();
            }

            mBeginIndex = mBeginIndex + mediaListsize + diretoryListsize;
            if ((mediaListsize == 0) && (diretoryListsize == 0)){
                mHasMoreData = false;
            }else{
                mMediaListAdapter.addToDataList(directory);
            }

            // 更新刷新等待状态
            mRefreshLayout.finishRefresh();
            mRefreshLayout.finishLoadMore();

            showLoadCallBack(SuccessCallback.class);
        }else{
            // 当获取数据失败时，则认为无数据了
            mHasMoreData = false;

            mRefreshLayout.finishRefresh();
            mRefreshLayout.finishLoadMore();
            showLoadCallBack(EmptyCallback.class);
        }
    }

    private void requestDataResource() {
        WRoom room = WApp.Instance.getDevManager().getSelectedRoom();
        if (room != null){
            String directoryMid = (mDirectoryMid != null) ? mDirectoryMid : "";
            int beginIndex = mBeginIndex;
            int num = mNum;
            boolean ignoreEmpty = false;
            WRoom.cmdGetLocalDirectory(directoryMid, beginIndex,num,ignoreEmpty, new CmdActionLister<Response<LocalDirectory>>(this, new ICmdCallback<Response<LocalDirectory>>() {
                @Override
                public void onSuccess(Response<LocalDirectory> data) {
                    updateDataList(data.bean);
                }

                @Override
                public void onFailed(int code, String msg) {
                    updateDataList(null);
                    Toast.makeText(getContext(),"GetLocalDirectory获取失败:"+code,Toast.LENGTH_SHORT).show();
                }
            }));
        }else{
            updateDataList(null);
        }
    }
}
