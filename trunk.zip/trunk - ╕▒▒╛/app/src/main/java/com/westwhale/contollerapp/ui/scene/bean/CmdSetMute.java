package com.westwhale.contollerapp.ui.scene.bean;


import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;

public class CmdSetMute extends CmdActionBase {
    public final static String MUTE_STAT_NORMAL = "normal";
    public final static String MUTE_STAT_MUTE = "mute";

    private String mMuteStat = MUTE_STAT_NORMAL;

    public CmdSetMute() {
        mType = CMD_TYPE_SETMUTE;
        mCmdName = getCmdName();
    }

    @Override
    public String toJsonString() {
        JSONObject argObject = new JSONObject();
        argObject.put("muteStat",mMuteStat);

        JSONObject jsonObject = new JSONObject();
        jsonObject.put("cmd",mCmdName);
        jsonObject.put("arg",argObject);

        return jsonObject.toJSONString();
    }

    @Override
    public String getActionValue() {
        String value = "非静音";
        if (MUTE_STAT_MUTE.equals(mMuteStat)){
            value = "静音";
        }
        return value;
    }

    @Override
    public void parseArgs() {
        if ((mCmdArgs == null) || (mCmdArgs.isEmpty())){
            return;
        }

        try {
            mMuteStat = JSON.parseObject(mCmdArgs).getString("muteStat");
        }catch (Exception e){
            mMuteStat = "";
        }
    }

    public void setMuteStat(String stat){
        mMuteStat = stat;
    }

    public String getMuteStat(){
        return mMuteStat;
    }
}
