package com.westwhale.contollerapp.ui.scene.activity;


import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.CheckBox;
import android.widget.LinearLayout;

import com.westwhale.api.protocolapi.bean.media.LocalMusic;
import com.westwhale.api.protocolapi.bean.media.Media;
import com.westwhale.contollerapp.R;
import com.westwhale.contollerapp.common.ImageTextItem;
import com.westwhale.contollerapp.ui.base.activity.BaseActivity;
import com.westwhale.contollerapp.ui.localmusic.activity.SelectLocalMusicActivity;
import com.westwhale.contollerapp.ui.scene.adapter.SceneOpenMediaAdapter;
import com.westwhale.contollerapp.ui.scene.bean.CmdActionBase;
import com.westwhale.contollerapp.ui.timer.TimerDefine;

import java.util.ArrayList;
import java.util.List;

/**
 * Description:
 * Author: chenyaoli
 * Date: 2018-12-20
 * History
 */
public class SceneOpenMediaActivity extends BaseActivity implements SceneOpenMediaAdapter.CallBack {
    private final String TAG = SceneOpenMediaActivity.class.getName();

    private final int REQUEST_CODE_OPENMEDIA_LOCALMUSIC = 1;
    private final int OPENMEDIA_MODE_DEFAULT = 1;
    private final int OPENMEDIA_MODE_SWITCHMEDIASRC = 2;
    private final int OPENMEDIA_MODE_LOCALMUSIC = 3;

    private Toolbar mToolbar;
    private LinearLayout mDefaultLayout, mLocalMusicLayout;
    private CheckBox mDefaultChx, mLocalMusicChx;

    private CheckBox mCurrentSelectedChx;

    private RecyclerView mDataRv;
    private SceneOpenMediaAdapter mAdapter;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_scene_openmedia);

        initView();
        initListener();

        initData();
    }

    @Override
    protected void onPause() {
        super.onPause();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if ((requestCode == REQUEST_CODE_OPENMEDIA_LOCALMUSIC) && (resultCode == Activity.RESULT_OK)){

            LocalMusic localMusic = null;
            if (data != null){
                 localMusic = data.getParcelableExtra("media");
            }

            Intent intent = new Intent();
//            intent.putExtra("cmdType", CmdActionBase.CMD_TYPE_PLAYLOCALMUSIC);
            intent.putExtra("cmdType", CmdActionBase.CMD_TYPE_PLAYMEDIA);
            intent.putExtra("mediaSrc", Media.LOCAL_MUSIC);
            intent.putExtra("media", localMusic);

            setResult(Activity.RESULT_OK,intent);

            finish();
        }else if ((requestCode == OPENMEDIA_MODE_SWITCHMEDIASRC) && (resultCode == Activity.RESULT_OK)){
            String mediaSrc = "";
            if (data != null){
                mediaSrc = data.getStringExtra(SceneSwitchSourceActivity.RESULT_KEY_MEDIASRC);
            }
            Intent intent = new Intent();
            intent.putExtra("cmdType", CmdActionBase.CMD_TYPE_SETAUDIOSOURCE );
            intent.putExtra("mediaSrc", mediaSrc );

            setResult(Activity.RESULT_OK,intent);

            finish();
        }
    }

    @Override
    public void onItemClick(ImageTextItem item, int pos) {
        if ((item != null) && (pos > -1)){
            switch (item.getType()){
                case OPENMEDIA_MODE_DEFAULT:
                    //无媒体配置
                    finish();
                    break;
                case OPENMEDIA_MODE_SWITCHMEDIASRC:
                    //音源切换
                    startActivityForResult(new Intent(SceneOpenMediaActivity.this, SceneSwitchSourceActivity.class),OPENMEDIA_MODE_SWITCHMEDIASRC);
                    break;
                case OPENMEDIA_MODE_LOCALMUSIC:
                    //本地音乐
                    startActivityForResult(new Intent(SceneOpenMediaActivity.this, SelectLocalMusicActivity.class),REQUEST_CODE_OPENMEDIA_LOCALMUSIC);
                    break;
                default:
                    break;
            }
        }
    }

    private void initView() {
        mToolbar = findViewById(R.id.openmedia_toolbar);
        // 设置toolbar
        setSupportActionBar(mToolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        mDataRv = findViewById(R.id.openmedia_recyclerview);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        mDataRv.setLayoutManager(linearLayoutManager);
        mAdapter = new SceneOpenMediaAdapter();
        mAdapter.setCallBack(this);
        mDataRv.setAdapter(mAdapter);
        mDataRv.setHasFixedSize(true);
        // 设置下拉上拉无阴影效果
        mDataRv.setOverScrollMode(View.OVER_SCROLL_NEVER);
        mDataRv.addItemDecoration(new DividerItemDecoration(this, DividerItemDecoration.VERTICAL));
    }

    private void initListener() {
        mToolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
    }

    private void initData() {
        List<ImageTextItem> dataList = new ArrayList<>();

        dataList.add(new ImageTextItem(OPENMEDIA_MODE_DEFAULT,"无"));
        dataList.add(new ImageTextItem(OPENMEDIA_MODE_SWITCHMEDIASRC,"音源切换"));
        dataList.add(new ImageTextItem(OPENMEDIA_MODE_LOCALMUSIC,"本地音乐"));

        mAdapter.setDataList(dataList);
        mAdapter.notifyDataSetChanged();
    }


}
