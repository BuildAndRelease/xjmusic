package com.westwhale.contollerapp.ui.cloudstory.dialog;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.DialogFragment;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.TextView;

import com.westwhale.contollerapp.R;
import com.westwhale.contollerapp.ui.cloudstory.adapter.StoryAlbumCategoryAdapter;
import com.westwhale.contollerapp.ui.base.dialog.AttachDialogFragment;
import com.westwhale.contollerapp.ui.cloudstory.fragment.CloudStoryCategoryAlbumFragment;
import com.westwhale.api.protocolapi.bean.telling.CatrgroyGroup;

/**
 * Description:
 * Author: chenyaoli
 * Date: 2018-12-01
 * History:
 */
public class StoryAlbumCategoryDialog extends AttachDialogFragment implements StoryAlbumCategoryAdapter.CallBack {
    public static final String CATEGORY_ID = "id";
    public static final String CATEGORY_NAME = "categoryName";
    public static final String CATEGORY_PARENTID = "parentId";

    private TextView mTitleTv;
    private ImageView mCancelIv;
    private RecyclerView mItemRv;
    private StoryAlbumCategoryAdapter mCategoryAdapter;

    private CatrgroyGroup.TellingCatrgroy mSelectedItem;
    private CatrgroyGroup mCategoryGroup;

    public void updateCategoryGroup(CatrgroyGroup.TellingCatrgroy selectedItem,CatrgroyGroup group){
        mCategoryGroup = group;
        if ( (group != null) && (group.subCategoryList != null) && (selectedItem != null) ){
            for (int i=0; i < group.subCategoryList.size(); i++){
                CatrgroyGroup.TellingCatrgroy item = group.subCategoryList.get(i);
                if ((item != null) && (selectedItem.id == item.id) && (selectedItem.parentId == item.parentId) && (selectedItem.categoryName == item.categoryName)){
                    mSelectedItem = item;
                    break;
                }
            }
        }
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // 背景色，动画效果，通过主题设置
        setStyle(DialogFragment.STYLE_NORMAL, R.style.CommonDialogStyle);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        //布局
        View view = inflater.inflate(R.layout.dialogfrag_story_album_category, container);

        initView(view);
        initListener();

        return view;
    }

    @Override
    public void onStart() {
        super.onStart();

        //设置fragment高度 、宽度
        double heightPercent = 0.4;
        double widthPercent = 0.9;
        int dialogHeight = (int) (mContext.getResources().getDisplayMetrics().heightPixels * heightPercent);
        int dialogWidth = (int) (mContext.getResources().getDisplayMetrics().widthPixels * widthPercent);
        Window window = getDialog().getWindow();
        if (window != null) {
            WindowManager.LayoutParams params = window.getAttributes();
            params.gravity = Gravity.CENTER;
            params.width = dialogWidth;
            params.height = dialogHeight;
            window.setAttributes(params);
        }
        getDialog().setCanceledOnTouchOutside(true);

        initData();
    }

    @Override
    public void onCategoryItemClick(CatrgroyGroup.TellingCatrgroy item) {
        // 点击某一项后
        if (getTargetFragment() == null) {
            return;
        }
        Intent intent = new Intent();
        intent.putExtra(CATEGORY_ID, String.valueOf(item.id));
        intent.putExtra(CATEGORY_NAME, item.categoryName);
        intent.putExtra(CATEGORY_PARENTID, String.valueOf(item.parentId));
        //获得目标Fragment,并将数据通过onActivityResult放入到intent中进行传值
        getTargetFragment().onActivityResult(CloudStoryCategoryAlbumFragment.REQUEST_CODDE, Activity.RESULT_OK, intent);

        dismiss();
    }

    private void initView(View view) {
        String title = (mCategoryGroup != null) ? mCategoryGroup.categoryName : "";
        mTitleTv = view.findViewById(R.id.dialogfrag_category_title);
        mTitleTv.setText(title);

        mCancelIv = view.findViewById(R.id.dialogfrag_category_cancel);

        mItemRv = view.findViewById(R.id.dialogfrag_category_recylerview);
        GridLayoutManager gridLayoutManager = new GridLayoutManager(mContext,3);
        mItemRv.setLayoutManager(gridLayoutManager);
        mCategoryAdapter = new StoryAlbumCategoryAdapter(this);
        mItemRv.setAdapter(mCategoryAdapter);
        mItemRv.setHasFixedSize(true);
        // 设置下拉上拉无阴影效果
        mItemRv.setOverScrollMode(View.OVER_SCROLL_NEVER);
    }

    private void initListener() {
        mCancelIv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dismiss();
            }
        });
    }

    private void initData() {
        if (mCategoryAdapter != null) {
            mCategoryAdapter.updateDataList(mCategoryGroup.subCategoryList);
            mCategoryAdapter.setSelectedItem(mSelectedItem);
            mCategoryAdapter.notifyDataSetChanged();
        }
    }


}
