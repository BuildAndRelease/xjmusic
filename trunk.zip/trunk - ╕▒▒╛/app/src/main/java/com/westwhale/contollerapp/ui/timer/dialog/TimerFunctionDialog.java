package com.westwhale.contollerapp.ui.timer.dialog;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.DialogFragment;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.westwhale.contollerapp.R;
import com.westwhale.contollerapp.ui.base.dialog.AttachDialogFragment;
import com.westwhale.contollerapp.ui.timer.TimerDefine;
import com.westwhale.contollerapp.ui.timer.activity.TimerAddEditActivity;

/**
 * Description:
 * Author: chenyaoli
 * Date: 2018-11-23
 * History:
 */
public class TimerFunctionDialog extends AttachDialogFragment {
    public static final String TAG = TimerFunctionDialog.class.getName();

    private TextView mTimerOpenTv,mTimerCloseTv,mTimerClockTv;
    private LinearLayout mTimerOpenLayout,mTimerCloseLayout,mTimerClockLayout;


    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // 背景色，动画效果，通过主题设置
        setStyle(DialogFragment.STYLE_NORMAL,R.style.CommonDialogStyle);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        //布局
        View view = inflater.inflate(R.layout.frag_timer_function, container);

        initView(view);
        initListener();

        return view;
    }

    @Override
    public void onStart() {
        super.onStart();

        initData();

        //设置fragment高度 、宽度
        double heightPercent = 0.5;
        int dialogHeight = (int) (mContext.getResources().getDisplayMetrics().heightPixels * heightPercent);
        Window window = getDialog().getWindow();
        if (window != null) {
            WindowManager.LayoutParams params = window.getAttributes();
            params.gravity = Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL;
            params.width = WindowManager.LayoutParams.MATCH_PARENT;
            params.height = dialogHeight; // 底部弹出的DialogFragment的高度，如果是MATCH_PARENT则铺满整个窗口
            window.setAttributes(params);
            getDialog().setCanceledOnTouchOutside(true);
        }
    }

    private void initView(View view) {
        mTimerOpenLayout = view.findViewById(R.id.dialog_timer_func_open_layout);
        mTimerOpenTv = view.findViewById(R.id.dialog_timer_func_open);

        mTimerCloseLayout = view.findViewById(R.id.dialog_timer_func_close_layout);
        mTimerCloseTv = view.findViewById(R.id.dialog_timer_func_close);

        mTimerClockLayout = view.findViewById(R.id.dialog_timer_func_clock_layout);
        mTimerClockTv = view.findViewById(R.id.dialog_timer_func_clock);
    }

    private void initListener() {
        mTimerOpenLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                switchTimerAction(TimerDefine.TIMER_FUNC_OPEN);
            }
        });

        mTimerCloseLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                switchTimerAction(TimerDefine.TIMER_FUNC_CLOSE);
            }
        });

        mTimerClockLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                switchTimerAction(TimerDefine.TIMER_FUNC_CLOCKPLAY);
                switchTimerAction(TimerDefine.TIMER_FUNC_ALARM);
            }
        });
    }

    private void initData() {
        mTimerOpenTv.setText(TimerDefine.TIMER_FUNC_OPEN_NAME);
        mTimerCloseTv.setText(TimerDefine.TIMER_FUNC_CLOSE_NAME);
//        mTimerClockTv.setText(TimerDefine.TIMER_FUNC_CLOCKPLAY_NAME);
        mTimerClockTv.setText(TimerDefine.TIMER_FUNC_ALARM_NAME);
    }

    private void switchTimerAction(String actionName){
        if (getActivity() instanceof TimerAddEditActivity){
            ((TimerAddEditActivity) getActivity()).updateTimerFunction(actionName);

            dismiss();
        }
    }
}
