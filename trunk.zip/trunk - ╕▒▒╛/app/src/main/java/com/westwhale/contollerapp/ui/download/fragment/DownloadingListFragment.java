package com.westwhale.contollerapp.ui.download.fragment;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.AppBarLayout;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;

import com.blankj.utilcode.util.ToastUtils;
import com.kingja.loadsir.callback.Callback;
import com.kingja.loadsir.callback.SuccessCallback;
import com.kingja.loadsir.core.LoadService;
import com.kingja.loadsir.core.LoadSir;
import com.scwang.smartrefresh.layout.api.RefreshLayout;
import com.scwang.smartrefresh.layout.listener.OnLoadMoreListener;
import com.scwang.smartrefresh.layout.listener.OnRefreshListener;
import com.westwhale.api.protocolapi.BAKey;
import com.westwhale.contollerapp.R;
import com.westwhale.contollerapp.application.WApp;
import com.westwhale.contollerapp.common.AppBarStateChangeListener;
import com.westwhale.contollerapp.dev.CmdActionLister;
import com.westwhale.contollerapp.dev.ICmdCallback;
import com.westwhale.contollerapp.dev.WRoom;
import com.westwhale.contollerapp.ui.base.fragment.BaseFragment;
import com.westwhale.contollerapp.ui.download.activity.DownloadingMultiActivity;
import com.westwhale.contollerapp.ui.download.adapter.DownloadingListAdapter;
import com.westwhale.contollerapp.ui.loadsircallback.EmptyCallback;
import com.westwhale.contollerapp.ui.loadsircallback.ErrorCallback;
import com.westwhale.contollerapp.ui.loadsircallback.LoadingCallback;
import com.westwhale.contollerapp.ui.loadsircallback.TimeoutCallback;
import com.westwhale.api.protocolapi.CMD;
import com.westwhale.api.protocolapi.bean.media.CloudMusic;
import com.westwhale.api.protocolapi.bean.media.Media;
import com.westwhale.api.protocolapi.bean.download.DownloadItem;

import java.util.List;

public class DownloadingListFragment extends BaseFragment implements DownloadingListAdapter.CallBack {

    private final static String TAG = DownloadingListFragment.class.getName();

    public static final int REQUEST_CODE_DETELE = 1;
    public static final int ACTIVITY_RESULT_CODE_DETELE = 1;

    private ActionBar mActionBar;
    private Toolbar mToolBar;
    private ImageView mHeaderTitleIv,mHeaderBgIv, mCancelIv, mEditIv;
    private TextView mSubtitleTv, mTitleTv;
    private FrameLayout mLoadingFLayout;
    private RecyclerView mRecyclerView;
    private RefreshLayout mRefreshLayout;
    private AppBarLayout mAppBarLayout;
    protected LoadService mLoadService;

    private DownloadingListAdapter mListAdapter;

    private String mFragmentTitle;
    private String mTitle;
    private String mSubtitle;


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        // 先显示加载动画，针对布局做一些初始化
        return inflater.inflate(R.layout.frag_download_downloading, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        initView(view);
        initListener();

        initData();
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_CODE_DETELE){
            if (resultCode == ACTIVITY_RESULT_CODE_DETELE){
                // 若删除成功，则重新获取数据
                requestDataResource();
            }
        }
    }

    @Override
    public void onMediaItemClick(List<DownloadItem<CloudMusic>> itemList, DownloadItem<CloudMusic> mediaItem) {

    }

    @Override
    public void onMediaItemMoreClick(DownloadItem<CloudMusic> mediaItem) {

    }

    private void initView(View view) {
        mToolBar = view.findViewById(R.id.download_downloading_toolbar);
        if (getActivity() != null) {
            ((AppCompatActivity) getActivity()).setSupportActionBar(mToolBar);
            mActionBar = ((AppCompatActivity) getActivity()).getSupportActionBar();
            if (mActionBar != null) {
                mActionBar.setDisplayHomeAsUpEnabled(true);
                mActionBar.setHomeAsUpIndicator(R.drawable.home_backup);
            }
        }

        mHeaderTitleIv = view.findViewById(R.id.download_downloading_header_pic);
        mHeaderTitleIv.setImageResource(R.drawable.local_playlist_header_default);

        mHeaderBgIv = view.findViewById(R.id.download_downloading_header_bg);
        mHeaderBgIv.setImageResource(R.drawable.local_playlist_header_mongo);

        mTitleTv = view.findViewById(R.id.download_downloading_header_title);
        mSubtitleTv = view.findViewById(R.id.download_downloading_header_subtitle);

        mCancelIv = view.findViewById(R.id.download_downloading_header_play);
        mEditIv = view.findViewById(R.id.download_downloading_header_edit);

        mLoadingFLayout = view.findViewById(R.id.download_downloading_loadsir_layout);

        mRecyclerView = view.findViewById(R.id.download_downloading_recyclerview);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(mContext);
        mRecyclerView.setLayoutManager(linearLayoutManager);
        mListAdapter = new DownloadingListAdapter(this);
        mRecyclerView.setAdapter(mListAdapter);
        mRecyclerView.setHasFixedSize(true);
        mRecyclerView.addItemDecoration(new DividerItemDecoration(mContext, DividerItemDecoration.VERTICAL));

        mRefreshLayout = view.findViewById(R.id.download_downloading_refreshlayout);
        mRefreshLayout.setEnableRefresh(false);
//        mRefreshLayout.setDisableContentWhenRefresh(true);
        mRefreshLayout.setEnableLoadMore(true);

        mAppBarLayout = view.findViewById(R.id.download_downloading_app_bar);


        LoadSir loadSir = new LoadSir.Builder()
                .addCallback(new LoadingCallback())
                .addCallback(new TimeoutCallback())
                .addCallback(new ErrorCallback())
                .addCallback(new EmptyCallback())
                .setDefaultCallback(LoadingCallback.class)
                .build();

//         创建mLoadService
        mLoadService = loadSir.register(mLoadingFLayout, new Callback.OnReloadListener() {
            @Override
            public void onReload(View v) {
                initData();
            }
        });
    }

    private void initListener() {
        mToolBar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (getActivity() != null){
                    getActivity().onBackPressed();
                }
            }
        });

        mCancelIv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 取消所有下载任务
                List<DownloadItem<CloudMusic>> datalist = null;
                if (mListAdapter != null) {
                    datalist = mListAdapter.getDataList();
                }
                if ((datalist != null) && (datalist.size() > 0)){
                    WRoom room = WApp.Instance.getDevManager().getSelectedRoom();
                    if (room != null){
                        room.cmdOperatorDownload(BAKey.ARG_DEL_DOWNLOADING_ALL,datalist,new CmdActionLister<Boolean>(DownloadingListFragment.this, new ICmdCallback<Boolean>() {
                            @Override
                            public void onSuccess(Boolean data) {
                                if (data) {
                                    ToastUtils.showShort("取消下载成功");
                                    mListAdapter.clearDataList();
                                }
                            }

                            @Override
                            public void onFailed(int code, String msg) {
                                ToastUtils.showShort("取消下载失败 %d",code);
                            }
                        }));
                    }
                }else{
                    ToastUtils.showShort("列表为空");
                }
            }
        });

        mEditIv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 多选编辑界面
                if (mListAdapter != null) {
                    DownloadingMultiActivity.setDataList(mListAdapter.getDataList());
                    startActivityForResult(new Intent(getContext(), DownloadingMultiActivity.class), REQUEST_CODE_DETELE);
                }
            }
        });

        mRefreshLayout.setOnRefreshListener(new OnRefreshListener() {
            @Override
            public void onRefresh(@NonNull RefreshLayout refreshLayout) {
                initData();
            }
        });

        mRefreshLayout.setOnLoadMoreListener(new OnLoadMoreListener() {
            @Override
            public void onLoadMore(@NonNull RefreshLayout refreshLayout) {
                //  判断是否还有数据，从而判断是否还需要加载更多数据
                if( hasMoreData() ){
                    loadMoreData();
                }else {
                    mRefreshLayout.finishLoadMoreWithNoMoreData();
                }
            }
        });

        // 监听 AppBarLayout 的偏移状态，设置Toolbar的背景色
        mAppBarLayout .addOnOffsetChangedListener(new AppBarStateChangeListener() {
            @Override
            public void onStateChanged(AppBarLayout appBarLayout, State state) {
                if( state == State.EXPANDED ) {
                    //展开状态
                    mToolBar.setTitle(mFragmentTitle);
                }else if(state == State.COLLAPSED){
                    //折叠状态
                    mToolBar.setTitle(mTitle);
                }else {
                    //中间状态

                }
            }
        });
    }

    private void initData() {
        mFragmentTitle = "云音乐-下载";
        mTitle = "下载中...";
        mSubtitle = "";

        mToolBar.setTitle(mFragmentTitle);
        mTitleTv.setText(mTitle);
        mSubtitleTv.setText(mSubtitle);

        mHasMoreData = false;

        if (mListAdapter != null){
            mListAdapter.clearDataList();
        }

        requestDataResource();
    }

    public void showLoadCallBack(Class<? extends Callback> callback){
        if (mLoadService != null){
            mLoadService.showCallback(callback);
            if (callback == SuccessCallback.class){
                if(mLoadingFLayout != null) {
                    mLoadingFLayout.setVisibility(View.INVISIBLE);
                }
                if (mRecyclerView != null){
                    mRecyclerView.setVisibility(View.VISIBLE);
                }

                if (mRefreshLayout != null){
                    mRefreshLayout.setEnableLoadMore(true);
                    mRefreshLayout.setEnableNestedScroll(true);
                }
            }else{
                if(mLoadingFLayout != null) {
                    mLoadingFLayout.setVisibility(View.VISIBLE);
                }
                if (mRecyclerView != null){
                    mRecyclerView.setVisibility(View.INVISIBLE);
                }

                if (mRefreshLayout != null){
                    mRefreshLayout.setEnableLoadMore(false);
                    mRefreshLayout.setEnableNestedScroll(false);
                }
            }
        }
    }


    private boolean mHasMoreData = false; // 记录是否还有更多数据

    private boolean hasMoreData() {
        return mHasMoreData;
    }

    private void loadMoreData() {
        requestDataResource();
    }

    private void updateDataList(List<DownloadItem<CloudMusic>> list) {
        if (list != null) {
            // 若刚开始加载数据，则先清空数据
            mListAdapter.setDataList(list);
            mListAdapter.notifyDataSetChanged();

            // 更新刷新等待状态
            mRefreshLayout.finishLoadMore();

            showLoadCallBack(SuccessCallback.class);
        }else{
            // 当获取数据失败时，则认为无数据了
            mHasMoreData = false;

            mRefreshLayout.finishLoadMore();
            showLoadCallBack(EmptyCallback.class);
        }
    }

    private void requestDataResource() {
        WRoom room = WApp.Instance.getDevManager().getSelectedRoom();
        if (room != null){
            String mediaSrc = Media.CLOUD_MUSIC;
            room.cmdGetDownloadingMusicList(mediaSrc,new CmdActionLister<List<DownloadItem<CloudMusic>>>(this, new ICmdCallback<List<DownloadItem<CloudMusic>>>() {
                @Override
                public void onSuccess(List<DownloadItem<CloudMusic>> data) {
                    updateDataList(data);
                }

                @Override
                public void onFailed(int code, String msg) {
                    updateDataList(null);
                    ToastUtils.showShort("GetFavoriteMedia Failed %d...,",code);
                }
            }));
        }else{
            updateDataList(null);
        }
    }


}
