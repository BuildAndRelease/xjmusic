package com.westwhale.contollerapp.ui.localmusic.adapter;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.westwhale.contollerapp.R;
import com.westwhale.api.protocolapi.bean.LocalDirectory;

import java.util.ArrayList;

/**
 * Description:
 * Author: chenyaoli
 * Date: 2018-12-14
 * History
 *
 */
public class LocalDirectoryAdapter extends RecyclerView.Adapter {
    private ArrayList<LocalDirectory.Directory> mItemList;
    private CallBack mCallBack;

    public interface CallBack{
        void onDirectoryClick(LocalDirectory.Directory item);
        void onDirecotryMoreClick(LocalDirectory.Directory item);
    }

    public int findPos(LocalDirectory.Directory item){
        int pos = -1;
        if (mItemList != null){
            pos = mItemList.indexOf(item);
        }
        return pos;
    }

    public void upateDataList(ArrayList<LocalDirectory.Directory> itemList){
        this.mItemList = itemList;
    }

    public LocalDirectoryAdapter(CallBack callBack){
        this.mItemList = null;
        this.mCallBack = callBack;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_local_directory, viewGroup, false);
        return new DirectoryItemHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder viewHolder, int i) {
        if (viewHolder instanceof DirectoryItemHolder){
            DirectoryItemHolder itemHolder = (DirectoryItemHolder)viewHolder;
            LocalDirectory.Directory item = mItemList.get(i);
            itemHolder.mDirectoryNameTv.setText(item.directoryName);

            itemHolder.mItemMoreIv.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (mCallBack != null){
                        mCallBack.onDirecotryMoreClick(item);
                    }
                }
            });

            itemHolder.mDirectoryNameTv.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (mCallBack != null){
                        mCallBack.onDirectoryClick(item);
                    }
                }
            });
        }
    }

    @Override
    public int getItemCount() {
        return (mItemList == null) ? 0 : mItemList.size();
    }

    /********************************  ItemHolder *******************************/
    private class DirectoryItemHolder extends RecyclerView.ViewHolder{
        ImageView mItemMoreIv;
        TextView mDirectoryNameTv;
        DirectoryItemHolder(@NonNull View itemView) {
            super(itemView);
            mItemMoreIv = itemView.findViewById(R.id.item_local_directory_more);
            mDirectoryNameTv = itemView.findViewById(R.id.item_local_directory_name);
        }
    }
}
