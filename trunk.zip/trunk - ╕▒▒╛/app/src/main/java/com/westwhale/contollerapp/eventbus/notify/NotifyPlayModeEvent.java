package com.westwhale.contollerapp.eventbus.notify;

public class NotifyPlayModeEvent {
    private String mPlayMode;

    public NotifyPlayModeEvent(String playMode){
        mPlayMode = playMode;
    }
    public String getPlayMode() {
        return mPlayMode;
    }
}
