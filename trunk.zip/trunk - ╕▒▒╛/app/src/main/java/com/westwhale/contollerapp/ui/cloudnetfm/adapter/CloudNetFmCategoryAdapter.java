package com.westwhale.contollerapp.ui.cloudnetfm.adapter;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.westwhale.contollerapp.R;
import com.westwhale.api.protocolapi.bean.cloudnetfm.Category;

import java.util.List;

/**
 * Description:
 * Author: chenyaoli
 * Date: 2019-04-06
 * History:
 */
public class CloudNetFmCategoryAdapter extends RecyclerView.Adapter  {
    private List<Category> mItemList;

    private CallBack mCallback;

    public interface CallBack{
        void onCategoryItemClick(Category item);
    }

    public void updateDataList(List<Category> itemList){
        this.mItemList = itemList;
    }

    public CloudNetFmCategoryAdapter(CallBack callBack){
        this.mItemList = null;
        this.mCallback = callBack;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_cloudnetfm_category_item, viewGroup, false);
        return new CategoryItemHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder viewHolder, int i) {
        if (viewHolder instanceof CategoryItemHolder){
            final Category item = mItemList.get(i);
            CategoryItemHolder itemHolder = (CategoryItemHolder)viewHolder;
            itemHolder.mContentTv.setText(item.name);

            itemHolder.itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (mCallback != null){
                        mCallback.onCategoryItemClick(item);
                    }
                }
            });
        }
    }

    @Override
    public int getItemCount() {
        return (null == mItemList) ? 0 : mItemList.size();
    }

    // ItemHolder
    private class CategoryItemHolder extends RecyclerView.ViewHolder{
        TextView mContentTv;
        CategoryItemHolder(@NonNull View itemView) {
            super(itemView);
            mContentTv = itemView.findViewById(R.id.item_netfm_category_text);
        }
    }
}
