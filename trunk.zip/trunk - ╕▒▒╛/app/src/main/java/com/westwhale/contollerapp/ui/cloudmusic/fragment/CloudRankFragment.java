package com.westwhale.contollerapp.ui.cloudmusic.fragment;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.Toast;

import com.kingja.loadsir.callback.Callback;
import com.kingja.loadsir.callback.SuccessCallback;
import com.scwang.smartrefresh.layout.api.RefreshLayout;
import com.scwang.smartrefresh.layout.listener.OnLoadMoreListener;
import com.scwang.smartrefresh.layout.listener.OnRefreshListener;
import com.westwhale.contollerapp.R;
import com.westwhale.contollerapp.application.WApp;
import com.westwhale.contollerapp.dev.CmdActionLister;
import com.westwhale.contollerapp.dev.ICmdCallback;
import com.westwhale.contollerapp.dev.WRoom;
import com.westwhale.contollerapp.ui.main.MainRoomActivity;
import com.westwhale.contollerapp.ui.cloudmusic.adapter.CloudRankAdatper;
import com.westwhale.contollerapp.ui.base.fragment.TitleBaseFragment;
import com.westwhale.contollerapp.ui.loadsircallback.EmptyCallback;
import com.westwhale.contollerapp.ui.loadsircallback.LoadingCallback;
import com.westwhale.api.protocolapi.bean.cloudmusic.TopCate;

import java.util.List;

/**
 * Description:
 * Author: chenyaoli
 * Date: 2018-11-12
 * History:
 */
public class CloudRankFragment extends TitleBaseFragment implements CloudRankAdatper.CallBack{
    public static final int REQUEST_CODDE = 0;

    private FrameLayout mFrameLayout;
    private RecyclerView mDataRv;
    private Toolbar mToolBar;
    private CloudRankAdatper mCloudRankAdapter;
    private RefreshLayout mRefreshLayout;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        // 先显示加载动画，针对布局做一些初始化
        return inflater.inflate(R.layout.frag_netmusic_rank,container,false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        mFrameLayout = view.findViewById(R.id.netmusic_rank_frame);

        // 创建mLoadService
        mLoadService = mLoadSir.register(mFrameLayout, new Callback.OnReloadListener() {
            @Override
            public void onReload(View v) {
                showLoadCallBack(LoadingCallback.class);
                initData();
            }
        });

        initView(view);

        initListener();

        initData();
    }

    @Override
    public void onResume() {
        super.onResume();
    }

    private void initView(View view) {
        mToolBar = view.findViewById(R.id.netmusic_rank_toolbar);
        configToolBar(mToolBar,getString(R.string.cloudmusic_rank_title));

        mDataRv = view.findViewById(R.id.netmusic_rank_recylerview);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(mContext);
        mDataRv.setLayoutManager(linearLayoutManager);
        mCloudRankAdapter = new CloudRankAdatper(this);
        mDataRv.setAdapter(mCloudRankAdapter);
        mDataRv.setHasFixedSize(true);

        mRefreshLayout = view.findViewById(R.id.netmusic_rank_refresh);
        mRefreshLayout.setDisableContentWhenRefresh(true);
        mRefreshLayout.setEnableLoadMore(true);
    }

    private void initListener() {
        mDataRv.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(@NonNull RecyclerView recyclerView, int newState) {
                super.onScrollStateChanged(recyclerView, newState);
            }

            @Override
            public void onScrolled(@NonNull RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);
            }
        });

        mRefreshLayout.setOnRefreshListener(new OnRefreshListener() {
            @Override
            public void onRefresh(@NonNull RefreshLayout refreshLayout) {
                initData();
            }
        });

        mRefreshLayout.setOnLoadMoreListener(new OnLoadMoreListener() {
            @Override
            public void onLoadMore(@NonNull RefreshLayout refreshLayout) {
                mRefreshLayout.finishLoadMoreWithNoMoreData();
            }
        });
    }

    private void initData() {
        requestCloudResource();
    }

    public void updateDataList(List<TopCate> list){
        if (list != null) {

            mCloudRankAdapter.updateDataList(list);
            mCloudRankAdapter.notifyDataSetChanged();

            // 更新刷新等待状态
            mRefreshLayout.finishRefresh();

            showLoadCallBack(SuccessCallback.class);
        }else {
            // 更新刷新等待状态
            mRefreshLayout.finishRefresh();

            showLoadCallBack(EmptyCallback.class);
        }
    }

    @Override
    public void onRankItemClick(TopCate.CloudToplistSet rankItem) {
        // 进入指定的榜单列表
        CloudMusicListRankFragment musiclistFragment = new CloudMusicListRankFragment();
        musiclistFragment.updateTopListSet(rankItem);
        if (getActivity() instanceof MainRoomActivity) {
            ((MainRoomActivity) getActivity()).showFragment(musiclistFragment);
        }
    }

    public void requestCloudResource() {
        WRoom room = WApp.Instance.getDevManager().getSelectedRoom();
        if (room != null){
            WRoom.cmdGetTopList(new CmdActionLister<List<TopCate>>(this, new ICmdCallback<List<TopCate>>() {
                @Override
                public void onSuccess(List<TopCate> data) {
                    updateDataList(data);
                }

                @Override
                public void onFailed(int code, String msg) {
                    updateDataList(null);
                    Toast.makeText(getContext(),"GetTopList获取失败:"+code,Toast.LENGTH_SHORT).show();
                }
            }));
        }else{
            updateDataList(null);
        }
    }
}
