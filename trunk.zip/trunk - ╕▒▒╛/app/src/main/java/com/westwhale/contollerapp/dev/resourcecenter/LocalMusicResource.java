package com.westwhale.contollerapp.dev.resourcecenter;

import android.os.Handler;

import com.blankj.utilcode.util.ThreadUtils;
import com.westwhale.contollerapp.application.WApp;
import com.westwhale.contollerapp.dev.CmdActionLister;
import com.westwhale.api.protocolapi.BaApi;
import com.westwhale.api.protocolapi.bean.LocalDirectory;
import com.westwhale.api.protocolapi.bean.media.Media;
import com.westwhale.api.protocolapi.net.Response;

import java.util.List;

public class LocalMusicResource {
    // 获取指定目录信息
    public static void cmdGetLocalDirectory(String directoryMid, int beginIndex, int num, boolean ignoreEmpty,CmdActionLister<Response<LocalDirectory>> actionLister) {
        ThreadUtils.getIoPool().execute(new Runnable() {
            @Override
            public void run() {
                Response<LocalDirectory> res = null;
                try {
                    res = BaApi.getInstance().getLocalDirectory(directoryMid,beginIndex,num,ignoreEmpty);
                } catch (Exception e) {
                    e.printStackTrace();
                } finally {
                    postCmdResponseAll(res, actionLister);
                }
            }
        });
    }

    // 搜索本地歌曲
    public static void cmdSearchLocalMusic(String keywords, int beginIndex, int num,CmdActionLister<List<Media>> actionLister) {
        ThreadUtils.getIoPool().execute(new Runnable() {
            @Override
            public void run() {
                Response<List<Media>> res = null;
                try {
                    res = BaApi.getInstance().searchLocalMusic(keywords,beginIndex,num);
                } catch (Exception e) {
                    e.printStackTrace();
                } finally {
                    postCmdResponse(res, actionLister);
                }
            }
        });
    }


    /*********************************************************************************************************/
    private static Handler mHandler; // 消息处理，用于当某个cmd执行完成后，在主线程中调用接口回调

    //在泛型类中声明了一个泛型方法，使用泛型E，这种泛型E可以为任意类型。可以类型与T相同，也可以不同。
    //由于泛型方法在声明的时候会声明泛型<E>，因此即使在泛型类中并未声明泛型，编译器也能够正确识别泛型方法中识别的泛型。
    private static <E> void postCmdResponse(Response<E> result, CmdActionLister<E> actionLister) {
        if (null == mHandler) {
            mHandler = new Handler(WApp.Instance.getMainLooper());
        }

        mHandler.post(new Runnable() {
            @Override
            public void run() {
                if (!ThreadUtils.isMainThread() || (null == actionLister)) {
                    return;
                }

                String msg = "";
                E data = null;
                int resultCode = -1;
                if (result != null) {
                    resultCode = result.resultCode;
                    if (0 == resultCode) {
                        resultCode = 0;
                        data = result.bean;
                    }
                }

                actionLister.callback(resultCode, data, msg);
            }
        });
    }

    private static <E> void postCmdResponseAll(Response<E> result, CmdActionLister<Response<E>> actionLister) {
        if (null == mHandler) {
            mHandler = new Handler(WApp.Instance.getMainLooper());
        }

        mHandler.post(new Runnable() {
            @Override
            public void run() {
                if (!ThreadUtils.isMainThread() || (null == actionLister)) {
                    return;
                }

                String msg = "";
                Response<E> data = null;
                int resultCode = -1;
                if (result != null) {
                    resultCode = result.resultCode;
                    if (0 == resultCode) {
                        resultCode = 0;
                        data = result;
                    }
                }

                actionLister.callback(resultCode, data, msg);
            }
        });
    }
}
