package com.westwhale.contollerapp.ui.slider;


import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.TextView;

import com.blankj.utilcode.util.ToastUtils;
import com.westwhale.contollerapp.R;
import com.westwhale.contollerapp.application.WApp;
import com.westwhale.contollerapp.dev.CmdActionLister;
import com.westwhale.contollerapp.dev.ICmdCallback;
import com.westwhale.contollerapp.dev.WHost;
import com.westwhale.contollerapp.dev.WRoom;
import com.westwhale.contollerapp.ui.base.activity.BaseActivity;
import com.westwhale.contollerapp.ui.slider.adapter.DevNameAdapter;
import com.westwhale.api.protocolapi.bean.hostroom.Room;

/**
 * Description:
 * Author: chenyaoli
 * Date: 2018-12-20
 * History
 *
 */
public class DeviceNameActivity extends BaseActivity implements DevNameAdapter.CallBack {
    private Toolbar mToolbar;
    private EditText mHostEdit;
    private RecyclerView mDataRv;

    private DevNameAdapter mAdapter;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_slider_devicename);

        initView();
        initListener();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        // 隐藏时，把虚拟键盘隐藏
        InputMethodManager imm = (InputMethodManager)this.getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm != null) {
            imm.hideSoftInputFromWindow(mHostEdit.getWindowToken(), 0);
        }

        super.onBackPressed();
    }

    @Override
    protected void onResume() {
        super.onResume();

        initData();
    }

    @Override
    protected void onPause() {
        super.onPause();
    }

    @Override
    protected void onStart() {
        super.onStart();
    }

    @Override
    protected void onStop() {
        super.onStop();
    }

    @Override
    public void onRoomItemClick(Room room,String name) {
        setDevName(room,name);

        hideSoftInput();
    }

    private void initView() {
        mToolbar = findViewById(R.id.devname_toolbar);
        // 设置toolbar
        setSupportActionBar(mToolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        mHostEdit = findViewById(R.id.devname_host_edit);

        mDataRv = findViewById(R.id.devname_room_recyclerview);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        mDataRv.setLayoutManager(linearLayoutManager);
        mAdapter = new DevNameAdapter();
        mAdapter.setCallBack(this);
        mDataRv.setAdapter(mAdapter);
        mDataRv.setHasFixedSize(true);
        mDataRv.setNestedScrollingEnabled(false);
    }

    private void initListener() {
        mToolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        mHostEdit.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                // 完成
                if (actionId == EditorInfo.IME_ACTION_DONE){
                    String text = v.getText().toString();

                    setHostName(text);

                    mHostEdit.clearFocus();

                    hideSoftInput();

                    return true;
                }

                return false;
            }
        });
    }

    private void hideSoftInput(){
        InputMethodManager imm = (InputMethodManager)this.getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm != null) {
            imm.hideSoftInputFromWindow(mHostEdit.getWindowToken(), 0);
        }
    }

    private void setHostName(String name) {
        WHost host = WApp.Instance.getDevManager().getSelectedHost();
        if ((host != null) && (!host.getHostName().equals(name))){
            host.cmdSetSystemServerName(name, new CmdActionLister<Boolean>(DeviceNameActivity.this, new ICmdCallback<Boolean>() {
                @Override
                public void onSuccess(Boolean data) {

                }

                @Override
                public void onFailed(int code, String msg) {
                    // 若设置失败，则把原来的名字设置回去
                    String name = host.getHostName();
                    mHostEdit.setText(name);

                    ToastUtils.showShort("SetDevInfo failed... %d",code);
                }
            }));
        }
    }

    private void setDevName(Room room,String name) {
        if (null == room){
            return;
        }
        WRoom wroom = WApp.Instance.getDevManager().getSelectedRoom();
        WHost host = WApp.Instance.getDevManager().getSelectedHost();
        if ( (wroom != null) && (host != null) && (!room.roomName.equals(name))){
            wroom.cmdSetDevInfo(host.getHost().ipAddress,room.roomId, name, new CmdActionLister<Boolean>(DeviceNameActivity.this, new ICmdCallback<Boolean>() {
                @Override
                public void onSuccess(Boolean data) {
                    room.roomName = name;

                    if (mAdapter != null){
                        mAdapter.updateItem(room);
                    }
                }

                @Override
                public void onFailed(int code, String msg) {
                    // 若设置失败，则把原来的名字设置回去
                    if (mAdapter != null){
                        mAdapter.updateItem(room);
                    }

                    ToastUtils.showShort("SetDevInfo failed... %d",code);
                }
            }));
        }
    }

    private void initData() {
        WHost host = WApp.Instance.getDevManager().getSelectedHost();
        if (host != null){
            String hostname = host.getHostName();
            mHostEdit.setText(hostname);

            if (mAdapter != null){
                mAdapter.updateList(host.getHost().rooms);

                mAdapter.notifyDataSetChanged();
            }
        }
    }


}
