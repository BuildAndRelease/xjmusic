package com.westwhale.contollerapp.ui.favorite.songsheet.activity;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.LinearLayout;

import com.blankj.utilcode.util.ToastUtils;
import com.westwhale.contollerapp.R;
import com.westwhale.contollerapp.ui.base.activity.BaseActivity;
import com.westwhale.contollerapp.ui.favorite.songsheet.adapter.FavoriteMediaManagerMultiAdapter;
import com.westwhale.api.protocolapi.bean.PlayList;

import java.util.List;

/**
 * Description:
 * Author: chenyaoli
 * Date: 2018-12-12
 * History:
 */
public class FavoriteMediaMultiManagerActivity extends BaseActivity implements FavoriteMediaManagerMultiAdapter.CallBack {

    public static final String PLAYLIST_EDIT_STAT_0 = "0";
    public static final String PLAYLIST_EDIT_STAT_1 = "1";
    public static final String PLAYLIST_EDIT_STAT_2 = "2";

    private Toolbar mToolbar;
    private RecyclerView mDataRecyclerView;
    private LinearLayout mDeleteLayout;
    private FavoriteMediaManagerMultiAdapter mAdapter;
    private Menu mMenu;

    private static List<PlayList> mItemList;

    public static void setDataList(List<PlayList> list){
        mItemList = list;
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_favorite_media_manager_multi);

        initView();
        initListener();
        initData();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        mItemList = null;
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        super.onCreateOptionsMenu(menu);

        getMenuInflater().inflate(R.menu.menu_batch, menu);

        mMenu = menu;
        return true;
    }

    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {
        MenuItem item = menu.findItem(R.id.menu_select_all);

        return super.onPrepareOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.menu_select_all){
            if (mAdapter.getSelectedNum() == mAdapter.getItemCount()){
                // 全不选
                mAdapter.cancelAllItem();
            }else{
                // 全选
                mAdapter.selectAllItem();
            }
        }
        return super.onOptionsItemSelected(item);
    }

    private void initView() {
        mToolbar = findViewById(R.id.favorite_media_manager_toolbar);
        // 设置toolbar
        setSupportActionBar(mToolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        mDeleteLayout = findViewById(R.id.favorite_media_manager_delete);

        mDataRecyclerView = findViewById(R.id.favorite_media_manager_recyclerview);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        mDataRecyclerView.setLayoutManager(linearLayoutManager);
        mAdapter = new FavoriteMediaManagerMultiAdapter(this);
        mDataRecyclerView.setAdapter(mAdapter);
        mDataRecyclerView.setHasFixedSize(true);
        mDataRecyclerView.addItemDecoration(new DividerItemDecoration(this, DividerItemDecoration.VERTICAL));
    }

    private void initListener() {
        mToolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        mDeleteLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 批量删除已选择的歌单
                List<PlayList> itemList = null;
                if (mAdapter != null){
                    itemList = mAdapter.getSelectedList();
                    if (itemList == null || itemList.size() == 0){
                        ToastUtils.showShort("没有选择任何一项，请先选择");
                    }

//                    for (int i=0; i < itemList.size(); i++){
//                        PlayList playList = itemList.get(i);
//                        WRoom room = WApp.Instance.getDevManager().getSelectedRoom();
//                        if (room != null){
//                            room.cmdDelFavoritePlayList(playList.playListId,new CmdActionLister<>(FavoriteMediaManagerActivity.this, new ICmdCallback<Boolean>() {
//                                @Override
//                                public void onSuccess(Boolean data) {
//
//                                }
//
//                                @Override
//                                public void onFailed(int code, String msg) {
//                                    ToastUtils.showShort("DelFavoritePlayList failed %d...",code);
//                                }
//                            }));
//                        }
//                    }
                }
            }
        });
    }

    private void initData() {
        if (mItemList != null) {
            mAdapter.setDataList(mItemList);
            mAdapter.notifyDataSetChanged();
        }
    }

    @Override
    public void onItemClick(PlayList item, boolean selected) {

    }

    @Override
    public void onCheckedNumChanged(int selectednum) {
        String title = getString(R.string.toolbar_menu_all_select);
        if (selectednum == mAdapter.getItemCount()){
            title = getString(R.string.toolbar_menu_all_un_select);
        }
        updateMenuTitle(title);

        String toolbarTitle = getString(R.string.favorite_media_manager_title);
        if (selectednum > 0){
            toolbarTitle = toolbarTitle + "(" + selectednum +")";
        }
        mToolbar.setTitle(toolbarTitle);
    }

    private void updateMenuTitle(String title){
        if (mMenu != null) {
            MenuItem menuItem = mMenu.findItem(R.id.menu_select_all);
            if (menuItem != null) {
                menuItem.setTitle(title);
            }
        }
    }
}
