package com.westwhale.contollerapp.ui.main;

import android.content.Context;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.view.ViewPager;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;

import com.westwhale.contollerapp.R;
import com.westwhale.contollerapp.ui.base.fragment.BaseFragment;
import com.westwhale.contollerapp.ui.cloudmusic.fragment.NetMusicHomeFragment;
import com.westwhale.contollerapp.ui.cloudnetfm.fragment.CloudNetFmHomeFragment;
import com.westwhale.contollerapp.ui.cloudstory.fragment.CloudStoryHomeFragment;
import com.westwhale.contollerapp.ui.localmusic.fragment.LocalHomeFragment;
import com.westwhale.contollerapp.ui.main.adapter.CustomViewPagerAdapter;

import net.lucode.hackware.magicindicator.MagicIndicator;
import net.lucode.hackware.magicindicator.ViewPagerHelper;
import net.lucode.hackware.magicindicator.buildins.commonnavigator.CommonNavigator;
import net.lucode.hackware.magicindicator.buildins.commonnavigator.abs.CommonNavigatorAdapter;
import net.lucode.hackware.magicindicator.buildins.commonnavigator.abs.IPagerIndicator;
import net.lucode.hackware.magicindicator.buildins.commonnavigator.abs.IPagerTitleView;
import net.lucode.hackware.magicindicator.buildins.commonnavigator.titles.CommonPagerTitleView;

import java.lang.reflect.Field;
import java.util.Arrays;
import java.util.List;

public class MainRoomTabFragment extends BaseFragment {
    private ViewPager mViewPager;
    private ActionBar mActionBar;
    private Toolbar mToolBar;
    private ImageView mRightMenuIv;

    private static final Integer[] TITLE_PIC = new Integer[]{R.drawable.home_localmusic,R.drawable.home_cloudmusic,R.drawable.home_cloudstory,R.drawable.home_netradio};
    private List<Integer> mTitlePicList = Arrays.asList(TITLE_PIC);


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.frag_main_tab,container,false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        initView(view);
        initListener();

        initData();
//
//
//        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
//            Window window = getActivity().getWindow();
//            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
//            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
//                try {
//                    Class decorViewClazz = Class.forName("com.android.internal.policy.DecorView");
//                    Field field = decorViewClazz.getDeclaredField("mSemiTransparentStatusBarColor");
//                    field.setAccessible(true);
//                    field.setInt(window.getDecorView(), Color.TRANSPARENT);  //改为透明
//                } catch (ClassNotFoundException e) {
//                    e.printStackTrace();
//                } catch (IllegalAccessException e) {
//                    e.printStackTrace();
//                } catch (NoSuchFieldException e) {
//                    e.printStackTrace();
//                }
//            }
//            window.setStatusBarColor(getActivity().getResources().getColor(R.color.colorPrimary));
//        }
    }

    private void initData() {
        mViewPager.setCurrentItem(1);
    }


    private void initView(@NonNull View view) {
        try{
            mToolBar = view.findViewById(R.id.frag_main_toolbar);
            if (getActivity() != null) {
                ((AppCompatActivity) getActivity()).setSupportActionBar(mToolBar);
                mActionBar = ((AppCompatActivity) getActivity()).getSupportActionBar();
                if (mActionBar != null) {
                    mActionBar.setDisplayHomeAsUpEnabled(true);
                    mActionBar.setTitle("");
                }
            }

            mRightMenuIv = view.findViewById(R.id.frag_main_menu);

            mViewPager = view.findViewById(R.id.frag_main_viewpager);
            CustomViewPagerAdapter customViewPagerAdapter = new CustomViewPagerAdapter(getChildFragmentManager());
            //待添加需要添加的Fragment
            customViewPagerAdapter.addFragment( new LocalHomeFragment());
            customViewPagerAdapter.addFragment(new NetMusicHomeFragment());
            customViewPagerAdapter.addFragment(new CloudStoryHomeFragment());
            customViewPagerAdapter.addFragment(new CloudNetFmHomeFragment());

            mViewPager.setAdapter(customViewPagerAdapter);
            mViewPager.setOffscreenPageLimit(customViewPagerAdapter.getCount());


            // 配置 magicIndicator
            MagicIndicator magicIndicator = view.findViewById(R.id.frag_main_magicindicator);
            CommonNavigator commonNavigator = new CommonNavigator(mContext);
            commonNavigator.setAdjustMode(true);
            commonNavigator.setAdapter(new CommonNavigatorAdapter() {
                @Override
                public int getCount() {
                    return mTitlePicList.size();
                }

                @Override
                public IPagerTitleView getTitleView(Context context, final int index) {
                    CommonPagerTitleView commonPagerTitleView = new CommonPagerTitleView(context);

                    // load custom layout
                    View customLayout = LayoutInflater.from(context).inflate(R.layout.item_mainroom_magicindex, null);
                    final ImageView titleImg = customLayout.findViewById(R.id.item_title_pic);
                    titleImg.setImageResource(mTitlePicList.get(index));
                    commonPagerTitleView.setContentView(customLayout);

                    commonPagerTitleView.setOnPagerTitleChangeListener(new CommonPagerTitleView.OnPagerTitleChangeListener() {

                        @Override
                        public void onSelected(int index, int totalCount) {
                            titleImg.setColorFilter(Color.WHITE);
                        }

                        @Override
                        public void onDeselected(int index, int totalCount) {
                            titleImg.setColorFilter(Color.GRAY);
                        }

                        @Override
                        public void onLeave(int index, int totalCount, float leavePercent, boolean leftToRight) {
                            titleImg.setScaleX(1.1f + (0.9f - 1.1f) * leavePercent);
                            titleImg.setScaleY(1.1f + (0.9f - 1.1f) * leavePercent);
                        }

                        @Override
                        public void onEnter(int index, int totalCount, float enterPercent, boolean leftToRight) {
                            titleImg.setScaleX(0.9f + (1.1f - 0.9f) * enterPercent);
                            titleImg.setScaleY(0.9f + (1.1f - 0.9f) * enterPercent);
                        }
                    });

                    commonPagerTitleView.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            mViewPager.setCurrentItem(index);
                        }
                    });

                    return commonPagerTitleView;
                }

                @Override
                public IPagerIndicator getIndicator(Context context) {
                    return null;
                }
            });
            magicIndicator.setNavigator(commonNavigator);
            ViewPagerHelper.bind(magicIndicator, mViewPager);

        }catch (NullPointerException e){
            e.printStackTrace();
        }

    }

    private void initListener() {
        mToolBar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (getActivity() != null) {
                    getActivity().onBackPressed();
                }
            }
        });


        mRightMenuIv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 弹出菜单栏
                if (getActivity() instanceof  MainRoomActivity) {
                    ((MainRoomActivity) getActivity()).showDrawer();
                }
            }
        });
    }

}
