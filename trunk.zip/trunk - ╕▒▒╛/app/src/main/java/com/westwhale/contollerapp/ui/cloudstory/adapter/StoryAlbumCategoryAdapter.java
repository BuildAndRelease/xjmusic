package com.westwhale.contollerapp.ui.cloudstory.adapter;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.westwhale.contollerapp.R;
import com.westwhale.api.protocolapi.bean.telling.CatrgroyGroup;

import java.util.List;

/**
 * Description:
 * Author: chenyaoli
 * Date: 2018-12-01
 * History:
 */
public class StoryAlbumCategoryAdapter extends RecyclerView.Adapter {
    private List<CatrgroyGroup.TellingCatrgroy> mItemList;
    private CatrgroyGroup.TellingCatrgroy mSelectedItem;

    private CallBack mCallback;

    public interface CallBack{
        void onCategoryItemClick(CatrgroyGroup.TellingCatrgroy item);
    }

    public void updateDataList(List<CatrgroyGroup.TellingCatrgroy> itemList){
        if (mItemList != null){
            mItemList.clear();
            notifyDataSetChanged();
        }
        this.mItemList = itemList;
    }

    public void setSelectedItem(CatrgroyGroup.TellingCatrgroy item){
        mSelectedItem = item;
    }

    public StoryAlbumCategoryAdapter(CallBack callBack){
        this.mItemList = null;
        this.mCallback = callBack;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_netmusic_category_item, viewGroup, false);
        return new CategoryItemHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder viewHolder, int i) {
        if (viewHolder instanceof CategoryItemHolder){
            final CatrgroyGroup.TellingCatrgroy item = mItemList.get(i);
            CategoryItemHolder itemHolder = (CategoryItemHolder)viewHolder;

            if (item.equals(mSelectedItem)){
                itemHolder.mContentTv.setBackgroundColor(itemHolder.itemView.getResources().getColor(R.color.cloud_singer_category_select));
            }else{
                itemHolder.mContentTv.setBackgroundColor(itemHolder.itemView.getResources().getColor(R.color.cloud_singer_category));
            }

//            String content = item.categoryName;
            itemHolder.mContentTv.setText(item.categoryName);


            itemHolder.mContentTv.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    // 先把已经变色的更改颜色，然后再设置当前选项的颜色
                    if ( (mSelectedItem != null) && !mSelectedItem.equals(item) ){
                        if (mItemList.contains(mSelectedItem)){
                            int pos = mItemList.indexOf(mSelectedItem);
                            notifyItemChanged(pos);
                        }
                    }
                    mSelectedItem = item;
                    itemHolder.mContentTv.setBackgroundColor(itemHolder.itemView.getResources().getColor(R.color.cloud_singer_category_select));

                    if (mCallback != null){
                        mCallback.onCategoryItemClick(item);
                    }
                }
            });
        }
    }

    @Override
    public int getItemCount() {
        return (mItemList == null) ? 0 : mItemList.size();
    }

    private class CategoryItemHolder extends RecyclerView.ViewHolder{
        TextView mContentTv;
        CategoryItemHolder(@NonNull View itemView) {
            super(itemView);
            mContentTv = itemView.findViewById(R.id.item_cloud_category_text);
        }
    }

}
