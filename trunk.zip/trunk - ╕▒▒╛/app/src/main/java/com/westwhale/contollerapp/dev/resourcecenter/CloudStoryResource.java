package com.westwhale.contollerapp.dev.resourcecenter;

import android.os.Handler;

import com.blankj.utilcode.util.ThreadUtils;
import com.westwhale.contollerapp.application.WApp;
import com.westwhale.contollerapp.dev.CmdActionLister;
import com.westwhale.api.protocolapi.BaApi;
import com.westwhale.api.protocolapi.bean.albumSet.StoryTelling;
import com.westwhale.api.protocolapi.bean.telling.Anchor;
import com.westwhale.api.protocolapi.bean.telling.AnchorCategroy;
import com.westwhale.api.protocolapi.bean.telling.CatrgroyGroup;
import com.westwhale.api.protocolapi.bean.telling.RankItem;
import com.westwhale.api.protocolapi.bean.media.Section;
import com.westwhale.api.protocolapi.net.Response;

import java.util.List;

public class CloudStoryResource {
    // 获取语言节目的推荐
    public static void cmdGetStorytellingPush(String pushType,int perpage,int pagenum, CmdActionLister<List<StoryTelling>> actionLister){
        ThreadUtils.getIoPool().execute(new Runnable() {
            @Override
            public void run() {
                Response<List<StoryTelling>> response = null;
                try {
                    response = BaApi.getInstance().getStorytellingPush(pushType,perpage,pagenum);
                } catch (Exception e) {
                    e.printStackTrace();
                }finally {
                    postCmdResponse(response,actionLister);
                }
            }
        });
    }

    // 获取语言节目分类
    public static void cmdGetStorytellingCategory(CmdActionLister<List<CatrgroyGroup>> actionLister){
        ThreadUtils.getIoPool().execute(new Runnable() {
            @Override
            public void run() {
                Response<List<CatrgroyGroup>> response = null;
                try {
                    response = BaApi.getInstance().getStorytellingCategory();
                } catch (Exception e) {
                    e.printStackTrace();
                }finally {
                    postCmdResponse(response,actionLister);
                }
            }
        });
    }

    // 获取专辑列表
    public static void cmdGetStorytelling(String categoryId, int perpage, int pagenum, CmdActionLister<List<StoryTelling>> actionLister){
        ThreadUtils.getIoPool().execute(new Runnable() {
            @Override
            public void run() {
                Response<List<StoryTelling>> response = null;
                try {
                    response = BaApi.getInstance().getStorytelling(categoryId,perpage,pagenum);
                } catch (Exception e) {
                    e.printStackTrace();
                }finally {
                    postCmdResponse(response,actionLister);
                }
            }
        });
    }

    // 获取指定媒体的播放列表
    public static void cmdGetStorytellingPlaylist(int mediaId, int perpage, int pagenum, CmdActionLister<List<Section>> actionLister){
        ThreadUtils.getIoPool().execute(new Runnable() {
            @Override
            public void run() {
                Response<List<Section>> response = null;
                try {
                    response = BaApi.getInstance().getStorytellingPlaylist(mediaId,perpage,pagenum);
                } catch (Exception e) {
                    e.printStackTrace();
                }finally {
                    postCmdResponse(response,actionLister);
                }
            }
        });
    }

    // 获取榜单列表
    public static void cmdGetStoryTellingRankingList(CmdActionLister<List<RankItem>> actionLister){
        ThreadUtils.getIoPool().execute(new Runnable() {
            @Override
            public void run() {
                Response<List<RankItem>> response = null;
                try {
                    response = BaApi.getInstance().getStoryTellingRankingList();
                } catch (Exception e) {
                    e.printStackTrace();
                }finally {
                    postCmdResponse(response,actionLister);
                }
            }
        });
    }

    // 获取榜单的专辑列表
    public static void cmdGetStoryTellingRankingListAlbum(int rankingListId,int perpage,int pagenum, CmdActionLister<List<StoryTelling>> actionLister){
        ThreadUtils.getIoPool().execute(new Runnable() {
            @Override
            public void run() {
                Response<List<StoryTelling>> response = null;
                try {
                    response = BaApi.getInstance().getStoryTellingRankingListAlbum(rankingListId,pagenum,perpage);
                } catch (Exception e) {
                    e.printStackTrace();
                }finally {
                    postCmdResponse(response,actionLister);
                }
            }
        });
    }

    // 获取主播分类
    public static void cmdGetStoryTellingAnchorCategory(CmdActionLister<List<AnchorCategroy>> actionLister){
        ThreadUtils.getIoPool().execute(new Runnable() {
            @Override
            public void run() {
                Response<List<AnchorCategroy>> response = null;
                try {
                    response = BaApi.getInstance().getStoryTellingAnchorCategory();
                } catch (Exception e) {
                    e.printStackTrace();
                }finally {
                    postCmdResponse(response,actionLister);
                }
            }
        });
    }

    // 获取主播列表
    public static void cmdGetStoryTellingAnchor(int categoryId, int pageSize, int pageNum, CmdActionLister<List<Anchor>> actionLister){
        ThreadUtils.getIoPool().execute(new Runnable() {
            @Override
            public void run() {
                Response<List<Anchor>> response = null;
                try {
                    response = BaApi.getInstance().getStoryTellingAnchor(categoryId,pageSize,pageNum);
                } catch (Exception e) {
                    e.printStackTrace();
                }finally {
                    postCmdResponse(response,actionLister);
                }
            }
        });
    }

    // 获取主播列表（ByNormal）
    public static void cmdGetStoryTellingAnchorByNormal(String categoryName, String recommendType, int pageSize, int pageNum,CmdActionLister<List<Anchor>> actionLister){
        ThreadUtils.getIoPool().execute(new Runnable() {
            @Override
            public void run() {
                Response<List<Anchor>> response = null;
                try {
                    response = BaApi.getInstance().getStoryTellingAnchorByNormal(categoryName,recommendType,pageSize,pageNum);
                } catch (Exception e) {
                    e.printStackTrace();
                }finally {
                    postCmdResponse(response,actionLister);
                }
            }
        });
    }

    // 获取主播的专辑列表
    public static void cmdGetStoryTellingAnchorAlbum(int anchorId,int perpage,int pagenum, CmdActionLister<List<StoryTelling>> actionLister){
        ThreadUtils.getIoPool().execute(new Runnable() {
            @Override
            public void run() {
                Response<List<StoryTelling>> response = null;
                try {
                    response = BaApi.getInstance().getStoryTellingAnchorAlbum(anchorId,perpage,pagenum);
                } catch (Exception e) {
                    e.printStackTrace();
                }finally {
                    postCmdResponse(response,actionLister);
                }
            }
        });
    }

    // 搜索语言节目
    public static void cmdSearchStorytelling(String searchText, int perpage, int pagenum, CmdActionLister<List<StoryTelling>> actionLister){
        ThreadUtils.getIoPool().execute(new Runnable() {
            @Override
            public void run() {
                Response<List<StoryTelling>> response = null;
                try {
                    response = BaApi.getInstance().searchStorytelling(searchText,perpage,pagenum);
                } catch (Exception e) {
                    e.printStackTrace();
                }finally {
                    postCmdResponse(response,actionLister);
                }
            }
        });
    }



    /*********************************************************************************************************/
    private static Handler mHandler; // 消息处理，用于当某个cmd执行完成后，在主线程中调用接口回调

    //在泛型类中声明了一个泛型方法，使用泛型E，这种泛型E可以为任意类型。可以类型与T相同，也可以不同。
    //由于泛型方法在声明的时候会声明泛型<E>，因此即使在泛型类中并未声明泛型，编译器也能够正确识别泛型方法中识别的泛型。
    private static <E> void postCmdResponse(Response<E> result, CmdActionLister<E> actionLister) {
        if (null == mHandler) {
            mHandler = new Handler(WApp.Instance.getMainLooper());
        }

        mHandler.post(new Runnable() {
            @Override
            public void run() {
                if (!ThreadUtils.isMainThread() || (null == actionLister)) {
                    return;
                }

                String msg = "";
                E data = null;
                int resultCode = -1;
                if (result != null) {
                    resultCode = result.resultCode;
                    // 针对云音乐的某些resultCode 为-2的特殊情况
                    if ((0 == resultCode) || (-2 == resultCode)) {
                        resultCode = 0;
                        data = result.bean;
                    }
                }

                actionLister.callback(resultCode, data, msg);
            }
        });
    }

    private static <E> void postCmdResponseAll(Response<E> result, CmdActionLister<Response<E>> actionLister) {
        if (null == mHandler) {
            mHandler = new Handler(WApp.Instance.getMainLooper());
        }

        mHandler.post(new Runnable() {
            @Override
            public void run() {
                if (!ThreadUtils.isMainThread() || (null == actionLister)) {
                    return;
                }

                String msg = "";
                Response<E> data = null;
                int resultCode = -1;
                if (result != null) {
                    resultCode = result.resultCode;
                    // 针对云音乐的某些resultCode 为-2的特殊情况
                    if ((0 == resultCode) || (-2 == resultCode)) {
                        resultCode = 0;
                        data = result;
                    }
                }

                actionLister.callback(resultCode, data, msg);
            }
        });
    }

}
