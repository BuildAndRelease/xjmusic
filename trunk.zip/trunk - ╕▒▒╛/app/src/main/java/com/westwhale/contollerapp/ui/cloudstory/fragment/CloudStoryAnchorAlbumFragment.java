package com.westwhale.contollerapp.ui.cloudstory.fragment;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.View;
import android.widget.Toast;

import com.kingja.loadsir.callback.SuccessCallback;
import com.westwhale.contollerapp.R;
import com.westwhale.contollerapp.application.WApp;
import com.westwhale.contollerapp.dev.CmdActionLister;
import com.westwhale.contollerapp.dev.ICmdCallback;
import com.westwhale.contollerapp.dev.WRoom;
import com.westwhale.api.protocolapi.bean.albumSet.StoryTelling;
import com.westwhale.api.protocolapi.bean.telling.Anchor;

import java.util.List;


/**
 * Description:
 * Author: chenyaoli
 * Date: 2019-04-06
 * History:
 */
public class CloudStoryAnchorAlbumFragment extends CloudStoryAlbumBaseFragment {
    private static final String TAG = "StoryAnchorAlbum";

    private int mCurPageNo = 1; //记录当前的页面数
    private int mPerPage = 50;
    private boolean mHasMoreData = true; // 记录是否还有更多数据

    private Anchor mAnchorItem;

    public void setAnchorItem (@NonNull Anchor item){
        mAnchorItem = item;
    }


    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        //初始化 toolbar
        String title =  (mAnchorItem != null) ? mAnchorItem.nickname : getString(R.string.story_album_defaulttitle);
        configToolBar(mToolBar,title);

        mCategoryLayout.setVisibility(View.GONE);
    }

    @Override
    protected void initData() {
        mCurPageNo = 1;
        mHasMoreData = true;

        // 每次先清空原有数据
        if (mAdapter != null){
            mAdapter.clearDataList();
        }

        requestCloudResource();
    }

    @Override
    protected boolean hasMoreData() {
        return mHasMoreData;
    }

    @Override
    protected void loadMoreData() {
        mCurPageNo++;
        requestCloudResource();
    }

    @Override
    protected  void updateDataList(List<StoryTelling> dataList){
        if (dataList != null){
            // 若无法获取到数据，则认为已经到底
            int size = dataList.size();

            if (mCurPageNo == 0) {
                mAdapter.clearDataList();
            }

            if (size != 0){
                int startIndex = mAdapter.getItemCount();
                mAdapter.addToDataList(dataList);
                mAdapter.notifyItemRangeInserted(startIndex,size);
            }else{
                mHasMoreData = false;
            }

            // 更新刷新等待状态
            mRefreshLayout.finishRefresh();
            mRefreshLayout.finishLoadMore();

            showLoadCallBack(SuccessCallback.class);
        }else{
            // 当获取数据失败时，则认为无数据了
            mHasMoreData = false;

            // 更新刷新等待状态
            mRefreshLayout.finishRefresh();
            mRefreshLayout.finishLoadMore();

            showLoadCallBack(SuccessCallback.class);
        }
    }

    @Override
    protected void requestCloudResource(){
        WRoom room = WApp.Instance.getDevManager().getSelectedRoom();
        if (room != null){
            int anchorId = (mAnchorItem != null) ? mAnchorItem.uid : 0;
            WRoom.cmdGetStoryTellingAnchorAlbum(anchorId,mPerPage,mCurPageNo, new CmdActionLister<List<StoryTelling>>(this, new ICmdCallback<List<StoryTelling>>() {
                @Override
                public void onSuccess(List<StoryTelling> data) {
                    updateDataList(data);
                }

                @Override
                public void onFailed(int code, String msg) {
                    updateDataList(null);
                    Toast.makeText(getContext(),"GetStoryTellingAnchorAlbum 获取失败:"+code,Toast.LENGTH_SHORT).show();
                }
            }));
        }else{
            updateDataList(null);
        }
    }


}
