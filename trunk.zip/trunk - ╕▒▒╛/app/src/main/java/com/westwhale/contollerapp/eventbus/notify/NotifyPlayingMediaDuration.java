package com.westwhale.contollerapp.eventbus.notify;

public class NotifyPlayingMediaDuration {
    private int mDuration;
    public NotifyPlayingMediaDuration(int duration){
        mDuration = duration;
    }

    public int getDuration(){
        return mDuration;
    }

}
