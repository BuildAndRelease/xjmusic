package com.westwhale.contollerapp.ui.favorite.songsheet.activity;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.View;

import com.blankj.utilcode.util.ToastUtils;
import com.westwhale.contollerapp.R;
import com.westwhale.contollerapp.application.WApp;
import com.westwhale.contollerapp.dev.CmdActionLister;
import com.westwhale.contollerapp.dev.ICmdCallback;
import com.westwhale.contollerapp.dev.WRoom;
import com.westwhale.contollerapp.ui.base.activity.BaseActivity;
import com.westwhale.contollerapp.ui.favorite.songsheet.adapter.FavoriteMediaManagerAdapter;
import com.westwhale.api.protocolapi.bean.PlayList;

import java.util.List;

/**
 * Description:
 * Author: chenyaoli
 * Date: 2018-12-12
 * History:
 */
public class FavoriteMediaManagerActivity extends BaseActivity implements FavoriteMediaManagerAdapter.CallBack {

    public static final int REQUEST_CODE_MANAGER = 3;
    public static final String PLAYLIST_EDIT_STAT_0 = "0";
    public static final String PLAYLIST_EDIT_STAT_1 = "1";
    public static final String PLAYLIST_EDIT_STAT_2 = "2";

    private Toolbar mToolbar;
    private RecyclerView mDataRecyclerView;
    private FavoriteMediaManagerAdapter mAdapter;

    private static List<PlayList> mItemList;

    public static void setDataList(List<PlayList> list){
        mItemList = list;
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_favorite_media_manager);

        initView();
        initListener();
        initData();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        mItemList = null;
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }

    private void initView() {
        mToolbar = findViewById(R.id.favorite_media_manager_toolbar);
        // 设置toolbar
        setSupportActionBar(mToolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        mDataRecyclerView = findViewById(R.id.favorite_media_manager_recyclerview);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        mDataRecyclerView.setLayoutManager(linearLayoutManager);
        mAdapter = new FavoriteMediaManagerAdapter(this);
        mDataRecyclerView.setAdapter(mAdapter);
        mDataRecyclerView.setHasFixedSize(true);
        mDataRecyclerView.addItemDecoration(new DividerItemDecoration(this, DividerItemDecoration.VERTICAL));
    }

    private void initListener() {
        mToolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
    }

    private void initData() {
        if (mItemList != null) {
            mAdapter.setDataList(mItemList);
            mAdapter.notifyDataSetChanged();
        }
    }

    @Override
    public void onItemDeleteClick(PlayList item) {
        if (item != null){
            WRoom room = WApp.Instance.getDevManager().getSelectedRoom();
            if (room != null){
                room.cmdDelFavoritePlayList(item.playListId, new CmdActionLister<Boolean>(FavoriteMediaManagerActivity.this, new ICmdCallback<Boolean>() {
                    @Override
                    public void onSuccess(Boolean data) {
                        if (data){
                            mItemList.remove(item);
                            mAdapter.notifyDataSetChanged();
                            ToastUtils.showShort("删除歌单成功");
                        }else{
                            ToastUtils.showShort("删除歌单失败");
                        }
                    }

                    @Override
                    public void onFailed(int code, String msg) {
                        ToastUtils.showShort("删除歌单失败:%d",code);
                    }
                }));
            }
        }
    }
}
