package com.westwhale.contollerapp.dev;

public class API_DEFINE {

    public static final String CMD_DIRECTION_RESPONE = "response";

    public static final String CMD_PLAYSTAT_PLAY = "playing";
    public static final String CMD_PLAYSTAT_PAUSE = "pause";

    public static final String CMD_PLAYMODE_NORMAL = "normal";
    public static final String CMD_PLAYMODE_CIRCLE = "circle";
    public static final String CMD_PLAYMODE_SHUFFLE = "shuffle";
    public static final String CMD_PLAYMODE_SINGLE = "single";

    public static final String CMD_MUTESTAT_MUTE = "mute";
    public static final String CMD_MUTESTAT_NORMAL = "normal";

    public static final String CMD_KEY_DEVSTAT = "mDevStat";
    public static final String CMD_DEVSTAT_OPEN = "open";
    public static final String CMD_DEVSTAT_CLOSE = "close";


    public static final String CMD_AUDIOSRC_CLOUDMUSIC = "cloudMusic";
    public static final String CMD_AUDIOSRC_CLOUDSTORY = "cloudStoryTelling";
    public static final String CMD_AUDIOSRC_CLOUDNETFM = "cloudNetFm";
    public static final String CMD_AUDIOSRC_LOCALMUSIC = "localMusic";
    public static final String CMD_AUDIOSRC_LOCALAUX = "localAux";
    public static final String CMD_AUDIOSRC_BT = "bt";



}
