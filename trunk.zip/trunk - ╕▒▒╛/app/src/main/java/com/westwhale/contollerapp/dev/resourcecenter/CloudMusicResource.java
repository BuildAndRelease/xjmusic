package com.westwhale.contollerapp.dev.resourcecenter;

import android.os.Handler;

import com.blankj.utilcode.util.ThreadUtils;
import com.westwhale.contollerapp.application.WApp;
import com.westwhale.contollerapp.dev.CmdActionLister;
import com.westwhale.api.protocolapi.BaApi;
import com.westwhale.api.protocolapi.bean.media.CloudMusic;
import com.westwhale.api.protocolapi.bean.albumSet.CloudAlbumSet;
import com.westwhale.api.protocolapi.bean.albumSet.CloudDissSet;
import com.westwhale.api.protocolapi.bean.albumSet.CloudSingerSet;
import com.westwhale.api.protocolapi.bean.cloudmusic.CloudMusicRecommed;
import com.westwhale.api.protocolapi.bean.cloudmusic.CloudRadioGroup;
import com.westwhale.api.protocolapi.bean.cloudmusic.DissCategoryGroup;
import com.westwhale.api.protocolapi.bean.cloudmusic.TopCate;
import com.westwhale.api.protocolapi.net.Response;

import java.util.List;

/**
 * 云音乐获取的相关API
 *
 */
public class CloudMusicResource {
    // 获取专辑
    public static void cmdGetAlbum(int time, int area, int type, int index, int sort, int perpage, int pageNo,CmdActionLister<List<CloudAlbumSet>> actionLister) {
        ThreadUtils.getIoPool().execute(new Runnable() {
            @Override
            public void run() {
                Response<List<CloudAlbumSet>> res = null;
                try {
                    res = BaApi.getInstance().getAlbum(time,area,type,index,sort,perpage,pageNo);
                } catch (Exception e) {
                    e.printStackTrace();
                } finally {
                    postCmdResponse(res, actionLister);
                }
            }
        });
    }

    // 获取专辑下的歌曲列表
    public static void cmdGetAlbumSong(String albumMid,CmdActionLister<List<CloudMusic>> actionLister) {
        ThreadUtils.getIoPool().execute(new Runnable() {
            @Override
            public void run() {
                Response<List<CloudMusic>> res = null;
                try {
                    res = BaApi.getInstance().getAlbumSong(albumMid);
                } catch (Exception e) {
                    e.printStackTrace();
                } finally {
                    postCmdResponse(res, actionLister);
                }
            }
        });
    }

    // 获取歌单的所有分类
    public static void cmdGetDissCategory(CmdActionLister<List<DissCategoryGroup>> actionLister) {
        ThreadUtils.getIoPool().execute(new Runnable() {
            @Override
            public void run() {
                Response<List<DissCategoryGroup>> res = null;
                try {
                    res = BaApi.getInstance().getDissCategory();
                } catch (Exception e) {
                    e.printStackTrace();
                } finally {
                    postCmdResponse(res, actionLister);
                }
            }
        });
    }



    // 获取歌单
    public static void cmdGetDiss(String categoryId, int sort, int from, int to,CmdActionLister<List<CloudDissSet>> actionLister) {
        ThreadUtils.getIoPool().execute(new Runnable() {
            @Override
            public void run() {
                Response<List<CloudDissSet>> res = null;
                try {
                    res = BaApi.getInstance().getDiss(categoryId,sort,from,to);
                } catch (Exception e) {
                    e.printStackTrace();
                } finally {
                    postCmdResponse(res, actionLister);
                }
            }
        });
    }

    // 获取歌单下的歌曲列表
    public static void cmdGetDissSong(String dissId,CmdActionLister<List<CloudMusic>> actionLister) {
        ThreadUtils.getIoPool().execute(new Runnable() {
            @Override
            public void run() {
                Response<List<CloudMusic>> res = null;
                try {
                    res = BaApi.getInstance().getDissSong(dissId);
                } catch (Exception e) {
                    e.printStackTrace();
                } finally {
                    postCmdResponse(res, actionLister);
                }
            }
        });
    }

    // 获取榜单
    public static void cmdGetTopList(CmdActionLister<List<TopCate>> actionLister) {
        ThreadUtils.getIoPool().execute(new Runnable() {
            @Override
            public void run() {
                Response<List<TopCate>> res = null;
                try {
                    res = BaApi.getInstance().getTopList();
                } catch (Exception e) {
                    e.printStackTrace();
                } finally {
                    postCmdResponse(res, actionLister);
                }
            }
        });
    }

    // 获取榜单下的歌曲列表
    public static void cmdGetTopListSong(String topListId, String topListDate,CmdActionLister<List<CloudMusic>> actionLister) {
        ThreadUtils.getIoPool().execute(new Runnable() {
            @Override
            public void run() {
                Response<List<CloudMusic>> res = null;
                try {
                    res = BaApi.getInstance().getTopListSong(topListId, topListDate);
                } catch (Exception e) {
                    e.printStackTrace();
                } finally {
                    postCmdResponse(res, actionLister);
                }
            }
        });
    }

    // 获取电台
    public static void cmdGetRadio(CmdActionLister<List<CloudRadioGroup>> actionLister) {
        ThreadUtils.getIoPool().execute(new Runnable() {
            @Override
            public void run() {
                Response<List<CloudRadioGroup>> res = null;
                try {
                    res = BaApi.getInstance().getRadio();
                } catch (Exception e) {
                    e.printStackTrace();
                } finally {
                    postCmdResponse(res, actionLister);
                }
            }
        });
    }

    // 获取歌手
    public static void cmdGetSingerss(String category, String index, int pageNo,CmdActionLister<List<CloudSingerSet>> actionLister) {
        ThreadUtils.getIoPool().execute(new Runnable() {
            @Override
            public void run() {
                Response<List<CloudSingerSet>> res = null;
                try {
                    res = BaApi.getInstance().getSingers(category,index,pageNo);
                } catch (Exception e) {
                    e.printStackTrace();
                } finally {
                    postCmdResponse(res, actionLister);
                }
            }
        });
    }

    // 获取歌手下的歌曲列表
    public static void cmdGetSingerSong(String singerMid, String order, int begin, int size,CmdActionLister<List<CloudMusic>> actionLister) {
        ThreadUtils.getIoPool().execute(new Runnable() {
            @Override
            public void run() {
                Response<List<CloudMusic>> res = null;
                try {
                    res = BaApi.getInstance().getSingerSong(singerMid,order,begin,size);
                } catch (Exception e) {
                    e.printStackTrace();
                } finally {
                    postCmdResponse(res, actionLister);
                }
            }
        });
    }

    // 获取推荐专辑
    public static void cmdGetRecommend(CmdActionLister<CloudMusicRecommed> actionLister) {
        ThreadUtils.getIoPool().execute(new Runnable() {
            @Override
            public void run() {
                Response<CloudMusicRecommed> res = null;
                try {
                    res = BaApi.getInstance().getRecommend();
                } catch (Exception e) {
                    e.printStackTrace();
                } finally {
                    postCmdResponse(res, actionLister);
                }
            }
        });
    }

    // 获取新歌速递
    public static void cmdGetNewSong(String area,CmdActionLister<List<CloudMusic>> actionLister) {
        ThreadUtils.getIoPool().execute(new Runnable() {
            @Override
            public void run() {
                Response<List<CloudMusic>> res = null;
                try {
                    res = BaApi.getInstance().getNewSong(area);
                } catch (Exception e) {
                    e.printStackTrace();
                } finally {
                    postCmdResponse(res, actionLister);
                }
            }
        });
    }


    // 搜索歌曲
    public static void cmdSearchSong(String searchText, int pageNo,CmdActionLister<List<CloudMusic>> actionLister) {
        ThreadUtils.getIoPool().execute(new Runnable() {
            @Override
            public void run() {
                Response<List<CloudMusic>> res = null;
                try {
                    res = BaApi.getInstance().searchSong(searchText, pageNo);
                } catch (Exception e) {
                    e.printStackTrace();
                } finally {
                    postCmdResponse(res, actionLister);
                }
            }
        });
    }

    // 获取歌词
    public static void cmdGetSongLyric(String mid,CmdActionLister<String> actionLister) {
        ThreadUtils.getIoPool().execute(new Runnable() {
            @Override
            public void run() {
                Response<String> res = null;
                try {
                    res = BaApi.getInstance().getSongLyric(mid);
                } catch (Exception e) {
                    e.printStackTrace();
                } finally {
                    postCmdResponse(res, actionLister);
                }
            }
        });
    }


    /*********************************************************************************************************/
    private static Handler mHandler; // 消息处理，用于当某个cmd执行完成后，在主线程中调用接口回调

    //在泛型类中声明了一个泛型方法，使用泛型E，这种泛型E可以为任意类型。可以类型与T相同，也可以不同。
    //由于泛型方法在声明的时候会声明泛型<E>，因此即使在泛型类中并未声明泛型，编译器也能够正确识别泛型方法中识别的泛型。
    private static <E> void postCmdResponse(Response<E> result, CmdActionLister<E> actionLister) {
        if (null == mHandler) {
            mHandler = new Handler(WApp.Instance.getMainLooper());
        }

        mHandler.post(new Runnable() {
            @Override
            public void run() {
                if (!ThreadUtils.isMainThread() || (null == actionLister)) {
                    return;
                }

                String msg = "";
                E data = null;
                int resultCode = -1;
                if (result != null) {
                    resultCode = result.resultCode;
                    // 针对云音乐的某些resultCode 为-2的特殊情况
                    if ((0 == resultCode) || (-2 == resultCode)) {
                        resultCode = 0;
                        data = result.bean;
                    }
                }

                actionLister.callback(resultCode, data, msg);
            }
        });
    }

    private static <E> void postCmdResponseAll(Response<E> result, CmdActionLister<Response<E>> actionLister) {
        if (null == mHandler) {
            mHandler = new Handler(WApp.Instance.getMainLooper());
        }

        mHandler.post(new Runnable() {
            @Override
            public void run() {
                if (!ThreadUtils.isMainThread() || (null == actionLister)) {
                    return;
                }

                String msg = "";
                Response<E> data = null;
                int resultCode = -1;
                if (result != null) {
                    resultCode = result.resultCode;
                    // 针对云音乐的某些resultCode 为-2的特殊情况
                    if ((0 == resultCode) || (-2 == resultCode)) {
                        resultCode = 0;
                        data = result;
                    }
                }

                actionLister.callback(resultCode, data, msg);
            }
        });
    }
}
