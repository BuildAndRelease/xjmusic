package com.westwhale.contollerapp.ui.cloudmusic.adapter;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.westwhale.contollerapp.R;
import com.westwhale.api.protocolapi.bean.media.CloudMusic;

import java.util.ArrayList;
import java.util.List;

/**
 * Description:
 * Author: chenyaoli
 * Date: 2018-11-17
 * History:
 */
public class CloudMusicPlayListAdapter extends RecyclerView.Adapter {

    private List<CloudMusic> mItemList;
    private CallBack mCallBack;
    private int mSelectedIndex;
    private CloudMusic mSelectedItem;

    public interface CallBack {
        void onSongItemClick(CloudMusic songItem);

        void onItemDeleteClick(CloudMusic item);
    }

    public void updateSelectedItem(CloudMusic item){
        if ((null == item) || (mItemList == null)){
            return;
        }
        int oldIndex = -1;
        if (mSelectedItem != null){
            oldIndex = mItemList.indexOf(mSelectedItem);
        }

        int newIndex = -1;
        for (int i=0; i < mItemList.size(); i++){
            CloudMusic cloudMusic = mItemList.get(i);
            if (cloudMusic != null){
                if (cloudMusic.songMid.equals(item.songMid) && cloudMusic.songName.equals(item.songName) && cloudMusic.songId.equals(item.songId)){
                    newIndex = i;
                    mSelectedItem = cloudMusic;
                    break;
                }

            }
        }

        if ((newIndex != -1) && (newIndex != oldIndex)){
            if (oldIndex != -1){
                notifyItemChanged(oldIndex);
            }

            notifyItemChanged(newIndex);
        }
    }

    public void updateDataList(List<CloudMusic> itemList){
        this.mItemList = itemList;
    }

    public void clearDataList(){
        if (mItemList != null){
            this.mItemList.clear();
        }
        notifyDataSetChanged();
    }

    public void addToDataList(List<CloudMusic> itemList){
        if (mItemList == null){
            mItemList = new ArrayList<>();
            notifyDataSetChanged();
        }
        mItemList.addAll(itemList);
    }

    public void removeItem(CloudMusic item){
        if (mItemList != null){
            int index = mItemList.indexOf(item);
            if (index > -1){
                mItemList.remove(index);
//                notifyItemRemoved(index);
                notifyDataSetChanged();
            }
        }
    }

    public CloudMusicPlayListAdapter(CallBack callBack) {
        this.mItemList = null;
        this.mCallBack = callBack;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_netmusic_song_1, viewGroup, false);
        return new MusicListItemHolder(view);

    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder viewHolder, int i) {
        // 在此处，处理默认类型的 viewHolder
        CloudMusic item = mItemList.get(i);
        MusicListItemHolder itemHolder = (MusicListItemHolder) viewHolder;

        itemHolder.mSongNoTv.setText(String.valueOf(i+1));
        itemHolder.mTitleTv.setText(item.songName);
        String subtitle = item.getSingersName() + "-" + item.albumName + "";
        itemHolder.mSubtitle.setText(subtitle);

        int colorResourceId = R.color.colorText;
        boolean canPlay = true;
        if (item.canPlay == 1) {
            colorResourceId = R.color.colorGrey;
            canPlay = false;
        }else{
            //设置选中颜色
            if (item == mSelectedItem){
                colorResourceId = R.color.colorAccent;
            }
        }
        int color = itemHolder.itemView.getResources().getColor(colorResourceId);
        itemHolder.mSongNoTv.setTextColor(color);
        itemHolder.mTitleTv.setTextColor(color);
        itemHolder.mSubtitle.setTextColor(color);

        itemHolder.mDeleteIv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mCallBack != null){
                    mCallBack.onItemDeleteClick(item);
                }
            }
        });

        itemHolder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mCallBack != null) {
                    mCallBack.onSongItemClick(item);
                }
            }
        });

    }

    @Override
    public int getItemCount() {
        return (mItemList == null) ? 0 : mItemList.size();
    }


    private class MusicListItemHolder extends RecyclerView.ViewHolder {
        TextView mSongNoTv, mTitleTv, mSubtitle;
        ImageView mDeleteIv;

        MusicListItemHolder(@NonNull View itemView) {
            super(itemView);
            mSongNoTv = itemView.findViewById(R.id.netmusic_song_item_no);
            mTitleTv = itemView.findViewById(R.id.netmusic_song_item_name);
            mSubtitle = itemView.findViewById(R.id.netmusic_song_item_artist);

            mDeleteIv = itemView.findViewById(R.id.netmusic_song_item_delete);
        }
    }
}
