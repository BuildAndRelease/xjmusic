package com.westwhale.contollerapp.common;

import android.os.Parcel;
import android.os.Parcelable;

public class CodeNameItem implements Parcelable {
    public String mType;
    public String mName;
    public String mCode;
    public CodeNameItem(String type, String name,String code){
        mType = type;
        mName = name;
        mCode = code;
    }

    public boolean equals(CodeNameItem other){
        if (other == null){
            return false;
        }

        if (mType.equals(other.mType) && mName.equals(other.mName) && mCode.equals(other.mCode)){
            return true;
        }else{
            return false;
        }
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(this.mType);
        dest.writeString(this.mName);
        dest.writeString(this.mCode);
    }

    // 序列化过程：必须按成员变量声明的顺序进行封装
    protected CodeNameItem(Parcel in) {
        this.mType = in.readString();
        this.mName = in.readString();
        this.mCode = in.readString();
    }

    // 反序列过程：必须实现Parcelable.Creator接口，并且对象名必须为CREATOR
    // 读取Parcel里面数据时必须按照成员变量声明的顺序，Parcel数据来源上面writeToParcel方法，读出来的数据供逻辑层使用
    public static final Parcelable.Creator<CodeNameItem> CREATOR = new Parcelable.Creator<CodeNameItem>() {
        @Override
        public CodeNameItem createFromParcel(Parcel source) {
            return new CodeNameItem(source);
        }

        @Override
        public CodeNameItem[] newArray(int size) {
            return new CodeNameItem[size];
        }
    };
}
