package com.westwhale.contollerapp.ui.base.adapter;

import android.support.v7.widget.RecyclerView;
import android.util.SparseBooleanArray;

import java.util.ArrayList;
import java.util.List;

public abstract class MultiOptBaseAdapter<T> extends RecyclerView.Adapter {
    protected List<T> mItemList;
    protected SparseBooleanArray mSelectedPositions = new SparseBooleanArray();
    protected CallBack mCallBack;

    public interface CallBack<T>{
        void onMultiItemClick(T item, boolean selected);

        void onCheckedNumChanged(int selectednum);
    }

    public List<T> getSelectedList(){
        List<T> musicList = new ArrayList<>();
        for (int i=0; i < mSelectedPositions.size(); i++){
            int index = mSelectedPositions.keyAt(i);
            if ((index > -1) && (mItemList != null) && (index < mItemList.size())){
                musicList.add(mItemList.get(index));
            }
        }

        return musicList;
    }

    public int getSelectedNum(){
        return mSelectedPositions.size();
    }

    public void selectAllItem(){
        if (mItemList != null){
            for (int i=0; i < mItemList.size(); i++){
                mSelectedPositions.put(i,true);
            }

            notifyDataSetChanged();

            if (mCallBack != null){
                mCallBack.onCheckedNumChanged(mSelectedPositions.size());
            }
        }
    }

    public void cancelAllItem(){
        mSelectedPositions.clear();
        notifyDataSetChanged();

        if (mCallBack != null){
            mCallBack.onCheckedNumChanged(mSelectedPositions.size());
        }
    }

    public void setDataList(List<T> itemList){
        if (mItemList != null){
            mItemList.clear();
            notifyDataSetChanged();
        }
        this.mItemList = itemList;
    }

    public boolean isItemChecked(int position) {
        return mSelectedPositions.get(position);
    }

    public MultiOptBaseAdapter(CallBack callBack){
        this.mItemList = null;
        this.mCallBack = callBack;
    }
}
