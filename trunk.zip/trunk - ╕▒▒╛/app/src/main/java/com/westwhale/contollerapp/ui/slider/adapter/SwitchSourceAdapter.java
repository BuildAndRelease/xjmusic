package com.westwhale.contollerapp.ui.slider.adapter;

import android.graphics.drawable.Drawable;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.westwhale.contollerapp.R;
import com.westwhale.contollerapp.common.ImageTextItem;

import java.util.ArrayList;
import java.util.List;

/**
 * Description:
 * Author: chenyaoli
 * Date: 2018-12-20
 * History
 *
 */
public class SwitchSourceAdapter extends RecyclerView.Adapter {
    private List<ImageTextItem> mItemList;
    private CallBack mCallBack;

    public interface CallBack{
        void onItemClick(ImageTextItem item,int pos);
    }

    public void setCallBack(CallBack callBack){
        this.mCallBack = callBack;
    }

    public void setDataList(List<ImageTextItem> itemList){
        this.mItemList = itemList;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_slider_switchsource, viewGroup, false);
        return new ItemHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder viewHolder, int i) {
        if (viewHolder instanceof ItemHolder){
            int pos = viewHolder.getAdapterPosition();
            final ImageTextItem item = mItemList.get(pos);
            ItemHolder itemHolder = (ItemHolder)viewHolder;

            itemHolder.mTextView.setText(item.getTitle());
            Drawable drawable = null;
            try {
                drawable = itemHolder.itemView.getResources().getDrawable(item.getImageRes());
            }catch (Exception e){
                drawable = null;
            }
            itemHolder.mImageView.setImageDrawable(drawable);
            if (drawable == null) {
                itemHolder.mImageView.setVisibility(View.GONE);
            }

            itemHolder.itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (mCallBack != null){
                        mCallBack.onItemClick(item,pos);
                    }
                }
            });
        }
    }

    @Override
    public int getItemCount() {
        return (mItemList == null) ? 0 : mItemList.size();
    }

    private class ItemHolder extends RecyclerView.ViewHolder{
        private ImageView mImageView;
        private TextView mTextView;
        public ItemHolder(@NonNull View itemView) {
            super(itemView);
            mImageView = itemView.findViewById(R.id.item_switchsource_pic);
            mTextView = itemView.findViewById(R.id.item_switchsource_name);
        }
    }
}
