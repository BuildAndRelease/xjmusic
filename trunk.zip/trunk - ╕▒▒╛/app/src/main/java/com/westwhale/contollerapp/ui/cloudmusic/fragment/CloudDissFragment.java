package com.westwhale.contollerapp.ui.cloudmusic.fragment;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.kingja.loadsir.callback.Callback;
import com.kingja.loadsir.callback.SuccessCallback;
import com.scwang.smartrefresh.layout.api.RefreshLayout;
import com.scwang.smartrefresh.layout.listener.OnLoadMoreListener;
import com.scwang.smartrefresh.layout.listener.OnRefreshListener;
import com.westwhale.contollerapp.R;
import com.westwhale.contollerapp.dev.CmdActionLister;
import com.westwhale.contollerapp.dev.ICmdCallback;
import com.westwhale.contollerapp.dev.WRoom;
import com.westwhale.contollerapp.ui.main.MainRoomActivity;
import com.westwhale.contollerapp.ui.cloudmusic.adapter.CloudDissAdapter;
import com.westwhale.contollerapp.ui.cloudmusic.dialog.CloudDissCategoryDialog;
import com.westwhale.contollerapp.ui.base.fragment.TitleBaseFragment;
import com.westwhale.contollerapp.ui.loadsircallback.ErrorCallback;
import com.westwhale.contollerapp.ui.loadsircallback.LoadingCallback;
import com.westwhale.api.protocolapi.bean.albumSet.CloudDissSet;
import com.westwhale.api.protocolapi.bean.cloudmusic.DissCategory;
import com.westwhale.api.protocolapi.bean.cloudmusic.DissCategoryGroup;

import java.util.List;

/**
 * Description:
 * Author: chenyaoli
 * Date: 2018-11-12
 * History:
 */
public class CloudDissFragment extends TitleBaseFragment implements CloudDissAdapter.CallBack {
    public static final int REQUEST_CODDE = 0;

    private FrameLayout mFrameLayout;
    private RecyclerView mDataRv;
    private TextView mTypeTv;
    private ImageView mCategoryIv;
    private Toolbar mToolBar;
    private CloudDissAdapter mCloudDissAdapter;

    private RefreshLayout mRefreshLayout;

    List<DissCategoryGroup> mDissCategoryGroupList;
    private static DissCategory mDissCategory = new DissCategory();  // 记录上次用户选择的项
    private static int mDefaultSort = 2;
    private static int mGetListFrom = 0;
    private static int mGetListTo = 0;
    private static int DEFAULT_PER_SIZE = 50;


    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        // 先显示加载动画，针对布局做一些初始化
        return inflater.inflate(R.layout.frag_netmusic_diss,container,false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        mFrameLayout = view.findViewById(R.id.netmusic_diss_content_layout);

        // 创建mLoadService
        mLoadService = mLoadSir.register(mFrameLayout, new Callback.OnReloadListener() {
            @Override
            public void onReload(View v) {
                showLoadCallBack(LoadingCallback.class);

                initData();
            }
        });

        initView(view);

        initListener();

        // 获取云音乐的歌单的分类
       requestDissCategoryCloudResource();
    }

    @Override
    public void onResume() {
        super.onResume();
    }

    @Override
    public void onDissItemClick(CloudDissSet dissItem) {
        // 点击指定歌单，跳转到歌单歌曲界面
        CloudMusicListDissFragment musiclistFragment = new CloudMusicListDissFragment();
        musiclistFragment.updateDissSet(dissItem);
        if (getActivity() instanceof MainRoomActivity) {
            ((MainRoomActivity) getActivity()).showFragment(musiclistFragment);
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        // 接收分类弹出框的返回结果
        if (REQUEST_CODDE == requestCode){
            String categoryId = data.getStringExtra(CloudDissCategoryDialog.CATEGORY_ID);
            String categoryName = data.getStringExtra(CloudDissCategoryDialog.CATEGORY_NAME);
            mDissCategory.categoryId = Integer.parseInt(categoryId);
            mDissCategory.categoryName = categoryName;

            showLoadCallBack(LoadingCallback.class);

            initData();
        }
    }

    private void initView(View view) {
        mToolBar = view.findViewById(R.id.netmusic_diss_toolbar);
        configToolBar(mToolBar,getString(R.string.cloudmusic_diss_title));

        mDataRv = view.findViewById(R.id.netmusic_diss_recylerview);
        GridLayoutManager gridLayoutManager = new GridLayoutManager(mContext, 2);
        mDataRv.setLayoutManager(gridLayoutManager);
        mCloudDissAdapter = new CloudDissAdapter(this);
        mDataRv.setAdapter(mCloudDissAdapter);
        mDataRv.setHasFixedSize(true);

        mRefreshLayout = view.findViewById(R.id.netmusic_diss_refresh);
        mRefreshLayout.setDisableContentWhenRefresh(true);
        mRefreshLayout.setEnableLoadMore(true);

        mTypeTv = view.findViewById(R.id.netmusic_diss_type);
        mCategoryIv = view.findViewById(R.id.netmusic_diss_category);
    }

    private void initListener() {
        mCategoryIv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 弹出类型选择界面
                CloudDissCategoryDialog cloudCategoryDialog = new CloudDissCategoryDialog();
                // 设置目标Fragment
                cloudCategoryDialog.setDissCategoryGroupList(mDissCategoryGroupList);
                cloudCategoryDialog.setTargetFragment(CloudDissFragment.this, REQUEST_CODDE);
                if (getFragmentManager() != null) {
                    cloudCategoryDialog.show(getFragmentManager(), "CloudCategory_Dialog");
                }
            }
        });

        mDataRv.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(@NonNull RecyclerView recyclerView, int newState) {
                super.onScrollStateChanged(recyclerView, newState);
            }

            @Override
            public void onScrolled(@NonNull RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);
            }
        });

        mRefreshLayout.setOnRefreshListener(new OnRefreshListener() {
            @Override
            public void onRefresh(@NonNull RefreshLayout refreshLayout) {
                initData();
            }
        });

        mRefreshLayout.setOnLoadMoreListener(new OnLoadMoreListener() {
            @Override
            public void onLoadMore(@NonNull RefreshLayout refreshLayout) {
                //  判断是否还有数据，从而判断是否还需要加载更多数据
                if (mGetListFrom <= mGetListTo){
                    mRefreshLayout.finishLoadMoreWithNoMoreData();
                }else {
                    mGetListTo = DEFAULT_PER_SIZE + mGetListFrom - 1;

                    requestCloudResource();
                }
            }
        });
    }

    private void initData() {
        if (mTypeTv != null) {
            mTypeTv.setText(mDissCategory.categoryName);
        }

        mGetListFrom = 0;
        mGetListTo = DEFAULT_PER_SIZE + mGetListFrom - 1;

        // 每次先清空原有数据
        if (mCloudDissAdapter != null){
            mCloudDissAdapter.clearDataList();
        }

        requestCloudResource();
    }

    public void updateDataList(List<CloudDissSet> list){
        if (list != null){
            // 若是重新获取，则先把原适配器中的数据清空
            int size = list.size();
            if (0 == mGetListFrom){
                mCloudDissAdapter.clearDataList();
            }

            mCloudDissAdapter.addToDataList(list);
            mCloudDissAdapter.notifyItemRangeInserted(mGetListFrom,size);

            mGetListFrom = mGetListFrom + size;

            // 更新刷新等待状态
            mRefreshLayout.finishRefresh();
            mRefreshLayout.finishLoadMore();

            showLoadCallBack(SuccessCallback.class);
        }else{
            showLoadCallBack(ErrorCallback.class);
        }

    }

    private void updateDissGroupList(List<DissCategoryGroup> dataList){
        boolean initDissCategory = false;
        if (dataList != null){
            mDissCategoryGroupList = dataList;
            if (mDissCategoryGroupList.size() > 0){
                List<DissCategory> items = mDissCategoryGroupList.get(0).items;
                if ( (items != null) && (items.size() > 0)){
                    mDissCategory.categoryName = items.get(0).categoryName;
                    mDissCategory.categoryId = items.get(0).categoryId;

                    initDissCategory = true;
                }
            }
        }

        if (!initDissCategory){
            mDissCategory = new DissCategory();
            mDissCategory.categoryId = 0;
            mDissCategory.categoryName = "";
        }

        // 歌单分类获取完成后，再获取指定的分类下的歌单
        initData();
    }


    public void requestCloudResource() {
        String categoryId = String.valueOf(mDissCategory.categoryId);
        WRoom.cmdGetDiss(categoryId,mDefaultSort, mGetListFrom, mGetListTo, new CmdActionLister<List<CloudDissSet>>(this, new ICmdCallback<List<CloudDissSet>>() {
            @Override
            public void onSuccess(List<CloudDissSet> data) {
                updateDataList(data);
            }

            @Override
            public void onFailed(int code, String msg) {
                updateDataList(null);
                Toast.makeText(getContext(),"GetDiss获取失败:"+code,Toast.LENGTH_SHORT).show();
            }
        }));
    }

    public void requestDissCategoryCloudResource() {
        WRoom.cmdGetDissCategory(new CmdActionLister<List<DissCategoryGroup>>(this, new ICmdCallback<List<DissCategoryGroup>>() {
            @Override
            public void onSuccess(List<DissCategoryGroup> data) {
                updateDissGroupList(data);
            }

            @Override
            public void onFailed(int code, String msg) {
                updateDissGroupList(null);
                Toast.makeText(getContext(),"GetDissCategory获取失败:"+code,Toast.LENGTH_SHORT).show();
            }
        }));
    }

}
