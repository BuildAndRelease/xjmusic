package com.westwhale.contollerapp.ui.favorite.songsheet.adapter;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.util.SparseBooleanArray;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.TextView;

import com.westwhale.contollerapp.R;
import com.westwhale.api.protocolapi.bean.media.CloudMusic;
import com.westwhale.api.protocolapi.bean.media.LocalMusic;
import com.westwhale.api.protocolapi.bean.media.Media;

import java.util.ArrayList;
import java.util.List;

/**
 * Description:
 * Author: chenyaoli
 * Date: 2018-12-12
 * History:
 */
public class FavoriteMediaListEditAdapter extends RecyclerView.Adapter {
    private List<Media> mItemList;
    private SparseBooleanArray mSelectedPositions = new SparseBooleanArray();
    private CallBack mCallBack;

    public interface CallBack{
        void onItemClick(Media item, boolean selected);

        void onCheckedNumChanged(int selectednum);
    }

    public List<Media> getSelectedList(){
        List<Media> itemlist = new ArrayList<>();
        for (int i=0; i < mSelectedPositions.size(); i++){
            int index = mSelectedPositions.keyAt(i);
            if ((index > -1) && (mItemList != null) && (index < mItemList.size())){
                itemlist.add(mItemList.get(index));
            }
        }

        return itemlist;
    }

    public int getSelectedNum(){
        return mSelectedPositions.size();
    }

    public void selectAllItem(){
        if (mItemList != null){
            for (int i=0; i < mItemList.size(); i++){
                mSelectedPositions.put(i,true);
            }

            notifyDataSetChanged();

            if (mCallBack != null){
                mCallBack.onCheckedNumChanged(mSelectedPositions.size());
            }
        }
    }

    public void cancelAllItem(){
        mSelectedPositions.clear();
        notifyDataSetChanged();

        if (mCallBack != null){
            mCallBack.onCheckedNumChanged(mSelectedPositions.size());
        }
    }

    public void setDataList(List<Media> itemList){
        if (mItemList != null){
            mItemList.clear();
            notifyDataSetChanged();
        }
        this.mItemList = itemList;
    }

    private boolean isItemChecked(int position) {
        return mSelectedPositions.get(position);
    }

    public FavoriteMediaListEditAdapter(CallBack callBack){
        this.mItemList = null;
        this.mCallBack = callBack;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_favorite_media_edit, viewGroup, false);
        return new ItemHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder viewHolder, int i) {
        Media item = mItemList.get(i);
        ItemHolder itemHolder = (ItemHolder)viewHolder;

        boolean checkStat = isItemChecked(i);
        itemHolder.mCheckBox.setChecked(checkStat);

        String title = "";
        String subtitle = "";
        switch(item.mediaSrc){
            case Media.CLOUD_MUSIC:
                title = ((CloudMusic)item).songName;
                subtitle = ((CloudMusic)item).getSingersName();
                break;
            case Media.LOCAL_MUSIC:
                title = ((LocalMusic)item).songName;
                subtitle = item.mediaSrc;
                break;
            default:
                subtitle = item.mediaSrc;
                break;
        }
        itemHolder.mTitleTv.setText(title);
        itemHolder.mSubtitleTv.setText(subtitle);

        itemHolder.mCheckBox.setClickable(false);
        itemHolder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                boolean checkStat = isItemChecked(i);
                boolean newStat = !checkStat;
                if (newStat) {
                    mSelectedPositions.put(i, newStat);
                }else{
                    mSelectedPositions.delete(i);
                }

                if (mCallBack != null){
                    mCallBack.onCheckedNumChanged(mSelectedPositions.size());
                }

                notifyItemChanged(i);

                mCallBack.onItemClick(item,newStat);
            }
        });
    }

    @Override
    public int getItemCount() {
        return (null == mItemList) ? 0 : mItemList.size();
    }

    /**************************************   ItemHolder *******************************************/
    public class ItemHolder extends RecyclerView.ViewHolder{
        CheckBox mCheckBox;
        TextView mTitleTv,mSubtitleTv;
        public ItemHolder(@NonNull View itemView) {
            super(itemView);
            mCheckBox = itemView.findViewById(R.id.item_favorite_media_edit_checkbox);
            mTitleTv = itemView.findViewById(R.id.item_favorite_media_edit_title);
            mSubtitleTv = itemView.findViewById(R.id.item_favorite_media_edit_subtitle);
        }
    }
}
