package com.westwhale.contollerapp.dev.player;

import com.westwhale.api.protocolapi.bean.media.LocalMusic;

public class LocalMusicPlayer extends WPlayer<LocalMusic> {
    private final static String TAG = "LocalMusicPlayer";

}
