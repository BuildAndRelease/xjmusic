package com.westwhale.contollerapp.ui.base.fragment;

import android.app.Activity;
import android.content.Context;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;

import com.westwhale.contollerapp.R;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;

public class BaseFragment extends Fragment {
    public Context mContext;

    private List<IDestroyListener> mList = new ArrayList<>();

    // 用于监听当前Fragment销毁事情
    public interface IDestroyListener{
        public void onFragmentPrepareDestroy();
    }

    public void registerDestroyedListener(IDestroyListener listener){
        mList.add(listener);
    }
    public void unRegisterDestroyedListener(IDestroyListener listener){
        if (mList.contains(listener)){
            mList.remove(listener);
        }
    }
    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        view.setClickable(true);
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        mContext = context;


    }

    @Override
    public void onDestroy() {
        for (int i=0; i < mList.size(); i++){
            IDestroyListener listener = mList.get(i);
            if (listener != null){
                listener.onFragmentPrepareDestroy();
            }
        }

        mList.clear();

        super.onDestroy();
    }
}
