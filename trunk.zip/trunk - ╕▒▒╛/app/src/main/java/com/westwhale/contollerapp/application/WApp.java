package com.westwhale.contollerapp.application;

import android.app.Application;
import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v4.content.LocalBroadcastManager;
import android.support.v7.app.AppCompatDelegate;

import com.lzy.okgo.OkGo;
import com.scwang.smartrefresh.layout.SmartRefreshLayout;
import com.scwang.smartrefresh.layout.api.DefaultRefreshHeaderCreator;
import com.scwang.smartrefresh.layout.api.DefaultRefreshInitializer;
import com.scwang.smartrefresh.layout.api.RefreshHeader;
import com.scwang.smartrefresh.layout.api.RefreshLayout;
import com.scwang.smartrefresh.layout.header.ClassicsHeader;
import com.squareup.leakcanary.LeakCanary;
import com.westwhale.contollerapp.R;
import com.westwhale.contollerapp.common.PreferenceManage;
import com.westwhale.contollerapp.dev.DevManager;
import com.westwhale.contollerapp.update.AppUpdateManager;


public class WApp extends Application {
    public static WApp Instance;  // 单例
    private LocalBroadcastManager localBroadcastManager; // 广播，暂时使用eventbus

    @NonNull
    private PreferenceManage mPreferenceManage; // 配置文件管理
    @NonNull
    private AppUpdateManager mAppUpdateManager; // APP升级管理
    @NonNull
    private DevManager mDevManager;             // 设备管理中心


    // 全局配置 SmartRefreshLayout 相关信息
    static {
        //启用矢量图兼容
        AppCompatDelegate.setCompatVectorFromResourcesEnabled(true);
        //设置全局默认配置（优先级最低，会被其他设置覆盖）
        SmartRefreshLayout.setDefaultRefreshInitializer(new DefaultRefreshInitializer() {
            @Override
            public void initialize(@NonNull Context context, @NonNull RefreshLayout layout) {
                //全局设置（优先级最低）
                layout.setEnableAutoLoadMore(true);
                layout.setEnableOverScrollDrag(false);
                layout.setEnableOverScrollBounce(true);
                layout.setEnableLoadMoreWhenContentNotFull(true);
                layout.setEnableScrollContentWhenRefreshed(true);
            }
        });

        SmartRefreshLayout.setDefaultRefreshHeaderCreator(new DefaultRefreshHeaderCreator() {
            @NonNull
            @Override
            public RefreshHeader createRefreshHeader(@NonNull Context context, @NonNull RefreshLayout layout) {
                //全局设置主题颜色（优先级第二低，可以覆盖 DefaultRefreshInitializer 的配置，与下面的ClassicsHeader绑定）
                layout.setPrimaryColorsId(R.color.colorPrimary, android.R.color.white);
                ClassicsHeader header = new ClassicsHeader(context);
                header.setEnableLastTime(false);
                header.clearAnimation();
                return header;
            }
        });
    }

    @Override
    public void onCreate() {
        super.onCreate();

        Instance = this;

        init();
    }

    public void init(){
        // 内存泄漏检测工具，备注：在华为手机上会有一个leaked，因为华为手机系统会保留一个activity的索引
        if (LeakCanary.isInAnalyzerProcess(this)) {
            // This process is dedicated to LeakCanary for heap analysis. You should not init your app in this process.
            return;
        }
//        LeakCanary.install(this);

        initOkGo();

        // 配置文件管理
        mPreferenceManage = new PreferenceManage(this);

        // APP升级初始化
        mAppUpdateManager = new AppUpdateManager(this);
        mAppUpdateManager.initBugly();

        // 设备管理初始化（配置文件管理必须在此之前初始化，从而保证能够获取到APP的发送ID）
        mDevManager = new DevManager(this,mPreferenceManage.getDevUuid());

        // 广播类
        localBroadcastManager = LocalBroadcastManager.getInstance(this);

    }

    private void initOkGo(){
        OkGo.getInstance().init(this);
    }


    @NonNull
    public DevManager getDevManager(){
        return mDevManager;
    }

}
