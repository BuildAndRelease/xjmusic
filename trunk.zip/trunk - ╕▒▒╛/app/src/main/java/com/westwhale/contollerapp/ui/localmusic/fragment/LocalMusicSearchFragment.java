package com.westwhale.contollerapp.ui.localmusic.fragment;

import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.kingja.loadsir.callback.Callback;
import com.kingja.loadsir.callback.SuccessCallback;
import com.kingja.loadsir.core.LoadService;
import com.kingja.loadsir.core.LoadSir;
import com.scwang.smartrefresh.layout.api.RefreshLayout;
import com.scwang.smartrefresh.layout.listener.OnLoadMoreListener;
import com.westwhale.contollerapp.R;
import com.westwhale.contollerapp.application.WApp;
import com.westwhale.contollerapp.dev.CmdActionLister;
import com.westwhale.contollerapp.dev.ICmdCallback;
import com.westwhale.contollerapp.dev.WRoom;
import com.westwhale.contollerapp.ui.localmusic.adapter.LocalMusicAdapter;
import com.westwhale.contollerapp.ui.base.fragment.BaseFragment;
import com.westwhale.contollerapp.ui.loadsircallback.EmptyCallback;
import com.westwhale.contollerapp.ui.loadsircallback.ErrorCallback;
import com.westwhale.contollerapp.ui.loadsircallback.LoadingCallback;
import com.westwhale.contollerapp.ui.loadsircallback.TimeoutCallback;
import com.westwhale.api.protocolapi.bean.media.LocalMusic;
import com.westwhale.api.protocolapi.bean.media.Media;

import java.util.ArrayList;
import java.util.List;

/**
 * Description:
 * Author: chenyaoli
 * Date: 2018-11-12
 * History:
 */
public class LocalMusicSearchFragment extends BaseFragment implements LocalMusicAdapter.CallBack {
    public static final int REQUEST_CODDE = 0;

    private ImageView mSearchTextCleanIv,mHistoryCleanIv;
    private EditText mSearchTextEt;
    private FrameLayout mResultFrameLayout,mSearchBtnLayout;
    private LinearLayout mHistoryLinearLayout;
    private RecyclerView mSearchDataRv, mHistoryRv;
    private Toolbar mToolBar;
    private LocalMusicAdapter mMediaAdapter;
    private RefreshLayout mRefreshLayout;

    protected LoadService mLoadService;
    private int mBeginIndex;
    private int mPageSize = 50;
    private boolean mHasMoreData;

    public void showLoadCallBack(Class<? extends Callback> callback){
        if (mLoadService != null){
            mLoadService.showCallback(callback);
        }
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        // 先显示加载动画，针对布局做一些初始化
        return inflater.inflate(R.layout.frag_localmusic_search,container,false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        initView(view);

        initListener();

        // 界面的加载等待框架配置
        LoadSir loadSir = new LoadSir.Builder()
                .addCallback(new LoadingCallback())
                .addCallback(new TimeoutCallback())
                .addCallback(new ErrorCallback())
                .addCallback(new EmptyCallback())
                .setDefaultCallback(SuccessCallback.class)
                .build();

        FrameLayout resultLayout = view.findViewById(R.id.search_result_layout);
        // 创建mLoadService
        mLoadService = loadSir.register(resultLayout, new Callback.OnReloadListener() {
            @Override
            public void onReload(View v) {
                showLoadCallBack(LoadingCallback.class);
                initData();
            }
        });


        initData();
    }

    @Override
    public void onResume() {
        super.onResume();
    }

    @Override
    public void onPause() {
        super.onPause();

        hideSoftInputWindow();
    }

    private void initView(View view) {
        mToolBar = view.findViewById(R.id.search_toolbar);

        mSearchTextEt = view.findViewById(R.id.search_searchtext);
        mSearchTextCleanIv = view.findViewById(R.id.search_searchtext_clear);
        mSearchBtnLayout = view.findViewById(R.id.search_search_layout);

        mResultFrameLayout = view.findViewById(R.id.search_result_layout);

        mSearchDataRv = view.findViewById(R.id.search_result_recyclerview);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(mContext);
        mSearchDataRv.setLayoutManager(linearLayoutManager);
        mMediaAdapter = new LocalMusicAdapter(this);
        mSearchDataRv.setAdapter(mMediaAdapter);
        mSearchDataRv.setHasFixedSize(true);
        mSearchDataRv.addItemDecoration(new DividerItemDecoration(mContext, DividerItemDecoration.VERTICAL));
        mSearchDataRv.setOverScrollMode(View.OVER_SCROLL_NEVER);

        mRefreshLayout = view.findViewById(R.id.search_refresh);
        mRefreshLayout.setEnableRefresh(false);
//        mRefreshLayout.setDisableContentWhenRefresh(true);
        mRefreshLayout.setEnableLoadMore(true);

        mHistoryLinearLayout = view .findViewById(R.id.search_history_layout);
        mHistoryCleanIv = view.findViewById(R.id.search_history_clear);

        mHistoryRv = view.findViewById(R.id.search_history_recyclerview);
    }

    private void initListener() {
        mToolBar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                hideSoftInputWindow();
                // 为了避免返回时，出现跳动的情况，延时50ms返回
                Handler handler = new Handler();
                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        if (getActivity() != null){
                            getActivity().onBackPressed();
                        }
                    }
                },100);
            }
        });

        mSearchTextCleanIv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               initData();
            }
        });

        mSearchTextEt.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                // 搜索
                if ((event != null) && ((event.getKeyCode() == KeyEvent.KEYCODE_ENTER) || (event.getAction() == EditorInfo.IME_ACTION_SEARCH))){
                    String text = v.getText().toString();

                    startSearch(text);
                }
                return false;
            }
        });

        mSearchTextEt.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                // TODO: 2019/4/15 添加到搜索历史中
                String text = mSearchTextEt.getText().toString();
                if (TextUtils.isEmpty(text)){
                    mSearchTextCleanIv.setVisibility(View.INVISIBLE);
                }else{
                    mSearchTextCleanIv.setVisibility(View.VISIBLE);
                }
            }
        });

        mSearchBtnLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String text = mSearchTextEt.getText().toString();

                startSearch(text);

            }
        });


        mRefreshLayout.setOnLoadMoreListener(new OnLoadMoreListener() {
            @Override
            public void onLoadMore(@NonNull RefreshLayout refreshLayout) {
                if (hasMoreData()){
                    loadMoreData();
                }else {
                    mRefreshLayout.finishLoadMoreWithNoMoreData();
                }
            }
        });
    }

    private void hideSoftInputWindow(){
        // 隐藏时，把虚拟键盘隐藏
        if (getActivity() != null){
            InputMethodManager imm = (InputMethodManager)getActivity().getSystemService(Context.INPUT_METHOD_SERVICE);
            if (imm != null) {
                imm.hideSoftInputFromWindow(mSearchTextEt.getWindowToken(), 0);
            }
        }
    }

    private void startSearch(String text) {
        // 隐藏时，把虚拟键盘隐藏
        hideSoftInputWindow();

        if (TextUtils.isEmpty(text)){
            Toast.makeText(mContext,"搜索文本为空",Toast.LENGTH_SHORT).show();
        }else{
            showLoadCallBack(LoadingCallback.class);

            resetRefreshInfo();

            requestCloudResource();
        }
    }

    private void requestCloudResource(){
        WRoom room = WApp.Instance.getDevManager().getSelectedRoom();
        if (room != null){
            String text = mSearchTextEt.getText().toString();
            room.cmdSearchLocalMusic(text,mBeginIndex,mPageSize,new CmdActionLister<List<Media>>(LocalMusicSearchFragment.this, new ICmdCallback<List<Media>>() {
                @Override
                public void onSuccess(List<Media> data) {
                    updateDataList(data);
                }

                @Override
                public void onFailed(int code, String msg) {
                    updateDataList(null);
                    Toast.makeText(mContext,"未搜索到结果"+code,Toast.LENGTH_SHORT).show();
                }
            }));
        }
    }

    private void initData() {
        showHistoryLayout(false);

        resetRefreshInfo();

        mSearchTextEt.setText("");
        mSearchTextEt.requestFocus();
        // 弹出软键盘
        if (getActivity() != null){
            InputMethodManager imm = (InputMethodManager)getActivity().getSystemService(Context.INPUT_METHOD_SERVICE);
            if (imm != null) {
                imm.toggleSoftInput(0, InputMethodManager.HIDE_NOT_ALWAYS);    //InputMethodManager.SHOW_FORCED
            }
        }

        mSearchTextCleanIv.setVisibility(View.INVISIBLE);
    }

    private void resetRefreshInfo(){
        mBeginIndex = 0;
        mHasMoreData = true;
        if (mMediaAdapter != null){
            mMediaAdapter.clearDataList();
        }
        mRefreshLayout.resetNoMoreData();
    }

    private void showHistoryLayout(boolean isshow){
        if (isshow){
            mHistoryLinearLayout.setVisibility(View.VISIBLE);
            mResultFrameLayout.setVisibility(View.GONE);
        }else{
            mHistoryLinearLayout.setVisibility(View.GONE);
            mResultFrameLayout.setVisibility(View.VISIBLE);
        }
    }

    private boolean hasMoreData(){
        return mHasMoreData;
    }

    private void loadMoreData(){

        requestCloudResource();
    }

    public void updateDataList(List<Media> list){
        if (list != null) {
            List<LocalMusic> dataList = new ArrayList<>();
            for (int i=0; i < list.size(); i++){
                Media media = list.get(i);
                if (media instanceof LocalMusic){
                    dataList.add((LocalMusic)media);
                }
            }

            int size = dataList.size();

            if (mBeginIndex == 0){
                mMediaAdapter.clearDataList();
            }

            mBeginIndex = mBeginIndex + size;
            if (size != 0){
                int startIndex = mMediaAdapter.getItemCount();
                mMediaAdapter.addToDataList(dataList);
                mMediaAdapter.notifyItemRangeInserted(startIndex,size);
            }else{
                mHasMoreData = false;
            }

            // 更新刷新等待状态
            mRefreshLayout.finishLoadMore();

            showLoadCallBack(SuccessCallback.class);
        }else{
            mHasMoreData = false;

            mRefreshLayout.finishLoadMore();

            showLoadCallBack(SuccessCallback.class);
        }
    }

    @Override
    public void onSongItemClick(LocalMusic songItem) {
        // 点击某歌曲，开始播放
        WRoom room = WApp.Instance.getDevManager().getSelectedRoom();
        if (room != null){
            room.cmdPlayMedia(songItem,new CmdActionLister<>(LocalMusicSearchFragment.this, new ICmdCallback<Boolean>() {
                @Override
                public void onSuccess(Boolean data) {

                }

                @Override
                public void onFailed(int code, String msg) {
                    Toast.makeText(getContext(), "播放歌曲失败..."+code, Toast.LENGTH_SHORT).show();
                }
            }));
        }
    }

    @Override
    public void onSongItemMoreClick(LocalMusic songItem) {

    }
}
