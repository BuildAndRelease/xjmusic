package com.westwhale.contollerapp.ui.cloudmusic.fragment;

import android.os.Bundle;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.support.v7.widget.RecyclerView;
import android.widget.Toast;

import com.kingja.loadsir.callback.Callback;
import com.kingja.loadsir.callback.SuccessCallback;
import com.kingja.loadsir.core.LoadService;
import com.kingja.loadsir.core.LoadSir;
import com.westwhale.contollerapp.R;
import com.westwhale.contollerapp.dev.CmdActionLister;
import com.westwhale.contollerapp.dev.ICmdCallback;
import com.westwhale.contollerapp.dev.WRoom;
import com.westwhale.contollerapp.ui.base.fragment.LazyBaseFragment;
import com.westwhale.contollerapp.ui.main.MainRoomActivity;
import com.westwhale.contollerapp.ui.cloudmusic.adapter.CloudAlbumAdapter;
import com.westwhale.contollerapp.ui.cloudmusic.adapter.CloudSongAdapter;
import com.westwhale.contollerapp.ui.cloudmusic.dialog.CloudMusicMoreDialog;
import com.westwhale.contollerapp.ui.loadsircallback.EmptyCallback;
import com.westwhale.contollerapp.ui.loadsircallback.ErrorCallback;
import com.westwhale.contollerapp.ui.loadsircallback.LoadingCallback;
import com.westwhale.contollerapp.ui.loadsircallback.TimeoutCallback;
import com.westwhale.api.protocolapi.bean.media.CloudMusic;
import com.westwhale.api.protocolapi.bean.albumSet.CloudAlbumSet;
import com.westwhale.api.protocolapi.bean.cloudmusic.CloudMusicRecommed;

import java.util.ArrayList;
import java.util.List;

public class NetMusicHomeFragment  extends LazyBaseFragment implements CloudAlbumAdapter.CallBack,CloudSongAdapter.CallBack{
    private static final String TAG = NetMusicHomeFragment.class.getName();
    private TextView mSearchTv;
    private ImageView mRankIv, mSingerIv, mCategoryIv, mRadioIv;
    private RecyclerView mNewAlbumRv, mNewSongRv;
    private View mNewAlbumLv,mNewSongLv;

    private CloudAlbumAdapter mCloudAlbumAdapter;
    private CloudSongAdapter mCloudSongAdapter;

    private LoadSir mLoadSir;
    private LoadService mAlbumLoadService;
    private LoadService mMusicLoadService;

    private CloudMusicRecommed mCloudMusicRecommed;
    private List<CloudMusic> mMusiclist;

    @Override
    public int getLayoutId() {
        return R.layout.frag_netmusic_home;
    }

    @Override
    public void initView(View view) {
        try {
            // 界面的加载等待框架配置
            mLoadSir = new LoadSir.Builder()
                    .addCallback(new LoadingCallback())
                    .addCallback(new TimeoutCallback())
                    .addCallback(new ErrorCallback())
                    .addCallback(new EmptyCallback())
                    .setDefaultCallback(SuccessCallback.class)
                    .build();



            mSearchTv = view.findViewById(R.id.netmusic_home_search);

            mRankIv = view.findViewById(R.id.netmusic_home_rank);
            mSingerIv = view.findViewById(R.id.netmusic_home_singer);
            mCategoryIv = view.findViewById(R.id.netmusic_home_catogry);
            mRadioIv = view.findViewById(R.id.netmusic_home_radio);

            mNewAlbumLv = view.findViewById(R.id.netmusic_home_newalbum_layout);
            mNewSongLv = view.findViewById(R.id.netmusic_home_newsong_layout);

            mNewAlbumRv = view.findViewById(R.id.netmusic_home_newalbum_recyclerview);
            GridLayoutManager gridLayoutManager = new GridLayoutManager(mContext, 3);
            mNewAlbumRv.setLayoutManager(gridLayoutManager);
            mCloudAlbumAdapter = new CloudAlbumAdapter(3, this);
            mNewAlbumRv.setAdapter(mCloudAlbumAdapter);
            mNewAlbumRv.setHasFixedSize(true);
            mNewAlbumRv.setNestedScrollingEnabled(false);

            mAlbumLoadService = mLoadSir.register(mNewAlbumRv, new Callback.OnReloadListener() {
                @Override
                public void onReload(View v) {
                    showLoadCallBack(mAlbumLoadService, LoadingCallback.class);
                    requestCloudResourceRecommand();
                }
            });

            mNewSongRv = view.findViewById(R.id.netmusic_home_newsong_recyclerview);
            LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getContext());
            mNewSongRv.setLayoutManager(linearLayoutManager);
            mCloudSongAdapter = new CloudSongAdapter(6, this);
            mNewSongRv.setAdapter(mCloudSongAdapter);
            mNewSongRv.setHasFixedSize(true);
            mNewSongRv.addItemDecoration(new DividerItemDecoration(mContext, DividerItemDecoration.VERTICAL));
            mNewSongRv.setNestedScrollingEnabled(false);

            // 创建mLoadService
            mMusicLoadService = mLoadSir.register(mNewSongRv, new Callback.OnReloadListener() {
                @Override
                public void onReload(View v) {
                    showLoadCallBack(mMusicLoadService, LoadingCallback.class);
                    requestCloudResource();
                }
            });
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    @Override
    public void initListener() {
        mSearchTv.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                // 跳转到搜索界面
                CloudSearchFragment fragment = new CloudSearchFragment();
                if (getActivity() instanceof MainRoomActivity){
                    ((MainRoomActivity)getActivity()).showFragment(fragment);
                }
            }
        });
        mRankIv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 跳转到榜单界面
                CloudRankFragment fragment = new CloudRankFragment();
                if (getActivity() instanceof MainRoomActivity){
                    ((MainRoomActivity)getActivity()).showFragment(fragment);
                }
            }
        });

        mSingerIv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 跳转到歌手界面
                CloudSingerFragment fragment = new CloudSingerFragment();
                if (getActivity() instanceof MainRoomActivity){
                    ((MainRoomActivity)getActivity()).showFragment(fragment);
                }
            }
        });

        mCategoryIv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 跳转到分类界面
                CloudDissFragment fragment = new CloudDissFragment();
                if (getActivity() instanceof MainRoomActivity){
                    ((MainRoomActivity)getActivity()).showFragment(fragment);
                }
            }
        });

        mRadioIv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 跳转到电台界面
                CloudRadioFragment fragment = new CloudRadioFragment();
                if (getActivity() instanceof MainRoomActivity){
                    ((MainRoomActivity)getActivity()).showFragment(fragment);
                }
            }
        });

        mNewAlbumLv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 跳转到专辑界面
                CloudAlbumFragment fragment = new CloudAlbumFragment();
                Bundle bundle = new Bundle();
                bundle.putString("type","专辑");
                fragment.setArguments(bundle);
                if (getActivity() instanceof MainRoomActivity){
                    ((MainRoomActivity)getActivity()).showFragment(fragment);
                }
            }
        });

        mNewSongLv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 跳转到新歌推荐界面
                CloudMusicListNewSongFragment fragment = new CloudMusicListNewSongFragment();
                if (getActivity() instanceof MainRoomActivity){
                    ((MainRoomActivity)getActivity()).showFragment(fragment);
                }
            }
        });
    }

    @Override
    public void onLazyLoad() {
        initData();
    }

    @Override
    public void initData() {
        requestCloudResourceRecommand();

        requestCloudResource();
    }

    @Override
    public void onRetryLoad() {
        super.onRetryLoad();
        // 若数据为空，则再次尝试获取数据
        if (mMusicLoadService == null){
            requestCloudResource();
        }

        if (mAlbumLoadService == null) {
            requestCloudResourceRecommand();
        }
    }

    @Override
    public void onAlbumItemClick(CloudAlbumSet albumItem) {
        // 点击指定专辑后，跳转到指定专辑界面
        CloudMusicListAlbumFragment musiclistFragment = new CloudMusicListAlbumFragment();
        musiclistFragment.updateAlbumSet(albumItem);
        if (getActivity() instanceof MainRoomActivity){
            ((MainRoomActivity)getActivity()).showFragment(musiclistFragment);
        }
    }

    @Override
    public void onSongItemClick(List<CloudMusic> itemList, CloudMusic songItem) {
        // 点击推荐歌曲的某歌曲，开始播放
        WRoom.cmdPlayCloudMusicList(songItem,itemList,new CmdActionLister<>(NetMusicHomeFragment.this, new ICmdCallback<Boolean>() {
            @Override
            public void onSuccess(Boolean data) {

            }

            @Override
            public void onFailed(int code, String msg) {
                Toast.makeText(getContext(), "播放歌曲失败...", Toast.LENGTH_SHORT).show();
            }
        }));
    }

    @Override
    public void onSongItemMoreClick(CloudMusic songItem) {
        // 点击推荐歌曲的某Item项的更多按钮时，弹出更多选项框
        CloudMusicMoreDialog moreDialog = new CloudMusicMoreDialog();
        Bundle bundle = new Bundle();
        bundle.putString("music",songItem.toString());
        moreDialog.setArguments(bundle);
        moreDialog.show(getChildFragmentManager(),CloudMusicMoreDialog.TAG);
    }

    /********************************    **************************************/
    public void showLoadCallBack(LoadService loadService,Class<? extends Callback> callback){
        if (loadService != null){
            loadService.showCallback(callback);
        }
    }


    public void updateAlbumDataList(CloudMusicRecommed cloudMusicRecommed){
        if( (cloudMusicRecommed != null) && (cloudMusicRecommed.album != null) ){
            mCloudMusicRecommed = cloudMusicRecommed;

            mCloudAlbumAdapter.updateDataList(new ArrayList<>(cloudMusicRecommed.album.cn));
            mCloudAlbumAdapter.notifyDataSetChanged();

            showLoadCallBack(mAlbumLoadService,SuccessCallback.class);
        }else{
            showLoadCallBack(mAlbumLoadService,EmptyCallback.class);
        }
    }

    public void updateMusicDataList(List<CloudMusic> list){
        if (list != null){
            mMusiclist = list;

            mCloudSongAdapter.updateDataList(new ArrayList<>(list));
            mCloudSongAdapter.notifyDataSetChanged();

            showLoadCallBack(mMusicLoadService,SuccessCallback.class);
        }else{
            showLoadCallBack(mMusicLoadService,EmptyCallback.class);
        }
    }

    public void requestCloudResourceRecommand() {
        showLoadCallBack(mAlbumLoadService,LoadingCallback.class);

        WRoom.cmdGetRecommend(new CmdActionLister<CloudMusicRecommed>(this, new ICmdCallback<CloudMusicRecommed>() {
            @Override
            public void onSuccess(CloudMusicRecommed data) {
                updateAlbumDataList(data);
            }

            @Override
            public void onFailed(int code, String msg) {
                updateAlbumDataList(null);
                Toast.makeText(getContext(),"GetRecommend获取失败:"+code,Toast.LENGTH_SHORT).show();
            }
        }));
    }

    public void requestCloudResource() {
        showLoadCallBack(mMusicLoadService,LoadingCallback.class);

        WRoom.cmdGetNewSong("nd", new CmdActionLister<List<CloudMusic>>(this, new ICmdCallback<List<CloudMusic>>() {
            @Override
            public void onSuccess(List<CloudMusic> data) {
                updateMusicDataList(data);
            }

            @Override
            public void onFailed(int code, String msg) {
                updateMusicDataList(null);
                Toast.makeText(getContext(),"GetNewSong获取失败:"+code,Toast.LENGTH_SHORT).show();
            }
        }));
    }

}

