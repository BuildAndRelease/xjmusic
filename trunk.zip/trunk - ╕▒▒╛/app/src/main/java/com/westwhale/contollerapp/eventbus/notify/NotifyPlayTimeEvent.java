package com.westwhale.contollerapp.eventbus.notify;

public class NotifyPlayTimeEvent {
    private int mPlayTime;

    public NotifyPlayTimeEvent(int playtime){
        mPlayTime = playtime;
    }
    public int getPlayTime() {
        return mPlayTime;
    }
}
