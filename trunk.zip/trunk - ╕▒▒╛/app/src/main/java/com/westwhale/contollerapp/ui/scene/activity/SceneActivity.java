package com.westwhale.contollerapp.ui.scene.activity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.ImageView;

import com.blankj.utilcode.util.LogUtils;
import com.blankj.utilcode.util.ToastUtils;
import com.scwang.smartrefresh.layout.api.RefreshLayout;
import com.scwang.smartrefresh.layout.listener.OnRefreshListener;
import com.westwhale.api.protocolapi.bean.Talk;
import com.westwhale.api.protocolapi.bean.hostroom.Room;
import com.westwhale.api.protocolapi.bean.scene.Scene;
import com.westwhale.contollerapp.R;
import com.westwhale.contollerapp.application.WApp;
import com.westwhale.contollerapp.dev.CmdActionLister;
import com.westwhale.contollerapp.dev.ICmdCallback;
import com.westwhale.contollerapp.dev.WRoom;
import com.westwhale.contollerapp.ui.base.activity.BaseActivity;
import com.westwhale.contollerapp.ui.scene.adapter.SceneAdapter;
import com.westwhale.contollerapp.ui.talk.adapter.TalkExpandItemAdapter;

import java.util.ArrayList;
import java.util.List;

public class SceneActivity extends BaseActivity implements SceneAdapter.CallBack {

    public static final int REQUEST_CODE_SCENE_NEW = 1;
    public static final int REQUEST_CODE_SCENE_EDIT = 2;

    private Toolbar mToolbar;
    private ImageView mManageIv,mAddIv;
    private RecyclerView mDataRv;
    private SceneAdapter mAdapter;
    private RefreshLayout mRefreshLayout;

    private int mSceneNum = 0;
    private int mSceneMode = SceneAdapter.ITEM_MODE_NORMAL;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_scene_info);

        initView();
        initListener();

        updateSceneMode(SceneAdapter.ITEM_MODE_NORMAL);

        initData();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if ((requestCode == REQUEST_CODE_SCENE_NEW) && (resultCode == Activity.RESULT_OK)) {
            initData();
        }else if ((requestCode == REQUEST_CODE_SCENE_EDIT) && (resultCode == Activity.RESULT_OK)) {
            initData();
        }
    }

    @Override
    public void onItemClick(Scene item) {
        if ( (SceneAdapter.ITEM_MODE_NORMAL == mSceneMode) && (item != null) ){
            // 进入场景编辑界面
            Intent intent = new Intent(SceneActivity.this, SceneAddEditActivity.class);
            intent.putExtra(SceneAddEditActivity.REQUEST_KEY_SCENEID,item.sceneId);
            intent.putExtra(SceneAddEditActivity.REQUEST_KEY_SCENENAME,item.sceneName);

            startActivityForResult(intent,REQUEST_CODE_SCENE_EDIT);
        }
    }

    @Override
    public void onItemStatClick(Scene item) {
        if ( (SceneAdapter.ITEM_MODE_NORMAL == mSceneMode) && (item != null) ){
            // 执行场景
            WRoom room = WApp.Instance.getDevManager().getSelectedRoom();
            if (room != null){
                WRoom.cmdExecuteScene(item.sceneId,new CmdActionLister<Boolean>(SceneActivity.this, new ICmdCallback<Boolean>() {
                    @Override
                    public void onSuccess(Boolean data) {
                    }

                    @Override
                    public void onFailed(int code, String msg) {
                        ToastUtils.showShort("执行场景%d,失败：%d",item.sceneId,code);
                    }
                }));
            }
        }
    }

    @Override
    public void onItemDeleteClick(Scene item) {
        if ( (SceneAdapter.ITEM_MODE_DELETE == mSceneMode) && (item != null) ){
            // 删除场景
            WRoom room = WApp.Instance.getDevManager().getSelectedRoom();
            if (room != null){
                WRoom.cmdDelScene(item.sceneId,new CmdActionLister<Boolean>(SceneActivity.this, new ICmdCallback<Boolean>() {
                    @Override
                    public void onSuccess(Boolean data) {
                        if (data){
                            removeScene(item.sceneId);
                        }
                    }

                    @Override
                    public void onFailed(int code, String msg) {

                    }
                }));
            }
        }
    }

    private void initView() {
        mToolbar = findViewById(R.id.scene_info_toolbar);
        // 设置toolbar
        setSupportActionBar(mToolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        mManageIv = findViewById(R.id.scene_info_edit);
        mAddIv = findViewById(R.id.scene_info_add);

        mDataRv = findViewById(R.id.scene_info_recylerview);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        mDataRv.setLayoutManager(linearLayoutManager);
        mAdapter = new SceneAdapter();
        mAdapter.setCallBack(this);
        mDataRv.setAdapter(mAdapter);
        mDataRv.setHasFixedSize(true);
        // 设置下拉上拉无阴影效果
        mDataRv.setOverScrollMode(View.OVER_SCROLL_NEVER);
        mDataRv.addItemDecoration(new DividerItemDecoration(this, DividerItemDecoration.VERTICAL));

        mRefreshLayout = findViewById(R.id.scene_info_refreshlayout);
        mRefreshLayout.setDisableContentWhenRefresh(true);
        mRefreshLayout.setEnableLoadMore(false);
    }

    private void initListener() {
        mToolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mSceneMode == SceneAdapter.ITEM_MODE_NORMAL){
                    onBackPressed();
                }else{
                    updateSceneMode(SceneAdapter.ITEM_MODE_NORMAL);
                }
            }
        });

        mManageIv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int mode = SceneAdapter.ITEM_MODE_NORMAL;
                if (mSceneMode == SceneAdapter.ITEM_MODE_NORMAL){
                    mode = SceneAdapter.ITEM_MODE_DELETE;
                }
                updateSceneMode(mode);
            }
        });

        mAddIv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 进入新建场景界面
                startActivityForResult(new Intent(SceneActivity.this, SceneAddEditActivity.class),REQUEST_CODE_SCENE_NEW);
            }
        });


        mRefreshLayout.setOnRefreshListener(new OnRefreshListener() {
            @Override
            public void onRefresh(@NonNull RefreshLayout refreshLayout) {
                initData();
            }
        });
    }

    private void initData() {
        mAdapter.removeAll();
        requestData();
    }


    private void removeScene(int sceneId){
        mAdapter.removeSceneItem(sceneId);

        updateSceneNum(mAdapter.getItemCount());
    }

    private void updateSceneMode(int mode){
        mSceneMode = mode;

        updateToolbarTitle();

        mManageIv.setVisibility(View.GONE);
        mAddIv.setVisibility(View.GONE);
        if (mSceneMode == TalkExpandItemAdapter.ITEM_MODE_NORMAL){
            mManageIv.setVisibility(View.VISIBLE);
            mAddIv.setVisibility(View.VISIBLE);
        }

        mAdapter.setItemMode(mSceneMode);
        mAdapter.notifyItemRangeChanged(0,mAdapter.getItemCount());
    }


    private void updateSceneNum(int num){
        mSceneNum = num;
        updateToolbarTitle();
    }

    private void updateToolbarTitle(){
        String title = "";
        if (mSceneMode == SceneAdapter.ITEM_MODE_NORMAL){
            title = title + getString(R.string.scene_info_title);
        }else{
            title = title + getString(R.string.scene_info_title_manager);
        }

        title = title + "(" + mSceneNum + ")";
        mToolbar.setTitle(title);
    }

    private void updateDataList(List<Scene> sceneList) {
        if (sceneList != null){
            updateSceneNum(sceneList.size());

            mAdapter.setDataList(sceneList);
            mAdapter.notifyDataSetChanged();
        }

        mRefreshLayout.finishRefresh();
    }

    private void requestData(){
        WRoom room = WApp.Instance.getDevManager().getSelectedRoom();
        if (room != null){
            WRoom.cmdGetSceneList(new CmdActionLister<List<Scene>>(SceneActivity.this, new ICmdCallback<List<Scene>>() {
                @Override
                public void onSuccess(List<Scene> data) {
                    updateDataList(data);
                }

                @Override
                public void onFailed(int code, String msg) {
                    updateDataList(null);
                }
            }));
        }
    }

}
