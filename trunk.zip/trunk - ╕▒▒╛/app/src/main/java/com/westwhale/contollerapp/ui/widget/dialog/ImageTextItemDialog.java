package com.westwhale.contollerapp.ui.widget.dialog;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.DialogFragment;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Adapter;
import android.widget.SeekBar;
import android.widget.TextView;

import com.westwhale.contollerapp.R;
import com.westwhale.contollerapp.common.ImageTextItem;
import com.westwhale.contollerapp.ui.base.dialog.AttachDialogFragment;
import com.westwhale.contollerapp.ui.widget.adapter.ImageTextItemAdapter;
import com.westwhale.contollerapp.ui.widget.interfs.DialogResultListener;

import java.util.List;


public class ImageTextItemDialog extends AttachDialogFragment implements ImageTextItemAdapter.CallBack {
    public static final String TAG = ImageTextItemDialog.class.getName();

    public static final String DIALOG_TITLE = "title";

    private TextView mTitleTv;
    private RecyclerView mDataRv;
    private ImageTextItemAdapter mAdapter;

    private DialogResultListener<ImageTextItem> mResultListener;

    private List<ImageTextItem> mDataList;
    public void setDataList(List<ImageTextItem> dataList){
        mDataList = dataList;
    }

    public void setOnDialogResultListener(DialogResultListener<ImageTextItem> listener){
        mResultListener = listener;
    }

    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // 背景色，动画效果，通过主题设置
        setStyle(DialogFragment.STYLE_NORMAL, R.style.CommonDialogStyle);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        //布局
        View view = inflater.inflate(R.layout.dialogfrag_imagetext, container);

        initView(view);
        initListener();

        initData();

        return view;
    }

    @Override
    public void onStart() {
        super.onStart();

        //设置fragment高度 、宽度
        double heightPercent = 0.5;
        double widthPercent = 0.85;
        int dialogHeight = (int) (mContext.getResources().getDisplayMetrics().heightPixels * heightPercent);
        int dialogWidth = (int) (mContext.getResources().getDisplayMetrics().widthPixels * widthPercent);
        Window window = getDialog().getWindow();
        if (window != null) {
            WindowManager.LayoutParams params = window.getAttributes();
            params.gravity = Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL;
            params.width = ViewGroup.LayoutParams.MATCH_PARENT;;
//            params.height = dialogHeight;
            params.height = ViewGroup.LayoutParams.WRAP_CONTENT;
            window.setAttributes(params);
        }
        getDialog().setCanceledOnTouchOutside(true);
    }

    @Override
    public void onItemClick(ImageTextItem item,int pos) {
        if (mResultListener != null){
            mResultListener.onResultListener(item);
        }

        dismiss();
    }

    private void initView(View view) {
        mTitleTv = view.findViewById(R.id.dialog_imagetext_title);

        mDataRv = view.findViewById(R.id.dialog_imagetext_recyclerview);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(mContext);
        mDataRv.setLayoutManager(linearLayoutManager);
        mAdapter = new ImageTextItemAdapter();
        mAdapter.setCallBack(this);
        mDataRv.setAdapter(mAdapter);
        mDataRv.setHasFixedSize(true);
        mDataRv.addItemDecoration(new DividerItemDecoration(mContext, DividerItemDecoration.VERTICAL));
        // 设置下拉上拉无阴影效果
        mDataRv.setOverScrollMode(View.OVER_SCROLL_NEVER);
    }

    private void initListener() {

    }

    private void initData() {
        String title = "";
        Bundle bundle = getArguments();
        if (getArguments() != null){
            title = bundle.getString(DIALOG_TITLE,"");
        }

        mTitleTv.setText(title);

        mAdapter.setDataList(mDataList);
        mAdapter.notifyDataSetChanged();
    }

}
