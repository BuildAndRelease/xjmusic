package com.westwhale.contollerapp.ui.cloudmusic.adapter;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.util.Base64;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.load.resource.bitmap.RoundedCorners;
import com.bumptech.glide.request.RequestOptions;
import com.westwhale.contollerapp.R;
import com.westwhale.api.protocolapi.bean.cloudmusic.TopCate;

import java.util.ArrayList;
import java.util.List;

/**
 * Description:
 * Author: chenyaoli
 * Date: 2018-12-06
 * History:
 */
public class CloudRankAdatper extends RecyclerView.Adapter{
    private final int ITEM_TYPE_PARENT = 0;
    private final int ITEM_TYPE_ITEM = 1;
    private final int ITEM_TYPE_DEFAULT = 2;

    private List<Object> mItemList = new ArrayList<>();
    private CallBack mCallBack;

    public CloudRankAdatper(CallBack callBack){
        this.mCallBack = callBack;
    }

    public interface CallBack{
        void onRankItemClick(TopCate.CloudToplistSet rankItem);
    }

    public void updateDataList(List<TopCate> dataList){
        mItemList.clear();
        for (int i=0; i < dataList.size(); i++){
            TopCate topCate = dataList.get(i);
            mItemList.add(topCate.cateItemName);
            mItemList.addAll(topCate.cloudToplistSets);
        }
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        switch (getItemViewType(i)){
            case ITEM_TYPE_PARENT:
                // 默认返回 HOST 类型的 viewHolder
                View view1 = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_netmusic_rank_tv, viewGroup, false);
                return new CloudRankCateItemHolder(view1);
            case ITEM_TYPE_ITEM:
                View view2 = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_netmusic_rank, viewGroup, false);
                return new CloudRankItemHolder(view2);
            default:
                View view3 = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_netmusic_rank_tv, viewGroup, false);
                return new CloudRankCateItemHolder(view3);
        }
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder viewHolder, int i) {
        switch (getItemViewType(i)){
            case ITEM_TYPE_PARENT:
                String text = "";
                if (mItemList.get(i) instanceof String){
                    text = mItemList.get(i).toString();
                }
                CloudRankCateItemHolder itemHolder = (CloudRankCateItemHolder)viewHolder;
                itemHolder.mCateNameTv.setText(text);

                break;
            case ITEM_TYPE_ITEM:
                if (mItemList.get(i) instanceof TopCate.CloudToplistSet){
                    TopCate.CloudToplistSet item = (TopCate.CloudToplistSet)mItemList.get(i);
                    CloudRankItemHolder itemHolder1 = (CloudRankItemHolder)viewHolder;
                    String firstText = "";
                    if (item.songList.size() > 0){
                        firstText = "1." + item.songList.get(0).song + "-" + item.songList.get(0).singer;
                    }
                    itemHolder1.mFirstSongTv.setText(firstText);
                    String secondText = "";
                    if (item.songList.size() > 1){
                        secondText = "2." + item.songList.get(1).song + "-" + item.songList.get(1).singer;
                    }
                    itemHolder1.mSecondSongTv.setText(secondText);
                    String thirdText = "";
                    if (item.songList.size() > 2){
                        thirdText = "3." + item.songList.get(2).song + "-" + item.songList.get(2).singer;
                    }
                    itemHolder1.mThirdSongTv.setText(thirdText);

                    // 首先 base64 解码
                    String pic = (item.picurl != null) ? item.picurl : "";
                    String url = new String(Base64.decode(pic.getBytes(), Base64.DEFAULT));
                    //设置图片圆角角度
                    RoundedCorners roundedCorners= new RoundedCorners(6);
                    //通过RequestOptions扩展功能,override:采样率,因为ImageView就这么大,可以压缩图片,降低内存消耗
                    RequestOptions mRequestOptions = RequestOptions.bitmapTransform(roundedCorners).diskCacheStrategy(DiskCacheStrategy.NONE) //不做磁盘缓存
                            .placeholder(R.drawable.cloud_album_default)  //未加载图片之前显示的图片
                            .error(R.drawable.cloud_album_default)     //错误时显示的图片
                            .override(350, 350);
//                      .skipMemoryCache(true);//不做内存缓存
                    Glide.with(itemHolder1.itemView)
                            .load(url)
                            .apply(mRequestOptions)
                            .into(itemHolder1.mRankItemPicIv);

                    viewHolder.itemView.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            mCallBack.onRankItemClick(item);
                        }
                    });
                }

            default:
                break;
        }
    }

    @Override
    public int getItemCount() {
        return mItemList.size();
    }

    @Override
    public int getItemViewType(int position) {
        if (mItemList.get(position) instanceof String){
            return ITEM_TYPE_PARENT;
        }else if (mItemList.get(position) instanceof TopCate.CloudToplistSet){
            return ITEM_TYPE_ITEM;
        }
        return ITEM_TYPE_DEFAULT;
    }

    private class CloudRankCateItemHolder extends RecyclerView.ViewHolder{
        TextView mCateNameTv;
        public CloudRankCateItemHolder(@NonNull View itemView) {
            super(itemView);
            mCateNameTv = itemView.findViewById(R.id.item_netmusic_text);
        }
    }

    private class CloudRankItemHolder extends RecyclerView.ViewHolder{
        ImageView mRankItemPicIv;
        TextView mFirstSongTv,mSecondSongTv,mThirdSongTv;
        public CloudRankItemHolder(@NonNull View itemView) {
            super(itemView);
            mRankItemPicIv = itemView.findViewById(R.id.item_netmusic_rank_pic);
            mFirstSongTv = itemView.findViewById(R.id.item_netmusic_rank_one);
            mSecondSongTv = itemView.findViewById(R.id.item_netmusic_rank_two);
            mThirdSongTv = itemView.findViewById(R.id.item_netmusic_rank_three);
        }
    }
}