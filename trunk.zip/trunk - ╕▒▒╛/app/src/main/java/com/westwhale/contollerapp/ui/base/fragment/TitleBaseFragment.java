package com.westwhale.contollerapp.ui.base.fragment;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;

import com.kingja.loadsir.callback.Callback;
import com.kingja.loadsir.core.LoadService;
import com.kingja.loadsir.core.LoadSir;
import com.westwhale.contollerapp.R;
import com.westwhale.contollerapp.ui.loadsircallback.EmptyCallback;
import com.westwhale.contollerapp.ui.loadsircallback.ErrorCallback;
import com.westwhale.contollerapp.ui.loadsircallback.LoadingCallback;
import com.westwhale.contollerapp.ui.loadsircallback.TimeoutCallback;

public class TitleBaseFragment extends BaseFragment {
    protected LoadSir mLoadSir;
    protected LoadService mLoadService;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // 界面的加载等待框架配置
        mLoadSir = new LoadSir.Builder()
                .addCallback(new LoadingCallback())
                .addCallback(new TimeoutCallback())
                .addCallback(new ErrorCallback())
                .addCallback(new EmptyCallback())
                .setDefaultCallback(LoadingCallback.class)
                .build();
    }

    public void showLoadCallBack(Class<? extends Callback> callback){
        if (mLoadService != null){
            mLoadService.showCallback(callback);
        }
    }

    public void configToolBar(Toolbar toolbar, String title){
        if (toolbar != null){
            if (getActivity() != null){
                ((AppCompatActivity) getActivity()).setSupportActionBar(toolbar);
                toolbar.setTitle(title);

                ActionBar actionBar = ((AppCompatActivity) getActivity()).getSupportActionBar();
                if (actionBar != null){
                    actionBar.setDisplayHomeAsUpEnabled(true);
                    actionBar.setHomeAsUpIndicator(R.drawable.home_backup);
                }
            }

            toolbar.setNavigationOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (getActivity() != null){
                        getActivity().onBackPressed();
                    }
                }
            });
        }
    }

}
