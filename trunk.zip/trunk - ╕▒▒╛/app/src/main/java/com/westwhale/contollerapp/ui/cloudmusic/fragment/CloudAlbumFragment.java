package com.westwhale.contollerapp.ui.cloudmusic.fragment;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.kingja.loadsir.callback.Callback;
import com.kingja.loadsir.callback.SuccessCallback;
import com.scwang.smartrefresh.layout.api.RefreshLayout;
import com.scwang.smartrefresh.layout.listener.OnLoadMoreListener;
import com.scwang.smartrefresh.layout.listener.OnRefreshListener;
import com.westwhale.contollerapp.R;
import com.westwhale.contollerapp.common.CodeNameGroup;
import com.westwhale.contollerapp.common.CodeNameItem;
import com.westwhale.contollerapp.dev.CmdActionLister;
import com.westwhale.contollerapp.dev.ICmdCallback;
import com.westwhale.contollerapp.dev.WRoom;
import com.westwhale.contollerapp.ui.main.MainRoomActivity;
import com.westwhale.contollerapp.ui.cloudmusic.adapter.CloudAlbumAdapter;
import com.westwhale.contollerapp.ui.cloudmusic.dialog.CloudAlbumCategoryDialog;
import com.westwhale.contollerapp.ui.base.fragment.TitleBaseFragment;
import com.westwhale.contollerapp.ui.loadsircallback.LoadingCallback;
import com.westwhale.api.protocolapi.bean.albumSet.CloudAlbumSet;

import java.util.ArrayList;
import java.util.List;

/**
 * Description:
 * Author: chenyaoli
 * Date: 2018-11-12
 * History:
 */
public class CloudAlbumFragment extends TitleBaseFragment implements CloudAlbumAdapter.CallBack {
    private String TAG = "CloudAlbumFragment";

    public static final int REQUEST_CODDE = 0;

    public static final String TYPE_TIME = "time";
    public static String TYPE_TIME_NAME = "时间";
    public static final String TYPE_AREA = "area";
    public static String TYPE_AREA_NAME = "地区";
    public static final String TYPE_INDEX = "index";
    public static String TYPE_INDEX_NAME = "索引";
    public static final String TYPE_TYPE = "type";
    public static String TYPE_TYPE_NAME = "类型";
    public static int DEFAULT_SORT = 1; // 1-发行时间    2-收听量   3-评分   4-下载品质

    private RecyclerView mDataRv;
    private TextView mAlbumTypeTv;
    private ImageView mCategoryIv;
    private Toolbar mToolBar;
    private RefreshLayout mRefreshLayout;

    private CloudAlbumAdapter mCloudAlbumAdapter;

    private ArrayList<CodeNameGroup> mCodeNameGroupList = new ArrayList<>();

    private int mCurPageNo = 1; //记录当前的页面数
    private int mPerPage = 50;
    private boolean mHasMoreData = true; // 记录是否还有更多数据

    private CodeNameItem mTimeItem;
    private CodeNameItem mAreaItem;
    private CodeNameItem mIndexItem;
    private CodeNameItem mTypeItem;


    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // 配置分类列表，同时初始化Item
        configCategory();
        for (int i=0; i < mCodeNameGroupList.size(); i++){
            CodeNameGroup CodeNameGroup = mCodeNameGroupList.get(i);
            CodeNameItem item = null;
            if ((CodeNameGroup != null) && (CodeNameGroup.mItemList != null) && (CodeNameGroup.mItemList.size() > 0)) {
                item = CodeNameGroup.mItemList.get(0);
            }
            if (item != null) {
                switch (item.mType) {
                    case TYPE_AREA:
                        mAreaItem = item;
                        break;
                    case TYPE_TIME:
                        mTimeItem = item;
                        break;
                    case TYPE_INDEX:
                        mIndexItem = item;
                        break;
                    case TYPE_TYPE:
                        mTypeItem = item;
                        break;
                    default:
                        break;
                }
            }
        }
    }

    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        // 先显示加载动画，针对布局做一些初始化
        return inflater.inflate(R.layout.frag_netmusic_album,container,false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        FrameLayout frameLayout = view.findViewById(R.id.netmusic_album_content_layout);

        // 创建mLoadService
        mLoadService = mLoadSir.register(frameLayout, new Callback.OnReloadListener() {
            @Override
            public void onReload(View v) {
//                mLoadService.showCallback(LoadingCallback.class);
                showLoadCallBack(LoadingCallback.class);
                initData();
            }
        });

        initView(view);

        initListener();

        initData();
    }

    @Override
    public void onResume() {
        super.onResume();
    }

    @Override
    public void onPause() {
        super.onPause();
    }

    @Override
    public void onAlbumItemClick(CloudAlbumSet albumItem) {
        // 点击指定专辑后，跳转到指定专辑界面
        CloudMusicListAlbumFragment musiclistFragment = new CloudMusicListAlbumFragment();
        musiclistFragment.updateAlbumSet(albumItem);
        ((MainRoomActivity)getActivity()).showFragment(musiclistFragment);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (REQUEST_CODDE == requestCode){
            mAreaItem = data.getParcelableExtra(CloudAlbumCategoryDialog.ALBUM_AREA);
            mIndexItem = data.getParcelableExtra(CloudAlbumCategoryDialog.ALBUM_INDEX);
            mTimeItem = data.getParcelableExtra(CloudAlbumCategoryDialog.ALBUM_TIME);
            mTypeItem = data.getParcelableExtra(CloudAlbumCategoryDialog.ALBUM_TYPE);

            initData();
        }
    }

    private void initView(View view) {
        mToolBar = view.findViewById(R.id.netmusic_album_toolbar);
        configToolBar(mToolBar,getResources().getString(R.string.cloudmusic_album_title));

        mDataRv = view.findViewById(R.id.netmusic_album_recylerview);
        GridLayoutManager gridLayoutManager = new GridLayoutManager(mContext, 3);
        mDataRv.setLayoutManager(gridLayoutManager);
        mCloudAlbumAdapter = new CloudAlbumAdapter(this);
        mDataRv.setAdapter(mCloudAlbumAdapter);
        mDataRv.setHasFixedSize(true);

        mRefreshLayout = view.findViewById(R.id.netmusic_album_refresh);
        mRefreshLayout.setDisableContentWhenRefresh(true);
        mRefreshLayout.setEnableLoadMore(true);

        mAlbumTypeTv = view.findViewById(R.id.netmusic_album_type);
        mCategoryIv = view.findViewById(R.id.netmusic_album_category);
    }

    private void initListener() {
        mCategoryIv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 弹出类型选择界面
                CloudAlbumCategoryDialog cloudCategoryDialog = new CloudAlbumCategoryDialog();
                cloudCategoryDialog.setCategoryGroupList(mCodeNameGroupList);
                cloudCategoryDialog.setSelectItems(mTimeItem,mAreaItem,mTypeItem,mIndexItem);
                //设置目标Fragment
                cloudCategoryDialog.setTargetFragment(CloudAlbumFragment.this, REQUEST_CODDE);
                if (getFragmentManager() != null) {
                    cloudCategoryDialog.show(getFragmentManager(), "CloudCategory_Dialog");
                }
            }
        });

        mRefreshLayout.setOnRefreshListener(new OnRefreshListener() {
            @Override
            public void onRefresh(@NonNull RefreshLayout refreshLayout) {
                initData();
            }
        });

        mRefreshLayout.setOnLoadMoreListener(new OnLoadMoreListener() {
            @Override
            public void onLoadMore(@NonNull RefreshLayout refreshLayout) {
                //  判断是否还有数据，从而判断是否还需要加载更多数据
                if (mHasMoreData){
                    mCurPageNo++;
                    requestCloudResource();
                }else {
                    mRefreshLayout.finishLoadMoreWithNoMoreData();
                }
            }
        });
    }

    private void initData() {
        updateCategoryContent();

        mCurPageNo = 1;
        mHasMoreData = true;

        // 每次先清空原有数据
        if (mCloudAlbumAdapter != null){
            mCloudAlbumAdapter.clearDataList();
        }

        requestCloudResource();
    }

    private void updateCategoryContent(){
        String area = (mAreaItem != null) ? mAreaItem.mName : "?";
        String type = (mTypeItem != null) ? mTypeItem.mName : "?";
        String index = (mIndexItem != null) ? mIndexItem.mName : "?";
        String time = (mTimeItem != null) ? mTimeItem.mName : "?";

        String category = area + "-" + type + "-" + time + "-" + index;
        mAlbumTypeTv.setText(category);
    }

    public void updateDataList(List<CloudAlbumSet> list){
        if (list != null){
            // 若无法获取到数据，则认为已经到底
            int size = list.size();

            if (mCurPageNo == 0) {
                mCloudAlbumAdapter.clearDataList();
            }

            if (size != 0){
                int startIndex = mCloudAlbumAdapter.getItemCount();
                mCloudAlbumAdapter.addToDataList(list);
                mCloudAlbumAdapter.notifyItemRangeInserted(startIndex,size);
            }else{
                mHasMoreData = false;
            }

            // 更新刷新等待状态
            mRefreshLayout.finishRefresh();
            mRefreshLayout.finishLoadMore();

            showLoadCallBack(SuccessCallback.class);
        }else{
            // 当获取数据失败时，则认为无数据了
            mHasMoreData = false;

            // 更新刷新等待状态
            mRefreshLayout.finishRefresh();
            mRefreshLayout.finishLoadMore();

            showLoadCallBack(SuccessCallback.class);
        }
    }

    public void requestCloudResource() {

        String code = (mTimeItem != null) ? mTimeItem.mCode : "";
        int time = Integer.parseInt(code);
        code = (mAreaItem != null) ? mAreaItem.mCode : "";
        int area = Integer.parseInt(code);
        code = (mTypeItem != null) ? mTypeItem.mCode : "";
        int type = Integer.parseInt(code);
        code = (mIndexItem != null) ? mIndexItem.mCode : "";
        int index = Integer.parseInt(code);

        int sort = DEFAULT_SORT;
        int perpage = mPerPage;
        int pageNo = mCurPageNo;

        WRoom.cmdGetAlbum(time,area,type,index,sort,perpage,pageNo, new CmdActionLister<List<CloudAlbumSet>>(this, new ICmdCallback<List<CloudAlbumSet>>() {
            @Override
            public void onSuccess(List<CloudAlbumSet> data) {
                updateDataList(data);
            }

            @Override
            public void onFailed(int code, String msg) {
                updateDataList(null);
                Toast.makeText(getContext(),"GetAlbum获取失败:"+code,Toast.LENGTH_SHORT).show();
            }
        }));
    }


    /*********************************************  内部类型类 *********************************************/
    public void configCategory(){

        CodeNameGroup codeNameGroup = null;
        ArrayList<CodeNameItem> itemList = null;

        // area-区域   {"全部", "国语", "粤语", "台语", "英文", "日语", "韩语", "法语", "西班牙语", "德语", "俄语", "其他"};
        codeNameGroup = new CodeNameGroup();
        itemList = new ArrayList<>();
        codeNameGroup.mType = TYPE_AREA;
        codeNameGroup.mTypeName = TYPE_AREA_NAME;
        itemList.add(new CodeNameItem(TYPE_AREA,"全部","0"));
        itemList.add(new CodeNameItem(TYPE_AREA,"国语","1"));
        itemList.add(new CodeNameItem(TYPE_AREA,"粤语","2"));
        itemList.add(new CodeNameItem(TYPE_AREA,"台语","3"));
        itemList.add(new CodeNameItem(TYPE_AREA,"英文","4"));
        itemList.add(new CodeNameItem(TYPE_AREA,"日语","5"));
        itemList.add(new CodeNameItem(TYPE_AREA,"韩语","6"));
        itemList.add(new CodeNameItem(TYPE_AREA,"法语","7"));
        itemList.add(new CodeNameItem(TYPE_AREA,"西班牙语","8"));
        itemList.add(new CodeNameItem(TYPE_AREA,"德语","9"));
        itemList.add(new CodeNameItem(TYPE_AREA,"俄语","10"));
        itemList.add(new CodeNameItem(TYPE_AREA,"其他","11"));

        codeNameGroup.mItemList = itemList;
        mCodeNameGroupList.add(codeNameGroup);

        // type-类型   {"全部", "流行", "摇滚", "R&B", "乡村", "新世纪", "嘻哈", "世界", "布鲁斯", "爵士", "民谣", "拉丁", "雷鬼", "金属", "儿童", "影视", "游戏", "动漫", "舞曲", "网络", "古典", "轻音乐", "民歌", "经典", "对唱", "胎教音乐"};
        codeNameGroup = new CodeNameGroup();
        codeNameGroup.mType = TYPE_TYPE;
        codeNameGroup.mTypeName = TYPE_TYPE_NAME;
        itemList = new ArrayList<>();
        itemList.add(new CodeNameItem(TYPE_TYPE,"全部","0"));
        itemList.add(new CodeNameItem(TYPE_TYPE,"流行","1"));
        itemList.add(new CodeNameItem(TYPE_TYPE,"摇滚","2"));
        itemList.add(new CodeNameItem(TYPE_TYPE,"R&B","3"));
        itemList.add(new CodeNameItem(TYPE_TYPE,"乡村","4"));
        itemList.add(new CodeNameItem(TYPE_TYPE,"新世纪","5"));
        itemList.add(new CodeNameItem(TYPE_TYPE,"嘻哈","6"));
        itemList.add(new CodeNameItem(TYPE_TYPE,"世界","7"));
        itemList.add(new CodeNameItem(TYPE_TYPE,"布鲁斯","8"));
        itemList.add(new CodeNameItem(TYPE_TYPE,"爵士","9"));
        itemList.add(new CodeNameItem(TYPE_TYPE,"民谣","10"));
        itemList.add(new CodeNameItem(TYPE_TYPE,"拉丁","11"));
        itemList.add(new CodeNameItem(TYPE_TYPE,"雷鬼","12"));
        itemList.add(new CodeNameItem(TYPE_TYPE,"金属","13"));
        itemList.add(new CodeNameItem(TYPE_TYPE,"儿童","14"));
        itemList.add(new CodeNameItem(TYPE_TYPE,"影视","15"));
        itemList.add(new CodeNameItem(TYPE_TYPE,"游戏","16"));
        itemList.add(new CodeNameItem(TYPE_TYPE,"动漫","17"));
        itemList.add(new CodeNameItem(TYPE_TYPE,"舞曲","18"));
        itemList.add(new CodeNameItem(TYPE_TYPE,"网络","19"));
        itemList.add(new CodeNameItem(TYPE_TYPE,"古典","20"));
        itemList.add(new CodeNameItem(TYPE_TYPE,"轻音乐","21"));
        itemList.add(new CodeNameItem(TYPE_TYPE,"民歌","22"));
        itemList.add(new CodeNameItem(TYPE_TYPE,"经典","23"));
        itemList.add(new CodeNameItem(TYPE_TYPE,"对唱","24"));
        itemList.add(new CodeNameItem(TYPE_TYPE,"胎教音乐","25"));

        codeNameGroup.mItemList = itemList;
        mCodeNameGroupList.add(codeNameGroup);


        // time-时间    {"全部", "最近七天", "最近一月", "最近一季"};
        codeNameGroup = new CodeNameGroup();
        itemList = new ArrayList<>();
        codeNameGroup.mType = TYPE_TIME;
        codeNameGroup.mTypeName = TYPE_TIME_NAME;
        itemList.add(new CodeNameItem(TYPE_TIME,"全部","0"));
        itemList.add(new CodeNameItem(TYPE_TIME,"最近七天","1"));
        itemList.add(new CodeNameItem(TYPE_TIME,"最近一月","2"));
        itemList.add(new CodeNameItem(TYPE_TIME,"最近一季","3"));

        codeNameGroup.mItemList = itemList;
        mCodeNameGroupList.add(codeNameGroup);

        // index-索引    {"全部", "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z", "#"};
        codeNameGroup = new CodeNameGroup();
        itemList = new ArrayList<>();
        codeNameGroup.mType = TYPE_INDEX;
        codeNameGroup.mTypeName = TYPE_INDEX_NAME;
        itemList.add(new CodeNameItem(TYPE_INDEX,"全部","0"));
        itemList.add(new CodeNameItem(TYPE_INDEX,"A","1"));
        itemList.add(new CodeNameItem(TYPE_INDEX,"B","2"));
        itemList.add(new CodeNameItem(TYPE_INDEX,"C","3"));
        itemList.add(new CodeNameItem(TYPE_INDEX,"D","4"));
        itemList.add(new CodeNameItem(TYPE_INDEX,"E","5"));
        itemList.add(new CodeNameItem(TYPE_INDEX,"F","6"));
        itemList.add(new CodeNameItem(TYPE_INDEX,"G","7"));
        itemList.add(new CodeNameItem(TYPE_INDEX,"H","8"));
        itemList.add(new CodeNameItem(TYPE_INDEX,"I","9"));
        itemList.add(new CodeNameItem(TYPE_INDEX,"J","10"));
        itemList.add(new CodeNameItem(TYPE_INDEX,"K","11"));
        itemList.add(new CodeNameItem(TYPE_INDEX,"L","12"));
        itemList.add(new CodeNameItem(TYPE_INDEX,"M","13"));
        itemList.add(new CodeNameItem(TYPE_INDEX,"N","14"));
        itemList.add(new CodeNameItem(TYPE_INDEX,"O","15"));
        itemList.add(new CodeNameItem(TYPE_INDEX,"P","16"));
        itemList.add(new CodeNameItem(TYPE_INDEX,"Q","17"));
        itemList.add(new CodeNameItem(TYPE_INDEX,"R","18"));
        itemList.add(new CodeNameItem(TYPE_INDEX,"S","19"));
        itemList.add(new CodeNameItem(TYPE_INDEX,"T","20"));
        itemList.add(new CodeNameItem(TYPE_INDEX,"U","21"));
        itemList.add(new CodeNameItem(TYPE_INDEX,"V","22"));
        itemList.add(new CodeNameItem(TYPE_INDEX,"W","23"));
        itemList.add(new CodeNameItem(TYPE_INDEX,"X","24"));
        itemList.add(new CodeNameItem(TYPE_INDEX,"Y","25"));
        itemList.add(new CodeNameItem(TYPE_INDEX,"Z","26"));
        itemList.add(new CodeNameItem(TYPE_INDEX,"#","27"));

        codeNameGroup.mItemList = itemList;
        mCodeNameGroupList.add(codeNameGroup);
    }

}
