package com.westwhale.contollerapp.ui.scene.activity;


import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.Toolbar;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.alibaba.fastjson.JSON;
import com.blankj.utilcode.util.ToastUtils;
import com.westwhale.api.protocolapi.bean.scene.RoomSceneAction;
import com.westwhale.api.protocolapi.bean.scene.Scene;
import com.westwhale.contollerapp.R;
import com.westwhale.contollerapp.application.WApp;
import com.westwhale.contollerapp.dev.CmdActionLister;
import com.westwhale.contollerapp.dev.ICmdCallback;
import com.westwhale.contollerapp.dev.WRoom;
import com.westwhale.contollerapp.ui.base.activity.BaseActivity;
import com.westwhale.contollerapp.ui.base.fragment.BaseFragment;
import com.westwhale.contollerapp.ui.scene.fragment.RoomSceneActionFragment;
import com.westwhale.contollerapp.utils.CommonUtils;

import java.util.ArrayList;


public class SceneAddEditActivity extends BaseActivity  {
    public final static String TAG = SceneAddEditActivity.class.getName();

    public final static String REQUEST_KEY_SCENEID = "sceneId";
    public final static String REQUEST_KEY_SCENENAME = "sceneName";

    private final int SCENE_MODE_NEW = 0;
    private final int SCENE_MODE_EDIT = 1;

    private Toolbar mToolbar;
    private EditText mNameEdit;
    private ImageView mSceneOkIv;

    private int mSceneMode = SCENE_MODE_NEW;
    private String mSelectedRoomId = "";

    private Scene mCurrentScene = null;
    private RoomSceneActionFragment mRoomSceneActionFragment = null;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_scene_addedit);

        initSceneModeInfo();

        initView();
        initListener();

        initData();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        hideSoftwareInputWindows();

        super.onBackPressed();
    }

    private void initSceneModeInfo() {
        // 默认值
        if (isOneRoomId()) {
            mSelectedRoomId = (WApp.Instance.getDevManager().getSelectedRoom() != null) ? WApp.Instance.getDevManager().getSelectedRoom().getRoomId() : "";
        }

        int sceneId = -1;
        String sceneName = "";
        Intent intent = getIntent();
        if (intent != null){
            sceneId = intent.getIntExtra(REQUEST_KEY_SCENEID,-1);
            sceneName  = intent.getStringExtra(REQUEST_KEY_SCENENAME);
        }

        mCurrentScene = new Scene();
        mCurrentScene.sceneId = -1;
        if (sceneId == -1){
            mSceneMode = SCENE_MODE_NEW;
            mCurrentScene.sceneName = getString(R.string.scene_addedit_defaultname);
            mCurrentScene.actionList = null;
            if (isOneRoomId()) {
                mCurrentScene.actionList = new ArrayList<>();
                RoomSceneAction roomSceneAction = new RoomSceneAction();
                roomSceneAction.roomId = mSelectedRoomId;
                mCurrentScene.actionList.add(roomSceneAction);
            }
        }else{
            mSceneMode = SCENE_MODE_EDIT;
            mCurrentScene.sceneId = sceneId;
            mCurrentScene.sceneName = sceneName;
        }
    }

    private void initView() {
        mToolbar = findViewById(R.id.scene_addedit_toolbar);
        // 设置toolbar
        setSupportActionBar(mToolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        mSceneOkIv = findViewById(R.id.scene_addedit_ok_iv);
        mNameEdit = findViewById(R.id.scene_addedit_scenename_edit);

    }

    private void initListener() {
        mToolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        mSceneOkIv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 确定按钮
                String sceneName = mNameEdit.getText().toString();
                if (sceneName.isEmpty()){
                    ToastUtils.showShort("场景名为空");
                    return;
                }

                if (isOneRoomId() && (mRoomSceneActionFragment != null)) {
                    updateRoomSceneActionList(mSelectedRoomId, mRoomSceneActionFragment.getActionList());
                }
                if (mCurrentScene == null){
                    return;
                }
                if (mSceneMode == SCENE_MODE_EDIT) {
                    WRoom room = WApp.Instance.getDevManager().getSelectedRoom();
                    if (room != null) {
                        String editName = mNameEdit.getText().toString();
                        if (!editName.equals(mCurrentScene.sceneName)){
                            mCurrentScene.sceneName = editName;
                            WRoom.cmdRenameScene(mCurrentScene.sceneId, editName, null);
                        }

                        WRoom.cmdSetActionListToScene(mCurrentScene.sceneId, mCurrentScene.actionList, new CmdActionLister<Boolean>(SceneAddEditActivity.this, new ICmdCallback<Boolean>() {
                            @Override
                            public void onSuccess(Boolean data) {
                                setResult(Activity.RESULT_OK);

                                finish();
                            }

                            @Override
                            public void onFailed(int code, String msg) {
                                ToastUtils.showShort("修改场景失败:"+code);
                            }
                        }));
                    }
                }else if (mSceneMode == SCENE_MODE_NEW){
                    // 更新场景名称
                    mCurrentScene.sceneName = mNameEdit.getText().toString();
                    WRoom room = WApp.Instance.getDevManager().getSelectedRoom();
                    if (room != null) {
                        WRoom.cmdAddSceneWithAction(mCurrentScene.sceneName, mCurrentScene.actionList, new CmdActionLister<Boolean>(SceneAddEditActivity.this, new ICmdCallback<Boolean>() {
                            @Override
                            public void onSuccess(Boolean data) {
                                setResult(Activity.RESULT_OK);

                                finish();
                            }

                            @Override
                            public void onFailed(int code, String msg) {
                                ToastUtils.showShort("添加场景失败:"+code);
                            }
                        }));
                    }
                }
            }
        });

        mNameEdit.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                // 完成
                if (actionId == EditorInfo.IME_ACTION_DONE){
                    String text = mNameEdit.getText().toString();
                    // 在编辑模式下，更改了场景名，需要及时发送更改的CMD
//                    if ((mSceneMode == SCENE_MODE_EDIT) && (mCurrentScene != null)){
//                        WRoom room = WApp.Instance.getDevManager().getSelectedRoom();
//                        if (room != null) {
//                            WRoom.cmdRenameScene(mCurrentScene.sceneId, text, null);
//                        }
//                    }
//                    if (mCurrentScene != null){
//                        mCurrentScene.sceneName = text;
//                    }
                    mNameEdit.clearFocus();

                    hideSoftwareInputWindows();

                    return true;
                }

                return false;
            }
        });
    }

    private void initData() {
        int titleResourceId = R.string.scene_addedit_add_title;
        if (mSceneMode == SCENE_MODE_EDIT){
            titleResourceId = R.string.scene_addedit_edit_title;
        }
        mToolbar.setTitle(titleResourceId);

        if (mCurrentScene != null) {
            mNameEdit.setText(mCurrentScene.sceneName);
        }

        // 判断是否直接显示场景的动作列表（针对单房间，直接显示场景列表）
        mRoomSceneActionFragment = null;
        if (isOneRoomId()){
            showActionListFragment();
        }else{
            //显示房间列表
            showRoomListFragment();
        }
    }

    private void updateSceneName(String sceneName) {
        mNameEdit.setText(sceneName);
    }

    private void hideSoftwareInputWindows(){
        // 隐藏时，把虚拟键盘隐藏
        InputMethodManager imm = (InputMethodManager)this.getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm != null) {
            imm.hideSoftInputFromWindow(mNameEdit.getWindowToken(), 0);
        }
    }

    private void updateDataList(Scene scene){
        if ((scene != null) && (scene.sceneId == mCurrentScene.sceneId)){
            mCurrentScene.actionList = scene.actionList;
            if (isOneRoomId()){
                String actionList = "";
                if ((scene.actionList == null) || (scene.actionList.size() == 0)) {
                    mCurrentScene.actionList = new ArrayList<>();
                    RoomSceneAction roomSceneAction = new RoomSceneAction();
                    roomSceneAction.roomId = mSelectedRoomId;
                    mCurrentScene.actionList.add(roomSceneAction);
                }

                try {
                    mSelectedRoomId = mCurrentScene.actionList.get(0).roomId;
                    actionList = CommonUtils.converListToJson(mCurrentScene.actionList.get(0).actionList).toString();
                } catch (Exception e) {
                    e.printStackTrace();
                }

                Bundle bundle = new Bundle();
                bundle.putInt("sceneId", mCurrentScene.sceneId);
                bundle.putString("actionList", actionList);
                mRoomSceneActionFragment.setArguments(bundle);

                showFragmentNoBack(mRoomSceneActionFragment);
            }else{
                //更新房间列表信息
            }

        }
    }

    private void updateRoomSceneActionList(String roomId,String actionListJson){
        try {
            if ((mCurrentScene != null) && (mCurrentScene.actionList != null)) {
                for (RoomSceneAction action : mCurrentScene.actionList) {
                    if (action.roomId.equals(roomId)) {
                        action.actionList = JSON.parseArray(actionListJson, RoomSceneAction.CmdAction.class);
                        break;
                    }
                }
            }
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    private void showActionListFragment() {
        mRoomSceneActionFragment = new RoomSceneActionFragment();
        if (mSceneMode == SCENE_MODE_EDIT) {
            requestDataList();
        } else {
            showFragmentNoBack(mRoomSceneActionFragment);
        }
    }

    private void showRoomListFragment() {

    }

    private void requestDataList() {
        // 获取场景的具体信息
        WRoom room = WApp.Instance.getDevManager().getSelectedRoom();
        if ( room != null){
            WRoom.cmdGetSceneActionList(mCurrentScene.sceneId,new CmdActionLister<Scene>(SceneAddEditActivity.this, new ICmdCallback<Scene>() {
                @Override
                public void onSuccess(Scene data) {
                    updateDataList(data);
                }

                @Override
                public void onFailed(int code, String msg) {
                    updateDataList(null);
                }
            }));
        }
    }


    public void showFragment(BaseFragment fragment) {
        getSupportFragmentManager()
                .beginTransaction()
                .add(R.id.scene_addedit_container, fragment)
                .addToBackStack(null)
                .commit();
    }

    public void showFragmentNoBack(BaseFragment fragment) {
        getSupportFragmentManager()
                .beginTransaction()
                .add(R.id.scene_addedit_container, fragment)
                .commit();
    }

    private boolean isOneRoomId(){
        boolean isShow = true;

        return isShow;
    }
}
