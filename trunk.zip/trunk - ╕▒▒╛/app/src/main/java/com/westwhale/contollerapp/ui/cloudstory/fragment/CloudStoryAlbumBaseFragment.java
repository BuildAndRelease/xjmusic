package com.westwhale.contollerapp.ui.cloudstory.fragment;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.kingja.loadsir.callback.Callback;
import com.scwang.smartrefresh.layout.api.RefreshLayout;
import com.scwang.smartrefresh.layout.listener.OnLoadMoreListener;
import com.scwang.smartrefresh.layout.listener.OnRefreshListener;
import com.westwhale.contollerapp.R;
import com.westwhale.contollerapp.ui.base.fragment.TitleBaseFragment;
import com.westwhale.contollerapp.ui.cloudstory.adapter.StoryAlbumAdapter;
import com.westwhale.contollerapp.ui.loadsircallback.LoadingCallback;
import com.westwhale.contollerapp.ui.main.MainRoomActivity;
import com.westwhale.api.protocolapi.bean.albumSet.StoryTelling;
import com.westwhale.api.protocolapi.bean.telling.CatrgroyGroup;

import java.util.List;


/**
 * Description:
 * Author: chenyaoli
 * Date: 2019-04-06
 * History:
 */
public abstract class CloudStoryAlbumBaseFragment extends TitleBaseFragment implements StoryAlbumAdapter.CallBack {
    private static final String TAG = "StoryCategoryAlbum";

    protected Toolbar mToolBar;
    protected RefreshLayout mRefreshLayout;
    protected TextView mAlbumTypeTv;
    protected ImageView mCategoryIv;
    protected RecyclerView mDataRv;
    protected LinearLayout mCategoryLayout;
    protected StoryAlbumAdapter mAdapter;

    protected abstract void initData();
    protected abstract boolean hasMoreData();
    protected abstract void loadMoreData();
    protected abstract void updateDataList(List<StoryTelling> list);
    protected abstract void requestCloudResource();

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        // 先显示加载动画，针对布局做一些初始化
        return inflater.inflate(R.layout.frag_cloudstory_base_album,container,false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        FrameLayout frameLayout = view.findViewById(R.id.cloudstory_album_content_layout);

        // 创建mLoadService
        mLoadService = mLoadSir.register(frameLayout, new Callback.OnReloadListener() {
            @Override
            public void onReload(View v) {
                showLoadCallBack(LoadingCallback.class);
                initData();
            }
        });

        initView(view);

        initListener();

        initData();
    }

    @Override
    public void onResume() {
        super.onResume();
    }

    @Override
    public void onAlbumItemClick(StoryTelling storyTellingItem) {
        // 进入专辑的媒体列表
        CloudStoryMediaListAlbumFragment fragment = new CloudStoryMediaListAlbumFragment();
        fragment.updateStoryTellingSet(storyTellingItem);
        if (getActivity() instanceof MainRoomActivity) {
            ((MainRoomActivity) getActivity()).showFragment(fragment);
        }
    }


    private void initView(View view) {
        mToolBar = view.findViewById(R.id.cloudstory_album_toolbar);

        mDataRv = view.findViewById(R.id.cloudstory_album_recylerview);
        GridLayoutManager gridLayoutManager = new GridLayoutManager(mContext, 3);
        mDataRv.setLayoutManager(gridLayoutManager);
        mAdapter = new StoryAlbumAdapter(this);
        mDataRv.setAdapter(mAdapter);
        mDataRv.setHasFixedSize(true);

        mRefreshLayout = view.findViewById(R.id.cloudstory_album_refresh);
        mRefreshLayout.setDisableContentWhenRefresh(true);
        mRefreshLayout.setEnableLoadMore(true);

        mCategoryLayout = view.findViewById(R.id.cloudstory_album_nav);
        mAlbumTypeTv = view.findViewById(R.id.cloudstory_album_type);
        mCategoryIv = view.findViewById(R.id.cloudstory_album_category);
    }


    private void initListener() {

        mRefreshLayout.setOnRefreshListener(new OnRefreshListener() {
            @Override
            public void onRefresh(@NonNull RefreshLayout refreshLayout) {
                initData();
            }
        });

        mRefreshLayout.setOnLoadMoreListener(new OnLoadMoreListener() {
            @Override
            public void onLoadMore(@NonNull RefreshLayout refreshLayout) {
                //  判断是否还有数据，从而判断是否还需要加载更多数据
                if (hasMoreData()){
                    loadMoreData();
                }else {
                    mRefreshLayout.finishLoadMoreWithNoMoreData();
                }
            }
        });
    }


}
