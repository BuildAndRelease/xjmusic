package com.westwhale.contollerapp.ui.scene.dialog;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.DialogFragment;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.TextView;

import com.blankj.utilcode.util.ToastUtils;
import com.westwhale.api.protocolapi.bean.scene.Scene;
import com.westwhale.contollerapp.R;
import com.westwhale.contollerapp.application.WApp;
import com.westwhale.contollerapp.dev.CmdActionLister;
import com.westwhale.contollerapp.dev.ICmdCallback;
import com.westwhale.contollerapp.dev.WRoom;
import com.westwhale.contollerapp.ui.base.dialog.AttachDialogFragment;
import com.westwhale.contollerapp.ui.scene.activity.SceneActivity;
import com.westwhale.contollerapp.ui.scene.adapter.SceneAdapter;

import java.util.List;

/**
 * Description:
 * Author: chenyaoli
 * Date: 2018-11-23
 * History:
 */
public class SceneExecuteDialog extends AttachDialogFragment implements SceneAdapter.CallBack {
    public static final String TAG = SceneExecuteDialog.class.getName();

    private ImageView mSettingIv,mCancelIv;
    private TextView mTitleTv;
    private RecyclerView mDataItemRv;
    private SceneAdapter mAdapter;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // 背景色，动画效果，通过主题设置
        setStyle(DialogFragment.STYLE_NORMAL,R.style.CommonDialogStyle);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        //布局
        View view = inflater.inflate(R.layout.dialog_scene_sceneexecute, container);
        return view;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        initView(view);
        initListener();

        initData();
    }

    @Override
    public void onStart() {
        super.onStart();

        //设置fragment高度 、宽度
        double heightPercent = 0.5;
        int dialogHeight = (int) (mContext.getResources().getDisplayMetrics().heightPixels * heightPercent);
        Window window = getDialog().getWindow();
        if (window != null) {
            WindowManager.LayoutParams params = window.getAttributes();
            params.gravity = Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL;
            params.width = WindowManager.LayoutParams.MATCH_PARENT;
            params.height = dialogHeight; // 底部弹出的DialogFragment的高度，如果是MATCH_PARENT则铺满整个窗口
            window.setAttributes(params);
            getDialog().setCanceledOnTouchOutside(true);
        }
    }

    @Override
    public void onItemClick(Scene item) {
        executeScene(item);
    }

    @Override
    public void onItemStatClick(Scene item) {
        executeScene(item);
    }

    @Override
    public void onItemDeleteClick(Scene item) {

    }

    private void initView(View view) {
        mTitleTv = view.findViewById(R.id.dialog_title);
        mSettingIv = view.findViewById(R.id.dialog_setting);
        mCancelIv = view.findViewById(R.id.dialog_cancel);

        mDataItemRv = view.findViewById(R.id.dialog_recylerview);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(mContext);
        mDataItemRv.setLayoutManager(linearLayoutManager);
        mAdapter = new SceneAdapter();
        mAdapter.setCallBack(this);
        mDataItemRv.setAdapter(mAdapter);
        mDataItemRv.setHasFixedSize(true);
        mDataItemRv.addItemDecoration(new DividerItemDecoration(mContext, DividerItemDecoration.VERTICAL));
        // 设置下拉上拉无阴影效果
        mDataItemRv.setOverScrollMode(View.OVER_SCROLL_NEVER);
    }

    private void initListener() {
        mSettingIv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //
                startActivity(new Intent(mContext,SceneActivity.class));
                dismiss();
            }
        });

        mCancelIv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dismiss();
            }
        });
    }

    private void initData() {
        mTitleTv.setText("场景执行");

        requestData();
    }


    private void executeScene(Scene scene){
        // 执行场景
        WRoom room = WApp.Instance.getDevManager().getSelectedRoom();
        if ((scene != null) && (room != null)){
            WRoom.cmdExecuteScene(scene.sceneId,new CmdActionLister<Boolean>(SceneExecuteDialog.this, new ICmdCallback<Boolean>() {
                @Override
                public void onSuccess(Boolean data) {
                    dismiss();
                }

                @Override
                public void onFailed(int code, String msg) {
                    ToastUtils.showShort("执行场景%d,失败：%d",scene.sceneId,code);
                }
            }));
        }
    }

    private void updateDataList(List<Scene> sceneList) {
        if (sceneList != null){
            mAdapter.setDataList(sceneList);
            mAdapter.notifyDataSetChanged();
        }
    }

    private void requestData(){
        WRoom room = WApp.Instance.getDevManager().getSelectedRoom();
        if (room != null){
            WRoom.cmdGetSceneList(new CmdActionLister<List<Scene>>(SceneExecuteDialog.this, new ICmdCallback<List<Scene>>() {
                @Override
                public void onSuccess(List<Scene> data) {
                    updateDataList(data);
                }

                @Override
                public void onFailed(int code, String msg) {
                    updateDataList(null);
                }
            }));
        }
    }

}
