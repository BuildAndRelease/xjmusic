package com.westwhale.contollerapp.eventbus.notify;

/**
 * Description:
 * Author: chenyaoli
 * Date: 2019-04-06
 * History:
 */
public class NotifyMuteEvent {
    private String mMuteStat;

    public NotifyMuteEvent(String mutestat){
        mMuteStat = mutestat;
    }
    public String getMuteStat() {
        return mMuteStat;
    }
}
