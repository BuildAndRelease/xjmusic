package com.westwhale.contollerapp.common;

import android.content.Context;
import android.content.SharedPreferences;
import android.support.annotation.NonNull;

import com.blankj.utilcode.constant.PermissionConstants;
import com.blankj.utilcode.util.PermissionUtils;
import com.blankj.utilcode.util.ToastUtils;

import java.util.UUID;

public class PreferenceManage {
    private final String Preference_File_Name = "westwhalePreferences";

    private static final String DEV_UUID_PREFFIX = "BAWWEC00";
    public static final String P_KEY_DEVUUID = "DevUuid";
    public static final String P_KEY_UUID = "Uuid";

    private Context mConext;
    private SharedPreferences mSharedPreferences;

    public PreferenceManage(@NonNull Context context){
        mConext = context;

        if (!PermissionUtils.isGranted(PermissionConstants.STORAGE)){
            PermissionUtils.permission(PermissionConstants.STORAGE)
                    .callback(new PermissionUtils.SimpleCallback() {
                        @Override
                        public void onGranted() {
                        }

                        @Override
                        public void onDenied() {
                            ToastUtils.showShort("请配置存储权限");
                        }
                    })
                    .request();
        }

        mSharedPreferences = mConext.getSharedPreferences(Preference_File_Name, Context.MODE_PRIVATE);
    }

    private void init(){
    }

    public String getDevUuid(){
        // 首先从配置文件中读取UUID，若不存在则创建生成UUID，并保存
        String devUuid = mSharedPreferences.getString(P_KEY_DEVUUID,"");
        // 若不存在，则先创建一个
        if (devUuid.isEmpty()){
            UUID uuid = UUID.randomUUID();
            devUuid = DEV_UUID_PREFFIX + uuid.toString().substring(24);

            SharedPreferences.Editor editor = mSharedPreferences.edit();
            editor.putString(P_KEY_UUID,uuid.toString());
            editor.putString(P_KEY_DEVUUID,devUuid);
            editor.apply();
            editor.commit();
        }

        return devUuid;
    }
}
