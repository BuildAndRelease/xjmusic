package com.westwhale.contollerapp.ui.cloudstory.adapter;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.westwhale.contollerapp.R;
import com.westwhale.api.protocolapi.bean.telling.CatrgroyGroup;

import java.util.List;

/**
 * Description:
 * Author: chenyaoli
 * Date: 2019-04-06
 * History:
 */
public class StoryCategoryAdapter extends RecyclerView.Adapter  {
    private List<CatrgroyGroup> mItemList;

    private CallBack mCallback;

    public interface CallBack{
        void onCategoryItemClick(CatrgroyGroup item);
    }

    public void updateDataList(List<CatrgroyGroup> itemList){
        this.mItemList = itemList;
    }

    public StoryCategoryAdapter(CallBack callBack){
        this.mItemList = null;
        this.mCallback = callBack;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_cloudstory_category_item, viewGroup, false);
        return new CategoryItemHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder viewHolder, int i) {
        if (viewHolder instanceof CategoryItemHolder){
            final CatrgroyGroup item = mItemList.get(i);
            CategoryItemHolder itemHolder = (CategoryItemHolder)viewHolder;
            itemHolder.mContentTv.setText(item.categoryName);

            itemHolder.itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (mCallback != null){
                        mCallback.onCategoryItemClick(item);
                    }
                }
            });
        }
    }

    @Override
    public int getItemCount() {
        return (null == mItemList) ? 0 : mItemList.size();
    }

    // ItemHolder
    private class CategoryItemHolder extends RecyclerView.ViewHolder{
        TextView mContentTv;
        CategoryItemHolder(@NonNull View itemView) {
            super(itemView);
            mContentTv = itemView.findViewById(R.id.item_story_category_text);
        }
    }
}
