package com.westwhale.contollerapp.eventbus;


import com.westwhale.api.protocolapi.bean.hostroom.Host;

/**
 * Description:
 * Author: chenyaoli
 * Date: 2018-12-24
 * History:
 */
public class SearchHostEvent {
    Host mHost;
    public SearchHostEvent(Host host){
        mHost = host;
    }
    public Host getHost() {
        return mHost;
    }

    public void setHost(Host mHost) {
        this.mHost = mHost;
    }
}
