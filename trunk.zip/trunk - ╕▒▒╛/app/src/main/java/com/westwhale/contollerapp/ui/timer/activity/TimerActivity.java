package com.westwhale.contollerapp.ui.timer.activity;

import android.os.Bundle;
import android.support.annotation.Nullable;

import com.westwhale.contollerapp.R;
import com.westwhale.contollerapp.ui.base.activity.BaseActivity;
import com.westwhale.contollerapp.ui.base.fragment.BaseFragment;
import com.westwhale.contollerapp.ui.timer.fragment.TimerFragment;
import com.westwhale.api.protocolapi.bean.Timer;

import java.util.ArrayList;
import java.util.List;

public class TimerActivity extends BaseActivity {

    private List<Timer> mDataList = new ArrayList<>();

    public List<Timer> getTimerList(){
        return mDataList;
    }

    public boolean addToTimerList(List<Timer> list){
        return mDataList.addAll(list);
    }

    public boolean removeTimer(Timer timer){
        return mDataList.remove(timer);
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_timer_empty);

        initView();
        initListener();
        initData();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    private void initData() {
        showFragmentNoBack(new TimerFragment());
    }

    private void initListener() {

    }

    private void initView() {

    }

    public void showFragment(BaseFragment fragment) {
        getSupportFragmentManager()
                .beginTransaction()
                .add(R.id.timer_main_container, fragment)
                .addToBackStack(null)
                .commit();
    }

    public void showFragmentNoBack(BaseFragment fragment) {
        getSupportFragmentManager()
                .beginTransaction()
                .add(R.id.timer_main_container, fragment)
                .commit();
    }



}
