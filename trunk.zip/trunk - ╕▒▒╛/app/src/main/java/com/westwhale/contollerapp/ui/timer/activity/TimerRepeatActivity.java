package com.westwhale.contollerapp.ui.timer.activity;


import android.app.Activity;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.Toolbar;
import android.view.MotionEvent;
import android.view.View;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.DatePicker;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ToggleButton;

import com.blankj.utilcode.util.LogUtils;
import com.westwhale.contollerapp.R;
import com.westwhale.contollerapp.ui.base.activity.BaseActivity;
import com.westwhale.contollerapp.ui.timer.TimerDefine;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

/**
 * Description:
 * Author: chenyaoli
 * Date: 2018-12-20
 * History
 */
public class TimerRepeatActivity extends BaseActivity {
    private final String TAG = TimerRepeatActivity.class.getName();

    private final int REPEAT_MODE_NOREPREAT = 1;
    private final int REPEAT_MODE_EVERYDATY = 2;
    private final int REPEAT_MODE_MONDAYFRIDAY = 3;
    private final int REPEAT_MODE_CUSTOM = 4;
    private final int REPEAT_MODE_SPECIALDAY = 5;

    private Toolbar mToolbar;
    private ImageView mSaveIv;
    private View mCustomContentLayout;
    private LinearLayout mNoRepeatLayout,mEverydayLayout,mMondayFridayLayout,mCustomLayout,mSpecialDateLayout,mSpecialDateContentLayout;
    private CheckBox mNoRepeatChx,mEverydayChx,mMondayFridayChx,mCustomChx,mSpecialDateChx;
    private ToggleButton mMondayBtn,mTuesdayBtn,mWednesdayBtn,mThursdayBtn,mFridayBtn,mSaturdayBtn,mSundayBtn;
    private DatePicker mDatePicker;

    private CheckBox mCurrentSelectedChx;

    private int mCircleDay = 0;
    private String mSpecialDate = "";

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_timer_repeat);

        initView();
        initListener();

        initData();
    }

    @Override
    protected void onPause() {
        super.onPause();
    }


    private void initView() {
        mToolbar = findViewById(R.id.timer_repeat_toolbar);
        // 设置toolbar
        setSupportActionBar(mToolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        mSaveIv = findViewById(R.id.timer_repeat_ok);

        mNoRepeatLayout = findViewById(R.id.timer_repeat_norepeat_layout);
        mNoRepeatChx = findViewById(R.id.timer_repeat_norepeat_checkbox);

        mEverydayLayout = findViewById(R.id.timer_repeat_everyday_layout);
        mEverydayChx = findViewById(R.id.timer_repeat_everyday_checkbox);

        mMondayFridayLayout = findViewById(R.id.timer_repeat_1_5_layout);
        mMondayFridayChx = findViewById(R.id.timer_repeat_1_5_checkbox);

        mCustomLayout = findViewById(R.id.timer_repeat_custom_layout);
        mCustomChx = findViewById(R.id.timer_repeat_custom_checkbox);

        mSpecialDateLayout = findViewById(R.id.timer_repeat_specialday_layout);
        mSpecialDateChx = findViewById(R.id.timer_repeat_specialday_checkbox);

        mCustomContentLayout = findViewById(R.id.timer_repeat_custom_content_layout);
        mSpecialDateContentLayout = findViewById(R.id.timer_repeat_presetdate_content_layout);

        mMondayBtn = findViewById(R.id.timer_repeat_custom_monday);
        mTuesdayBtn = findViewById(R.id.timer_repeat_custom_tuesday);
        mWednesdayBtn = findViewById(R.id.timer_repeat_custom_wednesday);
        mThursdayBtn = findViewById(R.id.timer_repeat_custom_thursday);
        mFridayBtn = findViewById(R.id.timer_repeat_custom_friday);
        mSaturdayBtn = findViewById(R.id.timer_repeat_custom_saturday);
        mSundayBtn = findViewById(R.id.timer_repeat_custom_sunday);

        mDatePicker = findViewById(R.id.timer_repeat_datepicker);
    }

    private void initListener() {
        mToolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        mSaveIv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 保存
                if (mCurrentSelectedChx == mSpecialDateChx){
                    mSpecialDate = calcDatePicker();
                }
                Intent intent = new Intent();
                intent.putExtra(TimerDefine.TIMER_INTENT_ARG_KEY_REPEAT_CIRCLEDAY,mCircleDay);
                intent.putExtra(TimerDefine.TIMER_INTENT_ARG_KEY_REPEAT_SPECIALDATE,mSpecialDate);

                setResult(Activity.RESULT_OK,intent);

                finish();
            }
        });

        mNoRepeatLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                switchToRepeatMode(REPEAT_MODE_NOREPREAT);
            }
        });

        mEverydayLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                switchToRepeatMode(REPEAT_MODE_EVERYDATY);
            }
        });

        mMondayFridayLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                switchToRepeatMode(REPEAT_MODE_MONDAYFRIDAY);
            }
        });

        mCustomLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                switchToRepeatMode(REPEAT_MODE_CUSTOM);
            }
        });

        mSpecialDateLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                switchToRepeatMode(REPEAT_MODE_SPECIALDAY);
            }
        });


        mMondayBtn.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                updateCustomCircleDay();
            }
        });
        mTuesdayBtn.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                updateCustomCircleDay();
            }
        });
        mWednesdayBtn.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                updateCustomCircleDay();
            }
        });
        mThursdayBtn.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                updateCustomCircleDay();
            }
        });
        mFridayBtn.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                updateCustomCircleDay();
            }
        });
        mSaturdayBtn.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                updateCustomCircleDay();
            }
        });
        mSundayBtn.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                updateCustomCircleDay();
            }
        });

        // mDatePicker.setOnDateChangedListener 只能用于 LEVEL 26以上的
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            mDatePicker.setOnDateChangedListener(new DatePicker.OnDateChangedListener() {
                @Override
                public void onDateChanged(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                    updateSpecialDate(year,monthOfYear,dayOfMonth);
                }
            });
        } else {
            mDatePicker.setClickable(true);
            mDatePicker.setFocusable(true);
            mDatePicker.setOnTouchListener(new View.OnTouchListener() {
                @Override
                public boolean onTouch(View v, MotionEvent event) {
                    updateSpecialDate(mDatePicker.getYear(),mDatePicker.getMonth(),mDatePicker.getDayOfMonth());

                    return true;
                }
            });
        }
    }

    private void updateSpecialDate(int year, int month, int day) {
        mSpecialDate = String.format(Locale.getDefault(),"%04d-%02d-%02d",year,month,day);
    }

    private void updateCustomCircleDay() {
        mCircleDay = calcCircleDay();
    }

    private void switchToRepeatMode(int i) {
        if (mCurrentSelectedChx != null){
            mCurrentSelectedChx.setChecked(false);
        }

        int customContentVisible = View.GONE;
        int specialdateContentVisible = View.GONE;
        int circleDay = 0;
        String specialdate = "";

        switch (i){
            case REPEAT_MODE_NOREPREAT:{
                mCurrentSelectedChx = mNoRepeatChx;
                customContentVisible = View.GONE;
                specialdateContentVisible = View.GONE;
                circleDay = TimerDefine.TIMER_REPEAT_NOREPEAT;
                specialdate = "";

                break;
            }
            case REPEAT_MODE_EVERYDATY:{
                mCurrentSelectedChx = mEverydayChx;
                customContentVisible = View.GONE;
                specialdateContentVisible = View.GONE;
                circleDay = TimerDefine.TIMER_REPEAT_EVERYDAY;
                specialdate = "";

                break;
            }
            case REPEAT_MODE_MONDAYFRIDAY:{
                mCurrentSelectedChx = mMondayFridayChx;
                customContentVisible = View.GONE;
                specialdateContentVisible = View.GONE;
                circleDay = TimerDefine.TIMER_REPEAT_1_5;
                specialdate = "";

                 break;
            }
            case REPEAT_MODE_CUSTOM:{
                mCurrentSelectedChx = mCustomChx;
                customContentVisible = View.VISIBLE;
                specialdateContentVisible = View.GONE;

                circleDay = calcCircleDay();
                specialdate = "";

                break;
            }
            case REPEAT_MODE_SPECIALDAY:{
                mCurrentSelectedChx = mSpecialDateChx;
                customContentVisible = View.GONE;
                specialdateContentVisible = View.VISIBLE;
                circleDay = TimerDefine.TIMER_REPEAT_NOREPEAT;
                specialdate = calcDatePicker();

                break;
            }
            default:
                break;
        }

        if (mCurrentSelectedChx != null) {
            mCurrentSelectedChx.setChecked(true);
            mCustomContentLayout.setVisibility(customContentVisible);
            mSpecialDateContentLayout.setVisibility(specialdateContentVisible);

            mCircleDay = circleDay;
            mSpecialDate = specialdate;
        }

    }

    private int calcCircleDay() {
        int circleday = 0;

        int bit0Value = mMondayBtn.isChecked() ? 1 : 0;
        int bit1Value = mTuesdayBtn.isChecked() ? 1 : 0;
        int bit2Value = mWednesdayBtn.isChecked() ? 1 : 0;
        int bit3Value = mThursdayBtn.isChecked() ? 1 : 0;
        int bit4Value = mFridayBtn.isChecked() ? 1 : 0;
        int bit5Value = mSaturdayBtn.isChecked() ? 1 : 0;
        int bit6Value = mSundayBtn.isChecked() ? 1 : 0;

        circleday = (bit6Value << 6) | (bit5Value << 5) | (bit4Value << 4) | (bit3Value << 3) | (bit2Value << 2) | (bit1Value << 1) | bit0Value;

        return circleday;
    }

    private String calcDatePicker(){
        String dateStr = "";

        if (mDatePicker != null) {
            dateStr = String.format(Locale.getDefault(), "%04d-%02d-%02d", mDatePicker.getYear(), mDatePicker.getMonth()+1, mDatePicker.getDayOfMonth());
        }
        LogUtils.eTag(TAG,"---------calcDatePicker-----------"+dateStr);

        return  dateStr;
    }


    private void initData() {
        //初始化
        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(System.currentTimeMillis());
        mDatePicker.updateDate(calendar.get(Calendar.YEAR),calendar.get(Calendar.MONTH),calendar.get(Calendar.DAY_OF_MONTH));

        mMondayBtn.setChecked(false);
        mTuesdayBtn.setChecked(false);
        mWednesdayBtn.setChecked(false);
        mThursdayBtn.setChecked(false);
        mFridayBtn.setChecked(false);
        mSaturdayBtn.setChecked(false);
        mSundayBtn.setChecked(false);

        Intent intent = getIntent();
        if (intent != null){
            int circleday = intent.getIntExtra(TimerDefine.TIMER_INTENT_ARG_KEY_REPEAT_CIRCLEDAY,0);
            String specialDate = intent.getStringExtra(TimerDefine.TIMER_INTENT_ARG_KEY_REPEAT_SPECIALDATE);

            int repeatMode = REPEAT_MODE_NOREPREAT;
            if ((specialDate != null) && (!specialDate.isEmpty())){
                repeatMode = REPEAT_MODE_SPECIALDAY;

                try {
                    calendar.setTime(new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).parse(specialDate));
                }catch (Exception e){
                    e.printStackTrace();
                    calendar.setTimeInMillis(System.currentTimeMillis());
                }
                LogUtils.eTag(TAG,"---------initData-----------"+specialDate);

                mDatePicker.updateDate(calendar.get(Calendar.YEAR),calendar.get(Calendar.MONTH),calendar.get(Calendar.DAY_OF_MONTH));
            }else{
                switch(circleday){
                    case TimerDefine.TIMER_REPEAT_NOREPEAT:
                        repeatMode = REPEAT_MODE_NOREPREAT;
                        break;
                    case TimerDefine.TIMER_REPEAT_EVERYDAY:
                        repeatMode = REPEAT_MODE_EVERYDATY;
                        break;
                    case TimerDefine.TIMER_REPEAT_1_5:
                        repeatMode = REPEAT_MODE_MONDAYFRIDAY;
                        break;
                    default:
                        repeatMode = REPEAT_MODE_CUSTOM;

                        mMondayBtn.setChecked((circleday & 0x01) == 1);
                        mTuesdayBtn.setChecked(((circleday>>1) & 0x01) == 1);
                        mWednesdayBtn.setChecked(((circleday>>2) & 0x01) == 1);
                        mThursdayBtn.setChecked(((circleday>>3) & 0x01) == 1);
                        mFridayBtn.setChecked(((circleday>>4) & 0x01) == 1);
                        mSaturdayBtn.setChecked(((circleday>>5) & 0x01) == 1);
                        mSundayBtn.setChecked(((circleday>>6) & 0x01) == 1);

                        break;
                }
            }

            switchToRepeatMode(repeatMode);
        }
    }

}
