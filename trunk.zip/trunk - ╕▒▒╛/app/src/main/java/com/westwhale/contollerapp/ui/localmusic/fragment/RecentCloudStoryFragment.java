package com.westwhale.contollerapp.ui.localmusic.fragment;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;

import com.blankj.utilcode.util.ToastUtils;
import com.kingja.loadsir.callback.Callback;
import com.kingja.loadsir.callback.SuccessCallback;
import com.kingja.loadsir.core.LoadService;
import com.kingja.loadsir.core.LoadSir;
import com.scwang.smartrefresh.layout.api.RefreshLayout;
import com.scwang.smartrefresh.layout.listener.OnLoadMoreListener;
import com.scwang.smartrefresh.layout.listener.OnRefreshListener;
import com.westwhale.contollerapp.R;
import com.westwhale.contollerapp.application.WApp;
import com.westwhale.contollerapp.dev.CmdActionLister;
import com.westwhale.contollerapp.dev.ICmdCallback;
import com.westwhale.contollerapp.dev.WRoom;
import com.westwhale.contollerapp.ui.base.fragment.LazyBaseFragment;
import com.westwhale.contollerapp.ui.cloudstory.adapter.CloudStoryMediaAdapter;
import com.westwhale.contollerapp.ui.loadsircallback.EmptyCallback;
import com.westwhale.contollerapp.ui.loadsircallback.ErrorCallback;
import com.westwhale.contollerapp.ui.loadsircallback.LoadingCallback;
import com.westwhale.contollerapp.ui.loadsircallback.TimeoutCallback;
import com.westwhale.api.protocolapi.bean.media.Media;
import com.westwhale.api.protocolapi.bean.media.Section;

import java.util.ArrayList;
import java.util.List;

public class RecentCloudStoryFragment extends LazyBaseFragment implements CloudStoryMediaAdapter.CallBack {
    private static final String TAG = "RecentCloudStory";

    private RecyclerView mDataRv;
    private RefreshLayout mRefreshLayout;
    private LoadSir mLoadSir;
    private LoadService mLoadService;

    private CloudStoryMediaAdapter mAdapter;

    private boolean mHasMoreData;
    private int mPageNo = 1;
    private static final int PAGE_SIZE = 50;

    List<Section> mItemList = new ArrayList<>();

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // 创建mLoadService
        // 界面的加载等待框架配置
        mLoadSir = new LoadSir.Builder()
                .addCallback(new LoadingCallback())
                .addCallback(new TimeoutCallback())
                .addCallback(new ErrorCallback())
                .addCallback(new EmptyCallback())
                .setDefaultCallback(SuccessCallback.class)
                .build();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
    }

    @Override
    public int getLayoutId() {
        return R.layout.frag_recent_content;
    }

    @Override
    public void initView(View view) {
        mRefreshLayout = view.findViewById(R.id.recent_content_refresh);
        mRefreshLayout.setDisableContentWhenRefresh(true);
        mRefreshLayout.setEnableLoadMore(true);

        mDataRv = view.findViewById(R.id.recent_content_recylerview);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(mContext);
        mDataRv.setLayoutManager(linearLayoutManager);
        mAdapter = new CloudStoryMediaAdapter(this);
        mDataRv.setAdapter(mAdapter);
        mDataRv.setHasFixedSize(true);
        mDataRv.addItemDecoration(new DividerItemDecoration(mContext, DividerItemDecoration.VERTICAL));

        // 创建mLoadService
        mLoadService = mLoadSir.register(mDataRv, new Callback.OnReloadListener() {
            @Override
            public void onReload(View v) {
                showLoadCallBack(mLoadService, LoadingCallback.class);
                requestData();
            }
        });
    }

    @Override
    public void initListener() {
        mRefreshLayout.setOnRefreshListener(new OnRefreshListener() {
            @Override
            public void onRefresh(@NonNull RefreshLayout refreshLayout) {
                initData();
                requestData();
            }
        });

        mRefreshLayout.setOnLoadMoreListener(new OnLoadMoreListener() {
            @Override
            public void onLoadMore(@NonNull RefreshLayout refreshLayout) {
                //  判断是否还有数据，从而判断是否还需要加载更多数据
                if (hasMoreData()){
                    loadMoreData();
                }else {
                    mRefreshLayout.finishLoadMoreWithNoMoreData();
                }
            }
        });
    }

    @Override
    public void initData() {
        showLoadCallBack(mLoadService,LoadingCallback.class);

        mHasMoreData = true;
        mPageNo = 1;

        mItemList.clear();
        if (mAdapter != null){
            mAdapter.updateDataList(mItemList);

            mAdapter.notifyDataSetChanged();
        }
    }

    @Override
    public void onLazyLoad() {
        requestData();
    }

    @Override
    public void onMediaItemClick(Section item) {

    }

    public void showLoadCallBack(LoadService loadService,Class<? extends Callback> callback){
        if (loadService != null){
            loadService.showCallback(callback);
        }
    }

    private boolean hasMoreData(){
        return mHasMoreData;
    }

    private void loadMoreData(){
        mPageNo++;
        requestData();
    }

    private void updateData(List<Section> datalist){
        if (datalist != null){

            int size = datalist.size();

            if (size != 0){
                int count = mAdapter.getItemCount();

                mAdapter.addToDataList(datalist);
                mAdapter.notifyItemRangeInserted(count,size);
            }else{
                mHasMoreData = false;
            }

            mRefreshLayout.finishRefresh();
            mRefreshLayout.finishLoadMore();

            showLoadCallBack(mLoadService,SuccessCallback.class);
        }else{
            mHasMoreData = false;

            mRefreshLayout.finishRefresh();
            mRefreshLayout.finishLoadMore();

            showLoadCallBack(mLoadService,SuccessCallback.class);
        }
    }

    private void requestData(){
        WRoom room = WApp.Instance.getDevManager().getSelectedRoom();
        if (room != null){
            room.cmdGetHistoryPlayList(Media.CLOUD_STORY_TELLING,mPageNo,PAGE_SIZE,new CmdActionLister<List<Media>>(RecentCloudStoryFragment.this, new ICmdCallback<List<Media>>() {
                @Override
                public void onSuccess(List<Media> data) {
                    List<Section> mediaList = null;
                    if (data != null){
                        mediaList = new ArrayList<>();
                        for (int i=0; i < data.size(); i++){
                            if (data.get(i) instanceof Section){
                                mediaList.add((Section)(data.get(i)));
                            }
                        }
                    }

                    updateData(mediaList);
                }

                @Override
                public void onFailed(int code, String msg) {
                    ToastUtils.showShort("GetHistory Failed.. %d",code);
                    updateData(null);
                }
            }));
        }
    }


}
