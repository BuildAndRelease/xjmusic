package com.westwhale.contollerapp.ui.cloudmusic.fragment;

import android.widget.Toast;

import com.kingja.loadsir.callback.SuccessCallback;
import com.westwhale.contollerapp.R;
import com.westwhale.contollerapp.application.WApp;
import com.westwhale.contollerapp.dev.CmdActionLister;
import com.westwhale.contollerapp.dev.ICmdCallback;
import com.westwhale.contollerapp.dev.WRoom;
import com.westwhale.contollerapp.ui.loadsircallback.EmptyCallback;
import com.westwhale.contollerapp.ui.loadsircallback.LoadingCallback;
import com.westwhale.api.protocolapi.bean.media.CloudMusic;

import java.util.List;

public class CloudMusicListNewSongFragment extends CloudMusicListBaseFragment {

    @Override
    public void initData() {
        showLoadCallBack(LoadingCallback.class);

        updateHeaderInfo();

        // 每次先清空原有数据
        if (mMusicAdapter != null){
            mMusicAdapter.clearDataList();
        }

        requestCloudResource();
    }

    @Override
    public boolean hasMoreData() {
        return false;
    }

    @Override
    public void loadMoreData() {
    }

    @Override
    public void requestCloudResource() {
        WRoom room = WApp.Instance.getDevManager().getSelectedRoom();
        if (room != null){
            WRoom.cmdGetNewSong("nd", new CmdActionLister<List<CloudMusic>>(this, new ICmdCallback<List<CloudMusic>>() {
                @Override
                public void onSuccess(List<CloudMusic> data) {
                    updateDataList(data);
                }

                @Override
                public void onFailed(int code, String msg) {
                    updateDataList(null);
                    Toast.makeText(getContext(),"GetNewSong获取失败:"+code,Toast.LENGTH_SHORT).show();
                }
            }));
        }else{
            updateDataList(null);
        }
    }

    @Override
    public void updateDataList(List<CloudMusic> list){
        if (list != null){

            mMusicAdapter.updateDataList(list);
            mMusicAdapter.notifyDataSetChanged();

            // 更新刷新等待状态
            mRefreshLayout.finishRefresh();
            mRefreshLayout.finishLoadMore();

            showLoadCallBack(SuccessCallback.class);
        }else{
            // 更新刷新等待状态
            mRefreshLayout.finishRefresh();
            mRefreshLayout.finishLoadMore();

            showLoadCallBack(EmptyCallback.class);
        }
    }

    private void updateHeaderInfo(){
        String toolbarTitle = getString(R.string.cloudmusic_recommand_title);
        String title = getString(R.string.cloudmusic_newsong_title);
        String subTitle = "";
        String picUrl = "";

        updateHeader(toolbarTitle,title,subTitle,picUrl);
    }
}
