package com.westwhale.contollerapp.ui.talk.activity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.ImageView;

import com.blankj.utilcode.util.LogUtils;
import com.blankj.utilcode.util.ThreadUtils;
import com.blankj.utilcode.util.ToastUtils;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.scwang.smartrefresh.layout.api.RefreshLayout;
import com.scwang.smartrefresh.layout.listener.OnRefreshListener;
import com.westwhale.api.protocolapi.bean.Talk;
import com.westwhale.api.protocolapi.bean.hostroom.Room;
import com.westwhale.contollerapp.R;
import com.westwhale.contollerapp.application.WApp;
import com.westwhale.contollerapp.dev.CmdActionLister;
import com.westwhale.contollerapp.dev.ICmdCallback;
import com.westwhale.contollerapp.dev.WRoom;
import com.westwhale.contollerapp.ui.base.activity.BaseActivity;
import com.westwhale.contollerapp.ui.talk.adapter.TalkExpandItemAdapter;

import java.util.ArrayList;
import java.util.List;

public class TalkActivity extends BaseActivity implements TalkExpandItemAdapter.CallBack {

    public static final int REQUEST_CODE_TALK_NEW = 1;
    public static final int REQUEST_CODE_TALK_EDIT = 2;
    public static final int REQUEST_CODE_TALK_TALKING = 3;

    public static final String TALK_STAT_OPEN = "open";
    public static final String TALK_STAT_CLOSE = "close";

    private Toolbar mToolbar;
    private ImageView mTalkManageIv,mTalkAddIv;
    private RecyclerView mDataRv;
    private TalkExpandItemAdapter mAdapter;
    private RefreshLayout mRefreshLayout;

    private int mTalkGroupNum = 0;
    private int mTalkMode = TalkExpandItemAdapter.ITEM_MODE_NORMAL;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_talk_info);

        initView();
        initListener();

        updateTalkMode(TalkExpandItemAdapter.ITEM_MODE_NORMAL);

        initData();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if ((requestCode == REQUEST_CODE_TALK_NEW) && (resultCode == Activity.RESULT_OK)) {
            initData();
        }else if ((requestCode == REQUEST_CODE_TALK_TALKING) && (resultCode == Activity.RESULT_OK)) {
            int talkId = -1;
            if (data != null) {
                talkId = data.getIntExtra("talkId", -1);
            }
            updateTalkStat(talkId,TALK_STAT_CLOSE);
        }
    }

    @Override
    public void onTalkItemClick(Talk item) {
        if (TalkExpandItemAdapter.ITEM_MODE_NORMAL == mTalkMode) {
            if ((item != null) && (TALK_STAT_OPEN.equals(item.talkStat))) {
                Intent intent = new Intent(TalkActivity.this, TalkDoingActivity.class);
                intent.putExtra("talkId", item.talkId);
                startActivityForResult(intent, REQUEST_CODE_TALK_TALKING);
            }
        }
    }

    @Override
    public void onTalkItemStatClick(Talk item) {
        WRoom room = WApp.Instance.getDevManager().getSelectedRoom();
        if ( (item != null) && (room != null) ){
            String preSetTalkStat = TALK_STAT_OPEN.equals(item.talkStat) ? TALK_STAT_CLOSE : TALK_STAT_OPEN;
            WRoom.cmdSetTalkStat(item.talkId,preSetTalkStat,new CmdActionLister<Talk>(TalkActivity.this, new ICmdCallback<Talk>() {
                @Override
                public void onSuccess(Talk data) {
                    updateTalkStat(item.talkId,preSetTalkStat);

                    if (TALK_STAT_OPEN.equals(preSetTalkStat)){
                        // 若是打开对讲，则进入对讲中界面
                        Intent intent = new Intent(TalkActivity.this,TalkDoingActivity.class);
                        intent.putExtra("talkId",item.talkId);
                        startActivityForResult(intent,REQUEST_CODE_TALK_TALKING);
                    }
                }

                @Override
                public void onFailed(int code, String msg) {
                    ToastUtils.showShort("设置对讲状态失败:"+code);
                }
            }));
        }
    }

    @Override
    public void onTalkItemDeleteClick(Talk item) {
        WRoom room = WApp.Instance.getDevManager().getSelectedRoom();
        if ( (item != null) && (room != null) ){
            WRoom.cmdDelTalk(item.talkId,new CmdActionLister<Boolean>(TalkActivity.this, new ICmdCallback<Boolean>() {
                @Override
                public void onSuccess(Boolean data) {
                    if (data){
                        removeTalk(item.talkId);
                    }
                }

                @Override
                public void onFailed(int code, String msg) {
                    ToastUtils.showShort("删除 对讲 失败:"+code);
                }
            }));
        }
    }

    private void initView() {
        mToolbar = findViewById(R.id.talk_info_toolbar);
        // 设置toolbar
        setSupportActionBar(mToolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        mTalkManageIv = findViewById(R.id.talk_info_edit);
        mTalkAddIv = findViewById(R.id.talk_info_add);



        mDataRv = findViewById(R.id.talk_info_recylerview);
        final GridLayoutManager manager = new GridLayoutManager(this, 4);
        mDataRv.setLayoutManager(manager);
        mAdapter = new TalkExpandItemAdapter(null);
        mAdapter.setSpanSizeLookup(new BaseQuickAdapter.SpanSizeLookup() {
            @Override
            public int getSpanSize(GridLayoutManager gridLayoutManager, int position) {
                return mAdapter.getItemViewType(position) == TalkExpandItemAdapter.ITEM_TYPE_ROOM ? 1 : gridLayoutManager.getSpanCount();
            }
        });
        mAdapter.setCallBack(this);
        mDataRv.setAdapter(mAdapter);
        mDataRv.setHasFixedSize(true);
//        mDataRv.addItemDecoration(new DividerItemDecoration(this, DividerItemDecoration.VERTICAL));

        mRefreshLayout = findViewById(R.id.talk_info_refreshlayout);
        mRefreshLayout.setDisableContentWhenRefresh(true);
        mRefreshLayout.setEnableLoadMore(false);
    }

    private void initListener() {
        mToolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mTalkMode == TalkExpandItemAdapter.ITEM_MODE_NORMAL){
                    onBackPressed();
                }else{
                    updateTalkMode(TalkExpandItemAdapter.ITEM_MODE_NORMAL);
                }
            }
        });

        mTalkManageIv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int mode = TalkExpandItemAdapter.ITEM_MODE_NORMAL;
                if (mTalkMode == TalkExpandItemAdapter.ITEM_MODE_NORMAL){
                    mode = TalkExpandItemAdapter.ITEM_MODE_DELETE;
                }
                updateTalkMode(mode);
            }
        });

        mTalkAddIv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 进入新建对讲组界面
                startActivityForResult(new Intent(TalkActivity.this, TalkAddEditActivity.class),REQUEST_CODE_TALK_NEW);
            }
        });


        mRefreshLayout.setOnRefreshListener(new OnRefreshListener() {
            @Override
            public void onRefresh(@NonNull RefreshLayout refreshLayout) {
                initData();
            }
        });
    }

    private void initData() {
        mAdapter.removeALl();
        requestData();
    }

    private void updateTalkStat(int talkId, String preSetTalkStat){
        mAdapter.updateTalkItem(talkId,preSetTalkStat);
    }


    private void removeTalk(int talkId){
        mAdapter.removeTalkItem(talkId);

        updateTalkNum(mAdapter.getData().size());
    }

    private void updateTalkMode(int mode){
        mTalkMode = mode;

        updateToolbarTitle();

        mTalkManageIv.setVisibility(View.GONE);
        mTalkAddIv.setVisibility(View.GONE);
        if (mTalkMode == TalkExpandItemAdapter.ITEM_MODE_NORMAL){
            mTalkManageIv.setVisibility(View.VISIBLE);
            mTalkAddIv.setVisibility(View.VISIBLE);
        }

        mAdapter.setItemMode(mTalkMode);
        mAdapter.notifyItemRangeChanged(0,mAdapter.getItemCount());
    }

    public void updateTalkRoomList(Talk talk, List<Room> roomList){
        if (talk != null){
            mAdapter.addDataItem(talk,roomList);
//            mAdapter.addTalkRoomItem(talk,roomList);

            if (roomList != null) {
                List<String> roomIdList = new ArrayList<>();
                for (Room room : roomList) {
                    if ((room != null) && (room.roomId != null) && (!room.roomId.isEmpty())) {
                        roomIdList.add(room.roomId);
                    }
                }
                String debugInfo = String.format("talkId:%d\n rooms:%s", talk.talkId, roomIdList.toString());
                LogUtils.e(debugInfo);
            }
        }

        mRefreshLayout.finishRefresh();
    }

    private void updateTalkNum(int num){
        mTalkGroupNum = num;
        updateToolbarTitle();
    }

    private void updateToolbarTitle(){
        String title = "";
        if (mTalkMode == TalkExpandItemAdapter.ITEM_MODE_NORMAL){
            title = title + getString(R.string.talk_info_title);
        }else{
            title = title + getString(R.string.talk_info_title_manager);
        }

        title = title + "(" + mTalkGroupNum + ")";
        mToolbar.setTitle(title);
    }

    private void requestData(){
        WRoom room = WApp.Instance.getDevManager().getSelectedRoom();
        if (room != null){
            WRoom.cmdGetTalkList(new CmdActionLister<List<Talk>>(TalkActivity.this, new ICmdCallback<List<Talk>>() {
                @Override
                public void onSuccess(List<Talk> data) {
//                    updateTalkData(data);
                    updateTalkNum(data.size());

                    for (Talk talk : data) {
                        if (talk != null) {
                            //  根据talkId，再获取talkId的相关成员列表
                            WRoom.cmdGetTalkRoomList(talk.talkId,new CmdActionLister<List<Room>>(TalkActivity.this, new ICmdCallback<List<Room>>() {
                                @Override
                                public void onSuccess(List<Room> data) {
                                    updateTalkRoomList(talk,data);
                                }

                                @Override
                                public void onFailed(int code, String msg) {
                                    updateTalkRoomList(talk,null);
                                }
                            }));
                        }

                        // 避免连续发送，有数据紊乱的可能
                        try {
                            Thread.sleep(10);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    }
                }

                @Override
                public void onFailed(int code, String msg) {
                    updateTalkRoomList(null,null);
                }
            }));
        }
    }

//    private void updateTalkData(List<Talk> talkList) {
//        if (talkList != null){
//            mTalkGroupNum = talkList.size();
//            updateToolbarTitle();
//
//            mAdapter.addTalkItem(talkList);
//
//            for (Talk talk : talkList) {
//                if (talk != null) {
//                    //  根据talkId，再获取talkId的相关成员列表
//                    WRoom.cmdGetTalkRoomList(talk.talkId,new CmdActionLister<List<Room>>(TalkActivity.this, new ICmdCallback<List<Room>>() {
//                        @Override
//                        public void onSuccess(List<Room> data) {
//                            updateTalkRoomList(talk,data);
//                        }
//
//                        @Override
//                        public void onFailed(int code, String msg) {
//                            updateTalkRoomList(talk,null);
//                        }
//                    }));
//                }
//            }
//        }
//
//        mRefreshLayout.finishRefresh();
//    }

}
