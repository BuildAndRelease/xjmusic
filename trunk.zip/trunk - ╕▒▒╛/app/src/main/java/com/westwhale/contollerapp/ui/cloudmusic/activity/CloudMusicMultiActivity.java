package com.westwhale.contollerapp.ui.cloudmusic.activity;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.LinearLayout;
import android.support.v7.widget.Toolbar;
import android.widget.Toast;

import com.alibaba.fastjson.JSON;
import com.blankj.utilcode.util.ToastUtils;
import com.westwhale.contollerapp.R;
import com.westwhale.contollerapp.application.WApp;
import com.westwhale.contollerapp.dev.CmdActionLister;
import com.westwhale.contollerapp.dev.ICmdCallback;
import com.westwhale.contollerapp.dev.WRoom;
import com.westwhale.contollerapp.ui.base.activity.BaseActivity;
import com.westwhale.contollerapp.ui.cloudmusic.adapter.CloudMultiAdapter;
import com.westwhale.contollerapp.ui.favorite.songsheet.dialog.FavoriteAddMediaDialog;
import com.westwhale.api.protocolapi.bean.media.CloudMusic;
import com.westwhale.api.protocolapi.bean.media.Media;

import java.util.List;

/**
 * Description:
 * Author: chenyaoli
 * Date: 2018-12-12
 * History:
 */
public class CloudMusicMultiActivity extends BaseActivity implements CloudMultiAdapter.CallBack {

    public final static String DATA_MUSIC_LIST = "musiclist";

    private Toolbar mToolbar;
    private RecyclerView mDataRecyclerView;
    private LinearLayout mPlayLayout,mPlaylistAddLayout, mFavoriteAddLayout, mDownloadLayout;
    private CloudMultiAdapter mCloudMultiAdapter;
    private Menu mMenu;

    private List<CloudMusic> mItemList;

    public void updateDataList(List<CloudMusic> list){
        mItemList = list;
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_cloudmusic_select);

        initView();
        initListener();
        initData();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        super.onCreateOptionsMenu(menu);

        getMenuInflater() .inflate(R.menu.menu_batch, menu);

        mMenu = menu;
        return true;
    }

    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {
        MenuItem item = menu.findItem(R.id.menu_select_all);

        return super.onPrepareOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.menu_select_all){
            if (mCloudMultiAdapter.getSelectedNum() == mCloudMultiAdapter.getItemCount()){
                // 全不选
                mCloudMultiAdapter.cancelAllItem();
            }else{
                // 全选
                mCloudMultiAdapter.selectAllItem();
            }
        }
        return super.onOptionsItemSelected(item);
    }

    private void initView() {
        mToolbar = findViewById(R.id.cloudmusic_mutli_toolbar);
        // 设置toolbar
        setSupportActionBar(mToolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setHomeAsUpIndicator(R.drawable.cloud_mutli_backup);
        }

        mPlayLayout = findViewById(R.id.cloudmusic_mutli_play);
        mPlaylistAddLayout = findViewById(R.id.cloudmusic_mutli_playlist_add);
        mFavoriteAddLayout = findViewById(R.id.cloudmusic_mutli_favorite_add);
        mDownloadLayout = findViewById(R.id.cloudmusic_mutli_download);

        mDataRecyclerView = findViewById(R.id.cloudmusic_mutli_recyclerview);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        mDataRecyclerView.setLayoutManager(linearLayoutManager);
        mCloudMultiAdapter = new CloudMultiAdapter(this);
        mDataRecyclerView.setAdapter(mCloudMultiAdapter);
        mDataRecyclerView.setHasFixedSize(true);
        mDataRecyclerView.addItemDecoration(new DividerItemDecoration(this, DividerItemDecoration.VERTICAL));
    }

    private void initListener() {
        mToolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        mPlayLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 开始播放已选择的歌曲
                CloudMusic item = null;
                List<CloudMusic> itemList = null;
                if (mCloudMultiAdapter != null){
                    itemList = mCloudMultiAdapter.getSelectedList();
                    if ((itemList != null) && (itemList.size() > 0)){
                        item = itemList.get(0);
                    }
                }
                WRoom room = WApp.Instance.getDevManager().getSelectedRoom();
                if (room != null){
                    WRoom.cmdPlayCloudMusicList(item,itemList,new CmdActionLister<>(CloudMusicMultiActivity.this, new ICmdCallback<Boolean>() {
                        @Override
                        public void onSuccess(Boolean data) {

                        }

                        @Override
                        public void onFailed(int code, String msg) {
                            Toast.makeText(CloudMusicMultiActivity.this, "播放歌曲失败...", Toast.LENGTH_SHORT).show();
                        }
                    }));
                }
            }
        });

        mPlaylistAddLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 添加到播放列表
                CloudMusic item = null;
                List<CloudMusic> itemList = null;
                if (mCloudMultiAdapter != null){
                    itemList = mCloudMultiAdapter.getSelectedList();
                }
                WRoom room = WApp.Instance.getDevManager().getSelectedRoom();
                if (room != null){
                    WRoom.cmdAddToCloudMusicList(itemList,new CmdActionLister<>(CloudMusicMultiActivity.this, new ICmdCallback<Boolean>() {
                        @Override
                        public void onSuccess(Boolean data) {
                            ToastUtils.showShort("添加到播放列表成功");
                        }

                        @Override
                        public void onFailed(int code, String msg) {
                            ToastUtils.showShort("添加失败...");
                        }
                    }));
                }
            }
        });

        mFavoriteAddLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 将已选择的歌曲添加到自建歌单
                List<CloudMusic> itemList = null;
                if (mCloudMultiAdapter != null){
                    itemList = mCloudMultiAdapter.getSelectedList();
                }

                if ((null == itemList) || (itemList.size() == 0)){
                    ToastUtils.showShort("列表为空");
                    return;
                }
                FavoriteAddMediaDialog favoriteDialog = new FavoriteAddMediaDialog();
                favoriteDialog.updateMediaList(Media.CLOUD_MUSIC,itemList);
                favoriteDialog.show(getSupportFragmentManager(),FavoriteAddMediaDialog.TAG);
            }
        });

        mDownloadLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                List<CloudMusic> itemList = null;
                if (mCloudMultiAdapter != null){
                    itemList = mCloudMultiAdapter.getSelectedList();
                }

                if ((null == itemList) || (itemList.size() == 0)){
                    ToastUtils.showShort("列表为空");
                    return;
                }
                // 开始下载已选择的歌曲
                WRoom room = WApp.Instance.getDevManager().getSelectedRoom();
                if (room != null){
                    room.cmdDownloadMusicList("",itemList,new CmdActionLister<Boolean>(CloudMusicMultiActivity.this, new ICmdCallback<Boolean>() {
                        @Override
                        public void onSuccess(Boolean data) {
                            if (data) {
                                ToastUtils.showShort("下载成功");
                            }
                        }

                        @Override
                        public void onFailed(int code, String msg) {
                            ToastUtils.showShort("下载失败");
                        }
                    }));
                }
            }
        });
    }

    private void initData() {
        if (mItemList != null){
            mItemList.clear();
            mItemList = null;
        }
        String dataStr = getIntent().getStringExtra(DATA_MUSIC_LIST);
        try{
            mItemList = JSON.parseArray(dataStr,CloudMusic.class);
        }catch (Exception e){
            e.printStackTrace();
            mItemList = null;
        }

        if (mItemList != null) {
            mCloudMultiAdapter.upateDataList(mItemList);
            mCloudMultiAdapter.notifyDataSetChanged();
        }
    }

    @Override
    public void onMusicItemClick(CloudMusic musicItem, boolean selected) {

    }

    @Override
    public void onCheckedNumChanged(int selectednum) {
        String title = getString(R.string.toolbar_menu_all_select);
        if (selectednum == mCloudMultiAdapter.getItemCount()){
            title = getString(R.string.toolbar_menu_all_un_select);
        }
        updateMenuTitle(title);

        String toolbarTitle = getString(R.string.cloudmusic_multi_title);
        if (selectednum > 0){
            toolbarTitle = toolbarTitle + "(" + selectednum +")";
        }
        mToolbar.setTitle(toolbarTitle);
    }

    private void updateMenuTitle(String title){

        if (mMenu != null) {
            MenuItem menuItem = mMenu.findItem(R.id.menu_select_all);
            if (menuItem != null) {
                menuItem.setTitle(title);
            }
        }
    }
}
