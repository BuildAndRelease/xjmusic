package com.westwhale.contollerapp.ui.base.fragment;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.annotation.UiThread;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

public abstract class LazyBaseFragment extends BaseFragment {
    private boolean mHasLazyLoaded = false;//懒加载过
    private boolean mHasPrepared = false;

    public abstract int getLayoutId();

    public abstract void initView(View view);
    public abstract void initListener();
    public abstract void initData();

    @UiThread
    public abstract void onLazyLoad();

    public void onRetryLoad(){

    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(getLayoutId(), container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        initView(view);
        initListener();

        mHasPrepared = true;

        lazyLoad();
    }


    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);
        if (isVisibleToUser) {
            lazyLoad();
        }
    }

    // 调用懒加载
    private void lazyLoad() {
        // 用户可见Fragment && 视图已经准备完毕
        if (getUserVisibleHint() && mHasPrepared) {
            // 没有加载过数据,则开始加载数据；若已经加载过，则提供接口，判断是否需要进行重试获取数据
            if (!mHasLazyLoaded) {
                onLazyLoad();
                mHasLazyLoaded = true;
            }else{
                onRetryLoad();
            }
        }
    }
}
