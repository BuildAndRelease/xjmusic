package com.westwhale.contollerapp.ui.main;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.SimpleItemAnimator;
import android.util.Log;
import android.widget.Toast;

import com.blankj.utilcode.util.LogUtils;
import com.blankj.utilcode.util.ThreadUtils;
import com.westwhale.contollerapp.R;
import com.westwhale.contollerapp.common.ImageTextItem;
import com.westwhale.contollerapp.dev.API_DEFINE;
import com.westwhale.contollerapp.dev.CmdActionLister;
import com.westwhale.contollerapp.dev.ICmdCallback;
import com.westwhale.contollerapp.dev.WHost;
import com.westwhale.contollerapp.dev.WRoom;
import com.westwhale.contollerapp.eventbus.notify.NotifyDevStatJsonEvent;
import com.westwhale.contollerapp.ui.base.activity.BaseActivity;
import com.westwhale.contollerapp.eventbus.SearchHostEvent;
import com.westwhale.contollerapp.ui.main.adapter.SearchDevExpandItemAdapter;
import com.westwhale.contollerapp.ui.main.dialog.HostInfoMoreDialog;
import com.westwhale.api.protocolapi.BaApi;
import com.westwhale.api.protocolapi.bean.hostroom.Host;
import com.westwhale.api.protocolapi.bean.hostroom.Room;
import com.westwhale.contollerapp.ui.widget.dialog.ImageTextItemDialog;
import com.westwhale.contollerapp.ui.widget.interfs.DialogResultListener;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class SearchDevActivity extends BaseActivity implements SearchDevExpandItemAdapter.CallBack {
    private final static String TAG = "SearchDevActivity";

    private final int WAIT_FOR_COUNT_MIN = 3;  // 搜索指令，每次最多发送3次

    private SwipeRefreshLayout mRefreshLayout;
    private SearchDevExpandItemAdapter mSearchDevItemAdapter;

    private boolean mIsVisible = false;  // 标记当前activity是否可见
    private int mWaitForCount = WAIT_FOR_COUNT_MIN;

    private final int HOST_MOREITEM_TYPE_ROOM = 1;
    private final int HOST_MOREITEM_TYPE_MACHINE = 2;
    private final int HOST_MOREITEM_TYPE_IP = 3;
    private final int HOST_MOREITEM_TYPE_RESTART = 4;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_dev);

        // eventbus 注册
        EventBus.getDefault().register(this);

        initView();
        initListener();

        initData();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        mSearchHostHandler.removeCallbacksAndMessages(null);
        // eventbus 取消注册
        EventBus.getDefault().unregister(this);
    }

    @Override
    protected void onStart() {
        super.onStart();
    }

    @Override
    protected void onResume() {
        super.onResume();

        mIsVisible = true;
        // 当从后台返回APP时，会调用 onStart()
        // 当 当前 Activity 可见时，会调用 onResume()
        this.searchHost();
    }

    @Override
    protected void onPause() {
        super.onPause();

        mIsVisible = false;
    }

    @Override
    protected void onStop() {
        super.onStop();
    }

    @Override
    public void onHostItemClick(Host host) {
        // 弹出 主机更多信息 界面
//        HostInfoMoreDialog hostInfoMoreFragment = new HostInfoMoreDialog();
//        Bundle args = new Bundle();
//        args.putString(HostInfoMoreDialog.ARG_HOST_NAME, host.name);
//        args.putString(HostInfoMoreDialog.ARG_HOST_TYPE, host.deviceType);
//        args.putString(HostInfoMoreDialog.ARG_HOST_IP, host.ipAddress);
//        args.putInt(HostInfoMoreDialog.ARG_HOST_ROOMNUMS, host.rooms.size());
//        args.putString(HostInfoMoreDialog.ARG_HOST_ID, host.id);
//        hostInfoMoreFragment.setArguments(args);
//
//        hostInfoMoreFragment.show(getSupportFragmentManager(), "host_info_more");
        String title = "主机:"+host.deviceType;
        String rooms = getResources().getString(R.string.host_more_dev_rooms) + "  " + host.rooms.size();
        String type = getResources().getString(R.string.host_more_dev_type) + "  "  + host.deviceType;
        String ipStr = getResources().getString(R.string.host_more_dev_ip) + "  "  + host.ipAddress;
        String rebootStr = getResources().getString(R.string.host_more_reboot);

        List<ImageTextItem> dataList = new ArrayList<>();
        dataList.add(new ImageTextItem(HOST_MOREITEM_TYPE_ROOM,R.drawable.host_more_room,rooms));
        dataList.add(new ImageTextItem(HOST_MOREITEM_TYPE_MACHINE,R.drawable.host_more_type,type));
        dataList.add(new ImageTextItem(HOST_MOREITEM_TYPE_IP,R.drawable.host_more_ip,ipStr));
        dataList.add(new ImageTextItem(HOST_MOREITEM_TYPE_RESTART,R.drawable.host_more_reboot,rebootStr));

        showHostMoreDialog(title, dataList, new DialogResultListener<ImageTextItem>() {
            @Override
            public void onResultListener(ImageTextItem value) {
                if (value != null){
                    switch (value.getType()){
                        case HOST_MOREITEM_TYPE_RESTART: {
                            // 重启
                            ThreadUtils.getIoPool().execute(new Runnable() {
                                @Override
                                public void run() {
                                    try {
                                        // 重启设备
                                        BaApi.getInstance().setRoomInfo(host.ipAddress, host.id);
                                        BaApi.getInstance().restartSystem();
                                    } catch (Exception e) {
                                        e.printStackTrace();
                                    }
                                }
                            });

                            break;
                        }
                        default:
                            break;
                    }
                }
            }
        });

    }

    @Override
    public void onRoomItemClick(Room room) {
        // 准备进入房间
        if ((Room.DevState.OPEN).equals(room.devStat)) {
            this.entryMainRoonActivity(room.hostId, room.roomId);
        }
    }

    @Override
    public void onRoomStatClick(Room room) {
        // 开关房间状态
        // 设置 room 状态
        if (!room.devStat.equals(Room.DevState.OPEN) && !room.devStat.equals(Room.DevState.CLOSE)) {
            Toast.makeText(SearchDevActivity.this, "房间未连接或未知...", Toast.LENGTH_SHORT).show();
            return;
        }
        String setDevStat = Room.DevState.CLOSE;
        if ((Room.DevState.CLOSE).equals(room.devStat)) {
            setDevStat = Room.DevState.OPEN;
        }

        Host host = mMyApp.getDevManager().getHostById(room.hostId);
        if (host == null){
            Toast.makeText(SearchDevActivity.this, "设备不存在...", Toast.LENGTH_SHORT).show();
            return;
        }
        BaApi.getInstance().setRoomInfo(host.ipAddress,room.roomId);
        String finalSetDevStat = setDevStat;
        WRoom.cmdSetDevStat(setDevStat,new CmdActionLister<Boolean>(SearchDevActivity.this, new ICmdCallback<Boolean>() {
            @Override
            public void onSuccess(Boolean data) {
                // 设置状态后，再次获取，以更新状态
                if (data) {
                    room.devStat = finalSetDevStat;
                    updateRoomStat(room);
                }
            }

            @Override
            public void onFailed(int code, String msg) {
                Toast.makeText(SearchDevActivity.this,"SetDevStat失败"+code+"  roomName:"+room.roomName,Toast.LENGTH_SHORT).show();
            }
        }));
    }


    private void initView() {
        // 先给adapter设置空数据，异步加载好后更新数据，防止Recyclerview no attach
        RecyclerView recyclerView = findViewById(R.id.dev_recyclerview);
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);
        mSearchDevItemAdapter = new SearchDevExpandItemAdapter(null);
        mSearchDevItemAdapter.setCallBack(this);
        recyclerView.setAdapter(mSearchDevItemAdapter);
        recyclerView.setHasFixedSize(true);
        recyclerView.addItemDecoration(new DividerItemDecoration(SearchDevActivity.this, DividerItemDecoration.VERTICAL));
        // 设置没有item动画
        ((SimpleItemAnimator) Objects.requireNonNull(recyclerView.getItemAnimator())).setSupportsChangeAnimations(false);

        mRefreshLayout = findViewById(R.id.dev_list_refresh_view);

    }

    private void initListener() {
        mRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                searchHost();
            }
        });
    }

    private void initData() {

    }

    Handler mSearchHostHandler = new Handler();
    private void searchHost() {
//        ToastUtils.showShort(R.string.searchdev_search_hint);
        Toast.makeText(SearchDevActivity.this,"正在搜索主机...",Toast.LENGTH_SHORT).show();

        // 重置数据
        mMyApp.getDevManager().resetHostAndRoom();
        mSearchDevItemAdapter.removeALl();

        // 刷新等待
        mRefreshLayout.setRefreshing(true);

        mWaitForCount = WAIT_FOR_COUNT_MIN;

        mSearchHostHandler.removeCallbacksAndMessages(null);
        mSearchHostHandler.post(new Runnable() {
            @Override
            public void run() {
                mSearchHostHandler.postDelayed(this,2*1000);
                mWaitForCount--;
                if (mWaitForCount == 0){
                    mRefreshLayout.setRefreshing(false);
                    mSearchHostHandler.removeCallbacksAndMessages(null);
                }

                ThreadUtils.getIoPool().execute(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            BaApi.getInstance().searchHostUDP();
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                });
            }
        });


    }

    public void entryMainRoonActivity(String hostId, String roomId) {
        //进入指定房间界面，首先需配置WApp中的room
        mMyApp.getDevManager().setCurrentRoom(hostId,roomId);

//        // 延时 50 ms，然后再进入主界面
//        try {
//            Thread.sleep(50);
//        } catch (InterruptedException e) {
//            e.printStackTrace();
//        }
        startActivity(new Intent(SearchDevActivity.this, MainRoomActivity.class));
    }

    public void addToHostMap(Host host){
        // 更新主机到主机列表，并更新界面
        if (host != null) {
            if (mRefreshLayout.isRefreshing()) {
                mRefreshLayout.setRefreshing(false);
            }

            if (!mMyApp.getDevManager().getHostMap().containsKey(host.id)){
                mMyApp.getDevManager().insertHostMap(host.id,host);
                mSearchDevItemAdapter.addHostItem(host);
            }
        }
    }

    public void updateRoomStat(Room room){
        if (null == room){
            return;
        }

        // 更新状态
        mSearchDevItemAdapter.updateRoomItem(room);
        if ((Room.DevState.OPEN).equals(room.devStat)) {
            entryMainRoonActivity(room.hostId, room.roomId);
        }
    }


    private void showHostMoreDialog(String title,List<ImageTextItem> dataList,DialogResultListener<ImageTextItem> listener){
        ImageTextItemDialog imageTextItemDialog = new ImageTextItemDialog();
        imageTextItemDialog.setOnDialogResultListener(listener);
        imageTextItemDialog.setDataList(dataList);

        Bundle bundle = new Bundle();
        bundle.putString(ImageTextItemDialog.DIALOG_TITLE,title);

        imageTextItemDialog.setArguments(bundle);
        imageTextItemDialog.show(getSupportFragmentManager(), "hostMoreInfoDialog");
    }

    /**
     * 接收处理 搜索主机回复处理
     * @param event
     */
    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onSearchHostCmdEvent(SearchHostEvent event) {
        // 当不可见时，忽略
        if (!mIsVisible){
            return;
        }

        Host host = event.getHost();
        if ((null == host) || (null == host.deviceType)){
            return;
        }


        WHost.cmdGetHostRoomList(host.ipAddress, host.id,new CmdActionLister<List<Room>>(SearchDevActivity.this, new ICmdCallback<List<Room>>() {
            @Override
            public void onSuccess(List<Room> data) {
                // 将主机添加到映射表中
                host.rooms = data;
                addToHostMap(host);
            }

            @Override
            public void onFailed(int code, String msg) {
                Toast.makeText(SearchDevActivity.this,"GetHostRoomList失败:"+code,Toast.LENGTH_SHORT).show();
            }
        }));
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onNotifyDevStatJsonEvent(NotifyDevStatJsonEvent event){
        if (!mIsVisible){
            return;
        }

        String devstat = event.getDevStat();
        if (!((API_DEFINE.CMD_DEVSTAT_CLOSE).equals(devstat)) && !((API_DEFINE.CMD_DEVSTAT_OPEN).equals(devstat))){
            return;
        }

        String sendId = event.getSendId();
        Room room = mMyApp.getDevManager().getRoomById(sendId);
        if (null == room){
            return;
        }

        room.devStat = devstat;
        // 更新状态
        mSearchDevItemAdapter.updateRoomItem(room);
    }


}
