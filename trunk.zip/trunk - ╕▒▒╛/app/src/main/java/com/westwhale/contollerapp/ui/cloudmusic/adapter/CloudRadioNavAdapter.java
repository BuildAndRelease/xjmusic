package com.westwhale.contollerapp.ui.cloudmusic.adapter;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.westwhale.contollerapp.R;
import com.westwhale.api.protocolapi.bean.cloudmusic.CloudRadioGroup;

import java.util.List;

public class CloudRadioNavAdapter extends RecyclerView.Adapter<CloudRadioNavAdapter.CloudRadioNavItemHolder> {
    public int TYPE_ITEM = 0;

    private List<CloudRadioGroup> mItemList;
    private CallBack mCallBack;
    private int mCurrentPos = -1;

    public void setCurrentPos(int pos) {
        /**
         * RecycylerView 的 notifyItemChanged 的机制（每次至少缓存两个）：
         *   1. 先把上两个ViewHolder放到缓存池中
         *   2. 然后再创建两个 ViewHolder
         *   3. 如果缓存池中已有 ViewHolder，则复用 ViewHolder，因此需要注意ViewHolder的状态
         */
        if (mCurrentPos == pos || pos == -1) {
            return;
        }
        int old = mCurrentPos;
        mCurrentPos = pos;
        notifyItemChanged(old);
        notifyItemChanged(mCurrentPos);
    }

    public interface CallBack {
        void onRadioNavItemClick(int pos, CloudRadioGroup raidoGroupItem);
    }

    public void upateDataList(List<CloudRadioGroup> itemList) {
        this.mItemList = itemList;
    }

    public CloudRadioNavAdapter(CallBack callBack) {
        this.mItemList = null;
        this.mCallBack = callBack;
    }

    @NonNull
    @Override
    public CloudRadioNavItemHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        // 默认返回 HOST 类型的 viewHolder
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_netmusic_radio_nav, viewGroup, false);
        return new CloudRadioNavItemHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull CloudRadioNavItemHolder cloudRadioNavItemHolder, int i) {
        final CloudRadioGroup radioGroup = mItemList.get(i);
        cloudRadioNavItemHolder.mTitleTv.setText(radioGroup.name);
        if (mCurrentPos == i) {
            cloudRadioNavItemHolder.mTitleTv.setTextColor(cloudRadioNavItemHolder.itemView.getResources().getColor(R.color.cloud_radio_nav_select));
            cloudRadioNavItemHolder.mThreeIv.setBackgroundColor(cloudRadioNavItemHolder.itemView.getResources().getColor(R.color.cloud_radio_nav_select));
        } else {
            cloudRadioNavItemHolder.mTitleTv.setTextColor(cloudRadioNavItemHolder.itemView.getResources().getColor(R.color.cloud_radio_nav_default));
            cloudRadioNavItemHolder.mThreeIv.setBackgroundColor(cloudRadioNavItemHolder.itemView.getResources().getColor(R.color.cloud_radio_nav_default));
        }
        // 设置第一项不显示上半部分线，最后一项不显示下半部分线
        if (0 == i) {
            cloudRadioNavItemHolder.mSecondIv.setVisibility(View.INVISIBLE);
        } else if (i == (mItemList.size() - 1)) {
            cloudRadioNavItemHolder.mFourIv.setVisibility(View.INVISIBLE);
            cloudRadioNavItemHolder.mFiveTv.setVisibility(View.INVISIBLE);
        }else{
            cloudRadioNavItemHolder.mSecondIv.setVisibility(View.VISIBLE);
            cloudRadioNavItemHolder.mFourIv.setVisibility(View.VISIBLE);
            cloudRadioNavItemHolder.mFiveTv.setVisibility(View.VISIBLE);
        }

        cloudRadioNavItemHolder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mCallBack != null) {
                    setCurrentPos(i);
                    mCallBack.onRadioNavItemClick(i, radioGroup);
                }
            }
        });
    }

    @Override
    public int getItemCount() {
        return (null == mItemList) ? 0 : mItemList.size();
    }

    @Override
    public int getItemViewType(int position) {
        return TYPE_ITEM;
    }

    /**************************************   ItemHolder *******************************************/
    public class CloudRadioNavItemHolder extends RecyclerView.ViewHolder {
        TextView mTitleTv;
        ImageView mSecondIv, mThreeIv, mFourIv, mFiveTv;

        public CloudRadioNavItemHolder(@NonNull View itemView) {
            super(itemView);
            mTitleTv = itemView.findViewById(R.id.item_netmusic_radio_nav_text);
            mSecondIv = itemView.findViewById(R.id.item_netmusic_radio_nav_second);
            mThreeIv = itemView.findViewById(R.id.item_netmusic_radio_nav_third);
            mFourIv = itemView.findViewById(R.id.item_netmusic_radio_nav_four);
            mFiveTv = itemView.findViewById(R.id.item_netmusic_radio_nav_five);
        }
    }
}
