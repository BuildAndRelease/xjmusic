package com.westwhale.contollerapp.ui.talk.adapter;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.util.SparseBooleanArray;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.TextView;

import com.westwhale.api.protocolapi.bean.hostroom.Room;
import com.westwhale.contollerapp.R;

import java.util.ArrayList;
import java.util.List;

/**
 * Description:
 * Author: chenyaoli
 * Date: 2018-12-20
 * History
 *
 */
public class TalkingRoomAdapter extends RecyclerView.Adapter {
    private List<Room> mItemList;
    private CallBack mCallBack;

    public interface CallBack{
        void onItemClick(Room room);
    }

    public void setCallBack(CallBack callBack){
        this.mCallBack = callBack;
    }

    public void setDataList(List<Room> itemList){
        this.mItemList = itemList;
    }

    public void clearAllData(){
        if (mItemList != null){
            mItemList.clear();
            mItemList = null;
            notifyDataSetChanged();
        }
    }


    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_talk_talking_room, viewGroup, false);
        return new ItemHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder viewHolder, int i) {
        if (viewHolder instanceof ItemHolder){
            int pos = viewHolder.getAdapterPosition();
            final Room item = mItemList.get(pos);
            ItemHolder itemHolder = (ItemHolder)viewHolder;

            itemHolder.mNameView.setText(item.roomName);
        }
    }

    @Override
    public int getItemCount() {
        return (mItemList == null) ? 0 : mItemList.size();
    }

    private class ItemHolder extends RecyclerView.ViewHolder{
        private TextView mNameView;
        public ItemHolder(@NonNull View itemView) {
            super(itemView);
            mNameView = itemView.findViewById(R.id.item_talk_room_name);
        }
    }
}
