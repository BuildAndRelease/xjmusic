package com.westwhale.contollerapp.ui.talk.activity;


import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.blankj.utilcode.util.ToastUtils;
import com.westwhale.api.protocolapi.bean.hostroom.Room;
import com.westwhale.contollerapp.R;
import com.westwhale.contollerapp.application.WApp;
import com.westwhale.contollerapp.dev.CmdActionLister;
import com.westwhale.contollerapp.dev.ICmdCallback;
import com.westwhale.contollerapp.dev.WHost;
import com.westwhale.contollerapp.dev.WRoom;
import com.westwhale.contollerapp.ui.base.activity.BaseActivity;
import com.westwhale.contollerapp.ui.talk.adapter.TalkNewRoomAdapter;

import java.util.ArrayList;
import java.util.List;


public class TalkAddEditActivity extends BaseActivity implements TalkNewRoomAdapter.CallBack {
    public final static String TAG = TalkAddEditActivity.class.getName();

    private Toolbar mToolbar;
    private EditText mNameEdit;
    private ImageView mTalkOkIv;
    private RecyclerView mDataRv;
    private TalkNewRoomAdapter mAdapter;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_talk_addedit);

        initView();
        initListener();

        initData();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        hideSoftwareInputWindows();

        super.onBackPressed();
    }

    @Override
    public void onItemClick(Room room, boolean checkStat) {

    }

    private void initView() {
        mToolbar = findViewById(R.id.talk_addedit_toolbar);
        // 设置toolbar
        setSupportActionBar(mToolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        mTalkOkIv = findViewById(R.id.talk_addedit_ok_iv);
        mNameEdit = findViewById(R.id.talk_addedit_talkname_edit);

        mDataRv = findViewById(R.id.talk_addedit_room_recyclerview);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        mDataRv.setLayoutManager(linearLayoutManager);
        mAdapter = new TalkNewRoomAdapter();
        mAdapter.setCallBack(this);
        mDataRv.setAdapter(mAdapter);
        mDataRv.setHasFixedSize(true);
        mDataRv.addItemDecoration(new DividerItemDecoration(this, DividerItemDecoration.VERTICAL));
    }

    private void initListener() {
        mToolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        mTalkOkIv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 确定按钮
                String name = mNameEdit.getText().toString();
                if (name.isEmpty() ){
                    ToastUtils.showShort("请输入对讲组名称~");
                    return;
                }
                List<String> roomIdList = new ArrayList<>();
                List<Room> roomList = mAdapter.getSelectedList();
                for (Room room: roomList) {
                    if ((room != null) && (room.roomId != null) && (!room.roomId.isEmpty())){
                        roomIdList.add(room.roomId);
                    }
                }
                if (roomIdList.isEmpty()){
                    ToastUtils.showShort("请选择房间~");
                    return;
                }

                WRoom room = WApp.Instance.getDevManager().getSelectedRoom();
                if (room != null){
                    WRoom.cmdAddTalk(name,roomIdList,new CmdActionLister<Boolean>(TalkAddEditActivity.this, new ICmdCallback<Boolean>() {
                        @Override
                        public void onSuccess(Boolean data) {
                            if (data){
                                // 添加对讲组成功，返回
                                Intent intent = new Intent();
                                setResult(Activity.RESULT_OK,intent);

                                finish();
                            }
                        }

                        @Override
                        public void onFailed(int code, String msg) {

                        }
                    }));
                }
            }
        });

        mNameEdit.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                // 完成
                if (actionId == EditorInfo.IME_ACTION_DONE){
                    mNameEdit.clearFocus();

                    hideSoftwareInputWindows();

                    return true;
                }

                return false;
            }
        });
    }

    private void initData() {
        requestDataRoomList();
    }

    private void requestDataRoomList() {
        // 获取房间列表信息
        WHost host = WApp.Instance.getDevManager().getSelectedHost();
        if ( (host != null) && (host.getHost() != null)){
            WHost.cmdGetHostRoomList(host.getHost().ipAddress, host.getHost().id,new CmdActionLister<List<Room>>(TalkAddEditActivity.this, new ICmdCallback<List<Room>>() {
                @Override
                public void onSuccess(List<Room> data) {
                    updateDataList(data);
                }

                @Override
                public void onFailed(int code, String msg) {
                    ToastUtils.showShort("GetHostRoomList 失败:%d",code);
                }
            }));
        }
    }

    private void updateDataList(List<Room> roomlist){
        if (mAdapter != null){
            mAdapter.clearAllData();

            mAdapter.setDataList(roomlist);
            mAdapter.notifyDataSetChanged();
        }
    }

    private void hideSoftwareInputWindows(){
        // 隐藏时，把虚拟键盘隐藏
        InputMethodManager imm = (InputMethodManager)this.getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm != null) {
            imm.hideSoftInputFromWindow(mNameEdit.getWindowToken(), 0);
        }
    }

}
