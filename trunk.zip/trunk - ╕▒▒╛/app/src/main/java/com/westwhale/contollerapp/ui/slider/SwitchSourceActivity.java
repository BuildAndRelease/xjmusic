package com.westwhale.contollerapp.ui.slider;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.ActionBar;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Toast;

import com.blankj.utilcode.util.LogUtils;
import com.blankj.utilcode.util.ToastUtils;
import com.westwhale.api.protocolapi.bean.media.Media;
import com.westwhale.contollerapp.R;
import com.westwhale.contollerapp.application.WApp;
import com.westwhale.contollerapp.dev.API_DEFINE;
import com.westwhale.contollerapp.dev.CmdActionLister;
import com.westwhale.contollerapp.dev.ICmdCallback;
import com.westwhale.contollerapp.dev.WRoom;
import com.westwhale.contollerapp.ui.base.activity.BaseActivity;
import com.westwhale.contollerapp.common.ImageTextItem;
import com.westwhale.contollerapp.ui.slider.adapter.SwitchSourceAdapter;

import java.util.ArrayList;
import java.util.List;

/**
 * Description:
 * Author: chenyaoli
 * Date: 2018-12-20
 * History
 *
 */
public class SwitchSourceActivity extends BaseActivity implements SwitchSourceAdapter.CallBack {
    private Toolbar mToolbar;
    private RecyclerView mDataRecyclerView;
    private SwitchSourceAdapter mSwitchSourceAdapter;

    private final int SOURCE_TYPE_CLOUDMUSIC = 1;
    private final int SOURCE_TYPE_LOCALMUSIC = 2;
    private final int SOURCE_TYPE_CLOUDNETFM = 3;
    private final int SOURCE_TYPE_CLOUDSTORYTELLING = 4;
    private final int SOURCE_TYPE_AUX1 = 5;
    private final int SOURCE_TYPE_AUX2 = 6;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_slider_switchsource);

        initView();
        initListener();
        initData();
    }

    private void initView() {
        mToolbar = findViewById(R.id.slider_switchsource_toolbar);
        // 设置toolbar
        setSupportActionBar(mToolbar);
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(true);
        }

        mDataRecyclerView = findViewById(R.id.slider_switchsource_recyclerview);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        mDataRecyclerView.setLayoutManager(linearLayoutManager);
        mSwitchSourceAdapter = new SwitchSourceAdapter();
        mSwitchSourceAdapter.setCallBack(this);
        mDataRecyclerView.setAdapter(mSwitchSourceAdapter);
        mDataRecyclerView.setHasFixedSize(true);
        // 设置下拉上拉无阴影效果
        mDataRecyclerView.setOverScrollMode(View.OVER_SCROLL_NEVER);
        // 设置不可滑动
//        mDataRecyclerView.setNestedScrollingEnabled(false);
    }

    private void initListener() {
        mToolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

    }

    private void initData() {
        List<ImageTextItem> dataList = new ArrayList<>();

        dataList.add(new ImageTextItem(SOURCE_TYPE_CLOUDMUSIC,R.drawable.switchsource_cloudmusic,getString(R.string.switchsoure_cloudmusic)));
        dataList.add(new ImageTextItem(SOURCE_TYPE_CLOUDSTORYTELLING,R.drawable.switchsource_story,getString(R.string.switchsoure_story)));
        dataList.add(new ImageTextItem(SOURCE_TYPE_CLOUDNETFM,R.drawable.switchsource_netfm,getString(R.string.switchsoure_netfm)));
        dataList.add(new ImageTextItem(SOURCE_TYPE_LOCALMUSIC,R.drawable.switchsource_lcoalmusic,getString(R.string.switchsoure_localmusic)));
        dataList.add(new ImageTextItem(SOURCE_TYPE_AUX1,R.drawable.switchsource_aux,getString(R.string.switchsoure_aux0)));
        dataList.add(new ImageTextItem(SOURCE_TYPE_AUX2,R.drawable.switchsource_aux,getString(R.string.switchsoure_aux1)));

        mSwitchSourceAdapter.setDataList(dataList);
        mSwitchSourceAdapter.notifyDataSetChanged();
    }

    @Override
    public void onItemClick(ImageTextItem item, int pos) {
        if ((item != null) && (pos > -1)){
            String audioSrc = "";
            String id = "0";
            switch (item.getType()){
                case SOURCE_TYPE_CLOUDMUSIC:
                    audioSrc = Media.CLOUD_MUSIC;
                    break;
                case SOURCE_TYPE_CLOUDSTORYTELLING:
                    audioSrc = Media.CLOUD_STORY_TELLING;
                    break;
                case SOURCE_TYPE_CLOUDNETFM:
                    audioSrc = Media.CLOUD_NETFM;
                    break;
                case SOURCE_TYPE_LOCALMUSIC:
                    audioSrc = Media.LOCAL_MUSIC;
                    break;
                case SOURCE_TYPE_AUX1:
                    audioSrc = Media.LOCAL_AUX;
                    id = "0";
                    break;
                case SOURCE_TYPE_AUX2:
                    audioSrc = Media.LOCAL_AUX;
                    id = "1";
                    break;
                default:
                    break;
            }
            if (!audioSrc.isEmpty()){
                WRoom room = WApp.Instance.getDevManager().getSelectedRoom();
                if (room != null) {
                    room.cmdSetAudioSource(audioSrc,id, new CmdActionLister<Boolean>(SwitchSourceActivity.this, new ICmdCallback<Boolean>() {
                        @Override
                        public void onSuccess(Boolean data) {
                            if (data){
                                finish();
                            }
                        }

                        @Override
                        public void onFailed(int code, String msg) {
                            Toast.makeText(SwitchSourceActivity.this, "SetAudioSource失败:" + code, Toast.LENGTH_SHORT).show();
                        }
                    }));
                }
            }else {
                ToastUtils.showShort("音源不匹配失败");
            }
        }
    }
}
