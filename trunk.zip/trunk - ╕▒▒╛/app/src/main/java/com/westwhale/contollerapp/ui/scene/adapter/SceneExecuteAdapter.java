package com.westwhale.contollerapp.ui.scene.adapter;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.westwhale.api.protocolapi.bean.scene.Scene;
import com.westwhale.contollerapp.R;

import java.util.List;

/**
 * Description:
 * Author: chenyaoli
 * Date: 2018-12-12
 * History:
 */
public class SceneExecuteAdapter extends RecyclerView.Adapter {

    private List<Scene> mItemList;

    private CallBack mCallBack;
    public interface CallBack{
        void onItemClick(Scene item);
    }

    public void setCallBack(CallBack callBack){
        mCallBack = callBack;
    }


    public void setDataList(List<Scene> dataList){
        if (mItemList != null){
            mItemList.clear();
            mItemList = null;
            notifyDataSetChanged();
        }

        mItemList = dataList;
    }

    public void removeAll(){
        if (mItemList != null){
            mItemList.clear();
            mItemList = null;
            notifyDataSetChanged();
        }
    }

    public SceneExecuteAdapter(){
        this.mItemList = null;
        this.mCallBack = null;
    }

    @NonNull
    @Override
    public ItemHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_scene_sceneexecute, viewGroup, false);
        return new ItemHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder viewHolder, int i) {
        if (viewHolder instanceof ItemHolder){
            ItemHolder itemHolder = (ItemHolder) viewHolder;
            Scene item = mItemList.get(i);

            itemHolder.mTitleTv.setText(item.sceneName);

            itemHolder.itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (mCallBack != null){
                        mCallBack.onItemClick(item);
                    }
                }
            });
        }

    }

    @Override
    public int getItemCount() {
        return (null == mItemList) ? 0 : mItemList.size();
    }

    /**************************************   ItemHolder *******************************************/
    public class ItemHolder extends RecyclerView.ViewHolder{
        TextView mTitleTv;
        ImageView mStatIv;
        public ItemHolder(@NonNull View itemView) {
            super(itemView);
            mTitleTv = itemView.findViewById(R.id.item_scene_name);
            mStatIv = itemView.findViewById(R.id.item_scene_stat);
        }
    }
}
