package com.westwhale.contollerapp.ui.scene.bean;

import com.alibaba.fastjson.JSONObject;

public abstract class CmdActionBase {
    public static final int CMD_TYPE_SETDEVSTAT = 0;
    public static final int CMD_TYPE_SETVOLUME = 1;
    public static final int CMD_TYPE_SETEQ = 2;
    public static final int CMD_TYPE_SETMUTE = 3;
    public static final int CMD_TYPE_SETPLAYMODE = 4;
    public static final int CMD_TYPE_SETAUDIOSOURCE = 5;
    public static final int CMD_TYPE_PLAYLOCALMUSIC = 6;

    public static final int CMD_TYPE_PLAYMEDIA = 100;
    public static final int CMD_TYPE_PLAYINFO = 101;

    public static final int CMD_TYPE_UNDEFINE = 100000;


    public static final String CMD_NAME_SETDEVSTAT = "SetDevStat";
    public static final String CMD_NAME_SETVOLUME = "SetVolume";
    public static final String CMD_NAME_SETEQ = "SetEq";
    public static final String CMD_NAME_SETMUTE = "SetMute";
    public static final String CMD_NAME_SETPLAYMODE = "SetPlayMode";
    public static final String CMD_NAME_SETAUDIOSOURCE = "SetAudioSource";
    public static final String CMD_NAME_PLAYLOCALMUSIC = "PlayLocalMusic";

    public static final String CMD_NAME_PLAYMEDIA = "PlayMedia";
    public static final String CMD_NAME_PLAYINFO = "PlayInfo";


    protected int mType;
    protected String mCmdName;
    protected String mCmdArgs;

    public abstract String toJsonString();
    public abstract String getActionValue();
    public abstract void parseArgs();
    public void setCmdArgsByJson(String arg){
        mCmdArgs = arg;
        parseArgs();
    }

    public int getType(){
        return mType;
    }

    public String getCmdName() {
        String name = "";
        switch (mType){
            case CMD_TYPE_SETDEVSTAT:
                name = CMD_NAME_SETDEVSTAT;
                break;
            case CMD_TYPE_SETVOLUME:
                name = CMD_NAME_SETVOLUME;
                break;
            case CMD_TYPE_SETEQ:
                name = CMD_NAME_SETEQ;
                break;
            case CMD_TYPE_SETMUTE:
                name = CMD_NAME_SETMUTE;
                break;
            case CMD_TYPE_SETPLAYMODE:
                name = CMD_NAME_SETPLAYMODE;
                break;
            case CMD_TYPE_SETAUDIOSOURCE:
                name = CMD_NAME_SETAUDIOSOURCE;
                break;
            case CMD_TYPE_PLAYLOCALMUSIC:
                name = CMD_NAME_PLAYLOCALMUSIC;
                break;
            case CMD_TYPE_PLAYMEDIA:
                name = CMD_NAME_PLAYMEDIA;
                break;
            case CMD_TYPE_PLAYINFO:
                name = CMD_NAME_PLAYINFO;
                break;
            default:
                break;
        }

        return name;
    }

    public String getActionName(){
        String name = "";
        switch (mType){
            case CMD_TYPE_SETDEVSTAT:
                name = "开关机";
                break;
            case CMD_TYPE_SETVOLUME:
                name = "音量";
                break;
            case CMD_TYPE_SETEQ:
                name = "音效";
                break;
            case CMD_TYPE_SETMUTE:
                name = "静音";
                break;
            case CMD_TYPE_SETPLAYMODE:
                name = "播放模式";
                break;
            case CMD_TYPE_SETAUDIOSOURCE:
                name = "切换音源";
                break;
            case CMD_TYPE_PLAYLOCALMUSIC:
                name = "本地音乐";
                break;
            case CMD_TYPE_PLAYMEDIA:
                name = "播放信息";
                break;
            case CMD_TYPE_PLAYINFO:
                name = "播放媒体";
                break;
            default:
                break;
        }

        return name;
    }

}
