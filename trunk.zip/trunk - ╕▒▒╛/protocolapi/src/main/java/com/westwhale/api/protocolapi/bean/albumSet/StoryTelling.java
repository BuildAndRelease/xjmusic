package com.westwhale.api.protocolapi.bean.albumSet;

/**
 * 9 语言节目
 * Created by cyl on 2018/4/18.
 */

public class StoryTelling extends AlbumSetMeta {
    public int announcer;
    public String description;
    public int id;
    public String mediaName;
    public String mediaTypeName;
    public String pic;
    public long popNum;
    public String score;
    public int anchorId;
    public String anchorName;
    public String tracksCounts;
    public String updateTime;

    public StoryTelling() {
        super.albumSetTypeName = AlbumSetMeta.STORY_TELLING_ALBUM_SET;
    }

    @Override
    public String getPic() {
        return pic;
    }

    @Override
    public String getName() {
        return "语言节目---" + mediaName;
    }

    @Override
    public String getListName() {
        return AlbumSetMeta.STORY_TELLING_ALBUM_SET_LIST;
    }
}
