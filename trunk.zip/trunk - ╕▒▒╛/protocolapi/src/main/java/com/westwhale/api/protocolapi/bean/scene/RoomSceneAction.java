package com.westwhale.api.protocolapi.bean.scene;

import com.alibaba.fastjson.JSONObject;

import java.util.List;

/**
 * 场景动作类（SceneAcion）定义
 * Created by cyl on 2018/5/30.
 */

public class RoomSceneAction {
    public String roomId;
    public List<CmdAction> actionList;

    public static class CmdAction{
        //cmd名  "SetDevStat","SetVolume","SetPlayMode","SetAudioSource","SetEq","SetMusicVolumeEq","SetUniquePartyStat","ModifyDelayCloseTimer","DelaySceneAction","PlayScene","PlayLocalMusic"
        public String cmd;
        //cmd的附加参数,具体怎么拼装参数看文档或对应接口。
//        public String arg;
        public JSONObject arg;
    }
}
