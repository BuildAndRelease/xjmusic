package com.westwhale.api.protocolapi.bean.media;

import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;

import com.alibaba.fastjson.JSONObject;
import com.westwhale.api.protocolapi.bean.Singer;

import java.util.List;

/**
 * Description: 云音乐歌曲信息类
 * Author: chenyaoli
 * Date: 2018-11-10
 * History
 *
 */
public class CloudMusic extends Media implements Parcelable {
//             "albumId":35485,
//             "albumMid":"001jmC6x1RMfh0",
//             "albumName":"Vae新歌+精选珍藏合辑",
//             "duration":229,
//             "mediaSrc":"cloudMusic",
//             "picUrl":"aHR0cDovL2kuZ3RpbWcuY24vbXVzaWMvcGhvdG8vbWlkX3Npbmdlcl8xNTAvSi90LzAwMENLNXhOM3laREp0LmpncA==",
//             "singer":[
//                 {
//                     "id":7221,
//                     "mid":"000CK5xN3yZDJt",
//                     "name":"许嵩"
//                 },
//                 {
//                     "id":94074,
//                     "mid":"004D8n3B0kPbgY",
//                     "name":"安琪"
//                 }
//             ],
//             "songId":436081,
//             "songMid":"003KfHmX2s8FMq",
//             "songName":"爱情里的眼泪",
//             "canPlay":1
    public String songId;
    public String songMid;
    public String songName;
    public String duration;
    public String albumId;
    public String albumMid;
    public String albumName;
    public int canPlay;
    public String picUrl;
    public String lrcUrl;
    public List<Singer> singer;

    public CloudMusic() {
        super.mediaSrc = Media.CLOUD_MUSIC;
    }

    @Override
    public String toString() {
        JSONObject musicJson = new JSONObject();
        musicJson.put("songId",songId);
        musicJson.put("songMid",songMid);
        musicJson.put("songName",songName);
        musicJson.put("duration",duration);
        musicJson.put("albumId",albumId);
        musicJson.put("albumMid",albumMid);
        musicJson.put("albumName",albumName);
        musicJson.put("canPlay",canPlay);
        musicJson.put("picUrl",picUrl);
        musicJson.put("lrcUrl",lrcUrl);
        musicJson.put("singer",singer.toArray());
        return musicJson.toString();
    }

    public String getTitle() {
        StringBuilder stringBuilder = new StringBuilder("");
        stringBuilder.append(TextUtils.isEmpty(songName) ? "未知歌曲" : songName);
        stringBuilder.append("-").append(getSingersName());
        return stringBuilder.toString();
    }

    public String getSingersName() {
        StringBuilder stringBuilder = new StringBuilder("");
        if (singer == null || singer.isEmpty()) return stringBuilder.toString();
        StringBuilder singrName = new StringBuilder();
        for (Singer s : singer) {
            if (s.name != null && !TextUtils.isEmpty(s.name.trim()))
                singrName.append(s.name).append(",");
        }
        String singerN = singrName.toString();
        singerN = TextUtils.isEmpty(singerN) ? "未知歌手," : singerN;
        singerN = singerN.substring(0, singerN.length() - 1);
        return singerN;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(this.songId);
        dest.writeString(this.songMid);
        dest.writeString(this.songName);
        dest.writeString(this.duration);
        dest.writeString(this.albumId);
        dest.writeString(this.albumMid);
        dest.writeString(this.albumName);
        dest.writeInt(this.canPlay);
        dest.writeString(this.picUrl);
        dest.writeString(this.lrcUrl);
        dest.writeTypedList(this.singer);
    }

    protected CloudMusic(Parcel in) {
        this.songId = in.readString();
        this.songMid = in.readString();
        this.songName = in.readString();
        this.duration = in.readString();
        this.albumId = in.readString();
        this.albumMid = in.readString();
        this.albumName = in.readString();
        this.canPlay = in.readInt();
        this.picUrl = in.readString();
        this.lrcUrl = in.readString();
        this.singer = in.createTypedArrayList(Singer.CREATOR);
    }

    public static final Parcelable.Creator<CloudMusic> CREATOR = new Parcelable.Creator<CloudMusic>() {
        @Override
        public CloudMusic createFromParcel(Parcel source) {
            return new CloudMusic(source);
        }

        @Override
        public CloudMusic[] newArray(int size) {
            return new CloudMusic[size];
        }
    };
}
