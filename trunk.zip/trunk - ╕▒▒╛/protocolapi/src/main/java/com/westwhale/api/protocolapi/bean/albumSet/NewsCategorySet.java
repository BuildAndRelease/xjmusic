package com.westwhale.api.protocolapi.bean.albumSet;

/**
 * 云新闻资讯分类类的类定义
 * Created by cyl on 2018/4/18.
 */

public class NewsCategorySet extends AlbumSetMeta {
    public String categoryName;
    public String createdTime;
    public String id;
    public String parentId;
    public String pic;
    public String subscribesNumShow;
    public String type;
    public String updatedTime;

    public NewsCategorySet() {
        super.albumSetTypeName =  AlbumSetMeta.CLOUD_NEWS_CATEGORY_SET;
    }

    @Override
    public String getPic() {
        return "";
    }

    @Override
    public String getName() {
        return "新闻资讯---" + categoryName;
    }

    @Override
    public String getListName() {
        return AlbumSetMeta.NEWS_CATEGORY_SET_LIST;
    }
}
