package com.westwhale.api.protocolapi.bean;

/**
 * 专辑收藏夹
 * Created by cyl on 2018/5/4.
 */

public class AlbumSetFavorite {

    public int folderId;
    public String folderName;
}
