package com.westwhale.api.protocolapi.bean.cloudmusic;

/**
 * 云音乐搜索返回的专辑
 * 对比 *  {@link com.westwhale.api.protocolapi.bean.albumSet.CloudAlbumSet}少很多属性，属性名称也不同
 * Created by cyl on 2018/5/10.
 */

public class SearchAlbum {
    public int singerId;
    public String publicTime;
    public String albumSetTypeName;
    public String albumName;
    public int albumId;
    public String singerName;
    public String singerMid;
    public String albumMid;
    public String pic_url;
}

