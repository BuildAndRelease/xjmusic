package com.westwhale.api.protocolapi.bean;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * 歌手
 * Created by cyl on 18/4/8.
 */

public class Singer implements Parcelable {
   /* {
        "id":xx,
            "mid": "xxxxx" ,
            "name":"xxxxx"
    }*/
    public String id;
    public String mid;
    public String name;

    @Override
    public String toString() {
        return "Singer{" +
                "id='" + id + '\'' +
                ", mid='" + mid + '\'' +
                ", name='" + name + '\'' +
                '}';
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(this.id);
        dest.writeString(this.mid);
        dest.writeString(this.name);
    }

    public Singer() {
    }

    protected Singer(Parcel in) {
        this.id = in.readString();
        this.mid = in.readString();
        this.name = in.readString();
    }

    public static final Parcelable.Creator<Singer> CREATOR = new Parcelable.Creator<Singer>() {
        @Override
        public Singer createFromParcel(Parcel source) {
            return new Singer(source);
        }

        @Override
        public Singer[] newArray(int size) {
            return new Singer[size];
        }
    };
}
