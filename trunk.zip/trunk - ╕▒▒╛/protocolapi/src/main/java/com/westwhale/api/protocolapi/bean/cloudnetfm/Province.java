package com.westwhale.api.protocolapi.bean.cloudnetfm;

/**
 * 省
 * Created by cyl on 2018/6/8.
 */

public class Province {
    public int provinceCode;
    public String provinceName;
}
