package com.westwhale.api.protocolapi.bean.media;

import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;

import com.alibaba.fastjson.JSONObject;
import com.westwhale.api.protocolapi.bean.Singer;

import java.util.ArrayList;
import java.util.List;

/**
 * 本地音乐(localMusic)类
 */

public class LocalMusic extends Media implements Parcelable {
    public String songId;
    public String songMid;
    public String songName;
    public String duration;
    public String albumId;
    public String albumMid;
    public String albumName;
    public String picUrl;
    public String lrcUrl;
    public List<Singer> singer;

    public LocalMusic() {
        super.mediaSrc = Media.LOCAL_MUSIC;
    }

    @Override
    public String toString() {
        JSONObject musicJson = new JSONObject();
        musicJson.put("mediaSrc",mediaSrc);
        musicJson.put("songId",songId);
        musicJson.put("songMid",songMid);
        musicJson.put("songName",songName);
        musicJson.put("duration",duration);
        musicJson.put("albumId",albumId);
        musicJson.put("albumMid",albumMid);
        musicJson.put("albumName",albumName);
        musicJson.put("picUrl",picUrl);
        musicJson.put("lrcUrl",lrcUrl);
        musicJson.put("singer",singer.toArray());
        return musicJson.toString();
    }

    public String getTitle() {
        StringBuilder stringBuilder = new StringBuilder("");
        stringBuilder.append(TextUtils.isEmpty(songName) ? "未知歌曲" : songName);
        stringBuilder.append("-").append(getSingersName());
        return stringBuilder.toString();
    }

    public String getSingersName() {
        StringBuilder stringBuilder = new StringBuilder("");
        if (singer == null || singer.isEmpty()) return stringBuilder.toString();
        StringBuilder singrName = new StringBuilder();
        for (Singer s : singer) {
            if (s.name != null && !TextUtils.isEmpty(s.name.trim()))
                singrName.append(s.name).append(",");
        }
        String singerN = singrName.toString();
        singerN = TextUtils.isEmpty(singerN) ? "未知歌手," : singerN;
        singerN = singerN.substring(0, singerN.length() - 1);
        return singerN;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(this.mediaSrc);
        dest.writeString(this.songId);
        dest.writeString(this.songMid);
        dest.writeString(this.songName);
        dest.writeString(this.duration);
        dest.writeString(this.albumId);
        dest.writeString(this.albumMid);
        dest.writeString(this.albumName);
        dest.writeString(this.picUrl);
        dest.writeString(this.lrcUrl);
        dest.writeList(this.singer);
    }

    protected LocalMusic(Parcel in) {
        this.mediaSrc = in.readString();
        this.songId = in.readString();
        this.songMid = in.readString();
        this.songName = in.readString();
        this.duration = in.readString();
        this.albumId = in.readString();
        this.albumMid = in.readString();
        this.albumName = in.readString();
        this.picUrl = in.readString();
        this.lrcUrl = in.readString();
        this.singer = new ArrayList<Singer>();
        in.readList(this.singer, Singer.class.getClassLoader());
    }

    public static final Parcelable.Creator<LocalMusic> CREATOR = new Parcelable.Creator<LocalMusic>() {
        @Override
        public LocalMusic createFromParcel(Parcel source) {
            return new LocalMusic(source);
        }

        @Override
        public LocalMusic[] newArray(int size) {
            return new LocalMusic[size];
        }
    };
}
