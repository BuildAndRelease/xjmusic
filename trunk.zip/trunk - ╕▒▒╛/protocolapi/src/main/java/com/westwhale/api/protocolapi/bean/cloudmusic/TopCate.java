package com.westwhale.api.protocolapi.bean.cloudmusic;

import com.alibaba.fastjson.annotation.JSONField;
import com.westwhale.api.protocolapi.util.Base64Util;

import java.util.List;

/**
 * 热门榜单数据集合
 * Created by cyl on 2018/5/2.
 */

public class TopCate {
    public String cateItemName;
    @JSONField(name = "List")
    public List<CloudToplistSet> cloudToplistSets;

    public static class CloudToplistSet {
        public String id;
        public String albumSetTypeName;
        public String picurl;
        public String date;
        public String name;
        public List<CloudTopSong> songList;

        public static class CloudTopSong {
            public String song;
            public long no;
            public String singer;
        }
    }

}
