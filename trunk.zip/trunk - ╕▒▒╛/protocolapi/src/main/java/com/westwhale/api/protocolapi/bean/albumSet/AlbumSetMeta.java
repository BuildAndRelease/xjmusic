package com.westwhale.api.protocolapi.bean.albumSet;

/**
 * 专辑类信息(albumSetMeta类)：
 * 一共有9种
 * Created by cyl on 2018/5/23.
 */

public abstract class AlbumSetMeta {
    //1 云音乐专辑类的类定义：
    public static final String CLOUD_ALBUM_SET = "cloudAlbumSet";
    //2 云音乐歌手类的类定义:
    public static final String CLOUD_SINGER_SET = "cloudSingerSet";
    //3 云音乐分类类的类定义
    public static final String CLOUD_CATEGORY_SET = "cloudCategorySet";
    //4 云音乐歌单类的类定义
    public static final String CLOUD_DISS_SET = "cloudDissSet";
    //5 云音乐电台类的类定义
    public static final String CLOUD_NET_RADIO_SET = "cloudNetRadioSet";
    //6 本地歌曲目录类的类定义
    public static final String LOCAL_MUSIC_DIR_SET = "localMusicDirSet";
    //7 云新闻资讯分类类的类定义
    public static final String CLOUD_NEWS_CATEGORY_SET = "cloudNewsCategorySet";
    //8 语言节目主播类的类定义
    public static final String STORY_TELLING_ANCHOR_SET = "storyTellingAnchorSet";
    //9 语言节目专辑类的类定义
    public static final String STORY_TELLING_ALBUM_SET = "storyTellingAlbumSet";

    public String albumSetTypeName;
    //归属的ListName,方便组装数据

    public static final String CLOUD_ALBUM_SET_LIST = "cloudAlbumSetList";
    public static final String CLOUD_CATEGORY_SET_LIST = "cloudCategorySetList";
    public static final String CLOUD_DISS_SET_LIST = "cloudDissSetList";
    public static final String CLOUD_NET_RADIO_SET_LIST = "cloudNetRadioSetList";
    public static final String CLOUD_SINGER_SET_LIST = "cloudSingerSetList";
    public static final String LOCAL_MUSIC_DIR_SET_LIST = "localMusicDirSetList";
    public static final String NEWS_CATEGORY_SET_LIST = "newsCategorySetList";
    public static final String STORY_TELLING_ALBUM_SET_LIST = "storyTellingAlbumSetList";
    public static final String STORY_TELLING_ANCHOR_SET_LIST = "storyTellingAnchorSetList";

    public abstract String getPic();
    public abstract String getName();
    public abstract String getListName();
}
