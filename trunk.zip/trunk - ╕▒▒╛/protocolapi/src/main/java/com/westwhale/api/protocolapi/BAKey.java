package com.westwhale.api.protocolapi;
/**
 * 西鲸内部协议json数据解析的key
 * Created by cyl on 2018/3/27.
 */

public class BAKey {
    //全局广播内容key
    public static final String CONTENT = "content";
    public static final String VERSION = "version";

    //公用请求头
    public static final String SEND_ID = "sendId";
    public static final String RECV_ID = "recvId";
    public static final String CMD = "cmd";
    public static final String DIRECTION = "direction";
    public static final String DIRECT = "direct";
    public static final String ARG = "arg";
    public static final String REQUEST = "request";
    public static final String RESULT_CODE = "resultCode";

    //host udp广播搜索后得到的host信息
    public static final String DEVICE_ID = "deviceId";

    //和协议上不同
    public static final String DEVICE_IP = "deviceIp";
    public static final String HOST_IPADDRESS = "hostIPAddress";
    public static final String DEVICE_NAME = "deviceName";
    public static final String DEV_NAME = "devName";
    public static final String DEVICE_TYPE = "deviceType";
    public static final String DEV_TYPE = "devType";
    public static final String DEVICE_VERSION = "deviceVersion";
    public static final String DEV_VERSION = "devVersion";
    public static final String DEVICE_BARCODE = "barcode";


    public static final int ARG_DEL_DOWNLOADING = 0;
    public static final int ARG_DEL_DOWNLOADING_ALL = 1;
    public static final int ARG_START_DOWNLOADING = 2;
    public static final int ARG_START_DOWNLOADING_ALL = 3;
    public static final int ARG_DEL_DOWNLOADED = 4;
    public static final int ARG_DEL_DOWNLOADED_ALL = 5;

}
