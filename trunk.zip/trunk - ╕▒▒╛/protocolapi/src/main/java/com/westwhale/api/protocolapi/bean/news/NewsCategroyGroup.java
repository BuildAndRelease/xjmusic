package com.westwhale.api.protocolapi.bean.news;

import android.text.TextUtils;

import com.westwhale.api.protocolapi.bean.albumSet.NewsCategorySet;

import java.util.ArrayList;
import java.util.List;

/**
 * 自己组装的类，来适应分类
 * Created by cyl on 2018/5/15.
 */

public class NewsCategroyGroup{
    public String categroyName;
    public List<NewsCategorySet> categroys;

    public static List<NewsCategroyGroup> transfer(List<NewsCategorySet> categroys) {
        List<NewsCategroyGroup> res = new ArrayList<>();
        if (categroys == null || categroys.isEmpty()) return res;
        String tempType = "";
        NewsCategroyGroup group = new NewsCategroyGroup();
        for (NewsCategorySet categroy : categroys) {
            if (TextUtils.isEmpty(categroy.type)) continue;
            if (!tempType.equals(categroy.type)) {
                tempType = categroy.type;
                group = new NewsCategroyGroup();
                group.categroyName = tempType;
                group.categroys = new ArrayList<>();
                res.add(group);
            }
            group.categroys.add(categroy);
        }
        return res;
    }
}
