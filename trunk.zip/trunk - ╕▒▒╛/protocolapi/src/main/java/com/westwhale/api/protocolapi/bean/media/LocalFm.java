package com.westwhale.api.protocolapi.bean.media;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * 5 本地FM(localFm)类的类定义：
 * Created by cyl on 2018/4/8.
 */

public class LocalFm extends Media implements Parcelable {
    public String fmMid;
    public String fmId;
    public String freq;
    public String freqName;

    public LocalFm(){
        super.mediaSrc = Media.LOCAL_FM;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(this.fmMid);
        dest.writeString(this.fmId);
        dest.writeString(this.freq);
        dest.writeString(this.freqName);
    }

    protected LocalFm(Parcel in) {
        this.fmMid = in.readString();
        this.fmId = in.readString();
        this.freq = in.readString();
        this.freqName = in.readString();
    }

    public static final Parcelable.Creator<LocalFm> CREATOR = new Parcelable.Creator<LocalFm>() {
        @Override
        public LocalFm createFromParcel(Parcel source) {
            return new LocalFm(source);
        }

        @Override
        public LocalFm[] newArray(int size) {
            return new LocalFm[size];
        }
    };
}
