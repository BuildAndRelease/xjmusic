package com.westwhale.api.protocolapi.bean;

/**
 * 串口配置ID
 */
public class RoomSerialSet {
    public int serialId;
    public String roomId;
}
