package com.westwhale.api.protocolapi;

import android.text.TextUtils;
import android.util.Pair;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.TypeReference;
import com.westwhale.api.protocolapi.bean.AlbumSetFavorite;
import com.westwhale.api.protocolapi.bean.RoomSerialSet;
import com.westwhale.api.protocolapi.bean.media.CloudMusic;
import com.westwhale.api.protocolapi.bean.media.LocalMusic;
import com.westwhale.api.protocolapi.bean.albumSet.StoryTelling;
import com.westwhale.api.protocolapi.bean.cloudmusic.CloudMusicRecommed;
import com.westwhale.api.protocolapi.bean.cloudmusic.DissCategoryGroup;
import com.westwhale.api.protocolapi.bean.cloudmusic.CloudRadioGroup;
import com.westwhale.api.protocolapi.bean.Controller;
import com.westwhale.api.protocolapi.bean.DelayClose;
import com.westwhale.api.protocolapi.bean.LocalDirectory;
import com.westwhale.api.protocolapi.bean.media.LocalFm;
import com.westwhale.api.protocolapi.bean.MusicVolumeEq;
import com.westwhale.api.protocolapi.bean.ServerIpInfo;
import com.westwhale.api.protocolapi.bean.Talk;
import com.westwhale.api.protocolapi.bean.cloudmusic.DissInfo;
import com.westwhale.api.protocolapi.bean.media.CloudNetFm;
import com.westwhale.api.protocolapi.bean.cloudnetfm.GetNetFmCategoryResult;
import com.westwhale.api.protocolapi.bean.cloudnetfm.Province;
import com.westwhale.api.protocolapi.bean.download.DownloadItem;
import com.westwhale.api.protocolapi.bean.scene.Channel;
import com.westwhale.api.protocolapi.bean.scene.Scene;
import com.westwhale.api.protocolapi.bean.scene.RoomSceneAction;
import com.westwhale.api.protocolapi.bean.Timer;
import com.westwhale.api.protocolapi.bean.albumSet.AlbumSetMeta;
import com.westwhale.api.protocolapi.bean.albumSet.CloudAlbumSet;
import com.westwhale.api.protocolapi.bean.albumSet.CloudCategorySet;
import com.westwhale.api.protocolapi.bean.albumSet.CloudDissSet;
import com.westwhale.api.protocolapi.bean.albumSet.CloudRadioSet;
import com.westwhale.api.protocolapi.bean.albumSet.CloudSingerSet;
import com.westwhale.api.protocolapi.bean.cloudmusic.LyricMusic;
import com.westwhale.api.protocolapi.bean.media.Media;
import com.westwhale.api.protocolapi.bean.media.News;
import com.westwhale.api.protocolapi.bean.PlayList;
import com.westwhale.api.protocolapi.bean.hostroom.PlayingInfo;
import com.westwhale.api.protocolapi.bean.hostroom.Room;
import com.westwhale.api.protocolapi.bean.cloudmusic.SearchAlbum;
import com.westwhale.api.protocolapi.bean.cloudmusic.SearchPreview;
import com.westwhale.api.protocolapi.bean.cloudmusic.SongCategroyGroup;
import com.westwhale.api.protocolapi.bean.albumSet.LocalMusicDirSet;
import com.westwhale.api.protocolapi.bean.albumSet.NewsCategorySet;
import com.westwhale.api.protocolapi.bean.albumSet.StoryTellingAnchorSet;
import com.westwhale.api.protocolapi.bean.hostroom.RoomStatInfo;
import com.westwhale.api.protocolapi.bean.telling.Anchor;
import com.westwhale.api.protocolapi.bean.telling.AnchorCategroy;
import com.westwhale.api.protocolapi.bean.telling.AnchorInfo;
import com.westwhale.api.protocolapi.bean.media.Section;
import com.westwhale.api.protocolapi.bean.telling.CatrgroyGroup;
import com.westwhale.api.protocolapi.bean.telling.RankItem;
import com.westwhale.api.protocolapi.bean.cloudmusic.TopCate;
import com.westwhale.api.protocolapi.net.Request;
import com.westwhale.api.protocolapi.net.Response;
import com.westwhale.api.protocolapi.net.SocketService;
import com.westwhale.api.protocolapi.util.BaUtil;
import com.westwhale.api.protocolapi.util.Base64Util;

//import org.greenrobot.eventbus.EventBus;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 使用前需要initSendId();
 * 使用房间相关接口必须先setRoomInfo();
 * Created by cyl on 2018/4/28.
 */

public class BaApi {
    private Request roomRequest;
    public static BaApi sInstance;
    private String sendId = BaUtil.createDeviceId();

    private BaApi() {
    }

    public static BaApi getInstance() {
        if (sInstance == null) {
            synchronized (BaApi.class) {
                if (sInstance == null)
                    sInstance = new BaApi();
            }
        }
        return sInstance;
    }

    /**
     * 如果不设置，会给一个随机值。
     *
     * @param sendId 也就是deviceId
     */
    public void initSendId(String sendId) {
        if (TextUtils.isEmpty(sendId)) return;
        this.sendId = sendId;
    }

    /**
     * 对房间请求需要设置房间信息
     * 换了房间要再调用变更信息
     */
    public void setRoomInfo(String hostIp, String roomId) {
        roomRequest = new Request();
        roomRequest.ipAddress(hostIp).recvId(roomId).sendId(this.sendId);
    }

    /**
     * 4.2.1	搜寻主机 [UDP]
     */
    public void searchHostUDP() throws Exception {
        searchHostUDP("0.0.0");
    }

    public void searchHostUDP(String version) throws Exception {
        JSONObject jsonObject = new JSONObject();
        jsonObject.put(BAKey.SEND_ID, this.sendId);
        jsonObject.put(BAKey.RECV_ID, "FFFFFFFFFFFFFFFFFFFF");
        jsonObject.put(BAKey.CMD, CMD.SEARCH_HOST);
        jsonObject.put(BAKey.DIRECTION, BAKey.REQUEST);
        JSONObject argJson = new JSONObject();
        argJson.put(BAKey.VERSION, version);
        jsonObject.put(BAKey.ARG, argJson);
        SocketService.sendUDP(jsonObject.toString());
    }

    public Response executeInnerCheck(String data, String dataMd5, String fileName, List<String> args) throws Exception {
        Map<String, Object> params = Request.argPut("fileName", fileName);
        params.put("dataMd5", dataMd5);
        params.put("data", data);
        JSONArray jsonArray = new JSONArray();
        if (args != null) for (String s : args) {
            jsonArray.put(s);
        }
        params.put("args", jsonArray);
        String s = roomRequest.sendTCP(CMD.EXECUTE_INNER_CHECK, params);
        return new Response<>(s);
    }

    /**
     * 4.2.2	获取所有房间Id  (recvId为主机ID)
     */
    public Response<List<Room>> getRooms(String hostIp, String hostId) throws Exception {
        String s = new Request().ipAddress(hostIp).recvId(hostId).sendId(this.sendId)
                .sendTCP(CMD.GET_HOST_ROOM_LIST, Request.argPut("hostId", hostId));
        Response<List<Room>> res = new Response<>(s);
        if (res.resultCode == 0)
            res.bean = JSON.parseArray(new JSONObject(res.arg).getString("roomList"), Room.class);
        if (res.bean != null) for (Room room : res.bean) room.hostId = hostId;
        return res;
    }

    /**
     * 4.3	心跳包
     */
    public Response<Boolean> hearbeat() throws Exception{
        String s = roomRequest.sendTCP(CMD.HEART_BEAT, null);
        Response<Boolean> res = new Response<>(s);
        res.bean = res.resultCode == 0;
        return res;
    }

    public String constructHeartPackage(String recvId) throws Exception {
        JSONObject jsonObject = new JSONObject();
        jsonObject.put(BAKey.SEND_ID, this.sendId);
        jsonObject.put(BAKey.RECV_ID, recvId);
        jsonObject.put(BAKey.CMD, CMD.HEART_BEAT);
        jsonObject.put(BAKey.DIRECTION, BAKey.REQUEST);
        JSONObject argJson = new JSONObject();
        jsonObject.put(BAKey.ARG, argJson);
        SocketService.sendUDP(jsonObject.toString());

        return jsonObject.toString();
    }

    /**
     * 4.4.1	获取房间当前信息
     */
    public Response<PlayingInfo> getPlayingInfo() throws Exception {
        String s = roomRequest.sendTCP(CMD.GET_PLAYING_INFO, null);
        Response<PlayingInfo> res = new Response<>(s);
        if (res.resultCode == 0)
            res.bean = new PlayingInfo(res.arg);
        return res;
    }

    /**
     * 4.4.3	获取当前房间的基本状态信息（用于一次性获取较多的信息）
     */
    public Response<RoomStatInfo> getRoomStatInfo() throws Exception {
        String s = roomRequest.sendTCP(CMD.GET_ROOM_STAT_INFO, null);
        Response<RoomStatInfo> res = new Response<>(s);
        if (res.resultCode == 0)
            res.bean = JSON.parseObject(res.arg, RoomStatInfo.class);
        return res;
    }

    /**
     * 4.4.1	获取设备信息
     */
    public Response<String> getDevInfo() throws Exception {
        String s = roomRequest.sendTCP(CMD.GET_DEV_INFO, null);
        Response<String> res = new Response<>(s);
        if (res.resultCode == 0)
            res.bean = res.arg;
        return res;
    }

    /**
     * 4.4.2	设置设备信息[用于更改房间名称]
     */
    public Response<Boolean> setDevInfo(String hostIp, String roomId, String devName) throws Exception {
        Map<String, Object> params = Request.argPut("devName", devName);
        String s = new Request().ipAddress(hostIp).recvId(roomId).sendId(this.sendId).sendTCP(CMD.SET_DEV_INFO, params);
        Response<Boolean> res = new Response<>(s);
        res.bean = res.resultCode == 0;
        return res;
    }

    /**
     * 4.5.1	获取设备开关机状态
     * 房间开关机状态
     */
    public Response<String> getDevStat() throws Exception {
        String s = roomRequest.sendTCP(CMD.GET_DEV_STAT, null);
        Response<String> res = new Response<>(s);
        if (res.resultCode == 0) res.bean = new JSONObject(res.arg).getString("devStat");
        return res;
    }

    /**
     * 4.5.2	开关机
     * 做了下升级，开关某主机的某房间
     */
    public Response<String> switchRoomDevstat(String hostIp, String roomId, String devStat) throws Exception {
        String s = new Request().ipAddress(hostIp).recvId(roomId).sendId(this.sendId)
                .sendTCP(CMD.SET_DEV_STAT, Request.argPut("devStat", devStat));
        Response<String> res = new Response<>(s);
        if (res.resultCode == 0)
            res.bean = new JSONObject(res.arg).getString("devStat");
        return res;
    }

    /**
     * 4.5.2	开关机
     */
    public Response<Boolean> setDevStat(String devStat) throws Exception {
        String s = roomRequest.sendTCP(CMD.SET_DEV_STAT, Request.argPut("devStat", devStat));
        Response<Boolean> res = new Response<>(s);
        if (res.arg != null) res.bean = res.resultCode == 0;
        return res;
    }


    /**
     * 4.5.4	房间全开/全关房间全开
     */
    public Response<Boolean> setAllDevStat(String devStat) throws Exception {
        String s = roomRequest.sendTCP(CMD.SET_ALL_DEV_STAT, Request.argPut("devStat", devStat));
        Response<Boolean> res = new Response<>(s);
        res.bean = res.resultCode == 0;
        return res;
    }

    /**
     * 4.6.1	获取音量
     */
    public Response<Integer> getVolume() throws Exception {
        String s = roomRequest.sendTCP(CMD.GET_VOLUME, null);
        Response<Integer> res = new Response<>(s);
        if (res.resultCode == 0)
            res.bean = new JSONObject(res.arg).getInt("volume");
        return res;
    }

    /**
     * 4.6.2	设置音量
     */
    public Response<Boolean> setVolum(String volume) throws Exception {
        String s = roomRequest.sendTCP(CMD.SET_VOLUME, Request.argPut("volume", volume));
        Response<Boolean> res = new Response<>(s);
        res.bean = res.resultCode == 0;
        return res;
    }

    /**
     * 4.6.3	音量加
     */
    public Response<Boolean> addVolume(int volume) throws Exception {
        String s = roomRequest.sendTCP(CMD.ADD_VOLUME, Request.argPut("volume",volume));
        Response<Boolean> res = new Response<>(s);
        res.bean = res.resultCode == 0;
        return res;
    }

    /**
     * 4.6.4	音量减
     */
    public Response<Boolean> subVolume(int volume) throws Exception {
        String s = roomRequest.sendTCP(CMD.SUB_VOLUME, Request.argPut("volume",volume));
        Response<Boolean> res = new Response<>(s);
        res.bean = res.resultCode == 0;
        return res;
    }

    /**
     * 4.7.1	获取音效
     */
    public Response<String> getEq() throws Exception {
        String s = roomRequest.sendTCP(CMD.GET_EQ, null);
        Response<String> res = new Response<>(s);
        if (res.resultCode == 0) res.bean = new JSONObject(res.arg).getString("eq");
        return res;
    }

    /**
     * 4.7.2	设置音效
     */
    public Response<Boolean> setEq(String eq) throws Exception {
        String s = roomRequest.sendTCP(CMD.SET_EQ, Request.argPut("eq", eq));
        Response<Boolean> res = new Response<>(s);
        res.bean = res.resultCode == 0;
        return res;
    }

    /**
     * 4.8.1	获取低音
     * 对中央机无效，对单体机有效
     */
    public Response<Integer> getBass() throws Exception {
        String s = roomRequest.sendTCP(CMD.GET_BASS, null);
        Response<Integer> res = new Response<>(s);
        if (res.resultCode == 0) res.bean = new JSONObject(res.arg).getInt("bass");
        return res;
    }

    /**
     * 4.8.2	设置低音
     * 对中央机无效，对单体机有效
     *
     * @param bass (-10, 10),和协议有出入
     */
    public Response<Boolean> setBass(int bass) throws Exception {
        String s = roomRequest.sendTCP(CMD.SET_BASS, Request.argPut("bass", bass));
        Response<Boolean> res = new Response<>(s);
        res.bean = res.resultCode == 0;
        return res;
    }

    /**
     * 4.9.1	获取高音
     */
    public Response<Integer> getTreble() throws Exception {
        String s = roomRequest.sendTCP(CMD.GET_TREBLE, null);
        Response<Integer> res = new Response<>(s);
        if (res.resultCode == 0) res.bean = new JSONObject(res.arg).getInt("treb");
        return res;
    }

    /**
     * 4.9.2	设置高音
     */
    public Response<Boolean> setTreble(int treb) throws Exception {
        String s = roomRequest.sendTCP(CMD.SET_TREBLE, Request.argPut("treb", treb));
        Response<Boolean> res = new Response<>(s);
        res.bean = res.resultCode == 0;
        return res;
    }

    /**
     * 4.10.1	获取静音状态
     */
    public Response<String> getMute() throws Exception {
        String s = roomRequest.sendTCP(CMD.GET_MUTE, null);
        Response<String> res = new Response<>(s);
        if (res.resultCode == 0)
            res.bean = new JSONObject(res.arg).getString("muteStat");
        return res;
    }

    /**
     * 4.10.2	设置静音
     *
     * @param muteStat “mute”“normal”
     */
    public Response<Boolean> setMute(String muteStat) throws Exception {
        String s = roomRequest.sendTCP(CMD.SET_MUTE, Request.argPut("muteStat", muteStat));
        Response<Boolean> res = new Response<>(s);
        res.bean = res.resultCode == 0;
        return res;
    }

    /**
     * 4.11.1	获取播放模式
     */
    public Response<String> getPlayMode() throws Exception {
        String s = roomRequest.sendTCP(CMD.GET_PLAY_MODE, null);
        Response<String> res = new Response<>(s);
        if (res.resultCode == 0)
            res.bean = new JSONObject(res.arg).getString("playMode");
        return res;
    }

    /**
     * 4.11.2	设置播放模式
     *
     * @param playMode “normal”“circle”“shuffle”“single”
     */
    public Response<Boolean> setPlayMode(String playMode) throws Exception {
        String s = roomRequest.sendTCP(CMD.SET_PLAY_MODE, Request.argPut("playMode", playMode));
        Response<Boolean> res = new Response<>(s);
        res.bean = res.resultCode == 0;
        return res;
    }

    /**
     * 4.12.1	查询电话静音是否被设置
     */
    @Deprecated
    public Response<Boolean> getPhoneMuteConfig() throws Exception {
        String s = roomRequest.sendTCP(CMD.GET_PHONE_MUTE_CONFIG, null);
        Response<Boolean> res = new Response<>(s);
        res.bean = res.resultCode == 0 && "enable".equals(new JSONObject(res.arg).getString("phoneMuteEnable"));
        return res;
    }

    /**
     * 4.12.2	使能/失能电话静音
     */
    @Deprecated
    public Response<Boolean> setPhoneMuteConfig(boolean enable) throws Exception {
        String s = roomRequest.sendTCP(CMD.SET_PHONE_MUTE_CONFIG, Request.argPut("phoneMuteEnable", enable ? "enable" : "disable"));
        Response<Boolean> res = new Response<>(s);
        res.bean = res.resultCode == 0;
        return res;
    }

    /**
     * 4.16.1	获取当前系统时间
     */
    public Response<String> getSysTime(String hostId) throws Exception {
        String s = new Request().ipAddress(roomRequest.ipAddress).sendId(sendId).recvId(hostId).sendTCP(CMD.GET_SYS_TIME, null);
        Response<String> res = new Response<>(s);
        if (res.resultCode == 0) res.bean = new JSONObject(res.arg).getString("time");
        return res;
    }

    /**
     * 4.16.2	设置当前系统时间
     */
    public Response<Boolean> setSysTime(String hostId, String time) throws Exception {
        String s = new Request().ipAddress(roomRequest.ipAddress).sendId(sendId).recvId(hostId).sendTCP(CMD.SET_SYS_TIME, Request.argPut("time", time));
        Response<Boolean> res = new Response<>(s);
        res.bean = res.resultCode == 0;
        return res;
    }

    /**
     * 4.17.1	获取系统日期
     */
    public Response<String> getSysDate(String hostId) throws Exception {
        String s = new Request().ipAddress(roomRequest.ipAddress).sendId(sendId).recvId(hostId).sendTCP(CMD.GET_SYS_DATE, null);
        Response<String> res = new Response<>(s);
        if (res.resultCode == 0) res.bean = new JSONObject(res.arg).getString("date");
        return res;
    }

    /**
     * 4.17.2	修改系统日期
     */
    public Response<Boolean> setSysDate(String hostId, String date) throws Exception {
        String s = new Request().ipAddress(roomRequest.ipAddress).sendId(sendId).recvId(hostId).sendTCP(CMD.SET_SYS_DATE, Request.argPut("date", date));
        Response<Boolean> res = new Response<>(s);
        res.bean = res.resultCode == 0;
        return res;
    }


    /**
     * 4.18.1	播放本地音乐
     */
    public Response<Boolean> playLocalMusic(LocalMusic music) throws Exception {
        return playMedia(CMD.PLAY_LOCAL_MUSIC, music);
    }

    /**
     * 4.18.2	播放云音乐
     */
    public Response<Boolean> playCloudMusic(CloudMusic music) throws Exception {
        return playMedia(CMD.PLAY_CLOUD_MUSIC, music);
    }

    /**
     * 4.18.3	播放云音乐(列表形式)
     */
    public Response<Boolean> playCloudMusicList(CloudMusic music, List<CloudMusic> musicList) throws Exception {
        Map<String, Object> params = Request.argPut("playMedia", music == null ? null : new JSONObject(JSON.toJSONString(music)));
        JSONArray jsonArray = new JSONArray();
        for (CloudMusic music1 : musicList) {
            jsonArray.put(new JSONObject(JSON.toJSONString(music1)));
        }
        params.put("mediaList", jsonArray);
        String s = roomRequest.sendTCP(CMD.PLAY_CLOUD_MUSIC_LIST, params);
        Response<Boolean> res = new Response<>(s);
        res.bean = res.resultCode == 0 && "success".equals(new JSONObject(res.arg).getString("playResult"));
        return res;
    }

    /**
     * 4.18.4	播放云电台
     */
    public Response<Boolean> playCloudRadio(String radioId) throws Exception {
        String s = roomRequest.sendTCP(CMD.PLAY_CLOUD_RADIO, Request.argPut("radioId", radioId));
        Response<Boolean> res = new Response<>(s);
        res.bean = res.resultCode == 0;
        return res;
    }

    /**
     * 4.18.5	播放云新闻资讯
     */
    public Response<Boolean> playCloudNews(News news) throws Exception {
        return playMedia(CMD.PLAY_CLOUD_NEWS, news);
    }

    /**
     * 4.18.6	播放云语言节目
     */
    public Response<Boolean> playCloudStory(Section section) throws Exception {
        return playMedia(CMD.PLAY_CLOUD_STORY, section);
    }

    public Response<Boolean> playCloudNetFm(CloudNetFm cloudNetFm) throws Exception {
        return playMedia(CMD.PLAY_CLOUD_NETFM, cloudNetFm);
    }


    private Response<Boolean> playMedia(String cmd, Media media) throws Exception {
        String s = roomRequest.sendTCP(cmd, Request.argPut("media", new JSONObject(JSON.toJSONString(media))));
        Response<Boolean> res = new Response<>(s);
        res.bean = res.resultCode == 0 && "success".equals(new JSONObject(res.arg).getString("playResult"));
        return res;
    }

    /**
     * 播放媒体，仅本地音乐，云音乐，新闻资讯，语言节目
     */
    public Response<Boolean> playMedia(Media media) throws Exception {
        if (media.mediaSrc == null) throw new BAException("mediasrc null");
        String cmd;
        switch (media.mediaSrc) {
            case Media.LOCAL_MUSIC:
                cmd = CMD.PLAY_LOCAL_MUSIC;
                break;
            case Media.CLOUD_MUSIC:
                cmd = CMD.PLAY_CLOUD_MUSIC;
                break;
            case Media.CLOUD_NEWS:
                cmd = CMD.PLAY_CLOUD_NEWS;
                break;
            case Media.CLOUD_STORY_TELLING:
                cmd = CMD.PLAY_CLOUD_STORY;
                break;
            case Media.CLOUD_NETFM:
                cmd = CMD.PLAY_CLOUD_NETFM;
                break;
            default:
                throw new BAException("mediasrc not support play");
        }
        return playMedia(cmd, media);
    }

    /**
     * 4.18.7	媒体播放、暂停、上一曲、下一曲控制
     *
     * @param Operation “pause”“resume”“next”“prev”
     */
    public Response<Boolean> playOperation(String Operation) throws Exception {
        String s = roomRequest.sendTCP(CMD.PLAY_CMD, Request.argPut("playCmd", Operation));
        Response<Boolean> res = new Response<>(s);
        res.bean = res.resultCode == 0;
        return res;
    }

    /**
     * 4.18.8	切换音源
     *
     * @param audioSource cloudMusic,storyTelling,newsCenter,localMusic,fm,aux,clientAux1,clientAux2
     */
    public Response<Boolean> setAudioSource(String audioSource, String id) throws Exception {
        Map<String, Object> params = Request.argPut("audioSource", audioSource);
        params.put("id", id);
        String s = roomRequest.sendTCP(CMD.SET_AUDIO_SOURCE, params);
        Response<Boolean> res = new Response<>(s);
        res.bean = res.resultCode == 0;
        return res;
    }

    /**
     * 4.18.9	获取当前播放状态
     */
    public Response<String> getPlayStat() throws Exception {
        String s = roomRequest.sendTCP(CMD.GET_PLAY_STAT, null);
        Response<String> res = new Response<>(s);
        if (res.resultCode == 0)
            res.bean = new JSONObject(res.arg).getString("playStat");
        return res;
    }

    /**
     * 4.19.1	获取当前播放时间
     */
    public Response<Integer> getPlayTime() throws Exception {
        String s = roomRequest.sendTCP(CMD.GET_PLAY_TIME, null);
        Response<Integer> res = new Response<>(s);
        if (res.resultCode == 0)
            res.bean = new JSONObject(res.arg).getInt("playTime");
        return res;
    }

    /**
     * 4.19.2	设置当前播放时间
     */
    public Response<Boolean> setPlayTime(int playTime) throws Exception {
        String s = roomRequest.sendTCP(CMD.SET_PLAY_TIME, Request.argPut("playTime", playTime));
        Response<Boolean> res = new Response<>(s);
        res.bean = res.resultCode == 0;
        return res;
    }

    /**
     * 4.20.1	播放当前播放列表
     */
    public Response<Boolean> playCurrentPlayList(Media media) throws Exception {
        String s = roomRequest.sendTCP(CMD.PLAY_CURRENT_PLAY_LIST, Request.argPut("media", new JSONObject(JSON.toJSONString(media))));
        Response<Boolean> res = new Response<>(s);
        res.bean = res.resultCode == 0 && "success".equals(new JSONObject(res.arg).getString("playResult"));
        return res;
    }

    /**
     * 4.20.2	获取当前播放列表
     */
    public Response<List<Media>> getCurrentPlayList(int pageNum, int pageSize) throws Exception {
        Map<String, Object> params = Request.argPut("pageNum", pageNum);
        params.put("pageSize", pageSize);
        String s = roomRequest.sendTCP(CMD.GET_CURRENT_PLAY_LIST, params);
        Response<List<Media>> res = new Response<>(s);
        if (res.resultCode == 0) res.bean = parseMedaiList(res.arg);
        return res;
    }

    /**
     * 4.20.3	从当前播放列表中删除媒体(批量操作)
     */
    public Response<Boolean> delMediaListFromPlayMediaList(List<Media> mediaList) throws Exception {
        String s = roomRequest.sendTCP(CMD.DEL_MEDIA_LIST_FROM_PLAY_MEDIA_LIST, Request.argPut("mediaList", consitiParams(mediaList)));
        Response<Boolean> res = new Response<>(s);
        res.bean = res.resultCode == 0;
        return res;
    }

    /**
     * 4.20.4	从当前播放列表中删除媒体(单个操作)
     */
    public Response<Boolean> delMediaFromPlayMediaList(Media media) throws Exception {
        String s = roomRequest.sendTCP(CMD.DEL_MEDIA_FROM_PLAY_MEDIA_LIST, Request.argPut("media", new JSONObject(JSON.toJSONString(media))));
        Response<Boolean> res = new Response<>(s);
        res.bean = res.resultCode == 0;
        return res;
    }

    /**
     * 4.20.5	清空当前播放列表
     */
    public Response<Boolean> clearPlayMediaList() throws Exception {
        String s = roomRequest.sendTCP(CMD.CLEAR_PLAY_MEDIA_LIST, null);
        Response<Boolean> res = new Response<>(s);
        res.bean = res.resultCode == 0;
        return res;
    }

    /**
     * 4.20.6	添加云音乐列表（目前仅支持云音乐）
     */
    public Response<Boolean> addToCloudMusicList(List<CloudMusic> mediaList) throws Exception {
        String s = roomRequest.sendTCP(CMD.ADD_TO_CLOUD_MUSIC_LIST, Request.argPut("mediaList", consitiParams(mediaList)));
        Response<Boolean> res = new Response<>(s);
        res.bean = res.resultCode == 0;
        return res;
    }

    /**
     * 4.20.7	获取上一次播放列表
     */
    public Response<List<Media>> getLastPlayList(String mediaSrc, int pageNum, int pageSize) throws Exception {
        Map<String, Object> params = Request.argPut("pageNum", pageNum);
        params.put("pageSize", pageSize);
        params.put("mediaSrc", mediaSrc);
        String s = roomRequest.sendTCP(CMD.GET_LAST_PLAY_LIST, params);
        Response<List<Media>> res = new Response<>(s);
        if (res.resultCode == 0) res.bean = parseMedaiList(res.arg);
        return res;
    }

    /**
     * 4.20.8	获取历史播放列表
     */
    public Response<List<Media>> getHistoryPlayList(String mediaSrc, int pageNum, int pageSize) throws Exception {
        Map<String, Object> params = Request.argPut("pageNum", pageNum);
        params.put("pageSize", pageSize);
        params.put("mediaSrc", mediaSrc);
        String s = roomRequest.sendTCP(CMD.GET_HISTORY_PLAY_LIST, params);
        Response<List<Media>> res = new Response<>(s);
        if (res.resultCode == 0) res.bean = parseMedaiList(res.arg);
        return res;
    }

    /**
     * 4.20.5	清空历史播放列表
     */
    public Response<Boolean> delHistoryPlayList() throws Exception {
        String s = roomRequest.sendTCP(CMD.DEL_HISTORY_PLAY_LIST, null);
        Response<Boolean> res = new Response<>(s);
        res.bean = res.resultCode == 0;
        return res;
    }

    public static List<Media> parseMedaiList(String arg) throws JSONException {
        List<Media> mediaList = new ArrayList<>();
        if (TextUtils.isEmpty(arg)) return mediaList;
        JSONObject argJson = new JSONObject(arg);
        JSONArray jsonArray = argJson.getJSONArray("mediaList");
        for (int i = 0, size = jsonArray.length(); i < size; i++) {
            Media media = PlayingInfo.parseMediaB(jsonArray.getJSONObject(i));
            if (media != null) mediaList.add(media);
        }
        return mediaList;
    }

    public Response<Boolean> switchToAux(int auxId) throws Exception {
        return switchAux(CMD.SWITCH_TO_AUX, Request.argPut("auxId", auxId));
    }

    /**
     * 4.21	切换到Aux
     * 切换到Aux2
     */
    public Response<Boolean> switchToAux1() throws Exception {
        return switchAux(CMD.SWITCH_TO_AUX, Request.argPut("auxId", "0"));
    }

    /**
     * 4.21 切换到Aux
     * 切换到Aux2
     */
    public Response<Boolean> switchToAux2() throws Exception {
        return switchAux(CMD.SWITCH_TO_AUX, Request.argPut("auxId", "1"));
    }

    /**
     * 4.22	切换到分机Aux
     * 切换到clientAux1
     */
    public Response<Boolean> switchToClientAux1() throws Exception {
        return switchAux(CMD.SWITCH_TO_CLIENT_AUX, Request.argPut("mediaSrc", "clientAux1"));
    }

    /**
     * 4.22	切换到分机Aux
     * 切换到clientAux2
     */
    public Response<Boolean> switchToClientAux2() throws Exception {
        return switchAux(CMD.SWITCH_TO_CLIENT_AUX, Request.argPut("mediaSrc", "clientAux2"));
    }

    private Response<Boolean> switchAux(String cmd, Map<String, Object> params) throws Exception {
        String s = roomRequest.sendTCP(cmd, params);
        Response<Boolean> res = new Response<>(s);
        res.bean = res.resultCode == 0;
        return res;
    }

    /**
     * 4.24.1	获取指定目录的信息，包含目录列表与歌曲列表
     * 300s只有根目录，不能操作目录
     * 主机没插U盘目录列表会空，不能操作目录
     */
    public Response<LocalDirectory> getLocalDirectory(String directoryMid, int beginIndex, int num, boolean ignoreEmpty) throws Exception {
        Map<String, Object> params = Request.argPut("directoryMid", directoryMid);
        params.put("beginIndex", beginIndex);
        params.put("num", num);
        params.put("ignoreEmpty", ignoreEmpty);
        String s = roomRequest.sendTCP(CMD.GET_LOCAL_DIRECTORY, params);
        Response<LocalDirectory> res = new Response<>(s);
        if (res.resultCode == 0) {
            res.bean = JSON.parseObject(res.arg, LocalDirectory.class);
            res.bean.mediaList = parseMedaiList(res.arg);
        }
        return res;
    }

    /**
     * 4.24.2	搜索本地歌曲
     */
    public Response<List<Media>> searchLocalMusic(String keywords, int beginIndex, int num) throws Exception {
        Map<String, Object> params = Request.argPut("keywords", keywords);
        params.put("beginIndex", beginIndex);
        params.put("num", num);
        String s = roomRequest.sendTCP(CMD.SEARCH_LOCAL_MUSIC, params);
        Response<List<Media>> res = new Response<>(s);
        if (res.resultCode == 0)
            res.bean = parseMedaiList(res.arg);
        return res;
    }


    /**
     * 4.25.1	新建目录
     *
     * @param dest 使用GetLocalDirectory中获取的绝对路径，并非名称
     */
    public Response<Boolean> mkLocalDiskDir(String dest) throws Exception {
        String s = roomRequest.sendTCP(CMD.MK_LOCAL_DISK_DIR, Request.argPut("dest", dest));
        Response<Boolean> res = new Response<>(s);
        res.bean = res.resultCode == 0;
        return res;
    }

    /**
     * 4.25.2	重命名目录
     * 参数是mid式的绝对目录
     */
    public Response<Boolean> moveLocalDiskDir(String source, String dest) throws Exception {
        Map<String, Object> params = Request.argPut("dest", dest);
        params.put("source", source);
        String s = roomRequest.sendTCP(CMD.MOVE_LOCAL_DISK_DIR, params);
        Response<Boolean> res = new Response<>(s);
        res.bean = res.resultCode == 0;
        return res;
    }

    /**
     * 4.25.3	删除目录
     */
    public Response<Boolean> rmLocalDiskDir(List<String> sourceList) throws Exception {
        JSONArray jsonArray = new JSONArray();
        for (String s : sourceList) jsonArray.put(s);
        Map<String, Object> params = Request.argPut("sourceList", jsonArray);
        String s = roomRequest.sendTCP(CMD.RM_LOCAL_DISK_DIR, params);
        Response<Boolean> res = new Response<>(s);
        res.bean = res.resultCode == 0;
        return res;
    }

    /**
     * 4.25.4	删除文件
     * 未测试
     */
    public Response<Boolean> rmLocalDiskFile(List<String> sourceList) throws Exception {
        JSONArray jsonArray = new JSONArray();
        for (String s : sourceList) jsonArray.put(s);
        Map<String, Object> params = Request.argPut("sourceList", jsonArray);
        String s = roomRequest.sendTCP(CMD.RM_LOCAL_DISK_FILE, params);
        Response<Boolean> res = new Response<>(s);
        res.bean = res.resultCode == 0;
        return res;
    }

    /**
     * 4.25.5	重命名文件
     * 未测试
     */
    public Response<Boolean> rmLocalDiskFile(String source, String dest) throws Exception {
        Map<String, Object> params = Request.argPut("source", source);
        params.put("dest", dest);
        String s = roomRequest.sendTCP(CMD.MOVE_LOCAL_DISK_FILE, params);
        Response<Boolean> res = new Response<>(s);
        res.bean = res.resultCode == 0;
        return res;
    }

    /**
     * 4.26.1	切换到FM
     * fmID 0 or 1
     */
    @Deprecated
    public Response<Boolean> switchToFm(String fmId) throws Exception {
        String s = roomRequest.sendTCP(CMD.SWITCH_TO_FM, Request.argPut("fmId", fmId));
        Response<Boolean> res = new Response<>(s);
        res.bean = res.resultCode == 0;
        return res;
    }

    /**
     * 4.26.2	播放指定FM
     */
    @Deprecated
    public Response<Boolean> playLocalFm(String fmId, String freq) throws Exception {
        Map<String, Object> params = Request.argPut("fmId", fmId);
        params.put("freq", freq);
        String s = roomRequest.sendTCP(CMD.PLAY_LOCAL_FM, params);
        Response<Boolean> res = new Response<>(s);
        res.bean = res.resultCode == 0 && "success".equals(new JSONObject(res.arg).getString("playResult"));
        return res;
    }

    /**
     * 4.26.3	获取FM列表
     * fmID 0 or 1
     */
    @Deprecated
    public Response<List<LocalFm>> getLocalFmFreq(String fmId) throws Exception {
        String s = roomRequest.sendTCP(CMD.GET_LOCAL_FM_FREQ, Request.argPut("fmId", fmId));
        Response<List<LocalFm>> res = new Response<>(s);
        if (res.resultCode == 0)
            res.bean = JSON.parseArray(new JSONObject(res.arg).getString("fmList"), LocalFm.class);
        return res;
    }

    /**
     * 4.26.4	添加指定频率
     */
    @Deprecated
    public Response<Boolean> addLocalFmFreq(String fmId, String freq, String freqName) throws Exception {
        Map<String, Object> params = Request.argPut("fmId", fmId);
        params.put("freq", freq);
        params.put("freqName", freqName);
        String s = roomRequest.sendTCP(CMD.ADD_LOCAL_FM_FREQ, params);
        Response<Boolean> res = new Response<>(s);
        res.bean = res.resultCode == 0;
        return res;
    }

    /**
     * 4.26.6	删除指定频率
     */
    @Deprecated
    public Response<Boolean> delLocalFmFreq(String fmId, String freq) throws Exception {
        Map<String, Object> params = Request.argPut("fmId", fmId);
        params.put("freq", freq);
        String s = roomRequest.sendTCP(CMD.DEL_LOCAL_FM_FREQ, params);
        Response<Boolean> res = new Response<>(s);
        res.bean = res.resultCode == 0;
        return res;
    }

    /**
     * 4.26.7	重命名指定频率
     */
    @Deprecated
    public Response<Boolean> renameLocalFmFreq(String fmId, String freq, String freqName) throws Exception {
        Map<String, Object> params = Request.argPut("fmId", fmId);
        params.put("freq", freq);
        params.put("freqName", freqName);
        String s = roomRequest.sendTCP(CMD.RENAME_LOCAL_FM_FREQ, params);
        Response<Boolean> res = new Response<>(s);
        res.bean = res.resultCode == 0;
        return res;
    }

    /**
     * 4.26.8	FM1、FM2自动搜台
     *
     * @param searchCmd "search""stop"
     */
    @Deprecated
    public Response<Boolean> autoSearchFm(String fmId, String searchCmd) throws Exception {
        Map<String, Object> params = Request.argPut("fmId", fmId);
        params.put("searchCmd", searchCmd);
        String s = roomRequest.sendTCP(CMD.AUTO_SEARCH_FM, params);
        Response<Boolean> res = new Response<>(s);
        res.bean = res.resultCode == 0;
        return res;
    }

    /**
     * 4.27.1	获取自建歌单列表
     */
    public Response<List<PlayList>> getFavoritePlayList() throws Exception {
        String s = roomRequest.sendTCP(CMD.GET_FAVORITE_PLAY_LIST, null);
        Response<List<PlayList>> res = new Response<>(s);
        if (res.resultCode == 0)
            res.bean = JSON.parseArray(new JSONObject(res.arg).getString("playList"), PlayList.class);
        return res;
    }

    /**
     * 4.27.2	新建自建歌单
     */
    public Response<PlayList> addFavoritePlayList(String playListName) throws Exception {
        String s = roomRequest.sendTCP(CMD.ADD_FAVORITE_PLAY_LIST, Request.argPut("playListName", playListName));
        Response<PlayList> res = new Response<>(s);
        if (res.resultCode == 0)
            res.bean = JSON.parseObject(res.arg, PlayList.class);
        return res;
    }

    /**
     * 4.27.4	删除自建歌单
     * 系统有一个默认的收藏夹，该收藏夹不能删除{“playListId”:0,“playListName”:”我喜欢”}
     */
    public Response<Boolean> delFavoritePlayList(int playListId) throws Exception {
        String s = roomRequest.sendTCP(CMD.DEL_FAVORITE_PLAY_LIST, Request.argPut("playListId", playListId));
        Response<Boolean> res = new Response<>(s);
        res.bean = res.resultCode == 0;
        return res;
    }

    /**
     * 4.27.6	修改自建歌单名
     * 并无通知
     */
    public Response<Boolean> renameFavoritePlayList(int playListId, String playListName) throws Exception {
        Map<String, Object> params = Request.argPut("playListId", playListId);
        params.put("playListName", playListName);
        String s = roomRequest.sendTCP(CMD.RENAME_FAVORITE_PLAY_LIST, params);
        Response<Boolean> res = new Response<>(s);
        res.bean = res.resultCode == 0;
        return res;
    }


    /**
     * 4.27.8	将歌曲收藏到指定的自建歌单（目前只能添加本地音乐、云音乐、语言节目）
     */
    public Response<Boolean> addFavoriteMedia(int playListId, String mediaSrc, List<? extends Media> mediaList) throws Exception {
        Map<String, Object> params = Request.argPut("mediaList", consitiParams(mediaList));
        params.put("playListId", playListId);
        params.put("mediaSrc", mediaSrc);
        String s = roomRequest.sendTCP(CMD.ADD_FAVORITE_MEDIA, params);
        Response<Boolean> res = new Response<>(s);
        res.bean = res.resultCode == 0;
        return res;
    }

    /**
     * 4.27.10	将歌曲从指定的自建歌单中取消收藏
     */
    public Response<Boolean> delFavoriteMedia(int playListId, String mediaSrc, List<Media> mediaList) throws Exception {
        Map<String, Object> params = Request.argPut("playListId", playListId);
        params.put("mediaSrc", mediaSrc);
        params.put("mediaList", consitiParams(mediaList));
        String s = roomRequest.sendTCP(CMD.DEL_FAVORITE_MEDIA, params);
        Response<Boolean> res = new Response<>(s);
        res.bean = res.resultCode == 0;
        return res;
    }

    /**
     * 4.27.11.1	获取指定的自建歌单的歌曲列表
     */
    public Response<List<Media>> getFavoriteMedia(int playListId,String mediaSrc,int beginIndex,int num) throws Exception {
        Map<String, Object> params = Request.argPut("playListId", playListId);
        params.put("mediaSrc", mediaSrc);
        params.put("beginIndex", beginIndex);
        params.put("num", num);

        String s = roomRequest.sendTCP(CMD.GET_FAVORITE_MEDIA, params);
        Response<List<Media>> res = new Response<>(s);
        if (res.resultCode == 0)
            res.bean = parseMedaiList(res.arg);
        return res;
    }

    /**
     * 4.27.12	判断歌曲是否已收藏
     */
    public Response<Boolean> containFavoriteMedia(int playListId, String mediaSrc, Media media) throws Exception {
        Map<String, Object> params = Request.argPut("playListId", playListId);
        params.put("mediaSrc", mediaSrc);
        params.put("media", new JSONObject(JSON.toJSONString(media)));
        String s = roomRequest.sendTCP(CMD.CONTAIN_FAVORITE_MEDIA, params);
        Response<Boolean> res = new Response<>(s);
        res.bean = res.resultCode == 0 && "contain".equals(new JSONObject(res.arg).getString("contain"));
        return res;
    }

    /**
     * 4.27.13	播放自建歌单的歌曲
     * 但这个和播放歌曲有啥区别呢
     */
    public Response<Boolean> playFavoriteMedia(int playListId, String mediaSrc, Media media) throws Exception {
        Map<String, Object> params = Request.argPut("playListId", playListId);
        params.put("mediaSrc", mediaSrc);
        params.put("media", new JSONObject(JSON.toJSONString(media)));
        String s = roomRequest.sendTCP(CMD.PLAY_FAVORITE_MEDIA, params);
        Response<Boolean> res = new Response<>(s);
        res.bean = res.resultCode == 0 && "success".equals(new JSONObject(res.arg).getString("playResult"));
        return res;
    }

    /**
     * 4.28.1	获取专辑收藏列表
     */
    public Response<List<AlbumSetFavorite>> getAlbumSetFavoriteList() throws Exception {
        String s = roomRequest.sendTCP(CMD.GET_ALBUM_SET_FAVORITE_LIST, null);
        Response<List<AlbumSetFavorite>> res = new Response<>(s);
        if (res.resultCode == 0)
            res.bean = JSON.parseArray(new JSONObject(res.arg).getString("albumSetFolderList"), AlbumSetFavorite.class);
        return res;
    }

    /**
     * 4.28.2	新建专辑收藏夹
     */
    public Response<AlbumSetFavorite> addAlbumSetFavoriteList(String folderName) throws Exception {
        String s = roomRequest.sendTCP(CMD.ADD_ALBUM_SET_FAVORITE_LIST, Request.argPut("folderName", folderName));
        Response<AlbumSetFavorite> res = new Response<>(s);
        if (res.resultCode == 0)
            res.bean = JSON.parseObject(res.arg, AlbumSetFavorite.class);
        return res;
    }

    /**
     * 4.28.4	删除专辑收藏夹
     */
    public Response<Boolean> delAlbumSetFavoriteList(int folderId) throws Exception {
        String s = roomRequest.sendTCP(CMD.DEL_ALBUM_SET_FAVORITE_LIST, Request.argPut("folderId", folderId));
        Response<Boolean> res = new Response<>(s);
        res.bean = res.resultCode == 0;
        return res;
    }

    /**
     * 4.28.6	修改专辑收藏夹名
     */
    public Response<Boolean> renameAlbumSetFavorite(int folderId, String folderName) throws Exception {
        Map<String, Object> params = Request.argPut("folderId", folderId);
        params.put("folderName", folderName);
        String s = roomRequest.sendTCP(CMD.RENAME_ALBUM_SET_FAVORITE, params);
        Response<Boolean> res = new Response<>(s);
        res.bean = res.resultCode == 0;
        return res;
    }

    /**
     * 4.20.8	将专辑收藏到指定的专辑收藏夹[单个]
     */
    public Response<Boolean> addSetToAlbumSetFavorite(int folderId, AlbumSetMeta albumSet) throws Exception {
        Map<String, Object> params = Request.argPut("folderId", folderId);
        params.put("albumSet", new JSONObject(JSON.toJSONString(albumSet)));
        String s = roomRequest.sendTCP(CMD.ADD_SET_TO_ALBUM_SET_FAVORITE, params);
        Response<Boolean> res = new Response<>(s);
        res.bean = res.resultCode == 0;
        return res;
    }

    /**
     * 4.28.8	将专辑收藏到指定的专辑收藏夹[批量]
     */
    public Response<Boolean> addSetToAlbumSetFavorite(int folderId, List<AlbumSetMeta> albumSetList) throws Exception {
        Map<String, Object> params = Request.argPut("folderId", folderId);
        params.put("list", consitiParams(albumSetList));
        String s = roomRequest.sendTCP(CMD.ADD_SET_LIST_TO_ALBUM_SET_FAVORITE, params);
        Response<Boolean> res = new Response<>(s);
        res.bean = res.resultCode == 0;
        return res;
    }

    /**
     * 4.28.10	将专辑从指定的专辑收藏夹中取消收藏
     */
    public Response<Boolean> delFavoriteSet(int folderId, List<AlbumSetMeta> albumSetList) throws Exception {
        Map<String, Object> params = Request.argPut("folderId", folderId);
        params.put("list", consitiParams(albumSetList));
        String s = roomRequest.sendTCP(CMD.DEL_FAVORITE_SET, params);
        Response<Boolean> res = new Response<>(s);
        res.bean = res.resultCode == 0;
        return res;
    }

    /**
     * 4.28.12	获取指定的专辑收藏夹中专辑列表
     *
     * @param albumSetTypeName 可以为空,则获取所有专辑
     *                     数组元素 see{@link com.westwhale.api.protocolapi.bean.albumSet.AlbumSetMeta}
     */
    public Response<List<AlbumSetMeta>> getFavoriteSet(int folderId, String albumSetTypeName) throws Exception {
        Map<String, Object> params = Request.argPut("folderId", folderId);
        params.put("albumTypeName", albumSetTypeName);
        String s = roomRequest.sendTCP(CMD.GET_FAVORITE_SET, params);
        Response<List<AlbumSetMeta>> res = new Response<>(s);
        if (res.resultCode == 0) res.bean = praseAlbumSetMeta(res.arg);
        return res;
    }

    /**
     * 4.28.13	判断专辑是否已收藏
     */
    public Response<Boolean> containFavoriteSet(int folderId, AlbumSetMeta albumSet) throws Exception {
        Map<String, Object> params = Request.argPut("folderId", folderId);
        params.put("albumSet", new JSONObject(JSON.toJSONString(albumSet)));
        String s = roomRequest.sendTCP(CMD.CONTAIN_FAVORITE_SET, params);
        Response<Boolean> res = new Response<>(s);
        res.bean = res.resultCode == 0 && "contain".equals(new JSONObject(res.arg).getString("contain"));
        return res;
    }

    /**
     * 4.29.1	获取场景列表
     */
    public Response<List<Scene>> getSceneList() throws Exception {
        String s = roomRequest.sendTCP(CMD.GET_SCENE_LIST, null);
        Response<List<Scene>> res = new Response<>(s);
        if (res.resultCode == 0)
            res.bean = JSON.parseArray(new JSONObject(res.arg).getString("sceneList"), Scene.class);
        return res;
    }

    /**
     * 4.29.2	新建场景
     */
    public Response<Scene> addScene(String sceneName) throws Exception {
        String s = roomRequest.sendTCP(CMD.ADD_SCENE, Request.argPut("sceneName", sceneName));
        Response<Scene> res = new Response<>(s);
        if (res.resultCode == 0)
            res.bean = JSON.parseObject(res.arg, Scene.class);
        return res;
    }

    public Response<Boolean> addSceneWithAction(String sceneName, List<RoomSceneAction> actionList) throws Exception {
        Map<String, Object> params = Request.argPut("sceneName", sceneName);
        params.put("list",consitiParams(actionList));
        String s = roomRequest.sendTCP(CMD.ADD_SCENE_WITH_ACTION, params);
        Response<Boolean> res = new Response<>(s);
        res.bean = res.resultCode == 0;
        return res;
    }

    /**
     * 4.29.4	删除场景
     */
    public Response<Boolean> delScene(int sceneId) throws Exception {
        String s = roomRequest.sendTCP(CMD.DEL_SCENE, Request.argPut("sceneId", sceneId));
        Response<Boolean> res = new Response<>(s);
        res.bean = res.resultCode == 0;
        return res;
    }

    /**
     * 4.29.6	修改场景名
     */
    public Response<Boolean> renameScene(int sceneId, String sceneName) throws Exception {
        Map<String, Object> params = Request.argPut("sceneId", sceneId);
        params.put("sceneName", sceneName);
        String s = roomRequest.sendTCP(CMD.RENAME_SCENE, params);
        Response<Boolean> res = new Response<>(s);
        res.bean = res.resultCode == 0;
        return res;
    }

    /**
     * 4.29.8	执行场景
     */
    public Response<Boolean> executeScene(int sceneId) throws Exception {
        String s = roomRequest.sendTCP(CMD.EXECUTE_SCENE, Request.argPut("sceneId", sceneId));
        Response<Boolean> res = new Response<>(s);
        res.bean = res.resultCode == 0;
        return res;
    }

    /**
     * 4.21.11	设置场景动作列表
     *
     */
    public Response<Boolean> setActionListToScene(int sceneId, List<RoomSceneAction> actionList) throws Exception {
        Map<String, Object> params = Request.argPut("sceneId", sceneId);
        params.put("list",consitiParams(actionList));
        String s = roomRequest.sendTCP(CMD.SET_ACTION_LIST_TO_SCENE, params);
        Response<Boolean> res = new Response<>(s);
        res.bean = res.resultCode == 0;
        return res;
    }

    /**
     * 4.29.16	获取指定的场景的场景动作列表
     */
    public Response<Scene> getSceneActionList(int sceneId) throws Exception {
        String s = roomRequest.sendTCP(CMD.GET_SCENE_ACTION_LIST, Request.argPut("sceneId", sceneId));
        Response<Scene> res = new Response<>(s);
        if (res.resultCode == 0) res.bean = JSON.parseObject(res.arg, Scene.class);
        return res;
    }

    /**
     * 4.30.1	Usb/SD热拔插设备拔插状态获取
     */
    public Response<String> getSystemUsbStat() throws Exception {
        String s = roomRequest.sendTCP(CMD.GET_SYSTEM_USB_STAT, null);
        Response<String> res = new Response<>(s);
        if (res.resultCode == 0) res.bean = new JSONObject(res.arg).getString("usbStat");
        return res;
    }

    /**
     * 4.30.3	网络状态获取
     * 房间网络状态
     */
    public Response<String> getNetStat() throws Exception {
        String s = roomRequest.sendTCP(CMD.GET_NET_STAT, null);
        Response<String> res = new Response<>(s);
        if (res.resultCode == 0) res.bean = new JSONObject(res.arg).getString("netStat");
        return res;
    }

    /**
     * 4.31.1	打开/关闭party组
     * 实际上hostId没有，传的是房间Id
     */
    public Response<Boolean> setUniquePartyStat(String hostId, String partyStat) throws Exception {
        Map<String, Object> params = Request.argPut("hostId", roomRequest.recvId);
        params.put("partyStat", partyStat);
        String s = roomRequest.sendTCP(CMD.SET_UNIQUE_PARTY_STAT, params);
        Response<Boolean> res = new Response<>(s);
        res.bean = res.resultCode == 0;
        return res;
    }

    /**
     * 4.31.3	获取party组状态
     */
    public Response<String> getUniquePartyStat() throws Exception {
        String s = roomRequest.sendTCP(CMD.GET_UNIQUE_PARTY_STAT, null);
        Response<String> res = new Response<>(s);
        if (res.resultCode == 0) res.bean = new JSONObject(res.arg).getString("partyStat");
        return res;
    }

    /**
     * 4.32.1	获取定时器列表
     */
    public Response<List<Timer>> getTimerList() throws Exception {
        String s = roomRequest.sendTCP(CMD.GET_TIMER_LIST, null);
        Response<List<Timer>> res = new Response<>(s);
        if (res.arg != null)
            res.bean = JSON.parseArray(new JSONObject(res.arg).getString("timerList"), Timer.class);
        return res;
    }

    /**
     * 4.32.2	添加定时器
     * 定时器只能定时开关机
     */
    public Response<Boolean> addTimer(Timer timer) throws Exception {
        JSONObject jsonObject = new JSONObject(JSON.toJSONString(timer));
        jsonObject.remove("timeId");
        jsonObject.remove("remainTime");
        roomRequest.setArgJson(jsonObject);
        String s = roomRequest.sendTCP(CMD.ADD_TIMER, null);
        Response<Boolean> res = new Response<>(s);
        if (res.arg != null) res.bean = res.resultCode == 0;
        return res;
    }

    /**
     * 4.32.4	删除定时器
     */
    public Response<Boolean> delTimer(int timerId) throws Exception {
        String s = roomRequest.sendTCP(CMD.DEL_TIMER, Request.argPut("timerId", timerId));
        Response<Boolean> res = new Response<>(s);
        res.bean = res.resultCode == 0;
        return res;
    }

    /**
     * 4.32.6	修改定时器
     */
    public Response<Boolean> modifyTimer(Timer timer) throws Exception {
        roomRequest.setArgJson(new JSONObject(JSON.toJSONString(timer)));
        String s = roomRequest.sendTCP(CMD.MODIFY_TIMER, null);
        Response<Boolean> res = new Response<>(s);
        res.bean = res.resultCode == 0;
        return res;
    }

    /**
     * 4.32.8	获取延时关机定时器
     */
    public Response<DelayClose> getDelayCloseTimer() throws Exception {
        String s = roomRequest.sendTCP(CMD.GET_DELAY_CLOSE_TIMER, null);
        Response<DelayClose> res = new Response<>(s);
        if (res.arg != null) res.bean = JSON.parseObject(res.arg, DelayClose.class);
        return res;
    }

    /**
     * 4.32.9	修改延时关机定时器
     */
    public Response<Boolean> modifyDelayCloseTimer(String timerEnable, int delayCloseAfterTimes) throws Exception {
        Map<String, Object> params = Request.argPut("timerEnable", timerEnable);
        params.put("delayCloseAfterTimes", delayCloseAfterTimes);
        String s = roomRequest.sendTCP(CMD.MODIFY_DELAY_CLOSE_TIMER, params);
        Response<Boolean> res = new Response<>(s);
        res.bean = res.resultCode == 0;
        return res;
    }

    public Response<Boolean> closeClockPlay(int timerId) throws Exception {
        String s = roomRequest.sendTCP(CMD.CLOSE_CLOCK_PLAY, Request.argPut("timerId", timerId));
        Response<Boolean> res = new Response<>(s);
        res.bean = res.resultCode == 0;
        return res;
    }

    /**
     * 4.25.1	设置房间串口ID
     */
    public Response<Boolean> setRoomSerialId(int serialId) throws Exception {
        String s = roomRequest.sendTCP(CMD.SET_ROOM_SERIALID, Request.argPut("serialId",serialId));
        Response<Boolean> res = new Response<>(s);
        res.bean = res.resultCode == 0;
        return res;
    }

    /**
     * 4.25.2	设置房间串口ID[列表形式]
     */
    public Response<Boolean> setRoomSerialIdList(List<RoomSerialSet> list) throws Exception {
        String s = roomRequest.sendTCP(CMD.GET_SYSTEM_SERVER_NAME, Request.argPut("list",consitiParams(list)));
        Response<Boolean> res = new Response<>(s);
        res.bean = res.resultCode == 0;
        return res;
    }

    /**
     * 4.33.1	获取系统主机名称
     */
    public Response<String> getSystemServerName() throws Exception {
        String s = roomRequest.sendTCP(CMD.GET_SYSTEM_SERVER_NAME, null);
        Response<String> res = new Response<>(s);
        if (res.arg != null) res.bean = new JSONObject(res.arg).getString("serverName");
        return res;
    }

    /**
     * 4.33.2	设置系统主机名称
     */
    public Response<Boolean> setSystemServerName(String serverName) throws Exception {
        Map<String, Object> params = Request.argPut("serverName", serverName);
        String s = roomRequest.sendTCP(CMD.SET_SYSTEM_SERVER_NAME, params);
        Response<Boolean> res = new Response<>(s);
        if (res.arg != null) res.bean = res.resultCode == 0;
        return res;
    }

    /**
     * 4.34.1	获取主机IP信息
     */
    public Response<ServerIpInfo> getServerIpInfo() throws Exception {
        String s = roomRequest.sendTCP(CMD.GET_SERVER_IP_INFO, null);
        Response<ServerIpInfo> res = new Response<>(s);
        if (res.resultCode == 0) res.bean = JSON.parseObject(res.arg, ServerIpInfo.class);
        return res;
    }

    /**
     * 4.34.2	设置主机IP信息
     * 会导致主机Ip变更的修改，请注意下。这里修改成功且是手动，会将请求地址变更成新的
     * 其他需要自己监听通知设置
     */
    public Response<Boolean> setServerIpInfo(ServerIpInfo serverIpInfo) throws Exception {
        roomRequest.setArgJson(new JSONObject(JSON.toJSONString(serverIpInfo)));
        String s = roomRequest.sendTCP(CMD.SET_SERVER_IP_INFO, null);
        Response<Boolean> res = new Response<>(s);
        res.bean = res.resultCode == 0;
        if (serverIpInfo.autoSetIp == 1 && res.bean) roomRequest.ipAddress(serverIpInfo.address);
        return res;
    }

    /**
     * 4.35.1	云资源下载
     * downloadPath：若为空时，则下载到默认路径
     * 但是接口还是会返回路径找不到
     */
    public Response<Boolean> downloadMusicList(String downloadPath, List<? extends Media> mediaList) throws Exception {
        Map<String, Object> params = Request.argPut("downloadPath", downloadPath);
        params.put("mediaList", consitiParams(mediaList));
        String s = roomRequest.sendTCP(CMD.DOWNLOAD_MUSIC_LIST, params);
        Response<Boolean> res = new Response<>(s);
        if (res.arg != null) res.bean = res.resultCode == 0;
        return res;
    }

    /**
     * 4.35.3	添加资源下载路径
     */
    public Response<Boolean> addDownloadPath(List<String> downloadPathList) throws Exception {
        JSONArray jsonArray = new JSONArray();
        if (downloadPathList != null) {
            for (String s : downloadPathList) jsonArray.put(s);
        }
        Map<String, Object> params = Request.argPut("downloadPathList", jsonArray);
        String s = roomRequest.sendTCP(CMD.ADD_DOWNLOAD_PATH, params);
        Response<Boolean> res = new Response<>(s);
        res.bean = res.resultCode == 0;
        return res;
    }

    /**
     * 4.35.5	获取资源下载下载路径
     *
     * @return Pair first是defaultPath,sencond是downloadPathList
     */
    public Response<Pair<String, List<String>>> getDownloadPathList() throws Exception {
        String s = roomRequest.sendTCP(CMD.GET_DOWNLOAD_PATH_LIST, null);
        Response<Pair<String, List<String>>> res = new Response<>(s);
        if (res.resultCode == 0) {
            List<String> downloadPathList = JSON.parseArray(new JSONObject(res.arg).getString("downloadPathList"), String.class);
            res.bean = new Pair<>(new JSONObject(res.arg).getString("defaultPath"), downloadPathList);
        }
        return res;
    }

    /**
     * 4.35.3	添加资源下载路径
     */
    public Response<Boolean> delDownloadPath(List<String> downloadPathList) throws Exception {
        JSONArray jsonArray = new JSONArray();
        if (downloadPathList != null) {
            for (String s : downloadPathList) jsonArray.put(s);
        }
        Map<String, Object> params = Request.argPut("downloadPathList", jsonArray);
        String s = roomRequest.sendTCP(CMD.DEL_DOWNLOAD_PATH, params);
        Response<Boolean> res = new Response<>(s);
        res.bean = res.resultCode == 0;
        return res;
    }

    /**
     * 4.35.6	设置默认下载
     * 有问题
     */
    public Response<Boolean> setDefaultDownloadPath(String defaultPath) throws Exception {
        String s = roomRequest.sendTCP(CMD.SET_DEFAULT_DOWNLOAD_PATH, Request.argPut("defaultPath", defaultPath));
        Response<Boolean> res = new Response<>(s);
        res.bean = res.resultCode == 0;
        return res;
    }

    /**
     * 4.35.7	获取已下载的列表
     */
    public Response<List<DownloadItem<CloudMusic>>> getDownloadedMusicList(String mediaSrc) throws Exception {
        Map<String, Object> params = Request.argPut("mediaSrc", mediaSrc);
        String s = roomRequest.sendTCP(CMD.GET_DOWNLOADED_MUSIC_LIST, params);
        Response<List<DownloadItem<CloudMusic>>> res = new Response<>(s);
        if (res.resultCode == 0)
            res.bean = JSON.parseObject(new JSONObject(res.arg).getString("mediaList"), new TypeReference<List<DownloadItem<CloudMusic>>>(){});
        return res;
    }

    /**
     * 4.35.8	获取正在下载中的列表
     */
    public Response<List<DownloadItem<CloudMusic>>> getDownloadingMusicList(String mediaSrc) throws Exception {
        String s = roomRequest.sendTCP(CMD.GET_DOWNLOADING_MUSIC_LIST, Request.argPut("mediaSrc", mediaSrc));
        Response<List<DownloadItem<CloudMusic>>> res = new Response<>(s);
        if (res.resultCode == 0)
            res.bean = JSON.parseObject(new JSONObject(res.arg).getString("mediaList"), new TypeReference<List<DownloadItem<CloudMusic>>>(){});
        return res;
    }

    /**
     * 4.35.9	操作下载列表
     *    0 : DEL_DOWNLOADING
     *    1 : DEL_DOWNLOADING_ALL
     *    2 : START_DOWNLOADING
     *    3 : START_DOWNLOADING_ALL
     *    4 : DEL_DOWNLOADED
     *    5 : DEL_DOWNLOADED_ALL
     */
    public Response<Boolean> operatorDownload(int cmd,List<DownloadItem<CloudMusic>> list) throws Exception {
        Map<String, Object> params = Request.argPut("cmd", cmd);
        params.put("mediaList",consitiParams(list));
        String s = roomRequest.sendTCP(CMD.OPERATOR_DOWNLOAD, params);
        Response<Boolean> res = new Response<>(s);
        res.bean = res.resultCode == 0;
        return res;
    }

    /**
     * 4.36	清空所有配置文件
     */
    public Response<Boolean> clearAllRoomSetting() throws Exception {
        String s = roomRequest.sendTCP(CMD.CLEAR_ALL_ROOM_SETTING, null);
        Response<Boolean> res = new Response<>(s);
        res.bean = res.resultCode == 0;
        return res;
    }

    /**
     * 4.37	关闭火警
     */
    public Response<Boolean> closeFireAlarm() throws Exception {
        String s = roomRequest.sendTCP(CMD.CLOSE_FIRE_ALARM, null);
        Response<Boolean> res = new Response<>(s);
        res.bean = res.resultCode == 0;
        return res;
    }

    /**
     * 4.38.1	获取对讲组列表
     */
    public Response<List<Talk>> getTalkList() throws Exception {
        String s = roomRequest.sendTCP(CMD.GET_TALK_LIST, null);
        Response<List<Talk>> res = new Response<>(s);
        if (res.resultCode == 0)
            res.bean = JSON.parseArray(new JSONObject(res.arg).getString("talkList"), Talk.class);
        return res;
    }

    /**
     * 4.38.2	新建对讲组
     */
    public Response<Boolean> addTalk(String talkName, List<String> talkRoom) throws Exception {
        Map<String, Object> params = Request.argPut("talkName", talkName);
        JSONArray jsonArray = new JSONArray();
        if (talkRoom != null) {
            for (String s : talkRoom) jsonArray.put(new JSONObject().put("roomId", s));
        }
        params.put("talkRoom", jsonArray);
        String s = roomRequest.sendTCP(CMD.ADD_TALK, params);
        Response<Boolean> res = new Response<>(s);
        res.bean = res.resultCode == 0;
        return res;
    }

    /**
     * 4.38.4	删除对讲组
     */
    public Response<Boolean> delTalk(int talkId) throws Exception {
        String s = roomRequest.sendTCP(CMD.DEL_TALK, Request.argPut("talkId", talkId));
        Response<Boolean> res = new Response<>(s);
        res.bean = res.resultCode == 0;
        return res;
    }

    /**
     * 4.38.6	重命名对讲组
     */
    public Response<Boolean> renameTalk(int talkId, String talkName) throws Exception {
        Map<String, Object> params = Request.argPut("talkId", talkId);
        params.put("talkName", talkName);
        String s = roomRequest.sendTCP(CMD.RENAME_TALK, params);
        Response<Boolean> res = new Response<>(s);
        res.bean = res.resultCode == 0;
        return res;
    }

    /**
     * @return room只有id与name属性会返回
     */
    public Response<List<Room>> getTalkRoomList(int talkId) throws Exception {
        String s = roomRequest.sendTCP(CMD.GET_TALK_ROOM_LIST, Request.argPut("talkId", talkId));
        Response<List<Room>> res = new Response<>(s);
        if (res.resultCode == 0)
            res.bean = JSON.parseArray(new JSONObject(res.arg).getString("talkRoom"), Room.class);
        return res;
    }

    /**
     * 4.38.9	将指定房间加入指定对讲组
     */
    public Response<Boolean> addTalkRoom(int talkId, List<String> talkRoom) throws Exception {
        Map<String, Object> params = Request.argPut("talkId", talkId);
        JSONArray jsonArray = new JSONArray();
        if (talkRoom != null) {
            for (String s : talkRoom) jsonArray.put(new JSONObject().put("roomId", s));
        }
        params.put("talkRoom", jsonArray);
        String s = roomRequest.sendTCP(CMD.ADD_TALK_ROOM, params);
        Response<Boolean> res = new Response<>(s);
        res.bean = res.resultCode == 0;
        return res;
    }

    /**
     * 4.38.11	将指定房间从指定对讲组中删除
     */
    public Response<Boolean> delTalkRoom(int talkId, List<String> talkRoom) throws Exception {
        Map<String, Object> params = Request.argPut("talkId", talkId);
        JSONArray jsonArray = new JSONArray();
        if (talkRoom != null) {
            for (String s : talkRoom) jsonArray.put(new JSONObject().put("roomId", s));
        }
        params.put("talkRoom", jsonArray);
        String s = roomRequest.sendTCP(CMD.DEL_TALK_ROOM, params);
        Response<Boolean> res = new Response<>(s);
        res.bean = res.resultCode == 0;
        return res;
    }

    /**
     * 4.38.15	获取对讲组开启/关闭状态
     *
     * @return talkStat:"open""close"
     * 如果开启成功，会有"talkMulticastIp": "192.168.0.251","talkPort": 30090,返回。需要自己解析
     */
    public Response<Talk> getTalkStat(int talkId) throws Exception {
        String s = roomRequest.sendTCP(CMD.GET_TALK_STAT, Request.argPut("talkId", talkId));
//        Response<String> res = new Response<>(s);
//        if (res.resultCode == 0) res.bean = new JSONObject(res.arg).getString("talkStat");
        Response<Talk> res = new Response<>(s);
        if (res.resultCode == 0){
            res.bean = JSON.parseObject(res.arg,Talk.class);
        }

        return res;
    }

    /**
     * 4.38.13	开启/关闭对讲组
     *
     * @param talkStat “open”“close”
     */
    public Response<Talk> setTalkStat(int talkId, String talkStat) throws Exception {
        Map<String, Object> params = Request.argPut("talkId", talkId);
        params.put("talkStat", talkStat);
        String s = roomRequest.sendTCP(CMD.SET_TALK_STAT, params);
//        Response<Boolean> res = new Response<>(s);
//        res.bean = res.resultCode == 0;
        Response<Talk> res = new Response<>(s);
        if (res.resultCode == 0){
            res.bean = JSON.parseObject(res.arg,Talk.class);
        }
        return res;
    }

    /**
     * careful: 未提供
     * 4.38.16	申请成为麦主（申请成为发言者）
     *
     * @param talkingStat talkingStat:“talking”“normal”
     */
    @Deprecated
    public Response<Boolean> setTalking(int talkId, String talkingStat) throws Exception {
        Map<String, Object> params = Request.argPut("talkId", talkId);
        params.put("talkingStat", talkingStat);
        String s = roomRequest.sendTCP(CMD.SET_TALKING, params);
        Response<Boolean> res = new Response<>(s);
        res.bean = res.resultCode == 0;
        return res;
    }

    /**
     * 4.39.1	获取音效均衡器
     *
     * @return first是eqType，音效。second是均衡器数值，在[-20,20],默认为0
     * 每个音效都有固定的数值。要设置自己的数值需要eqType为UserDefine（自定义）。
     * 每个音效，固定数值返回不正确。
     */
    public Response<Pair<String, MusicVolumeEq>> getMusicVolumeEq() throws Exception {
        String s = roomRequest.sendTCP(CMD.GET_MUSIC_VOLUME_EQ, null);
        Response<Pair<String, MusicVolumeEq>> res = new Response<>(s);
        if (res.resultCode == 0) {
            JSONObject argJson = new JSONObject(res.arg);
            String eq = argJson.getString("eqType");
            MusicVolumeEq musicVolumeEq = JSON.parseObject(argJson.getString("musicVolumeEq"), MusicVolumeEq.class);
            res.bean = new Pair<>(eq, musicVolumeEq);
        }
        return res;
    }

    /**
     * 4.39.2	设置音效均衡器
     *
     * @param eqType        音效
     * @param musicVolumeEq 均衡器数值，在[-20,20],默认为0
     *                      每个音效都有固定的数值。要设置自己的数值需要eqType为UserDefine（自定义）。
     */
    public Response<Boolean> setMusicVolumeEq(String eqType, MusicVolumeEq musicVolumeEq) throws Exception {
        Map<String, Object> params = Request.argPut("eqType", eqType);
        params.put("musicVolumeEq", new JSONObject(JSON.toJSONString(musicVolumeEq)));
        String s = roomRequest.sendTCP(CMD.SET_MUSIC_VOLUME_EQ, params);
        Response<Boolean> res = new Response<>(s);
        res.bean = res.resultCode == 0;
        return res;
    }

    /**
     * 4.40	系统重启
     */
    public Response<Boolean> restartSystem() throws Exception {
        String s = roomRequest.sendTCP(CMD.RESTART_SYSTEM, null);
        Response<Boolean> res = new Response<>(s);
        res.bean = res.resultCode == 0;
        return res;
    }

    /**
     * 4.41	重新搜索房间(用于重新获取房间列表)
     * 适用分布式机来重新去分机建立连接
     * 一体式主机没明显效果
     */
    public Response<Boolean> researchRoom() throws Exception {
        String s = roomRequest.sendTCP(CMD.RESEARCH_ROOM, null);
        Response<Boolean> res = new Response<>(s);
        res.bean = res.resultCode == 0;
        return res;
    }

    /**
     * 4.42.1	获取条形码
     * 暂时给内部用
     */
    public Response<String> getServerBarCode() throws Exception {
        String s = roomRequest.sendTCP(CMD.GET_SERVER_BAR_CODE, null);
        Response<String> res = new Response<>(s);
        if (res.resultCode == 0) res.bean = new JSONObject(res.arg).getString("barCode");
        return res;
    }

    /**
     * 4.42.2	设置条形码
     * 暂时给内部用
     */
    public Response<Boolean> SetServerBarCode(String barCode) throws Exception {
        String s = roomRequest.sendTCP(CMD.SET_SERVER_BAR_CODE, Request.argPut("barCode", barCode));
        Response<Boolean> res = new Response<>(s);
        res.bean = res.resultCode == 0;
        return res;
    }

    /**
     * 4.43.1	获取云音乐注册码
     * 暂时给内部用
     */
    public Response<String> getCloudLicense() throws Exception {
        String s = roomRequest.sendTCP(CMD.GET_CLOUD_LICENSE, null);
        Response<String> res = new Response<>(s);
        if (res.resultCode == 0) res.bean = new JSONObject(res.arg).getString("cloudLicense");
        return res;
    }

    /**
     * 4.43.2	设置云音乐注册码
     * 暂时给内部用
     */
    public Response<Boolean> setCloudLicense(String cloudLicense) throws Exception {
        String s = roomRequest.sendTCP(CMD.SET_CLOUD_LICENSE, Request.argPut("cloudLicense", cloudLicense));
        Response<Boolean> res = new Response<>(s);
        res.bean = res.resultCode == 0;
        return res;
    }

    /**
     * 4.44.1	获取主机的GUID
     * 暂时给内部用
     */
    public Response<String> getServerGuid() throws Exception {
        String s = roomRequest.sendTCP(CMD.GET_SERVER_GUID, null);
        Response<String> res = new Response<>(s);
        if (res.resultCode == 0) res.bean = new JSONObject(res.arg).getString("serverGuid");
        return res;
    }

    /**
     * 4.44.2	设置主机的GUID
     *
     * @param serverGuid 有格式要求1fe49cf0-6815-4e27-a8ac-43e9272bxxxx,不然会参数错误
     *                   暂时给内部用
     */
    public Response<Boolean> setServerGuid(String serverGuid) throws Exception {
        String s = roomRequest.sendTCP(CMD.SET_SERVER_GUID, Request.argPut("serverGuid", serverGuid));
        Response<Boolean> res = new Response<>(s);
        res.bean = res.resultCode == 0;
        return res;
    }

    /**
     * 4.45.1	主机请求控制端发送命令
     * 主机用的，手机控制App请求无效，会返回protocol can't parse
     */
    @Deprecated
    public Response<Boolean> requestCmd() throws Exception {
        String s = roomRequest.sendTCP(CMD.REQUEST_CMD, null);
        Response<Boolean> res = new Response<>(s);
        res.bean = res.resultCode == 0;
        return res;
    }

    /**
     * 4.45.2	获取当前控制端的列表
     */
    public Response<List<Controller>> getControllerList() throws Exception {
        String s = roomRequest.sendTCP(CMD.GET_CONTROLLER_LIST, null);
        Response<List<Controller>> res = new Response<>(s);
        if (res.resultCode == 0)
            res.bean = JSON.parseArray(new JSONObject(res.arg).getString("controllerList"), Controller.class);
        return res;
    }

    /**
     * 4.45.3	添加控制端列表
     */
    public Response<Boolean> addControllerList(List<Controller> controllerList) throws Exception {
        String s = roomRequest.sendTCP(CMD.ADD_CONTROLLER_LIST, Request.argPut("controllerList", consitiParams(controllerList)));
        Response<Boolean> res = new Response<>(s);
        res.bean = res.resultCode == 0;
        return res;
    }

    /**
     * 4.45.4	删除控制端列表
     */
    public Response<Boolean> delControllerList(List<Controller> controllerList) throws Exception {
        String s = roomRequest.sendTCP(CMD.DEL_CONTROLLER_LIST, Request.argPut("controllerList", consitiParams(controllerList)));
        Response<Boolean> res = new Response<>(s);
        res.bean = res.resultCode == 0;
        return res;
    }

    /**
     * 4.45.5	检查控制端是否连同
     *
     * @return
     * @throws Exception
     */
    public Response<Boolean> checkControllerList() throws Exception {
        String s = roomRequest.sendTCP(CMD.CHECK_CONTROLLER_LIST, null);
        Response<Boolean> res = new Response<>(s);
        res.bean = res.resultCode == 0;
        return res;
    }


    /**---------------------------------------云音乐系列接口---------------------**/

    /**
     * 1.1 	GetSinger 获取歌手
     * 接口数据没有返回resultCode,默认-1,属于正常。使用就判断arg是否空
     *
     * @param category 类别
     * @param index    索引
     * @param pageNo   分页页码
     * @return 歌手列表
     */
    public Response<List<CloudSingerSet>> getSingers(String category, String index, int pageNo) throws Exception {
        Map<String, Object> params = Request.argPut("category", category);
        params.put("index", index);
        params.put("pageNo", pageNo);
        String s = roomRequest.sendTCP(CMD.GET_SINGER, params);
        Response<List<CloudSingerSet>> res = new Response<>(s);
        if (res.resultCode == -2 || res.resultCode == 0)
            res.bean = JSON.parseArray(new JSONObject(res.arg).getString("list"), CloudSingerSet.class);
        return res;
    }

    /**
     * 1.2 	GetSingerSong 获取歌手的歌曲
     *
     * @return 歌曲列表
     */
    public Response<List<CloudMusic>> getSingerSong(String singerMid, String order, int begin, int size) throws Exception {
        Map<String, Object> params = Request.argPut("singerMid", singerMid);
        params.put("order", order);
        params.put("begin", begin);
        params.put("size", size);
        String s = roomRequest.sendTCP(CMD.GET_SINGER_SONG, params);
        Response<List<CloudMusic>> res = new Response<>(s);
        if (res.resultCode == -2 || res.resultCode == 0)
            res.bean = JSON.parseArray(new JSONObject(res.arg).getString("list"), CloudMusic.class);
        return res;
    }

    /**
     * 1.3 	GetSingerAlbum 获取歌手的专辑
     */
    public Response<List<CloudAlbumSet>> getSingerAlbum(String singerMid, String order, int begin, int size) throws Exception {
        Map<String, Object> params = Request.argPut("singerMid", singerMid);
        params.put("order", order);
        params.put("begin", begin);
        params.put("size", size);
        String s = roomRequest.sendTCP(CMD.GET_SINGER_ALBUM, params);
        Response<List<CloudAlbumSet>> res = new Response<>(s);
        res.bean = JSON.parseArray(new JSONObject(res.arg).getString("list"), CloudAlbumSet.class);
        return res;
    }

    /**
     * 1.4 	GetSingerInfo 获取歌手的信息
     * 歌手信息返回结果需要调整，现在直接返回string结果
     */
    public Response<String> getSingerInfo(String singerMid) throws Exception {
        String s = roomRequest.sendTCP(CMD.GET_SINGER_INFO, Request.argPut("singerMid", singerMid));
        Response<String> res = new Response<>(s);
        if (res.resultCode == -2 || res.resultCode == 0) res.bean = res.arg;
        return res;
    }

    /**
     * 2.1 	GetTopList 获取云音乐排行榜
     */
    public Response<List<TopCate>> getTopList() throws Exception {
        String s = roomRequest.sendTCP(CMD.GET_TOP_LIST, null);
        Response<List<TopCate>> res = new Response<>(s);
        if (res.resultCode == -2 || res.resultCode == 0)
            res.bean = JSON.parseArray(new JSONObject(res.arg).getString("TopListCate"), TopCate.class);
        return res;
    }

    /**
     * 2.2 	GetTopListSong 获取排行榜的歌曲
     * 某条榜单下的歌曲列表
     * 参数是 {@link TopCate.CloudToplistSet}的属性
     */
    public Response<List<CloudMusic>> getTopListSong(String topListId, String topListDate) throws Exception {
        Map<String, Object> params = Request.argPut("topListId", topListId);
        params.put("topListDate", topListDate);
        String s = roomRequest.sendTCP(CMD.GET_TOP_LIST_SONG, params);
        Response<List<CloudMusic>> res = new Response<>(s);
        if (res.resultCode == -2 || res.resultCode == 0)
            res.bean = JSON.parseArray(new JSONObject(res.arg).getString("list"), CloudMusic.class);
        return res;
    }

    /**
     * 3.1 	GetCategory 获取歌曲分类列表
     */
    public Response<List<SongCategroyGroup>> getCategory() throws Exception {
        String s = roomRequest.sendTCP(CMD.GET_CATEGORY, null);
        Response<List<SongCategroyGroup>> res = new Response<>(s);
        if (res.resultCode == -2 || res.resultCode == 0)
            res.bean = JSON.parseArray(new JSONObject(res.arg).getString("categories"), SongCategroyGroup.class);
        return res;
    }

    /**
     * 3.2 	GetCategorySong 获取歌曲分类下面的歌曲
     *
     * @param categoryId {@link CloudCategorySet} id
     */
    public Response<List<CloudMusic>> getCategorySong(String categoryId, String sort, int pageNum) throws Exception {
        Map<String, Object> params = Request.argPut("categoryId", categoryId);
        params.put("sort", sort);
        params.put("perpage", 20);
        params.put("pageNum", pageNum);
        String s = roomRequest.sendTCP(CMD.GET_CATEGORY_SONG, params);
        Response<List<CloudMusic>> res = new Response<>(s);
        if (res.resultCode == 0)
            res.bean = JSON.parseArray(new JSONObject(res.arg).getString("list"), CloudMusic.class);
        return res;
    }

    /**
     * 3.3 	GetCategoryDiss 获取歌曲分类下面的歌单
     *
     * @param categoryId {@link CloudCategorySet} id
     */
    public Response<List<CloudDissSet>> getCategoryDiss(String categoryId, String sort, int pageNum) throws Exception {
        Map<String, Object> params = Request.argPut("categoryId", categoryId);
        params.put("sort", sort);
        params.put("perpage", 20);
        params.put("pageNum", pageNum);
        String s = roomRequest.sendTCP(CMD.GET_CATEGORY_DISS, params);
        Response<List<CloudDissSet>> res = new Response<>(s);
        if (res.resultCode == 0)
            res.bean = JSON.parseArray(new JSONObject(res.arg).getString("list"), CloudDissSet.class);
        return res;
    }

    /**
     * 3.4 	GetCategoryAlbum 获取分类下面的专辑
     *
     * @param categoryId {@link CloudCategorySet} id
     *                   还未调通
     */
    @Deprecated
    public Response<?> getCategoryAlbum(String categoryId, String sort, int pageNum) throws Exception {
        Map<String, Object> params = Request.argPut("categoryId", categoryId);
        params.put("sort", sort);
        params.put("perpage", 20);
        params.put("pageNum", pageNum);
        String s = roomRequest.sendTCP(CMD.GET_CATEGORY_ALBUM, params);
        Response<?> res = new Response<>(s);
//        if (res.resultCode == 0)
//            res.bean = JSON.parseArray(new JSONObject(res.arg).getString("list"), CloudDissSet.class);
        return res;
    }

    /**
     * 4.1 	GetDissCategory获取歌单分类列表
     */
    public Response<List<DissCategoryGroup>> getDissCategory() throws Exception {
        String s = roomRequest.sendTCP(CMD.GET_DISS_CATEGORY, null);
        Response<List<DissCategoryGroup>> res = new Response<>(s);
        if (res.resultCode == 0)
            res.bean = JSON.parseArray(new JSONObject(res.arg).getString("categories"), DissCategoryGroup.class);
        return res;
    }

    /**
     * 4.2 	GetDiss 获取分类下的歌单
     * 获取歌单分类下的歌单
     *
     * @param categoryId {@link com.westwhale.api.protocolapi.bean.cloudmusic.DissCategory} 的id
     */
    public Response<List<CloudDissSet>> getDiss(String categoryId, int sort, int from, int to) throws Exception {
        Map<String, Object> params = Request.argPut("categoryId", categoryId);
        params.put("sort", sort);
        params.put("from", from);
        params.put("to", to);
        String s = roomRequest.sendTCP(CMD.GET_DISS, params);
        Response<List<CloudDissSet>> res = new Response<>(s);
        if (res.resultCode == 0)
            res.bean = JSON.parseArray(new JSONObject(res.arg).getString("list"), CloudDissSet.class);
        return res;
    }

    /**
     * 4.3 	GetDissSong 获取歌单下的歌曲
     *
     * @param dissId {@link CloudDissSet} 的dissId
     */
    public Response<List<CloudMusic>> getDissSong(String dissId) throws Exception {
        String s = roomRequest.sendTCP(CMD.GET_DISS_SONG, Request.argPut("dissId", dissId));
        Response<List<CloudMusic>> res = new Response<>(s);
        if (res.resultCode == 0)
            res.bean = JSON.parseArray(new JSONObject(res.arg).getString("list"), CloudMusic.class);
        return res;
    }

    /**
     * 4.4 	GetDissInfo 获取歌单的信息
     */
    public Response<List<DissInfo>> getDissInfo(List<String> dissIds) throws Exception {
        if (dissIds == null || dissIds.isEmpty()) throw new BAException("params empty");
        JSONArray jsonArray = new JSONArray();
        for (String s : dissIds) {
            jsonArray.put(s);
        }
        String s = roomRequest.sendTCP(CMD.GET_DISS_INFO, Request.argPut("dissId", jsonArray));
        Response<List<DissInfo>> res = new Response<>(s);
        if (res.resultCode == -2 || res.resultCode == 0)
            res.bean = JSON.parseArray(new JSONObject(res.arg).getString("cdList"), DissInfo.class);
        return res;
    }

    /**
     * 5.1 	GetAlbum获取专辑
     */
    public Response<List<CloudAlbumSet>> getAlbum(int time, int area, int type, int index, int sort, int perpage, int pageNo) throws Exception {
        Map<String, Object> params = Request.argPut("time", time);
        params.put("area", area);
        params.put("type", type);
        params.put("index", index);
        params.put("sort", sort);
        params.put("perpage", perpage);
        params.put("pageNo", pageNo);
        String s = roomRequest.sendTCP(CMD.GET_ALBUM, params);
        Response<List<CloudAlbumSet>> res = new Response<>(s);
        if (res.resultCode == 0)
            res.bean = JSON.parseArray(new JSONObject(res.arg).getString("list"), CloudAlbumSet.class);
        return res;
    }

    /**
     * 5.2 	GetAlbumSong获取专辑下的歌曲
     */
    @Deprecated
    public Response<List<CloudMusic>> getAlbumSong(String albumMid) throws Exception {
        String s = roomRequest.sendTCP(CMD.GET_ALBUM_SONG, Request.argPut("albumMid", albumMid));
        Response<List<CloudMusic>> res = new Response<>(s);
        if (res.resultCode == 0)
            res.bean = JSON.parseArray(new JSONObject(res.arg).getString("list"), CloudMusic.class);
        return res;
    }

    /**
     * 6.1 	GetRadio 获取电台
     */
    public Response<List<CloudRadioGroup>> getRadio() throws Exception {
        String s = roomRequest.sendTCP(CMD.GET_RADIO, null);
        Response<List<CloudRadioGroup>> res = new Response<>(s);
        if (res.resultCode == 0)
            res.bean = JSON.parseArray(new JSONObject(res.arg).getString("groupList"), CloudRadioGroup.class);
        return res;
    }

    /**
     * 6.2 	GetRadioSong 获取电台歌曲 [内部]
     * 仅内部使用
     */
    public Response<List<CloudMusic>> getRadioSong(String radioId) throws Exception {
        String s = roomRequest.sendTCP(CMD.GET_RADIO_SONG, Request.argPut("radioId", radioId));
        Response<List<CloudMusic>> res = new Response<>(s);
        if (res.resultCode == 0)
            res.bean = JSON.parseArray(new JSONObject(res.arg).getString("songs"), CloudMusic.class);
        return res;
    }

    /**
     * 7.1 	GetNewSong 新歌速递
     *
     * @param area nd,gt,eu,k,j()
     */
    public Response<List<CloudMusic>> getNewSong(String area) throws Exception {
        String s = roomRequest.sendTCP(CMD.GET_NEW_SONG, Request.argPut("area", area));
        Response<List<CloudMusic>> res = new Response<>(s);
        if ((res.resultCode == 0) || (res.resultCode == -2))
            res.bean = JSON.parseArray(new JSONObject(res.arg).getString("songList"), CloudMusic.class);
        return res;
    }

    /**
     * 7.2 	GetRecommend 热推专辑、歌单、音乐人
     */
    public Response<CloudMusicRecommed> getRecommend() throws Exception {
        String s = roomRequest.sendTCP(CMD.GET_RECOMMEND, null);
        Response<CloudMusicRecommed> res = new Response<>(s);
        if (res.resultCode == 0)
            res.bean = JSON.parseObject(res.arg, CloudMusicRecommed.class);
        return res;
    }

    /**
     * 8.1 	SearchPreView 搜索提示
     */
    public Response<SearchPreview> searchPreView(String searchText) throws Exception {
        String s = roomRequest.sendTCP(CMD.SEARCH_PREVIEW, Request.argPut("searchText", searchText));
        Response<SearchPreview> res = new Response<>(s);
        if (res.resultCode == 0) res.bean = JSON.parseObject(res.arg, SearchPreview.class);
        return res;
    }

    /**
     * 8.2 	SearchLyric 搜索歌词
     */
    public Response<List<LyricMusic>> searchLyric(String searchText, int pageNo) throws Exception {
        Map<String, Object> params = Request.argPut("searchText", searchText);
        params.put("pageNo", pageNo);
        String s = roomRequest.sendTCP(CMD.SEARCH_LYRIC, params);
        Response<List<LyricMusic>> res = new Response<>(s);
        if (res.resultCode == 0)
            res.bean = JSON.parseArray(new JSONObject(res.arg).getString("list"), LyricMusic.class);
        return res;
    }

    /**
     * 8.3 	SearchSong 搜索歌曲
     */
    public Response<List<CloudMusic>> searchSong(String searchText, int pageNo) throws Exception {
        Map<String, Object> params = Request.argPut("searchText", searchText);
        params.put("pageNo", pageNo);
        String s = roomRequest.sendTCP(CMD.SEARCH_SONG, params);
        Response<List<CloudMusic>> res = new Response<>(s);
        if (res.resultCode == 0)
            res.bean = JSON.parseArray(new JSONObject(res.arg).getString("list"), CloudMusic.class);
        return res;
    }

    /**
     * 8.4 	SearchAlbum 搜索专辑
     */
    public Response<List<SearchAlbum>> searchAlbum(String searchText, int pageNo) throws Exception {
        Map<String, Object> params = Request.argPut("searchText", searchText);
        params.put("pageNo", pageNo);
        String s = roomRequest.sendTCP(CMD.SEARCH_ALBUM, params);
        Response<List<SearchAlbum>> res = new Response<>(s);
        if (res.resultCode == 0)
            res.bean = JSON.parseArray(new JSONObject(res.arg).getString("list"), SearchAlbum.class);
        return res;
    }

    // 获取歌词
    public Response<String> getSongLyric(String mid) throws Exception {
        Map<String, Object> params = Request.argPut("mid", mid);
        params.put("songMid",mid);// 为了兼容
        String s = roomRequest.sendTCP(CMD.GET_SONG_LYRIC, params);
        Response<String> res = new Response<>(s);
        if (res.resultCode == 0)
            res.bean = new JSONObject(res.arg).getString("lyric");
        return res;
    }

    /**---------------------------------------语言节目与新闻资讯系列接口---------------------**/
    /**
     * 1.1	 GetStorytellingCategory 获取语言节目的分类组
     */
    public Response<List<CatrgroyGroup>> getStorytellingCategory() throws Exception {
        String s = roomRequest.sendTCP(CMD.GET_STORYTELLING_CATEGORY, null);
        Response<List<CatrgroyGroup>> res = new Response<>(s);
        if (res.resultCode == 0)
            res.bean = JSON.parseArray(new JSONObject(res.arg).getString("categoryList"), CatrgroyGroup.class);
        return res;
    }

    /**
     * 1.2	 GetStorytelling获取分类下的语言节目列表
     */
    public Response<List<StoryTelling>> getStorytelling(String categoryId, int perpage, int pagenum) throws Exception {
        Map<String, Object> params = Request.argPut("categoryId", categoryId);
        params.put("perpage", perpage);
        params.put("pagenum", pagenum);
        String s = roomRequest.sendTCP(CMD.GET_STORYTELLING, params);
        Response<List<StoryTelling>> res = new Response<>(s);
        if (res.resultCode == 0)
            res.bean = JSON.parseArray(new JSONObject(res.arg).getString("mediaList"), StoryTelling.class);
        if (res.bean != null) for (StoryTelling album : res.bean) {
            album.pic = Base64Util.decode(album.pic);
        }
        return res;
    }

    /**
     * 1.3	 GetStorytellingPlaylist 获取语言节目的播放列表
     * 语言节目下的分集
     */
    public Response<List<Section>> getStorytellingPlaylist(int mediaId, int perpage, int pagenum) throws Exception {
        Map<String, Object> params = Request.argPut("mediaId", String.valueOf(mediaId));
        params.put("perpage", perpage);
        params.put("pagenum", pagenum);
        String s = roomRequest.sendTCP(CMD.GET_STORYTELLING_PLAYLIST, params);
        Response<List<Section>> res = new Response<>(s);
        if (res.resultCode == 0)
            res.bean = JSON.parseArray(new JSONObject(res.arg).getString("mediaPlayList"), Section.class);
        return res;
    }

    /**
     * 1.4	 GetStorytellingPush 获取语言节目的推介
     *
     * @param pushType pop,topComments,new,recommend(人气，最热，最新，推荐)
     */
    public Response<List<StoryTelling>> getStorytellingPush(String pushType, int perpage, int pagenum) throws Exception {
        Map<String, Object> params = Request.argPut("pushType", pushType);
        params.put("perpage", perpage);
        params.put("pagenum", pagenum);
        String s = roomRequest.sendTCP(CMD.GET_STORYTELLING_PUSH, params);
        Response<List<StoryTelling>> res = new Response<>(s);
        if (res.resultCode == -2 || res.resultCode == 0)
            res.bean = JSON.parseArray(new JSONObject(res.arg).getString("mediaList"), StoryTelling.class);
        return res;
    }

    /**
     * 1.5	 SearchStorytelling 搜索语言节目
     */
    public Response<List<StoryTelling>> searchStorytelling(String searchText, int perpage, int pagenum) throws Exception {
        Map<String, Object> params = Request.argPut("searchText", searchText);
        params.put("perpage", perpage);
        params.put("pagenum", pagenum);
        String s = roomRequest.sendTCP(CMD.SEARCH_STORYTELLING, params);
        Response<List<StoryTelling>> res = new Response<>(s);
        if (res.resultCode == -2 || res.resultCode == 0)
            res.bean = JSON.parseArray(new JSONObject(res.arg).getString("mediaList"), StoryTelling.class);
        return res;
    }

    /**
     * 1.6	GetStoryTellingAnchorCategory  获取所有主播分类
     */
    public Response<List<AnchorCategroy>> getStoryTellingAnchorCategory() throws Exception {
        String s = roomRequest.sendTCP(CMD.GET_STORY_TELLING_ANCHOR_CATEGORY, null);
        Response<List<AnchorCategroy>> res = new Response<>(s);
        if (res.resultCode == 0)
            res.bean = JSON.parseArray(new JSONObject(res.arg).getString("mediaList"), AnchorCategroy.class);
        return res;
    }

    /**
     * 1.7	 GetStoryTellingAnchor获取分类下的主播
     *
     * @param categoryId {@link AnchorCategroy}的id,且type为Famous
     */
    public Response<List<Anchor>> getStoryTellingAnchor(int categoryId, int pageSize, int pageNum) throws Exception {
        Map<String, Object> params = Request.argPut("categoryId", categoryId);
        params.put("pageSize", pageSize);
        params.put("pageNum", pageNum);
        String s = roomRequest.sendTCP(CMD.GET_STORY_TELLING_ANCHOR, params);
        Response<List<Anchor>> res = new Response<>(s);
        if (res.resultCode == 0)
            res.bean = JSON.parseArray(new JSONObject(res.arg).getString("mediaList"), Anchor.class);
        return res;
    }

    /**
     * 1.8	GetStoryTellingAnchorByNormal获取分类下的主播
     *
     * @param recommendType hot,new()
     * @param categoryName  {@link AnchorCategroy}的name,且type为normal
     */
    public Response<List<Anchor>> getStoryTellingAnchorByNormal(String categoryName, String recommendType, int pageSize, int pageNum) throws Exception {
        Map<String, Object> params = Request.argPut("categoryName", categoryName);
        params.put("recommendType", recommendType);
        params.put("pageSize", pageSize);
        params.put("pageNum", pageNum);
        String s = roomRequest.sendTCP(CMD.GET_STORY_TELLING_ANCHOR_BY_NORMAL, params);
        Response<List<Anchor>> res = new Response<>(s);
        if (res.arg != null)
            res.bean = JSON.parseArray(new JSONObject(res.arg).getString("mediaList"), Anchor.class);
        return res;
    }

    /**
     * 1.9	GetStoryTellingAnchorAlbum 获取主播的语言节目
     *
     * @param anchorId {@link Anchor}的uid
     */
    public Response<List<StoryTelling>> getStoryTellingAnchorAlbum(int anchorId, int pageSize, int pageNum) throws Exception {
        Map<String, Object> params = Request.argPut("anchorId", anchorId);
        params.put("pageSize", pageSize);
        params.put("pageNum", pageNum);
        String s = roomRequest.sendTCP(CMD.GET_STORY_TELLING_ANCHOR_ALBUM, params);
        Response<List<StoryTelling>> res = new Response<>(s);
        if (res.resultCode == 0)
            res.bean = JSON.parseArray(new JSONObject(res.arg).getString("mediaList"), StoryTelling.class);
        return res;
    }

    /**
     * 1.10	GetStoryTellingAnchorInfo 获取主播信息
     */
    public Response<AnchorInfo> getStoryTellingAnchorInfo(int anchorId) throws Exception {
        String s = roomRequest.sendTCP(CMD.GET_STORY_TELLING_ANCHOR_INFO, Request.argPut("anchorId", anchorId));
        Response<AnchorInfo> res = new Response<>(s);
        if (res.resultCode == -2 || res.resultCode == 0)
            res.bean = JSON.parseObject(res.arg, AnchorInfo.class);
        return res;
    }

    /**
     * 1.11	GetStoryTellingAnchorTrack 获取主播的媒体(语言节目分集)列表
     */
    public Response<List<Section>> getStoryTellingAnchorTrack(int anchorId, int pageSize, int pageNum) throws Exception {
        Map<String, Object> params = Request.argPut("anchorId", anchorId);
        params.put("pageSize", pageSize);
        params.put("pageNum", pageNum);
        String s = roomRequest.sendTCP(CMD.GET_STORY_TELLING_ANCHOR_TRACK, params);
        Response<List<Section>> res = new Response<>(s);
        if (res.resultCode == 0)
            res.bean = JSON.parseArray(new JSONObject(res.arg).getString("mediaList"), Section.class);
        return res;
    }

    /**
     * 1.12	 GetStoryTellingRankingList  获取语言节目榜单
     */
    public Response<List<RankItem>> getStoryTellingRankingList() throws Exception {
        String s = roomRequest.sendTCP(CMD.GET_STORY_TELLING_RANKING_LIST, null);
        Response<List<RankItem>> res = new Response<>(s);
        if (res.resultCode != 0) return res;
        JSONArray array = new JSONObject(res.arg).getJSONArray("rankingList");
        if (array == null) return res;
        res.bean = new ArrayList<>();
        for (int i = 0, size = array.length(); i < size; i++)
            res.bean.addAll(JSON.parseArray(array.getJSONObject(i).getString("list"), RankItem.class));
        return res;
    }

    /**
     * 1.13	 GetStoryTellingRankingListAlbum  获取榜单下的专辑
     */
    public Response<List<StoryTelling>> getStoryTellingRankingListAlbum(int rankingListId, int pageNum, int pageSize) throws Exception {
        return getStoryTellingRankingListItem(rankingListId, pageNum, pageSize, CMD.GET_STORY_TELLING_RANKING_LIST_ALBUM, StoryTelling.class);
    }

    /**
     * 1.14	 GetStoryTellingRankingListAnchor获取榜单下的主播
     */
    public Response<List<Anchor>> getStoryTellingRankingListAnchor(int rankingListId, int pageNum, int pageSize) throws Exception {
        return getStoryTellingRankingListItem(rankingListId, pageNum, pageSize, CMD.GET_STORY_TELLING_RANKING_LIST_ANCHOR, Anchor.class);
    }

    /**
     * 1.15 GetStoryTellingRankingListTrack 获取榜单下的媒体
     */
    public Response<List<Section>> getStoryTellingRankingListTrack(int rankingListId, int pageNum, int pageSize) throws Exception {
        return getStoryTellingRankingListItem(rankingListId, pageNum, pageSize, CMD.GET_STORY_TELLING_RANKING_LIST_TRACK, Section.class);
    }

    private <T> Response<List<T>> getStoryTellingRankingListItem(int rankingListId, int pageNum, int pageSize, String cmd, Class<T> tClass) throws Exception {
        Map<String, Object> params = Request.argPut("rankingListId", rankingListId);
        params.put("pageSize", pageSize);
        params.put("pageNum", pageNum);
        String s = roomRequest.sendTCP(cmd, params);
        Response<List<T>> res = new Response<>(s);
        if (res.resultCode == 0)
            res.bean = JSON.parseArray(new JSONObject(res.arg).getString(CMD.GET_STORY_TELLING_RANKING_LIST_TRACK.equals(cmd) ? "mediaList" : "list"), tClass);
        return res;
    }

    /**
     * 2.1	 GetNewsCategory 获取新闻资讯的分类
     */
    public Response<List<NewsCategorySet>> getNewsCategory() throws Exception {
        String s = roomRequest.sendTCP(CMD.GET_NEWS_CATEGORY, null);
        Response<List<NewsCategorySet>> res = new Response<>(s);
        if (res.resultCode == 0)
            res.bean = JSON.parseArray(new JSONObject(res.arg).getString("categoryList"), NewsCategorySet.class);
        return res;
    }

    /**
     * 2.2	 GetNews 获取分类下的新闻
     * 返回空news数据
     */
    public Response<List<News>> getNews(String categoryId, int perpage, int pagenum) throws Exception {
        Map<String, Object> params = Request.argPut("categoryId", categoryId);
        params.put("perpage", perpage);
        params.put("pagenum", pagenum);
        String s = roomRequest.sendTCP(CMD.GET_NEWS, params);
        Response<List<News>> res = new Response<>(s);
        if (res.resultCode == 0)
            res.bean = JSON.parseArray(new JSONObject(res.arg).getString("newsList"), News.class);
        return res;
    }

    /**
     * 2.3	 SearchNews 搜索分类下的新闻
     * 接口未写好
     */
    @Deprecated
    public Response<List<News>> searchNews(String searchText, int perpage, int pagenum) throws Exception {
        Map<String, Object> params = Request.argPut("searchText", searchText);
        params.put("perpage", perpage);
        params.put("pagenum", pagenum);
        String s = roomRequest.sendTCP(CMD.SEARCH_NEWS, params);
        Response<List<News>> res = new Response<>(s);
//        if (res.resultCode == 0)
//            res.bean = JSON.parseArray(new JSONObject(res.arg).getString("newsList"), News.class);
        return res;
    }

    /**--------------------------------CloudNetFm----------------------------*/
    /**
     * 1.1.	获取所有电台总目录ID,本地台，热门台
     */
    public Response<GetNetFmCategoryResult> getNetFmCategory() throws Exception {
        String s = roomRequest.sendTCP(CMD.GET_NET_FM_CATEGORY, null);
        Response<GetNetFmCategoryResult> res = new Response<>(s);
        if (res.resultCode == 0)
            res.bean = JSON.parseObject(res.arg, GetNetFmCategoryResult.class);
        return res;
    }

    /**
     * 1.2.	获取电台总目下子电台分类
     */
    public Response<List<CloudNetFm>> getNetFmByCategory(int categoryId, int pageNum, int pageSize) throws Exception {
        Map<String, Object> params = Request.argPut("categoryId", categoryId);
        params.put("pageNum", pageNum);
        params.put("pageSize", pageSize);
        String s = roomRequest.sendTCP(CMD.GET_NET_FM_BY_CATEGORY, params);
        Response<List<CloudNetFm>> res = new Response<>(s);
        if (res.resultCode == 0)
            res.bean = JSON.parseArray(new JSONObject(res.arg).getString("list"), CloudNetFm.class);
        return res;
    }

    /**
     * 1.3.	排行榜
     */
    public Response<List<CloudNetFm>> getNetFmTopList(int pageNum, int pageSize) throws Exception {
        Map<String, Object> params = Request.argPut("pageNum", pageNum);
        params.put("pageSize", pageSize);
        String s = roomRequest.sendTCP(CMD.GET_NET_FM_TOP_LIST, params);
        Response<List<CloudNetFm>> res = new Response<>(s);
        if (res.resultCode == 0)
            res.bean = JSON.parseArray(new JSONObject(res.arg).getString("list"), CloudNetFm.class);
        return res;
    }

    /**
     * 2.1.	获取本地台ID
     *
     * @param latitude  经度
     * @param longitude 纬度
     *                  protocol can't parse 接口未好
     */
    @Deprecated
    public Response<List<CloudNetFm>> getProvinceCodeByLatLng(double latitude, double longitude) throws Exception {
        Map<String, Object> params = Request.argPut("latitude", latitude);
        params.put("longitude", longitude);
        String s = roomRequest.sendTCP(CMD.GET_PROVINCE_CODE_BY_LAT_LNG, params);
        Response<List<CloudNetFm>> res = new Response<>(s);
        if (res.resultCode == 0)
            res.bean = JSON.parseArray(new JSONObject(res.arg).getString("list"), CloudNetFm.class);
        return res;
    }

    /**
     * 2.2.	国家台
     */
    public Response<List<CloudNetFm>> getNetFmNational(int pageNum, int pageSize) throws Exception {
        Map<String, Object> params = Request.argPut("pageNum", pageNum);
        params.put("pageSize", pageSize);
        String s = roomRequest.sendTCP(CMD.GET_NET_FM_NATIONAL, params);
        Response<List<CloudNetFm>> res = new Response<>(s);
        if (res.resultCode == 0)
            res.bean = JSON.parseArray(new JSONObject(res.arg).getString("list"), CloudNetFm.class);
        return res;
    }

    /**
     * 2.3.	网络台
     */
    public Response<List<CloudNetFm>> getNetFmNetwork(int pageNum, int pageSize) throws Exception {
        Map<String, Object> params = Request.argPut("pageNum", pageNum);
        params.put("pageSize", pageSize);
        String s = roomRequest.sendTCP(CMD.GET_NET_FM_NETWORK, params);
        Response<List<CloudNetFm>> res = new Response<>(s);
        if (res.resultCode == 0)
            res.bean = JSON.parseArray(new JSONObject(res.arg).getString("list"), CloudNetFm.class);
        return res;
    }

    /**
     * 2.4.	所有省市列表
     */
    public Response<List<Province>> getProvinceCodeCategory() throws Exception {
        String s = roomRequest.sendTCP(CMD.GET_PROVINCE_CODE_CATEGORY, null);
        Response<List<Province>> res = new Response<>(s);
        if (res.resultCode == 0)
            res.bean = JSON.parseArray(new JSONObject(res.arg).getString("list"), Province.class);
        return res;
    }

    /**
     * 2.5.	省市台
     */
    public Response<List<CloudNetFm>> getNetFmByCode(int provinceCode, int pageNum, int pageSize) throws Exception {
        Map<String, Object> params = Request.argPut("provinceCode", provinceCode);
        params.put("pageNum", pageNum);
        params.put("pageSize", pageSize);
        String s = roomRequest.sendTCP(CMD.GET_NET_FM_BY_CODE, params);
        Response<List<CloudNetFm>> res = new Response<>(s);
        if (res.resultCode == 0)
            res.bean = JSON.parseArray(new JSONObject(res.arg).getString("list"), CloudNetFm.class);
        return res;
    }

    /**
     * 3.1.	获取播放列表
     *
     */
    @Deprecated
    public Response<List<CloudNetFm>> getNetFmPlayList(int radioId) throws Exception {
        String s = roomRequest.sendTCP(CMD.GET_NET_FM_PLAY_LIST, Request.argPut("radioId", radioId));
        Response<List<CloudNetFm>> res = new Response<>(s);
        if (res.resultCode == 0)
            res.bean = JSON.parseArray(new JSONObject(res.arg).getString("list"), CloudNetFm.class);
        return res;
    }

    /**
     * 3.2.	获取当前直播信息
     * protocol can't parse 接口未好
     */
    @Deprecated
    public Response<List<CloudNetFm>> getNetFmPlayingInfo(int radioId) throws Exception {
        String s = roomRequest.sendTCP(CMD.GET_NET_FM_PLAYING_INFO, Request.argPut("radioId", radioId));
        Response<List<CloudNetFm>> res = new Response<>(s);
        if (res.resultCode == 0)
            res.bean = JSON.parseArray(new JSONObject(res.arg).getString("list"), CloudNetFm.class);
        return res;
    }


    private List<AlbumSetMeta> praseAlbumSetMeta(String arg) throws Exception {
        if (TextUtils.isEmpty(arg)) return null;
        List<AlbumSetMeta> res = new ArrayList<>();
        JSONArray jsonArray = new JSONArray(arg);
        if (jsonArray.length() == 0){
            return res;
        }
        for (int i=0; i < jsonArray.length(); i++){
            JSONObject jsonObject = jsonArray.optJSONObject(i);
            if (jsonObject != null){
                String setType = jsonObject.optString("albumSetTypeName");
                switch(setType){
                    case AlbumSetMeta.CLOUD_ALBUM_SET:
                        res.add(JSON.parseObject(jsonObject.toString(),CloudAlbumSet.class));
                        break;
                    case AlbumSetMeta.CLOUD_SINGER_SET:
                        res.add(JSON.parseObject(jsonObject.toString(),CloudSingerSet.class));
                        break;
                    case AlbumSetMeta.CLOUD_CATEGORY_SET:
                        res.add(JSON.parseObject(jsonObject.toString(),CloudCategorySet.class));
                        break;
                    case AlbumSetMeta.CLOUD_DISS_SET:
                        res.add(JSON.parseObject(jsonObject.toString(),CloudDissSet.class));
                        break;
                    case AlbumSetMeta.CLOUD_NET_RADIO_SET:
                        res.add(JSON.parseObject(jsonObject.toString(),CloudRadioSet.class));
                        break;
                    case AlbumSetMeta.LOCAL_MUSIC_DIR_SET:
                        res.add(JSON.parseObject(jsonObject.toString(),LocalMusicDirSet.class));
                        break;
                    case AlbumSetMeta.STORY_TELLING_ANCHOR_SET:
                        res.add(JSON.parseObject(jsonObject.toString(),StoryTellingAnchorSet.class));
                        break;
                    case AlbumSetMeta.STORY_TELLING_ALBUM_SET:
                        res.add(JSON.parseObject(jsonObject.toString(),StoryTelling.class));
                        break;
                    case AlbumSetMeta.CLOUD_NEWS_CATEGORY_SET:
                        res.add(JSON.parseObject(jsonObject.toString(),NewsCategorySet.class));
                        break;
                    default:
                        break;
                }
            }
        }

        return res;
    }


    private Map<String, JSONArray> albumSetParams(List<AlbumSetMeta> albumSetList) throws Exception {
        Map<String, JSONArray> params = new HashMap<>();
        if (albumSetList == null) return params;
        for (AlbumSetMeta set : albumSetList) {
            JSONArray value = params.get(set.getListName());
            if (value == null)
                params.put(set.getListName(), consitiParams(Collections.singletonList(set)));
            else value.put(new JSONObject(JSON.toJSONString(set)));
        }
        return params;
    }

    private JSONArray consitiParams(List list) throws JSONException {
        if (list == null) return null;
        JSONArray jsonArray = new JSONArray();
        for (Object o : list) {
            jsonArray.put(new JSONObject(JSON.toJSONString(o)));
        }
        return jsonArray;
    }

//    public void eventGo(String s) {
//        EventBus.getDefault().post(s);
//    }

}
