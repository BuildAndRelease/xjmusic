package com.westwhale.api.protocolapi.bean.cloudmusic;

/**
 * 歌单分类
 * Created by cyl on 2018/5/8.
 */

public class DissCategory {
    public int categoryId;
    public String categoryName;
}
