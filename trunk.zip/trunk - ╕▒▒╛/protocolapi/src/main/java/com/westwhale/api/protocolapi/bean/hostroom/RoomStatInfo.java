package com.westwhale.api.protocolapi.bean.hostroom;

import android.text.TextUtils;

import com.alibaba.fastjson.JSON;
import com.westwhale.api.protocolapi.bean.media.CloudMusic;
import com.westwhale.api.protocolapi.bean.media.LocalAux;
import com.westwhale.api.protocolapi.bean.media.LocalFm;
import com.westwhale.api.protocolapi.bean.media.LocalMusic;
import com.westwhale.api.protocolapi.bean.media.Media;
import com.westwhale.api.protocolapi.bean.media.CloudNetFm;
import com.westwhale.api.protocolapi.bean.media.News;
import com.westwhale.api.protocolapi.bean.media.Section;

import org.json.JSONException;
import org.json.JSONObject;

/**
 * 房间的基本状态信息
 * Created by cyl on 2018/5/28.
 */

public class RoomStatInfo {
    public String devStat;
    public Media media;
    public String muteStat;
    public String phoneMuteEnable;
    public String playMode;
    public String playStat;
    public String talkId;
    public String partyId;
    public int playTime;
    public String roomStat;
    public int volume;

    public void setMedia(String json) {
        if (TextUtils.isEmpty(json)) return;
        try {
            JSONObject mediaJson = new JSONObject(json);
            String type = mediaJson.getString("mediaSrc");
            switch (type) {
                case Media.CLOUD_MUSIC:
                    this.media = JSON.parseObject(json, CloudMusic.class);
                    break;
                case Media.LOCAL_MUSIC:
                    this.media = JSON.parseObject(json, LocalMusic.class);
                    break;
                case Media.CLOUD_NEWS:
                    this.media = JSON.parseObject(json, News.class);
                    break;
                case Media.CLOUD_STORY_TELLING:
                    this.media = JSON.parseObject(json, Section.class);
                    break;
                case Media.CLOUD_NETFM:
                    this.media = JSON.parseObject(json, CloudNetFm.class);
                    break;
                case Media.LOCAL_AUX:
                    this.media = JSON.parseObject(json, LocalAux.class);
                    break;
                case Media.LOCAL_FM:
                    this.media = JSON.parseObject(json, LocalFm.class);
                    break;
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }
}
