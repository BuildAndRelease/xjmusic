package com.westwhale.api.protocolapi.bean.scene;

import com.westwhale.api.protocolapi.bean.hostroom.Room;

/**
 * 通道 or 房间
 * Created by cyl on 2018/5/31.
 */

public class Channel {
    //房间uuid
    public String channelUuid;
    //房间名称
    public String channelName;

    public Channel () {

    }

    public Channel(Room room) {
        this.channelName = room.roomName;
        this.channelUuid = room.roomId;
    }
}
