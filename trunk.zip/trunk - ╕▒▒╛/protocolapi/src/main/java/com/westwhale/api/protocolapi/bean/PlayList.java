package com.westwhale.api.protocolapi.bean;

/**
 * 4.27.1	获取我的收藏歌单
 * Created by cyl on 2018/5/7.
 */

public class PlayList {
    public int playListId;
    public String playListName;
    public String editStat;
}
