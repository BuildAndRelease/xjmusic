package com.westwhale.api.protocolapi.bean;

/**
 * 延时关机参数
 * Created by cyl on 2018/4/24.
 */

public class DelayClose {
    //enable, disable
    public String timerEnable;
    //以分钟为单位，还剩多少分钟
    public int remainTime;
    //延时多久，以分钟为单位。0,10,20,30,60,120
    public int delayCloseAfterTimes;
}
