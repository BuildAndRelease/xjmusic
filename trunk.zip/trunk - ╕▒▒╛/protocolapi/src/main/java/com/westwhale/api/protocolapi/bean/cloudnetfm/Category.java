package com.westwhale.api.protocolapi.bean.cloudnetfm;

/**
 * 电台分类
 * Created by cyl on 2018/6/8.
 */

public class Category {
    public int id;
    public String name;
}
