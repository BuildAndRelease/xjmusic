package com.westwhale.api.protocolapi.bean.albumSet;

/**
 *本地歌曲目录类的类定义
 * Created by cyl on 2018/4/18.
 */

public class LocalMusicDirSet extends AlbumSetMeta {
    public String directoryMid;
    public String directoryName;

    public LocalMusicDirSet() {
        super.albumSetTypeName = AlbumSetMeta.LOCAL_MUSIC_DIR_SET;
    }

    @Override
    public String getPic() {
        return "";
    }

    @Override
    public String getName() {
        return "本地音乐---" + directoryName;
    }

    @Override
    public String getListName() {
        return AlbumSetMeta.LOCAL_MUSIC_DIR_SET_LIST;
    }
}
