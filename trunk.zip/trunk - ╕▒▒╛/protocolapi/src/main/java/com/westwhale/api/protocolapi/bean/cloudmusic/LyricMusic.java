package com.westwhale.api.protocolapi.bean.cloudmusic;

import com.westwhale.api.protocolapi.bean.media.CloudMusic;

/**
 * 云音乐搜索歌词返回的音乐
 * Created by cyl on 2018/5/10.
 */

public class LyricMusic extends CloudMusic {
    public String lyric;
    public String content;
}
