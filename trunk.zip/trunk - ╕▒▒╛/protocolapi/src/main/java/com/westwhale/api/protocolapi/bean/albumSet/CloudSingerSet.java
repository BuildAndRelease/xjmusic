package com.westwhale.api.protocolapi.bean.albumSet;

/**
 * 歌手
 * Created by cyl on 2018/5/8.
 */

public class CloudSingerSet extends AlbumSetMeta {
    public String Farea;
    public String Fother_name;
    public String Findex;
    public String Fsort;
    public String Fsinger_id;
    public String Fsinger_mid;
    public String Fsinger_name;
    public String Fsinger_tag;
    public String type;
    public String pic_url;

    public CloudSingerSet() {
        super.albumSetTypeName = AlbumSetMeta.CLOUD_SINGER_SET;
    }

    @Override
    public String getPic() {
        return pic_url;
    }

    @Override
    public String getName() {
        return "云音乐歌手---" + Fsinger_name;
    }

    @Override
    public String getListName() {
        return AlbumSetMeta.CLOUD_SINGER_SET_LIST;
    }
}
