package com.westwhale.api.protocolapi.bean.media;

import android.os.Parcel;
import android.os.Parcelable;

import com.westwhale.api.protocolapi.bean.media.Media;

/**
 * 新闻资讯
 * Created by cyl on 2018/5/15.
 */

public class News extends Media implements Parcelable {
    public String categoryId;
    public String categoryName;
    public String description;
    public String duration;
    public String id;
    public boolean isUsable;
    public String listenNumShow;
    public String mid;
    public String parentId;
    public String pic;
    public String pubTime;
    public String title;
    public String updateTime;

    /**有些返回的字段是newsTitle，所以做这个兼容,使用还是newsTitle*/
    public void setNewsTitle(String title) {
        this.title = title;
    }

    public News(){
        super.mediaSrc = Media.CLOUD_NEWS;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(this.categoryId);
        dest.writeString(this.categoryName);
        dest.writeString(this.description);
        dest.writeString(this.duration);
        dest.writeString(this.id);
        dest.writeByte(this.isUsable ? (byte) 1 : (byte) 0);
        dest.writeString(this.listenNumShow);
        dest.writeString(this.mid);
        dest.writeString(this.parentId);
        dest.writeString(this.pic);
        dest.writeString(this.pubTime);
        dest.writeString(this.title);
        dest.writeString(this.updateTime);
    }

    protected News(Parcel in) {
        this.categoryId = in.readString();
        this.categoryName = in.readString();
        this.description = in.readString();
        this.duration = in.readString();
        this.id = in.readString();
        this.isUsable = in.readByte() != 0;
        this.listenNumShow = in.readString();
        this.mid = in.readString();
        this.parentId = in.readString();
        this.pic = in.readString();
        this.pubTime = in.readString();
        this.title = in.readString();
        this.updateTime = in.readString();
    }

    public static final Parcelable.Creator<News> CREATOR = new Parcelable.Creator<News>() {
        @Override
        public News createFromParcel(Parcel source) {
            return new News(source);
        }

        @Override
        public News[] newArray(int size) {
            return new News[size];
        }
    };
}
