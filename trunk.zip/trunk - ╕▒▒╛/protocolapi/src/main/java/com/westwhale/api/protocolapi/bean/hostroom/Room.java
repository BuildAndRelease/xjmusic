package com.westwhale.api.protocolapi.bean.hostroom;

import android.text.TextUtils;
import android.util.Pair;

/**
 * 房间
 * Created by cyl on 18/4/28.
 */

public class Room {
    public String roomId;
    public String roomName;
    public String devStat;
    public String channelStat;
    public String playStat;
    public String playName;
    public String serialId; //串口ID，用于串口通讯时，ID可配置
    /**
     * 冗余一个hostId,方便一些操作
     */
    public String hostId;


    /**
     * 通道状态，同房间状态
     * Created by cyl on 2018/3/27.
     */
    public static class ChannelState {
        public static final String INCLOSED = "inClosed";
        public static final String INNORMAL = "inNormal";
        public static final String INTALK = "inTalk";
        public static final String INPARTY = "inParty";
        public static final String INDLNA = "inDlna";
        public static final String INAIRPLAY = "inAirplay";
        public static final String INBT = "inBT";
        public static final String INCLOCK = "inClock";
    }


    /**
     * Created by cyl on 2018/3/27.
     * 设备状态
     */
    public class DevState {
        public static final String OPEN = "open";
        public static final String CLOSE = "close";
        public static final String UNCONNECTED = "unconnected";
    }


}
