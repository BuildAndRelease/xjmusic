package com.westwhale.api.protocolapi.bean.download;

public class DownloadItem<T> {
    public static final int DOWNLOAD_STATE_COMPLETE = 0;
    public static final int DOWNLOAD_STATE_PENDING = 1;
    public static final int DOWNLOAD_STATE_CONNECTING = 2;
    public static final int DOWNLOAD_STATE_STATED = 3;
    public static final int DOWNLOAD_STATE_CANCEL = 4;

    public static final int DOWNLOAD_STATE_ERROR_NO_VOLUME = -1;
    public static final int DOWNLOAD_STATE_ERROR_CAN_RETRY = -2;
    public static final int DOWNLOAD_STATE_ERROR_NO_RESPONSE = -3;
    public static final int DOWNLOAD_STATE_ERROR_NO_URL = -4;

    public long id;
    public String mediaSrc;
    public String mid;
    public String downloadPath;
    public String filePath;
    public int state;
    public boolean fileExist;
    public T media;
}
