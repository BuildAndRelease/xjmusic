package com.westwhale.api.protocolapi.bean;

/**
 * 主机IP信息
 * Created by cyl on 2018/6/1.
 */

public class ServerIpInfo {
    //192.168.0.1
    public String address;
    //0 – 自动获取IP 1 – 手动配置IP,若自动则修改address无效
    public int autoSetIp;
    public String dns1;
    public String dns2;
    //网关
    public String gateway;
    // 网络掩码:又称子网掩码
    public String netmask;
}
