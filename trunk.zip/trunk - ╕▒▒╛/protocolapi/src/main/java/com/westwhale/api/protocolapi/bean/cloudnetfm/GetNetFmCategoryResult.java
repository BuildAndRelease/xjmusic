package com.westwhale.api.protocolapi.bean.cloudnetfm;

import com.westwhale.api.protocolapi.bean.media.CloudNetFm;

import java.util.List;

/**
 * GetNetFmCategory的返回结果
 * Created by cyl on 2018/6/8.
 */

public class GetNetFmCategoryResult {
    public List<Category> categories;
    public List<CloudNetFm> localRadios;
    public List<CloudNetFm> topRadios;
    public String location;
}
