package com.westwhale.api.protocolapi.bean.cloudmusic;

import java.util.List;

/**
 * 歌单信息
 * Created by cyl on 2018/6/6.
 */

public class DissInfo {
    public String creatorName;
    public int ctime;
    public String desc;
    public String dissName;
    public String dissPic;
    public String disstId;
    public String scoreAvage;
    public int songNum;
    public List<Tag> tags;

    public static class Tag {
        public int id;
        public String name;
    }
}
