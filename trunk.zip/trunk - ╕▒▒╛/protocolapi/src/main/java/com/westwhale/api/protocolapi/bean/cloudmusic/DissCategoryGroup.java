package com.westwhale.api.protocolapi.bean.cloudmusic;

import java.util.List;

/**
 * 歌单分类组
 * Created by cyl on 2018/5/8.
 */

public class DissCategoryGroup {
    public String categoryGroupName;
    public List<DissCategory> items;
}
