package com.westwhale.api.protocolapi.bean.cloudmusic;

import com.westwhale.api.protocolapi.bean.albumSet.CloudRadioSet;

import java.util.List;

/**
 * 音乐电台组
 * Created by cyl on 2018/4/17.
 */

public class CloudRadioGroup {
    public String categoryName;
    public String name;
    public String type;
    public List<CloudRadioSet> radioList;
}
