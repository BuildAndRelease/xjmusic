package com.westwhale.api.protocolapi.bean.albumSet;

/**
 * 3 云音乐分类
 * Created by cyl on 2018/4/18.
 */

public class CloudCategorySet extends AlbumSetMeta {
    public String pic;
    public String tagAlbum;
    public String tagAlbumType;
    public String tagDiss;
    public String tagDissType;
    public String tagTrack;
    public String tagTrackType;
    public String tag_id;
    public String tag_intro;
    public String title;

    public CloudCategorySet() {
        super.albumSetTypeName =  AlbumSetMeta.CLOUD_CATEGORY_SET;
    }

    @Override
    public String getPic() {
        return pic;
    }

    @Override
    public String getName() {
        return "云音乐分类---" + title;
    }

    @Override
    public String getListName() {
        return  AlbumSetMeta.CLOUD_CATEGORY_SET_LIST;
    }
}
