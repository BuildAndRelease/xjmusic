package com.westwhale.api.protocolapi.bean.media;

/**
 * 媒体类
 * Created by cyl on 2018/4/8.
 */

public abstract class Media{
    public static final String LOCAL_MUSIC = "localMusic";
    public static final String CLOUD_MUSIC = "cloudMusic";
    public static final String CLOUD_STORY_TELLING = "cloudStoryTelling";
    public static final String CLOUD_NEWS = "cloudNews";
    public static final String CLOUD_NETFM = "cloudNetFm";//新增
    public static final String LOCAL_FM = "localFm";//协议上是这个
    public static final String FM1 = "fm1";
    public static final String FM2 = "fm2";
    public static final String LOCAL_AUX = "localAux";//协议上是这个
    public static final String AUX1 = "aux1";
    public static final String AUX2 = "aux2";
    public static final String CLIENT_AUX1 = "clientAux1";
    public static final String CLIENT_AUX2 = "clientAux2";
    public String mediaSrc;

}
