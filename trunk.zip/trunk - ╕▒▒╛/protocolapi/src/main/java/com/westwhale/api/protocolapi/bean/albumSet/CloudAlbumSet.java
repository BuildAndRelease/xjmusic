package com.westwhale.api.protocolapi.bean.albumSet;

import com.westwhale.api.protocolapi.bean.cloudmusic.SearchAlbum;
import com.westwhale.api.protocolapi.util.BaUtil;

/**
 * 云音乐专辑类的类定义
 * Created by cyl on 2018/4/18.
 */

public class CloudAlbumSet extends AlbumSetMeta {
    public String albumMID;
    public String area;
    public String genre;
    public String id;
    public String index;
    public String language;
    public String name;
    public String pic_url;
    public String pub_time;
    public String singer_id;
    public String singer_mid;
    public String singer_name;
    public String singer_type;
    public String song_num;

    public CloudAlbumSet() {
        super.albumSetTypeName = AlbumSetMeta.CLOUD_ALBUM_SET;
    }

    /**
     * searchAlbum的字段有很大出入，理论上两者要一样
     *
     * @param searchAlbum
     */
    public CloudAlbumSet(SearchAlbum searchAlbum) {
        this.id = String.valueOf(searchAlbum.albumId);
        this.albumMID = searchAlbum.albumMid;
        this.name = searchAlbum.albumName;
        this.pub_time = searchAlbum.publicTime;
        this.singer_id = String.valueOf(searchAlbum.singerId);
        this.singer_mid = searchAlbum.singerMid;
        this.singer_name = searchAlbum.singerName;
        this.pic_url = searchAlbum.pic_url;
        super.albumSetTypeName = AlbumSetMeta.CLOUD_ALBUM_SET;
    }

    @Override
    public String getPic() {
        return BaUtil.getPicUrlWithAlbumMID(albumMID);
    }

    @Override
    public String getName() {
        return "云音乐专辑---" + name;
    }

    @Override
    public String getListName() {
        return AlbumSetMeta.CLOUD_ALBUM_SET_LIST;
    }

    //兼容
    public void setAlbumId(String s) {
        this.id = s;
    }

    //兼容
    public void setAlbumName(String s) {
        this.name = s;
    }

    //兼容
    public void setPubTime(String s) {
        this.pub_time = s;
    }

    //兼容
    public void setSingerId(String s) {
        this.singer_id = s;
    }

    //兼容
    public void setSingerMid(String s) {
        this.singer_mid = s;
    }

    //兼容
    public void setSingerName(String s) {
        this.singer_name = s;
    }
}
