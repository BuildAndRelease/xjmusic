package com.westwhale.api.protocolapi.bean.hostroom;


import android.text.TextUtils;

import com.westwhale.api.protocolapi.BAKey;
import com.westwhale.api.protocolapi.util.SLog;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/**
 * 主机实体类
 * last updated by cyl
 * 2018/03/26
 */
public class Host {
    public String id;
    public String name;
    public String ipAddress;
    public String deviceVersion;
    public String deviceType;
    public String deviceBarcode;
    public List<Room> rooms = new ArrayList<>();

    public Host() {
    }

    public boolean enable() {
        if (TextUtils.isEmpty(id)
                || TextUtils.isEmpty(name)
                || TextUtils.isEmpty(ipAddress)
                || TextUtils.isEmpty(deviceVersion)
                || TextUtils.isEmpty(deviceType)
                ){
            SLog.e(Host.class.getSimpleName(), "host unavailable");
            return false;
        }
        return true;
    }

    public Host(String hostId) {
        this.id = hostId;
    }

    public void modifyRoomNameWithRoomId(String roomId, String roomName) {
        for (Room room : rooms) if (room.roomId.endsWith(roomId)) room.roomName = roomName;
    }

    public void modifyRoomStateWithRoomId(String roomId, String state) {
        for (Room room : rooms) {
            if (room.roomId.equals(roomId)) room.devStat = state;
        }
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Host host = (Host) o;
        return id.equals(host.id);
    }

    public static Host parse(String arg, String ip) {
        Host host = new Host();
        try {
            JSONObject orgJson = new JSONObject(arg);
            host.id = orgJson.getString(BAKey.DEVICE_ID);
            host.ipAddress = ip;
            host.name = orgJson.optString(BAKey.DEV_NAME);
            if (TextUtils.isEmpty(host.name)) host.name = orgJson.getString(BAKey.DEVICE_NAME);
            host.deviceVersion = orgJson.optString(BAKey.DEV_VERSION);
            if (TextUtils.isEmpty(host.deviceVersion)) host.deviceVersion = orgJson.getString(BAKey.DEVICE_VERSION);
            host.deviceType = orgJson.optString(BAKey.DEV_TYPE);
            if (TextUtils.isEmpty(host.deviceType)) host.deviceType = orgJson.getString(BAKey.DEVICE_TYPE);

            host.deviceBarcode = orgJson.optString(BAKey.DEVICE_BARCODE);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return host;
    }
}