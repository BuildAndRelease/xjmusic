package com.westwhale.api.protocolapi.bean;

import com.alibaba.fastjson.annotation.JSONField;

/**
 * 音效均衡器
 * Created by cyl on 2018/6/4.
 */

public class MusicVolumeEq {
    @JSONField(name = "125BandValue")
    public int _$125BandValue;
    @JSONField(name = "16kBandValue")
    public int _$16kBandValue;
    @JSONField(name = "1kBandValue")
    public int _$1kBandValue;
    @JSONField(name = "250BandValue")
    public int _$250BandValue;
    @JSONField(name = "2kBandValue")
    public int _$2kBandValue;
    @JSONField(name = "31BandValue")
    public int _$31BandValue;
    @JSONField(name = "4kBandValue")
    public int _$4kBandValue;
    @JSONField(name = "500BandValue")
    public int _$500BandValue;
    @JSONField(name = "62BandValue")
    public int _$62BandValue;
    @JSONField(name = "8kBandValue")
    public int _$8kBandValue;
}
