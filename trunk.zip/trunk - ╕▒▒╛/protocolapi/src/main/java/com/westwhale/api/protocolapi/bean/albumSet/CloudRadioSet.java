package com.westwhale.api.protocolapi.bean.albumSet;

/**
 * 5 云音乐电台
 * Created by cyl on 2018/4/18.
 */

public class CloudRadioSet extends AlbumSetMeta {
    public String listenNum;
    public String radioId;
    public String radioImg;
    public String radioName;

    @Override
    public String getPic() {
        return radioImg;
    }

    @Override
    public String getName() {
        return "云音乐电台---" + radioName;
    }

    @Override
    public String getListName() {
        return AlbumSetMeta.CLOUD_NET_RADIO_SET_LIST;
    }

    public CloudRadioSet() {
        super.albumSetTypeName = AlbumSetMeta.CLOUD_NET_RADIO_SET;
    }

}
