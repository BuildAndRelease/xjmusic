package com.westwhale.api.protocolapi.bean;

/**
 * RS485控制端
 * Created by cyl on 2018/6/4.
 */

public class Controller {
    public String id;
    public String name;
    public int num;
    public String type;
}
