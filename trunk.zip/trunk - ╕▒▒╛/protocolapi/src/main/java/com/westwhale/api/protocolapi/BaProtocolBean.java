package com.westwhale.api.protocolapi;

import android.text.TextUtils;

import com.westwhale.api.protocolapi.BAKey;

import org.json.JSONException;

/**
 * 西鲸内部协议基类
 * Created by cyl on 2018/4/14.
 */

public class BaProtocolBean {
    public String sendId;
    public String recvId;
    public String cmd;
    public String direction;
    public String arg;

 /*   {
        "sendId":"ba76ec01001122334455",
            "recvId":"ba760001001122334456",
            "cmd":"xxxx",
            "direction":"request",
            "arg":{
    }
    }*/

   public BaProtocolBean(String jsonStr) {
       try {
           org.json.JSONObject object = new org.json.JSONObject(jsonStr);
           this.sendId = object.getString(BAKey.SEND_ID);
           this.recvId = object.getString(BAKey.RECV_ID);
           this.cmd = object.getString(BAKey.CMD);
           this.direction = object.optString(BAKey.DIRECTION);
           if (TextUtils.isEmpty(this.direction)) this.direction = object.getString(BAKey.DIRECT);
           this.arg = object.getString(BAKey.ARG);
       } catch (JSONException e) {
           e.printStackTrace();
       }
   }

 public boolean isUnavailable() {
     return TextUtils.isEmpty(sendId)
             || TextUtils.isEmpty(recvId)
             || TextUtils.isEmpty(cmd)
             || TextUtils.isEmpty(direction);
 }

}
