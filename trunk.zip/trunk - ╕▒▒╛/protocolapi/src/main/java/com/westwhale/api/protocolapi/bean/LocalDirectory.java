package com.westwhale.api.protocolapi.bean;

import com.westwhale.api.protocolapi.bean.media.Media;

import java.util.List;

/**
 * 4.24.1	获取指定目录的信息v
 * Created by cyl on 2018/5/29.
 */

public class LocalDirectory {
    //本目录的Mid
    public String directoryMid;
    //本来的子目录
    public  List<Directory> directoryList;
    //本目录下的媒体
    public List<Media> mediaList;

    public static class Directory {
        public String directoryMid;
        public String directoryName;

    }

}
