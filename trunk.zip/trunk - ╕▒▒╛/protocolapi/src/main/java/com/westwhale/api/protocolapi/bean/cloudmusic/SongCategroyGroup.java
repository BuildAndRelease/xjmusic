package com.westwhale.api.protocolapi.bean.cloudmusic;

import com.alibaba.fastjson.annotation.JSONField;
import com.westwhale.api.protocolapi.bean.albumSet.CloudCategorySet;

import java.util.List;

/**
 *云音乐分类组
 * Created by cyl on 2018/5/3.
 */

public class SongCategroyGroup {
    @JSONField(name = "group_id")
    public String groupId;
    public String title;
    @JSONField(name = "items")
    public List<CloudCategorySet> albums;
}
