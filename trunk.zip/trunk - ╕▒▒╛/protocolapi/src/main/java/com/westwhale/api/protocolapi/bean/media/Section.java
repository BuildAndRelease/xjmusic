package com.westwhale.api.protocolapi.bean.media;

import android.os.Parcel;
import android.os.Parcelable;

import com.westwhale.api.protocolapi.bean.media.Media;

/**
 * 语言节目某集
 * 语言节目(cloudStoryTelling)类的类定义,1代表协议上规定的数据
 * s表示要兼容,300s与300是String,其他是int;
 * Created by cyl on 2018/5/14.
 */

public class Section extends Media implements Parcelable {
//             "albumId":6924901,
//             "anchorId":74653899,
//             "anchorName":"王立群",
//             "categoryId":39,
//             "id":55117446,
//             "isUsable":false,
//             "mediaSrc":"cloudStoryTelling",
//             "mid":"",
//             "pic":"http://fdfs.xmcdn.com/group31/M01/8E/EF/wKgJX1l3Q5qQhl4qAAD4yzXQqJo650_mobile_large.jpg",
//             "pubTime":1508490636000,
//             "score":11222,
//             "sectionName":"100.岳飞《满江红·怒发冲冠》：莫等闲、白了少年头，空悲切！"
    public String mid;//1
    public String id;//1//s
    public String sectionName;//1
    public int duration;//1
    public String parentId;//1//s
    public String albumId;//s
    public String anchorId;//s
    public String anchorName;
    public long updatedTime;
    public String pic;
    public boolean isUsable;

    public Section() {
        super.mediaSrc = Media.CLOUD_STORY_TELLING;
    }

    public void setAlbumId(int id) {
        this.albumId = String.valueOf(id);
    }

    public void setAlbumId(String id) {
        this.albumId = id;
    }

    public void setAnchorId(int id) {
        this.anchorId = String.valueOf(id);
    }

    public void setAnchorId(String id) {
        this.anchorId = id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public void setId(int id) {
        this.id = String.valueOf(id);
    }

    public void setParentId(int parentId) {
        this.parentId = String.valueOf(parentId);
    }

    public void setParentId(String parentId) {
        this.parentId = parentId;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(this.mid);
        dest.writeString(this.id);
        dest.writeString(this.sectionName);
        dest.writeInt(this.duration);
        dest.writeString(this.parentId);
        dest.writeString(this.albumId);
        dest.writeString(this.anchorId);
        dest.writeString(this.anchorName);
        dest.writeLong(this.updatedTime);
        dest.writeString(this.pic);
        dest.writeByte(this.isUsable ? (byte) 1 : (byte) 0);
    }

    protected Section(Parcel in) {
        this.mid = in.readString();
        this.id = in.readString();
        this.sectionName = in.readString();
        this.duration = in.readInt();
        this.parentId = in.readString();
        this.albumId = in.readString();
        this.anchorId = in.readString();
        this.anchorName = in.readString();
        this.updatedTime = in.readLong();
        this.pic = in.readString();
        this.isUsable = in.readByte() != 0;
    }

    public static final Parcelable.Creator<Section> CREATOR = new Parcelable.Creator<Section>() {
        @Override
        public Section createFromParcel(Parcel source) {
            return new Section(source);
        }

        @Override
        public Section[] newArray(int size) {
            return new Section[size];
        }
    };
}
