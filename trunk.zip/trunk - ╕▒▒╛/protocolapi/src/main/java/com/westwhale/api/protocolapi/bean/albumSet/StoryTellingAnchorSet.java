package com.westwhale.api.protocolapi.bean.albumSet;

/**
 * 8 语言节目主播类的类定义
 * Created by cyl on 2018/4/18.
 */

public class StoryTellingAnchorSet extends AlbumSetMeta {
    public int followersCounts;
    public boolean isVerified;
    public String nickname;
    public String personDescribe;
    public String pic;
    public int tracksCounts;
    public int uid;
    public String verifyTitle;

    public StoryTellingAnchorSet() {
        super.albumSetTypeName = AlbumSetMeta.STORY_TELLING_ANCHOR_SET;
    }

    @Override
    public String getPic() {
        return pic;
    }

    @Override
    public String getName() {
        return "语言节目主播---" + nickname;
    }

    @Override
    public String getListName() {
        return AlbumSetMeta.STORY_TELLING_ANCHOR_SET_LIST;
    }
}
