package com.westwhale.api.protocolapi.bean.hostroom;

import android.support.annotation.Nullable;
import android.text.TextUtils;

import com.alibaba.fastjson.JSON;
import com.westwhale.api.protocolapi.bean.media.CloudMusic;
import com.westwhale.api.protocolapi.bean.media.LocalAux;
import com.westwhale.api.protocolapi.bean.media.LocalFm;
import com.westwhale.api.protocolapi.bean.media.LocalMusic;
import com.westwhale.api.protocolapi.bean.media.Media;
import com.westwhale.api.protocolapi.bean.media.CloudNetFm;
import com.westwhale.api.protocolapi.bean.media.News;
import com.westwhale.api.protocolapi.bean.media.Section;

import org.json.JSONException;
import org.json.JSONObject;

/**
 * 播放信息
 * Created by cyl on 18/04/23.
 */
public class PlayingInfo {
    public String roomState;
    public String talkId;
    public String partyId;
    public Media media;

    public PlayingInfo (){

    }
    public PlayingInfo(String argString) {
        try {
            JSONObject argJson = new JSONObject(argString);
            this.roomState = argJson.getString("roomStat");
            switch (roomState) {
                case Room.ChannelState.INCLOSED:
                    break;
                case Room.ChannelState.INPARTY:
                    this.partyId = argJson.getString("partyId");
                    this.media = parseMedia(argJson);
                    break;
                case Room.ChannelState.INNORMAL:
                    this.media = parseMedia(argJson);
                    break;
                case Room.ChannelState.INAIRPLAY:
                    break;
                case Room.ChannelState.INDLNA:
                    break;
                case Room.ChannelState.INTALK:
                    this.talkId = argJson.getString("talkId");
                    break;
                default:
                    break;
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    public boolean isAvailble() {
        return !TextUtils.isEmpty(roomState);
    }

    @Nullable
    private Media parseMedia(JSONObject argjson) throws JSONException {
        JSONObject mediaJson = argjson.getJSONObject("media");
        return parseMediaB(mediaJson);
    }

    public static Media parseMediaB(JSONObject mediaJson) throws JSONException {
        if (mediaJson == null) return null;
        String mediaStr = mediaJson.toString();
        String type = mediaJson.getString("mediaSrc");
        switch (type) {
            case Media.CLOUD_MUSIC:
                return JSON.parseObject(mediaStr, CloudMusic.class);
            case Media.LOCAL_MUSIC:
                return JSON.parseObject(mediaStr, LocalMusic.class);
            case Media.CLOUD_NEWS:
                return JSON.parseObject(mediaStr, News.class);
            case Media.CLOUD_STORY_TELLING:
                return JSON.parseObject(mediaStr, Section.class);
            case Media.CLOUD_NETFM:
                return JSON.parseObject(mediaStr, CloudNetFm.class);
            case Media.LOCAL_AUX:
                return JSON.parseObject(mediaStr, LocalAux.class);
            case Media.LOCAL_FM:
                return JSON.parseObject(mediaStr, LocalFm.class);
        }
        return null;
    }

    public String getMediaId() {
        if (media == null) return null;
        switch (media.mediaSrc) {
            case Media.CLOUD_MUSIC:
                return ((CloudMusic)media).songId;
            case Media.LOCAL_MUSIC:
                return ((LocalMusic)media).songId;
            case Media.CLOUD_NEWS:
                return ((News)media).id;
            case Media.CLOUD_STORY_TELLING:
                return ((Section)media).id;
            case Media.CLOUD_NETFM:
                return String.valueOf(((CloudNetFm)media).id);
            case Media.LOCAL_AUX:
                return ((LocalAux)media).auxId + "";
            case Media.LOCAL_FM:
                return ((LocalFm)media).fmId;
        }
        return null;
    }
}
