package com.westwhale.api.protocolapi.bean.scene;

import com.alibaba.fastjson.annotation.JSONField;

import java.util.List;

/**
 * 场景
 * Created by cyl on 2018/4/24.
 */

public class Scene {
    //新增不需要填
    public int sceneId;
    //场景名
    public String sceneName;
    //场景动作列表
    @JSONField(name = "list")
    public List<RoomSceneAction> actionList;
}
