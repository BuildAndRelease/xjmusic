package com.westwhale.api.protocolapi.bean.media;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * 5 本地AUX(localAux)类的类定义：
 * AUX接口（Auxiliary）是指音频输入接口，可以从包括mp3在内的电子声频设备输出音频（一般的耳机插孔），用车上的音响听这些设备的音乐。
 * Created by cyl on 2018/4/8.
 */

public class LocalAux extends Media implements Parcelable {
    public String auxMid;
    public int auxId;

    public LocalAux(){
        super.mediaSrc = Media.LOCAL_AUX;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(this.auxMid);
        dest.writeInt(this.auxId);
    }

    protected LocalAux(Parcel in) {
        this.auxMid = in.readString();
        this.auxId = in.readInt();
    }

    public static final Parcelable.Creator<LocalAux> CREATOR = new Parcelable.Creator<LocalAux>() {
        @Override
        public LocalAux createFromParcel(Parcel source) {
            return new LocalAux(source);
        }

        @Override
        public LocalAux[] newArray(int size) {
            return new LocalAux[size];
        }
    };
}
