package com.westwhale.api.protocolapi.bean.albumSet;

/**
 * 4 云音乐歌单
 * 歌曲榜单下的歌单与歌曲分类的歌单有差异，这里兼容了下
 *
 * Created by cyl on 2018/4/18.
 */

public class CloudDissSet extends AlbumSetMeta {
    public String createTime;
    public String createrName;
    public String dissId;
    public String dissName;
    public String imgUrl;
    public double score;
    /**歌曲榜单下的歌单独有属性*/
    public String introduction;
    public int listenNum;
    /**歌曲分类的歌单独有属性*/
    public int songnum;
    public int visitnum;

    public CloudDissSet() {
        super.albumSetTypeName = AlbumSetMeta.CLOUD_DISS_SET;
    }

    @Override
    public String getPic() {
        return imgUrl;
    }

    @Override
    public String getName() {
        return "云音乐歌单---" + dissName;
    }

    @Override
    public String getListName() {
        return AlbumSetMeta.CLOUD_DISS_SET_LIST;
    }

    //兼容
    public void setCtime(String s) {
        this.createTime = s;
    }

    //兼容
    public void setCreatorName(String s) {
        this.createrName = s;
    }

    //兼容
    public void setDissPic(String s) {
        this.imgUrl = s;
    }

    //兼容
    public void setScoreavage(double s) {
        this.score = s;
    }

    //兼容
    public void setDisstid(String s) {
        this.dissId = s;
    }



}
