package com.westwhale.api.protocolapi.bean.cloudmusic;

import com.alibaba.fastjson.annotation.JSONField;
import com.westwhale.api.protocolapi.bean.albumSet.CloudAlbumSet;

import java.util.List;

/**
 * 7.2 	GetRecommend 热推专辑、歌单、音乐人
 * Created by cyl on 2018/6/7.
 */

public class CloudMusicRecommed {
    public AlbumRecommed album;
    public static class  AlbumRecommed {
        public List<CloudAlbumSet> cn;
        public List<CloudAlbumSet> eu;
        public List<CloudAlbumSet> gt;
        public List<CloudAlbumSet> j;
        public List<CloudAlbumSet> k;
        public List<CloudAlbumSet> nd;
        @JSONField(name = "new")
        public List<CloudAlbumSet> news;
    }
    public List<DissReCommed> diss;
    public static class DissReCommed {
        public String name;
        public String recommendList;
    }
    public List<SingerRecommed> yinyueren;
    public static class  SingerRecommed {
        public String desc;
        public String genres;
        public String picurl;
        public String singerid;
        public String singermid;
        public String singername;
    }

}
