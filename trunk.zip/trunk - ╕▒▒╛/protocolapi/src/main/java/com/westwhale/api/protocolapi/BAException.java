package com.westwhale.api.protocolapi;

/**
 * BAException,自己抛出的异常
 * Created by cyl on 2018/4/28.
 */

public class BAException extends Exception {
    public BAException(String message){
        super(message);
    }
}
