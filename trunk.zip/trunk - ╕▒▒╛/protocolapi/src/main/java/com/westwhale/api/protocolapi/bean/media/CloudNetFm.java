package com.westwhale.api.protocolapi.bean.media;

import android.os.Parcel;
import android.os.Parcelable;

import com.alibaba.fastjson.JSONObject;
import com.westwhale.api.protocolapi.bean.media.Media;

/**
 * Created by cyl on 2018/6/8.
 */

public class CloudNetFm extends Media implements Parcelable {
//    "fmUid":19414524,
//    "id":1065,
//    "name":"中国之声",
//    "picUrl":"http://fdfs.xmcdn.com/group28/M0A/30/28/wKgJSFkxRX-ALd8CAABn8GON2wI634_mobile_large.jpg",
//    "playCount":77316778,
//    "playUrl1":"http://live.xmcdn.com/live/1065/64.m3u8?transcode=ts",
//    "playUrl2":"http://live.xmcdn.com/live/1065/64.m3u8",
//    "programId":45783,
//    "programName":"央广新闻晚高峰",
//    "programScheduleId":5263
    public int fmUid;
    public int id;
    public String name;
    public String picUrl;
    public long playCount;
    public String playUrl1;
    public String playUrl2;
    public int programId;
    public String programName;
    public int programScheduleId;
    public String mediaSrc;

    public CloudNetFm() {
        super.mediaSrc = Media.CLOUD_NETFM;
    }

    @Override
    public String toString() {
        JSONObject musicJson = new JSONObject();
        musicJson.put("mediaSrc",mediaSrc);
        musicJson.put("fmUid",fmUid);
        musicJson.put("id",id);
        musicJson.put("name",name);
        musicJson.put("picUrl",picUrl);
        musicJson.put("playCount",playCount);
        musicJson.put("playUrl1",playUrl1);
        musicJson.put("playUrl2",playUrl2);
        musicJson.put("programId",programId);
        musicJson.put("programName",programName);
        musicJson.put("programScheduleId",programScheduleId);

        return musicJson.toString();
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(this.fmUid);
        dest.writeInt(this.id);
        dest.writeString(this.name);
        dest.writeString(this.picUrl);
        dest.writeLong(this.playCount);
        dest.writeString(this.playUrl1);
        dest.writeString(this.playUrl2);
        dest.writeInt(this.programId);
        dest.writeString(this.programName);
        dest.writeInt(this.programScheduleId);
        dest.writeString(this.mediaSrc);
    }

    protected CloudNetFm(Parcel in) {
        this.fmUid = in.readInt();
        this.id = in.readInt();
        this.name = in.readString();
        this.picUrl = in.readString();
        this.playCount = in.readLong();
        this.playUrl1 = in.readString();
        this.playUrl2 = in.readString();
        this.programId = in.readInt();
        this.programName = in.readString();
        this.programScheduleId = in.readInt();
        this.mediaSrc = in.readString();
    }

    public static final Parcelable.Creator<CloudNetFm> CREATOR = new Parcelable.Creator<CloudNetFm>() {
        @Override
        public CloudNetFm createFromParcel(Parcel source) {
            return new CloudNetFm(source);
        }

        @Override
        public CloudNetFm[] newArray(int size) {
            return new CloudNetFm[size];
        }
    };
}
