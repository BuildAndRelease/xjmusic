package com.westwhale.api.protocolapi.bean.cloudmusic;

import com.westwhale.api.protocolapi.util.BaUtil;

import java.util.List;

/**
 * 搜索preview的数据结构
 * Created by cyl on 2018/5/11.
 */

public class SearchPreview {
    public PreView album;
    public PreView singer;
    public PreView song;

    public static class PreView {
        public int count;
        public String name;
        public int order;
        public int type;
        public List<Item> itemList;

        public static class Item {
            public String id;
            public String docid;
            public String name;
            public String mid;
            public String pic;
            public String singer;

            public void setAlbummid(String s) {
                this.pic = BaUtil.getPicUrlWithAlbumMID(s);
            }
        }
    }

}
