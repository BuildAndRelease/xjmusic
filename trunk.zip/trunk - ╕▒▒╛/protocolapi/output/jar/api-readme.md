
          xjprotocolapi：西鲸电子的JSON版协议调试SDK
    ==================================================

关于:
    封装了西鲸协议(JSON版)，简化了对接流程，降低了二次开发难度


基本信息:

    1	网络拓扑图
            控制端————————————路由器————————————设备
    
    2	基本名称解释
        1）	主机：主设备。所有的控制端与主机通信，由主机协调各通道工作。主机包含多个房间。
        2）	房间：独立播放控制分区。可以单独播放、暂停、音量调节等操作。
        3）	音源：可播放媒体的来源。如云音乐、本地音乐、网络电台、语言节目、AUX等。
        4）	播放媒体：包含音频数据的、可播放的数据流。
        
    3	协议
        3.1	协议整体框架
                          协议头                            协议内容
                --------------------------------------------------------------
                协议内容的长度(4个字节表示)               协议具体指令的JSON数据
                --------------------------------------------------------------
                
                
                协议内容采用json标准. 整体框架如下：
                /*****************************************************************/
                {
                    “sendId”: “BA50EC01001122334455”,
                    “recvId”: “BA50001001122334456”,
                    “cmd”:”xxxx”,
                    “direction”:”request”, // request or response
                    “arg”:{
                        /* 此处填充具体的cmd对应的参数 */
                }
                }
                /****************************************************************/
                1)	搜索主机时，采用UDP广播，(搜索主机时，recvId用f填充)
                          发送端口  18090（这里发送端口可用其他未被占用端口号），接收端口  18090
                2)	其他的协议，采用TCP 进行通讯，通讯端口: 20090
                3)	采用TCP数据通讯，都是控制端发送TCP短连接，TCP的断开由控制端主动断开
                4)	在发送数据前，须在数据前添加四个字节的数据长度，不足四个字节，用0填充，如协议数据长度为25个字节，则在发送前，添加四个字节” 19 00 00 00”  
                5)	编码集采用的是UTF-8
                6)	新增TCP长连接端口，端口号22090
    
          3.2	协议结构数据解析
            3.2.1	sendId、recvId
                sendId与recvId为一个 20字符的字符串，字符串中每一个字符取值范围为0-9/A-F。
            3.2.2	diretcion
                建议兼容 “direction”、“direct”两个字段
            3.2.3	cmd、arg
                具体参考“命令定义”
                
        3.3	命令归类
            1.	所有的通知 均为 UDP
            2.	除搜寻主机命令 为 UDP，其他的主动获取或设置命令均采用TCP传输


  
代码Demo:

    public class DevManager {
        private Map<String,Host> mHostMap = new HashMap<>();  // 主机列表
        private Host mSelectedHost;  // 当前所选主机设备
        private Room mSelectedRoom;  // 当前所选房间
        private String mDeviceUUID;  // API中所需的设备ID
        private Context mContext;   // 建议配置 application
    
        public DevManager(@NonNull Context context){
            mContext = context;
    
            initWestWhaleSdk();
        }
    
        private void initWestWhaleSdk(){
    
            // 配置ID，建议保存此ID，保证手机APP的UUID固定
            mDeviceUUID = BaUtil.createDeviceId();
            BaApi.getInstance().initSendId(mDeviceUUID);
    
            // 启动SOCKET 服务
            mContext.startService(new Intent(mContext, SocketService.class));
    
            // 启用SDK调试信息，默认打开的， 2019.08.31
            SocketService.configureDebugMode(true);
            
            // 定义一个 SocketService UDP广播 回调函数
            // new Consumer<Pair<data, ip>> 
            SocketService.setConsumer(new Consumer<Pair<String, String>>() {
                @Override
                public void accept(Pair<String, String> stringStringPair) {
                    String ip = stringStringPair.second;
                    String jsonInfo = stringStringPair.first;
    
                    // 过滤自身IP数据
                    String selfIp = NetworkUtils.getIPAddress(true);
                    if (ip.equals(selfIp)){
                        return;
                    }
    
                    handleApiCallback(ip, jsonInfo);
                }
            });
        }
    
        private void handleApiCallback(String ip, String jsonInfo){
            try {
                BaProtocolBean head = new BaProtocolBean(jsonInfo);
                switch (head.cmd){
                    case CMD.SEARCH_HOST:
                        Host host = Host.parse(head.arg, ip);
                        mHostMap.put(host.id, host);
                        break;
                    case CMD.NOTIFY_PLAYING_INFO:
                        String argStr = head.arg;
                        JSONObject obj = new JSONObject(argStr);
                        //todo 通知类自己解析,参看文档
                        break;
    
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    
        public void clearHostMap(){
            mHostMap.clear();
            mSelectedHost = null;
        }
    
        public void setSelectedHost(Host host,Room room){
            if (mHostMap.containsValue(host)){
                mSelectedHost = host;
                mSelectedRoom = room;
                
                // 开启TCP广播长连接，2019.08.30
                // new Consumer<Pair<data, ip>> 
                SocketService.startBroadcastTcpListener(mSelectedHost.ipAddress, mSelectedHost.id, new Consumer<Pair<String, String>>() {
                    @Override
                    public void accept(Pair<String, String> stringStringPair) {
                        String info = stringStringPair.first;
                        String ip = stringStringPair.second;
                        if ((null == ip) || (null == info)){
                            return;
                        }
                        handleApiCallback(ip,info);
                    }
                });
            }
        }
    
        public Host getSelectedHost(){
            return mSelectedHost;
        }
    
        public Room getSelectedRoom(){
            return mSelectedRoom;
        }
    
        public List<Host> getHostList(){
            return  new ArrayList<>(mHostMap.values());
        }
    
        public Host getHostByRoomId(String hostId) {
            return mHostMap.get(hostId);
        }
    }