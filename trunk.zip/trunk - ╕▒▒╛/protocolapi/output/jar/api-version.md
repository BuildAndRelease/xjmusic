

xjprotocolapi-1.0.2.0831  说明:
1. 提供了协议调试信息开关，默认打开
        SocketService.configureDebugMode(boolean debug)
2. 提供了广播TCP长连接方式
        SocketService.startBroadcastTcpListener(final String hostIp, final String recvId, final Consumer<Pair<String,String>> consumer)
3. 修改了 云音乐 图片URL 字段 picURL => picUrl



xjprotocolapi-1.0.0.0719  说明:
1. 整理了协议SDK API  